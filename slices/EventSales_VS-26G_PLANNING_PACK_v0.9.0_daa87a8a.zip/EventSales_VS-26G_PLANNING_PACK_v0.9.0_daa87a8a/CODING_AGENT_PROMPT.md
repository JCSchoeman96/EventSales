# Planning Agent Prompt — VS-26G

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-26G_PLANNING_PACK_v0.9.0_daa87a8a.zip`
Planning baseline: `daa87a8a1693e399c8effeb23297efad159397fd`

## Authorised phase

Repository reconnaissance, redacted source-evidence planning and implementation planning only.

Do not:

- modify files;
- commit or open a PR;
- run migrations;
- query production WooCommerce;
- extract PII;
- classify production products;
- reclassify historical rows;
- change metrics;
- deploy or merge.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified VS-26F.1 and VS-26F.2 artifacts. If they do not yet exist, mark all dependent interfaces for `JC-173` refresh.

## Required plan decisions

1. exact semantic kinds and versioning;
2. ProductMapping separation;
3. product-versus-variation precedence;
4. order-line semantic snapshot;
5. entitlement quantity versus monetary contribution;
6. unknown/fail-closed policy;
7. exact Woo fields/fixtures needed;
8. parser extensions;
9. net/tax/gross field contract;
10. fee resource and attribution;
11. refund resource, sign convention and quantity treatment;
12. complete versus partial payload child reconciliation;
13. source-version/idempotency interactions;
14. OrderUpserter extension without parallel writer;
15. historical compatibility strategy;
16. dry-run impact preview and exact-hash apply;
17. admin review workflow and audit;
18. aggregate/read-model compatibility;
19. migrations/indexes/query plans;
20. tests-first sequence;
21. staged PR/slice recommendation;
22. rollout/kill switches;
23. production evidence;
24. `JC-173` activation/evidence inputs.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`; or
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
