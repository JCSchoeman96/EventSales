# Current Code Semantics Map

| Area | Current truth | Gap |
|---|---|---|
| ProductMapping | requires Event + TicketType | cannot represent membership/renewal/add-on/ignored |
| OrderItem item kind | ticket / non_ticket / unknown | insufficient semantic detail |
| OrderItem mapping state | pending, mapped, unmapped, non_ticket, ignored | no review/version evidence |
| Mapping actions | successful mapping forces ticket | accidental mapping may override unknown intent |
| Product mapping UI | ticket-only Event/TicketType form | no semantic classification workflow |
| Mapping queue | read-only unresolved rows | no audited semantics review |
| Parser | line items, coupons, order totals/tax | no line tax, fee, tax-line, refund or renewal ancestry |
| OrderUpserter | upserts incoming children | missing children are not reconciled |
| Order status | includes refunded | no partial-refund resource |
| MetricRules | completed + mapped ticket; revenue=line_total | no tax-inclusive/fee/refund/ancillary contract |
| WordPress feed | product type/subscription metadata | cannot distinguish membership/payment plan/renewal |
| Historical rows | coarse item kind | no policy version or semantic snapshot |
