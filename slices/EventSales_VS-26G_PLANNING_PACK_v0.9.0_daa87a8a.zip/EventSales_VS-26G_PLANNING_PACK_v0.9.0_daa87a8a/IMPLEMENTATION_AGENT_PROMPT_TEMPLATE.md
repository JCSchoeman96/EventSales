# Implementation Agent Prompt Template — VS-26G

**Do not use until JC-173 returns APPROVE.**

Activation must fill:

- exact current main SHA;
- certified F.1/F.2 interfaces;
- approved redacted fixture/evidence matrix;
- final semantic kinds and policy version;
- final product/variation precedence;
- final monetary/tax/fee/refund contract;
- exact historical compatibility and preview/apply boundary;
- exact resources/actions/migrations/indexes;
- exact tests/files/rollout/stop conditions.

Write tests first. Implement only activated scope. Open a PR and stop before merge, deployment or historical apply.
