# VS-26G Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified VS-26F.1/F.2 interfaces
## 4. Redacted source evidence and missing classes
## 5. Current schema/metric compatibility
## 6. Semantic kinds and policy version
## 7. Product semantic resource/versioning
## 8. Product-versus-variation precedence
## 9. Order-line semantic snapshot
## 10. Ticket entitlement contract
## 11. Event ticket/ancillary revenue contract
## 12. Parser source fields
## 13. Net/tax/gross monetary model
## 14. Fee resource and attribution
## 15. Refund resources and sign convention
## 16. Complete versus partial child reconciliation
## 17. OrderUpserter integration
## 18. Source-version/replay/idempotency
## 19. Historical compatibility strategy
## 20. Impact preview and exact-hash apply
## 21. Admin review/audit workflow
## 22. Read-model/aggregate compatibility
## 23. Migrations/index/query plans
## 24. Tests-first sequence
## 25. Scope split/staged PR recommendation
## 26. Exact files create/modify/generated/forbidden
## 27. Verification commands
## 28. Rollout/kill switches
## 29. Production fixture/canary evidence
## 30. JC-173 activation inputs
## 31. Risks/stop conditions
## 32. Prohibited-actions statement
