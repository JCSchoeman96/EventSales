# Historical Reclassification Contract

## Default

Schema deployment does not change historical totals.

Existing rows either:

- retain their current explicit ticket state; or
- receive an unknown/pending semantic snapshot that is excluded from new broader calculations.

The implementation plan must choose a compatibility strategy with tests.

## Preview

A historical semantic change requires a durable bounded preview containing:

- source/product/variation scope;
- old and proposed semantic;
- policy versions;
- affected order/item/event counts;
- ticket-quantity delta;
- revenue/tax/fee/refund deltas;
- unresolved conflicts;
- exact snapshot/hash;
- query bounds and truncation state.

## Apply

Apply requires:

- exact preview hash;
- global-admin authorisation;
- actor and reason;
- transaction/batched restart-safe work;
- idempotency;
- audit history;
- affected-event refresh after commit;
- no scope expansion beyond preview.

## Future-only option

An administrator may classify future ingestion only.

This must be visibly distinct from historical apply.

## Rollback

Semantic history is append-only/audited. A correction creates a new reviewed classification or compensating reclassification; it does not erase evidence.

## Stop conditions

- impact preview truncated;
- source/policy version changed;
- metric delta exceeds reviewed bounds;
- unknown relationships;
- active catch-up payload version skew;
- inability to rebuild affected read models.
