# Refund and Child Reconciliation Contract

## Full refund

Current completed-only rules already exclude an order whose source status is `refunded`.

It remains visible as operational context.

## Partial refund

Introduce durable refund evidence before changing metrics.

Candidate refund identity:

```text
source_system_id + woo_refund_id
```

Candidate fields:

- order_id;
- woo_refund_id;
- source-created/modified time if available;
- gross/net/tax refund amounts;
- reason category, bounded;
- line allocations;
- refunded quantities;
- source fingerprint;
- active/presence state.

## Conservative treatment

- Monetary refund alone does not revoke a ticket.
- Unallocated refund changes no ticket quantity automatically.
- Line monetary allocation may affect revenue only under reviewed policy.
- Ticket quantity changes require explicit refunded quantity or ticket-authority evidence.
- Repeated refund payloads are idempotent.
- Negative amounts are normalized under one documented sign convention.

## Child presence reconciliation

Current OrderUpserter updates or inserts incoming lines/coupons but does not resolve rows absent from a later payload.

The plan must define per-child behaviour:

- line item missing;
- coupon missing;
- fee missing;
- refund missing/changed;
- source plugin omits historical children;
- partial payload versus authoritative full order payload.

Never delete or deactivate a child merely because an event/webhook payload is known to be partial.

## Source payload authority

Each ingestion path must state whether it received:

- complete authoritative order representation;
- compact/partial webhook;
- REST full order;
- separate refund response.

Presence reconciliation is allowed only for an authoritative complete representation.
