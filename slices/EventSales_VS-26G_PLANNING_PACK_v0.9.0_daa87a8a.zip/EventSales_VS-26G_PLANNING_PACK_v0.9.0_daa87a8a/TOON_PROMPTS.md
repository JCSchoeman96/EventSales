# TOON Prompts — VS-26G

## Planning agent
Task: Design evidence-first product/order-line semantic authority.
Objective: Prevent renewals, memberships and unknown products inflating ticket totals.
Output: Complete implementation plan.
Boundary: No code, production reads or reclassification.

## Source-evidence reviewer
Task: Attack whether fixtures prove payment-plan, renewal, bundle, tax, fee and refund meaning.
Output: Missing-evidence matrix.
Boundary: No PII.

## Semantic-policy reviewer
Task: Attack entitlement/revenue precedence and impossible states.
Output: Policy findings and truth-table verdict.
Boundary: Unknown fails closed.

## Monetary/refund reviewer
Task: Attack net/tax/gross, fee allocation, partial refunds and child presence.
Output: Findings and tests.
Boundary: Amount alone never revokes a ticket.

## Historical-safety reviewer
Task: Attack preview/apply, version drift, bounds and rollback.
Output: APPROVE / REQUEST CHANGES / BLOCKED.
Boundary: No silent rewrite.

## Activation reviewer
Task: Refresh main, F.1/F.2 contracts and redacted fixtures.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
