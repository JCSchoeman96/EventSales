# Semantic Data Model Contract

## Product semantic classification

Prefer a separate resource from ProductMapping.

Candidate fields:

- source_system_id;
- woo_product_id;
- woo_variation_id;
- semantic_kind;
- review_status;
- evidence_version/hash;
- policy_version;
- classification_source;
- optional event/ticket references where justified;
- effective_from/effective_to or version history;
- active;
- actor/reason/audit timestamps.

Use product-level fallback with variation-level override only under explicit precedence.

## Order-line semantic snapshot

Persist at processing time:

- semantic_kind;
- semantic_status;
- semantic_policy_version;
- classification_source;
- product_semantic_id/version;
- ticket_entitlement_quantity;
- revenue_category;
- bounded semantic reason.

Later product changes do not silently rewrite existing lines.

## Precedence

Recommended:

1. explicit reviewed variation semantic;
2. explicit reviewed product semantic;
3. explicit non-ticket/renewal classification;
4. certified ticket ProductMapping plus compatible source evidence;
5. source Tickera identity;
6. conservative catalogue signals;
7. unknown/review.

The plan must prove conflict handling and audit.

## Impossible-state prevention

Prefer one semantic kind plus a pure policy result over independent mutable booleans that allow contradictory combinations.
