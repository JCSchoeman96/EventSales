# Semantic Classification Runbook

## New/future line

1. Parse authoritative source fields.
2. Resolve reviewed variation semantic.
3. Resolve reviewed product semantic.
4. Check explicit non-ticket/renewal conflict.
5. Resolve compatible ticket ProductMapping/Tickera identity.
6. Apply versioned pure policy.
7. Persist semantic snapshot before the line can count.
8. Emit review item when unknown/conflicting.
9. Recompute affected event only after durable commit.

## Admin classification

1. Load safe product/line evidence.
2. Choose reviewed semantic and reason.
3. Save future-effective classification with audit.
4. Optionally request historical preview.
5. Never auto-apply preview.

## Conflict

Keep line excluded and visible. Do not choose the more permissive interpretation.
