# Rollout and Stop Conditions

## Rollout

1. Deploy schema/policy code with conservative defaults.
2. Verify migrations and existing ticket totals unchanged.
3. Load approved redacted fixtures in tests/staging.
4. Enable future-order semantic snapshots for one source.
5. Verify ordinary ticket remains unchanged.
6. Verify membership/renewal/payment-plan/add-on unknown classes remain excluded.
7. Enable admin future-only classification.
8. Run historical preview only; do not apply.
9. Review production impact.
10. Authorise historical apply separately, if needed.
11. Unlock VS-27B.1 only after certification.

## Kill switches

- semantic classifier mode disabled/observe;
- future classification disabled;
- historical apply disabled;
- fee/refund contribution disabled;
- affected-event refresh queue pause.

## Stop immediately

- historical totals change on schema deploy;
- unknown or renewal counts tickets;
- line total is relabelled gross without proof;
- partial refund revokes ticket from amount alone;
- mixed-event fee is guessed;
- ProductMapping accepts fake non-ticket event links;
- child rows disappear from partial payload;
- PII/secrets enter evidence;
- F.1/F.2 recovery authority is bypassed.
