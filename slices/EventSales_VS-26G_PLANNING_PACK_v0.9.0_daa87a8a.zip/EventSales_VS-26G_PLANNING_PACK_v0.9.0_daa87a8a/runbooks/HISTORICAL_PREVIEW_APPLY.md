# Historical Preview and Apply Runbook

## Preview

1. Select bounded source/product/variation/date scope.
2. Freeze current policy and classification versions.
3. Read affected rows in bounded batches.
4. Compute before/after semantic and metric deltas.
5. Record conflicts and truncation.
6. Persist exact preview snapshot/hash.
7. Present PII-free counts and deltas.

## Apply

1. Require global admin, reason and exact preview hash.
2. Reject if main/schema/policy/source versions drifted.
3. Process exact ids in restart-safe batches.
4. Record before/after semantic versions.
5. Recompute only affected events/ranges.
6. Record completion/failures.
7. Never widen scope automatically.

## Rollback/correction

Create a new reviewed compensating classification/preview. Do not erase audit history.
