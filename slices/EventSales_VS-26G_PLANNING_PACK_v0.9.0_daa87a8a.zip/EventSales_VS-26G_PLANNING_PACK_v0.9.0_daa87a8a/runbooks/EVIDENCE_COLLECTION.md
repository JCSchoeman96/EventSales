# Redacted Evidence Collection Runbook

1. Identify installed Woo/Tickera/subscription extensions and versions.
2. Select one representative source record per semantic class.
3. Export only structural JSON fields required by SOURCE_EVIDENCE_MATRIX.
4. Remove/replace all customer, payment and credential values.
5. Preserve ids only as deterministic pseudonyms to retain relationships.
6. Record full versus partial payload origin.
7. Record status/timestamp sequence separately.
8. Hash each redacted fixture.
9. Reviewer verifies no PII and sufficient semantics.
10. Store fixture hashes and conclusions, not production secrets, in activation evidence.

Do not collect production payloads merely to fill a missing class. Record `not observed` or `not present`.
