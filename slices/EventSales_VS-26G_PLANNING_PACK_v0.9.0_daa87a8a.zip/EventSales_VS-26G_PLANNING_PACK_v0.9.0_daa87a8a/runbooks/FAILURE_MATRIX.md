# Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| unknown semantic | excluded/review | classify with evidence |
| mapping/semantic conflict | excluded/conflict | admin review |
| missing parent renewal id | no ticket/revenue | gather evidence |
| bundle decomposition absent | excluded/review | explicit contract |
| tax fields ambiguous | current totals unchanged | source contract |
| fee has no event attribution | order-level only | reviewed allocation |
| partial refund unallocated | no ticket revocation | line evidence/review |
| partial payload omits child | preserve child | authoritative refresh |
| fixture contains PII | reject evidence | re-redact |
| policy version drift | preview/apply rejected | regenerate |
| impact preview truncated | apply blocked | narrower scope |
| F.1/F.2 interface drift | activation blocked | refresh pack/plan |
| read-model refresh fails | durable semantics remain | retry affected events |
