# VS-26G Acceptance Checklist

## Evidence
- [ ] Ordinary ticket fixture.
- [ ] Ticket variation fixture.
- [ ] Payment-plan initial fixture or explicit absence.
- [ ] Payment-plan instalment fixture or explicit absence.
- [ ] Membership initial/renewal fixtures or explicit absence.
- [ ] Add-on/bundle fixtures or explicit absence.
- [ ] Full/partial/line refund fixtures.
- [ ] Fee/tax fixtures.
- [ ] Removed-child behaviour.
- [ ] No PII/secrets.

## Semantic authority
- [ ] ProductMapping remains ticket-specific.
- [ ] Separate product semantic classification.
- [ ] Variation/product precedence.
- [ ] Versioned pure policy.
- [ ] Unknown fails closed.
- [ ] Line semantic snapshot.
- [ ] Ticket entitlement separated from money.
- [ ] Conflict state/review.

## Monetary
- [ ] Net/tax/gross fields explicit.
- [ ] Existing fields not silently reinterpreted.
- [ ] Tax-inclusive presentation proven.
- [ ] Fee identity/idempotency.
- [ ] Mixed-event fee not guessed.
- [ ] Order-component reconciliation.

## Refunds/children
- [ ] Full refund behaviour explicit.
- [ ] Partial refund durable identity.
- [ ] Refund sign convention.
- [ ] Quantity revocation requires evidence.
- [ ] Complete/partial payload distinction.
- [ ] Missing child semantics explicit.
- [ ] Replay idempotent.

## Historical safety
- [ ] Migration preserves current totals.
- [ ] Future-only classification.
- [ ] Bounded impact preview.
- [ ] Exact hash/version apply.
- [ ] Actor/reason/audit.
- [ ] Affected-event refresh.
- [ ] No automatic historical apply.

## Integration
- [ ] Existing parser/OrderUpserter path only.
- [ ] F.1 catch-up compatible.
- [ ] F.2 live/freshness compatible.
- [ ] No catalogue auto-apply broadening.
- [ ] No VS-27B scope.

## Tests
- [ ] Every policy matrix row.
- [ ] Conflict precedence.
- [ ] Tax/fee/refund fixtures.
- [ ] Child reconciliation.
- [ ] Historical preview/apply.
- [ ] Source-version/replay.
- [ ] Privacy/security.
- [ ] Full CI.

## Production
- [ ] Conservative future-order canary.
- [ ] Ordinary ticket unchanged.
- [ ] Renewal/membership excluded.
- [ ] Unknown visible/excluded.
- [ ] Historical totals unchanged.
- [ ] Kill switch verified.
- [ ] Certification recorded.
