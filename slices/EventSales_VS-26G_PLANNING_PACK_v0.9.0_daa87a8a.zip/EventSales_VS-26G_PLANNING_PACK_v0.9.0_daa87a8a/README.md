# EventSales VS-26G Planning Pack

## Identity

- Slice: `VS-26G`
- Name: Ticket, Payment-Plan, Membership, Add-On and Renewal Semantics
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `daa87a8a1693e399c8effeb23297efad159397fd`
- GitHub scope: `#82`
- Linear parent: `JC-168`
- Pack: `JC-169`
- Pack review: `JC-170`
- Agent plan: `JC-171`
- Plan review: `JC-172`
- Activation/evidence gate: `JC-173`
- Implementation: `JC-174`

## Authority

This ZIP authorises repository reconnaissance, redacted evidence planning and an implementation plan only.

It does not authorise:

- code changes;
- migrations;
- production WooCommerce reads;
- fixture extraction containing PII;
- product classification changes;
- historical reclassification;
- metric changes;
- merge or deployment.

Implementation requires:

1. independent pack approval;
2. independently approved implementation plan;
3. VS-26F.2 production certification and `JC-167` closeout;
4. redacted source evidence approved at `JC-173`;
5. exact-current-main activation supplement;
6. `JC-173` verdict `APPROVE`.

## Outcome

Explicitly separate:

```text
product/order-line semantic identity
ticket entitlement quantity
event ticket revenue
ancillary revenue
tax
fees
refunds
operational status
```

Unknown or risky semantics remain visible but excluded by default.

## Core architectural rule

`ProductMapping` remains the ticket-to-Event/TicketType authority.

A separate product semantic classification governs memberships, renewals, payment plans, add-ons, bundles and ignored products. Each order line stores the semantic decision and policy version used at processing time.

## Historical rule

No migration or policy deployment may silently rewrite existing totals. Historical reclassification requires a bounded preview, explicit approval and audited apply.
