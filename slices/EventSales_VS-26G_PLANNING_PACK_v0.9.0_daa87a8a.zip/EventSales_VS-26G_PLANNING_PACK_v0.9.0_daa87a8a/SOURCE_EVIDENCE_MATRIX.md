# Redacted Source Evidence Matrix

Implementation is blocked until activation records whether each class exists and captures redacted structural evidence.

| Class | Required source evidence |
|---|---|
| ordinary simple ticket | product type, Tickera ids, order line amounts/tax |
| ticket variation | parent product, variation id/attributes, mapping |
| payment-plan initial | product type, order/contract/subscription metadata, total meaning |
| payment-plan instalment | parent/renewal identity, sequence, amount, event link |
| membership initial | product type, subscription/membership metadata |
| membership renewal | parent identity, renewal sequence, status transitions |
| subscription failure/cancel | source statuses and order relationship |
| add-on | event linkage, quantity meaning, price/tax |
| bundle | component/entitlement evidence and allocation |
| full refund | order status, refund ids/totals |
| partial refund | refund objects, amounts, timestamps |
| line quantity refund | refund line ids, quantities, item links |
| fee | fee line id, name, total/tax, metadata |
| tax | order and line net/tax/gross source fields |
| removed child | before/after line/coupon payload behaviour |

## Evidence rules

- No names, email addresses, addresses or customer ids.
- No transaction ids, credentials, webhook secrets or payment tokens.
- Use stable fake/redacted ids while preserving relationships.
- Record actual Woo/plugin versions and relevant installed extensions.
- Record whether order total is full contract value or only current payment.
- Record field absence explicitly; do not infer.
