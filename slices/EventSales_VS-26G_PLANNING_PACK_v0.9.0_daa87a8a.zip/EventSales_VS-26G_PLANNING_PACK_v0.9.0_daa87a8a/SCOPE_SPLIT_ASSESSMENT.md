# Scope Split Assessment

VS-26G is intentionally one semantic certification outcome, but the implementation plan must assess whether delivery should be split into staged PRs or child slices.

A reasonable sequence may be:

1. semantic policy/resource and conservative line snapshots;
2. source parser monetary/fee/refund extensions;
3. admin review and future-only classification;
4. historical preview/apply;
5. aggregate/read-model compatibility.

A split is required if one PR would:

- mix schema foundations with irreversible historical apply;
- exceed reviewability;
- require unavailable source evidence;
- change current totals before policy certification;
- combine unrelated fee/refund work without complete fixtures.

Even if split, one authority model and one final VS-26G certification must remain.
