# Source Classification Precedence

## Input sources

Possible evidence:

- reviewed ProductSemantic classification;
- variation-level classification;
- ticket ProductMapping;
- Tickera event metadata on the line;
- WordPress product type/subscription fields;
- Woo order parent/subscription/renewal metadata;
- bundle component metadata;
- operator review.

## Recommended precedence

```text
reviewed variation semantic
> reviewed product semantic
> explicit reviewed non-ticket/renewal rule
> compatible certified ticket ProductMapping
> compatible Tickera line identity
> conservative source signals
> unknown_requires_review
```

## Conflicts

Examples requiring review:

- ProductMapping says ticket but semantic says membership renewal;
- Tickera event metadata appears on a membership product;
- product-level ticket but variation-level payment plan;
- two different event identities;
- subscription product with no parent/renewal evidence;
- bundle mapped directly to one TicketType without entitlement decomposition.

Conflict results remain excluded until resolved.

## Classification timing

The plan must decide whether classification occurs:

- during normalized upsert;
- immediately after durable line write;
- through a deterministic post-write classifier.

Whichever is chosen must preserve atomicity or recoverable convergence and must not let an unclassified line briefly count.
