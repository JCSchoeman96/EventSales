# Monetary, Tax and Fee Contract

## Current ambiguity

The current parser stores:

- Woo order `total` as `raw_total`;
- order `discount_total`;
- order `total_tax`;
- line `subtotal`;
- line `total`;
- derived line discount.

It does not store line tax or fees. Existing names must not be silently reinterpreted.

## Required normalized concepts

The plan must map verified Woo fields into explicit values such as:

- subtotal_net;
- subtotal_tax;
- subtotal_gross;
- total_net_after_discount;
- total_tax_after_discount;
- total_gross_after_discount;
- discount_net;
- discount_tax;
- discount_gross;
- fee_net;
- fee_tax;
- fee_gross;
- order_gross_total.

Exact names may differ, but net/tax/gross meaning must be unambiguous.

## Tax-inclusive reporting

Product direction is tax-inclusive display.

Until source fixtures prove the field contract:

- current ticket quantity behaviour remains stable;
- no new gross revenue is presented as certified;
- no existing `line_total` value is relabelled as gross;
- discrepancies between order total and normalized components are recorded.

## Fee resource

Use stable Woo fee-line identity where available.

Candidate fields:

- order_id;
- woo_fee_line_id;
- name;
- net amount;
- tax amount;
- gross amount;
- semantic kind;
- optional event attribution;
- source metadata fingerprint;
- active/presence status if child reconciliation requires it.

## Fee attribution

- Do not divide an order fee among events by guesswork.
- Event attribution requires explicit source metadata or reviewed deterministic allocation.
- Mixed-event unallocated fees remain order-level context.
- Booking-fee catalogue configuration is not a substitute for the actual order fee line.

## Reconciliation

The plan must prove:

```text
order gross total
≈ line gross totals
+ fee gross totals
- discounts/refunds
+/- documented Woo rounding/shipping components
```

Shipping and other unsupported components must be explicitly identified rather than absorbed silently.
