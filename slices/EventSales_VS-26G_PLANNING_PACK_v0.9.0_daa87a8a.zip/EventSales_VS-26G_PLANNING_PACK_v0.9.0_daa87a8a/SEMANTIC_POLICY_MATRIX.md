# Conservative Semantic Policy Matrix

This matrix is the planning default. Activation may tighten it; broadening requires evidence and review.

| Semantic kind | Ticket entitlement | Event ticket revenue | Ancillary revenue | Default |
|---|---:|---:|---:|---|
| ordinary_ticket | line quantity | reviewed gross line amount | no | eligible when mapped |
| unknown_requires_review | 0 | 0 | 0 | visible/review |
| ignored_non_ticket | 0 | 0 | 0 | excluded/audited |
| membership_initial | 0 | 0 | separate later | excluded |
| membership_renewal | 0 | 0 | separate later | excluded |
| subscription_other | 0 | 0 | separate later | excluded |
| payment_plan_initial | 0 until explicit contract | 0 until allocation contract | 0 | review |
| payment_plan_instalment | never a new ticket by default | 0 until allocation contract | 0 | review/excluded |
| add_on | 0 | 0 | reviewed event-linked amount only | review |
| bundle | 0 until decomposition | 0 until allocation | reviewed only | review |
| fee_product | 0 | 0 | reviewed only | review |

## Invariants

- Ticket entitlement and money received are separate.
- Order-line quantity is not automatically entitlement for bundles/payment plans.
- A renewal never creates another ticket without a stable entitlement contract.
- A ticket ProductMapping cannot override an explicit reviewed non-ticket semantic.
- Unknown classes fail closed.
- Policy is pure, versioned and exhaustively tested.
