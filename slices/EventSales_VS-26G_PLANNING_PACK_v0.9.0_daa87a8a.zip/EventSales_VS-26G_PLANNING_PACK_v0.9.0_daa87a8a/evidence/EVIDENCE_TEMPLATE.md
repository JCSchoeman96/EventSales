# VS-26G Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- Evidence version/hash:
- Semantic policy version:
- Source/plugin versions:

## Fixture matrix
| Class | Present | Fixture hash | Expected semantic | Result |
|---|---|---|---|---|

## Monetary proof
- line net/tax/gross:
- order component reconciliation:
- fee identity/attribution:
- rounding/unsupported components:

## Refund proof
- full refund:
- partial unallocated:
- line allocation:
- quantity evidence:
- replay:

## Historical proof
- totals before schema:
- totals after schema:
- preview scope/hash:
- ticket delta:
- revenue delta:
- apply authorised:
- affected-event refresh:

## Negative proof
- unknown excluded:
- membership/renewal excluded:
- payment instalment no duplicate ticket:
- bundle without decomposition excluded:
- no fee guess:
- no PII/secrets:
- no parallel writer/scheduler:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
