# Admin Semantics Workflow

## Access

Global admin only until later role/access slices.

## Review queue

Show only bounded, PII-free fields:

- source;
- product/variation ids;
- product/line labels;
- source product type;
- subscription/renewal evidence flags;
- Tickera event identity;
- current mapping and semantic;
- affected future/historical counts;
- bounded conflict/review reason.

## Actions

- classify future orders only;
- preview historical reclassification;
- approve exact preview/apply in a separate action;
- deactivate/supersede classification;
- retry affected-event refresh;
- export redacted evidence if needed.

## Audit

Every action records:

- actor;
- role;
- source;
- old/new semantic;
- policy/evidence versions;
- reason;
- preview hash where applicable;
- timestamps.

## Boundaries

- No raw order body.
- No customer fields.
- No direct payment/ticket/scanner action.
- No automatic historical apply after classification.
- No mutation through the existing read-only mapping queue without a reviewed service.
