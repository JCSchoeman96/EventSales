# Predecessor Contracts — VS-26G

## VS-26E.0–E.3

The catalogue programme owns Event, TicketType and ticket ProductMapping truth.

VS-26G may consume:

- product type;
- subscription evidence;
- source review reasons;
- product/variation identity;
- certified event and ticket mappings.

It may not broaden catalogue auto-apply or create catalog entities from order ingestion.

## VS-26F.1

F.1 owns the durable source-wide catch-up cursor, run, worker and OrderUpserter path.

VS-26G may extend the normalized payload and child resources, but no second order writer or catch-up engine is allowed.

## VS-26F.2

F.2 owns scheduling, queued refresh, source freshness and live operational status.

VS-26G must emit compatible post-commit affected-event/read-model signals and may not create another scheduler.

## VS-27B.1

VS-26G defines inclusion/exclusion and monetary semantics.

VS-27B.1 later defines management-facing time windows, comparisons and dashboard numbers.
