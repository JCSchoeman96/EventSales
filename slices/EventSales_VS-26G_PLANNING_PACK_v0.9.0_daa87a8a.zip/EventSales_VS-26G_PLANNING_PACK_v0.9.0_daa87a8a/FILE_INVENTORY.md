# Mandatory File Inventory — VS-26G

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Catalogue semantics inputs
- `lib/event_sales/catalog/resources/product_mapping.ex`
- `lib/event_sales/catalog/mapping_resolver.ex`
- `lib/event_sales/catalog/order_attribution_resolver.ex`
- `lib/event_sales/catalog/manual_mapping_creator.ex`
- `lib/event_sales/catalog/tickera_catalog/normalizer.ex`
- `lib/event_sales/catalog/tickera_catalog/planner.ex`
- `integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`
- `docs/ops/tickera_catalog_feed_contract.md`

## Sales resources and policy
- `lib/event_sales/sales/resources/order.ex`
- `lib/event_sales/sales/resources/order_item.ex`
- `lib/event_sales/sales/resources/coupon_snapshot.ex`
- `lib/event_sales/sales/order_upserter.ex`
- `lib/event_sales/sales/order_item_mapper.ex`
- `lib/event_sales/sales/status_rules.ex`
- `lib/event_sales/sales/automatic_mapping_policy.ex`
- `lib/event_sales/sales/source_version_guard.ex`
- `lib/event_sales/sales/order_attribution_correction.ex`

## Ingestion
- `lib/event_sales/ingestion/parsers/woocommerce_order_parser.ex`
- `lib/event_sales/ingestion/webhook_processor.ex`
- `lib/event_sales/ingestion/order_reconciliation.ex`
- certified VS-26F.1 parser/upserter/catch-up files;
- certified VS-26F.2 scheduler/live-status files.

## Analytics and exports
- `lib/event_sales/analytics/metric_rules.ex`
- `lib/event_sales/analytics/aggregators/event_aggregator.ex`
- `lib/event_sales/analytics/admin_dashboard.ex`
- `lib/event_sales/analytics/event_detail.ex`
- `lib/event_sales/analytics/order_processed_notifier.ex`
- `lib/event_sales/exports/event_sales_csv.ex`

## Admin
- `lib/event_sales_web/live/admin/mappings_live.ex`
- `lib/event_sales_web/live/admin/product_mappings_live.ex`
- `lib/event_sales_web/live/admin/unmapped_alert_resolve_live.ex`
- `lib/event_sales_web/router.ex`

## Migrations
- `priv/repo/migrations/20260515124923_slice_4_sales.exs`
- all later migrations touching sales orders/items, mappings, snapshots or aggregates.

## Tests
- `test/event_sales/ingestion/parsers/woocommerce_order_parser_test.exs`
- `test/event_sales/sales/order_upserter_test.exs`
- `test/event_sales/sales/order_item_mapper_test.exs`
- `test/event_sales/sales/status_rules_test.exs`
- `test/event_sales/analytics/metric_rules_test.exs`
- `test/event_sales/analytics/event_aggregator_test.exs`
- `test/event_sales_web/live/admin/mappings_live_test.exs`
- `test/event_sales_web/live/admin/product_mappings_live_test.exs`
- all certified VS-26F.1/F.2 tests.

## External/version evidence
- WooCommerce version;
- Tickera and Woo bridge versions;
- Woo Subscriptions/payment-plan plugin versions if present;
- redacted structural fixture matrix approved at JC-173.
