# Independent Reviewer Prompt — VS-26G

Review adversarially.

Block any design that:

- overloads ProductMapping so non-ticket products require fake Event/TicketType links;
- uses mutable count/revenue booleans that allow contradictory states;
- lets unknown semantics count;
- treats renewal order quantity as new ticket entitlement;
- infers payment-plan entitlement without stable parent/contract identity;
- guesses bundle decomposition;
- silently treats Woo line `total` as tax-inclusive;
- guesses fee allocation across mixed-event orders;
- infers ticket revocation from refund amount alone;
- changes partial-refund metrics without durable refund identity/allocation;
- deletes children because a partial payload omitted them;
- bypasses OrderUpserter or F.1/F.2;
- silently reclassifies historical rows during migration;
- couples future classification to automatic historical apply;
- lacks exact-hash preview/apply protection;
- exposes PII, credentials or transaction details;
- pulls VS-27B dashboards/time windows into scope.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only. JC-173 controls implementation.
