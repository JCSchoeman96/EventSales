# Independent Reviewer Prompt — VS-26F.2

Block designs that:

- create another cursor/worker instead of F.1;
- use a timer on every app node;
- assume Cron leadership without proof;
- let the scheduler call Woo directly;
- treat ETS rate limiting as durable uniqueness;
- conflate hot-cache age with source freshness;
- use last sale/order time as freshness;
- fail to clear stale after an empty successful window;
- clear stale after incomplete/failed work;
- use PubSub as authority;
- create a broad global topic without bounds;
- label dashboard rebuild as Woo refresh;
- rely only on per-order notifier despite swallowed failures;
- run a global rebuild every five minutes;
- expose PII/raw payload/credentials;
- pull VS-26G, VS-27B or VS-27C scope forward.

Classify blocker, major and minor.

Verdict: APPROVE / REQUEST CHANGES / BLOCKED.

Approval authorises planning only; JC-162 controls implementation.
