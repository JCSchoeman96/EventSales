# PubSub and LiveView Contract

## Source topic

Use a source-scoped operational topic, for example:

```text
order-catch-up:source:<source_id>
```

Suggested message:

```text
{:order_catch_up_status_changed, source_id, run_id, status, occurred_at}
```

Messages are hints only.

## Rules

- broadcast after durable commit;
- bounded fields only;
- no PII, raw payload, trace or credentials;
- duplicates/missed messages harmless;
- mount/reconnect reloads Postgres truth;
- no cache/PubSub cursor authority;
- avoid an unbounded global topic.

## Operations page

Show mode, schedule, watermark, lag, freshness, active run/window, safe counts, bounded error, queue action and bounded history.

Do not show a percentage unless total work is known.

## Dashboard and event detail

Expose `source_system_id` in admin read models.

Subscribe to source status plus existing event hot-state topics.

- queued/running/retry updates immediately;
- completion reloads source freshness;
- failure/blocked becomes visible;
- event metrics continue through current event PubSub;
- empty completion clears source-stale banner.

## Reconnect

Every page reconstructs status from durable read facades; no replay dependency.
