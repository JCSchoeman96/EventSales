# Source Freshness Contract

## Authority

Source freshness comes from the certified F.1 committed cursor and current run.

Never infer it from latest sale/order time, PubSub time, hot-cache age or browser state.

## States

`unknown`, `fresh`, `stale`, `queued`, `running`, `retry_scheduled`, `blocked`, `failed`, `disabled`, `full_recovery_required`.

## Bounded fields

- source id/name;
- committed modified-through watermark;
- operational completeness boundary;
- lag;
- current run/status/origin/window;
- safe counts and reason code;
- last attempted/successful times;
- mode/schedule state.

## Thresholds

- normal target under five minutes;
- initial stale threshold ten minutes;
- account for F.1 settling delay;
- exact formula reviewed at activation.

## Quiet-source rule

A complete empty F.1 window advances the watermark and clears source-stale state even with no order or hot-state event.

## Failure rule

Incomplete, failed or blocked work does not clear stale state.

## Display

Keep source freshness, run lifecycle and hot-state cache lifecycle distinct.
