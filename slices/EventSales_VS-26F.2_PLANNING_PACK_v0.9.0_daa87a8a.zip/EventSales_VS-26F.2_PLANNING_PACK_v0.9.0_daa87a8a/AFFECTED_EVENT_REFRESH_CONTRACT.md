# Affected-Event Refresh Contract

## Problem

Current per-order notifier failures are swallowed after telemetry. A catch-up run may complete while an event summary update was missed.

## Required convergence

Do not schedule a global dashboard rebuild every five minutes.

Preferred direction:

1. F.1/F.2 records or derives a bounded affected-event set for the run.
2. A unique post-completion refresh worker recomputes those event summaries from Postgres.
3. Successful recomputes use existing event PubSub.
4. Retryable failures remain visible/recoverable.
5. Empty/no-change runs update source freshness only.

## Invariants

- durable Sales truth remains authoritative;
- refresh worker never writes Sales;
- duplicate refresh is harmless;
- affected-event cardinality is bounded;
- source completion may be successful while read-model refresh is separately pending;
- UI distinguishes source fresh from read-model refresh pending.
