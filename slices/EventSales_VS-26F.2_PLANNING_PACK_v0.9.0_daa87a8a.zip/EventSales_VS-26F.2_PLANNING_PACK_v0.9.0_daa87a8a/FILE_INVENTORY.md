# Mandatory File Inventory — VS-26F.2

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Certified F.1
- final VS-26F.1 pack/plan/activation/PR/certification;
- every F.1 cursor, run, failure, facade, worker and test file;
- F.1 domain events/telemetry/read extension points.

## Current scheduling/config
- `config/config.exs`
- `config/runtime.exs`
- `mix.exs`
- `mix.lock`
- `lib/event_sales/application.ex`
- `railway.toml`
- `docs/architecture/oban-pgbouncer.md`
- `docs/runbooks/oban-queue-backlog.md`

## Current reconciliation/admin
- `lib/event_sales/ingestion/manual_sync.ex`
- `lib/event_sales/ingestion/sync_debug.ex`
- `lib/event_sales/ingestion/order_reconciliation.ex`
- `lib/event_sales/ingestion/resources/sync_run.ex`
- `lib/event_sales/ingestion/resources/sync_cursor.ex`
- `lib/event_sales/ingestion/workers/reconcile_orders_worker.ex`
- `lib/event_sales_web/live/admin/sync_live.ex`
- `lib/event_sales_web/live/admin/manual_action_rate_limiter.ex`

## Analytics/live updates
- `lib/event_sales/analytics/order_processed_notifier.ex`
- `lib/event_sales/analytics/hot_state_aggregator.ex`
- `lib/event_sales/analytics/dashboard_pub_sub.ex`
- `lib/event_sales/analytics/dashboard_cache.ex`
- `lib/event_sales/analytics/admin_dashboard.ex`
- `lib/event_sales/analytics/event_detail.ex`
- `lib/event_sales/analytics/workers/rebuild_hot_state_worker.ex`
- `lib/event_sales_web/live/admin/dashboard_live.ex`
- `lib/event_sales_web/live/admin/event_detail_live.ex`
- `lib/event_sales_web/live/admin/components/stale_data_banner.ex`
- `lib/event_sales_web/router.ex`
- `lib/event_sales_web/components/admin_shell.ex`

## Policy/audit/source
- `lib/event_sales/accounts/policies.ex`
- `lib/event_sales/audit/logger.ex`
- `lib/event_sales/catalog/resources/source_system.ex`

## Current tests
- `test/event_sales_web/live/admin/sync_live_test.exs`
- `test/event_sales/ingestion/manual_sync_test.exs`
- `test/event_sales_web/live/admin/dashboard_live_test.exs`
- `test/event_sales_web/live/admin/event_detail_live_test.exs`
- `test/event_sales/analytics/order_processed_notifier_test.exs`
- `test/event_sales/analytics/hot_state_aggregator_test.exs`
- `test/event_sales/analytics/dashboard_pub_sub_test.exs`
- `test/event_sales/analytics/admin_dashboard_test.exs`
- `test/event_sales/analytics/event_detail_test.exs`
- `test/event_sales_web/live/admin/manual_action_rate_limiter_test.exs`
