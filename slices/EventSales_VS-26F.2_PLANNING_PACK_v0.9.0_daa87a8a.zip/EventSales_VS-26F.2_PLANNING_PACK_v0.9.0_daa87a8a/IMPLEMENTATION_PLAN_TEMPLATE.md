# VS-26F.2 Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified F.1 interfaces
## 4. Current scheduler/admin/dashboard truth
## 5. Scheduler plugin and leader proof
## 6. Schedule configuration and source scan bounds
## 7. Admin queue/audit facade
## 8. Source freshness formula and state machine
## 9. Operational read facade
## 10. Source PubSub contract
## 11. Operations page route and UX
## 12. Dashboard integration and wording
## 13. Event Detail integration
## 14. Mount/reconnect durable reload
## 15. Affected-event refresh convergence
## 16. Retry/operator controls
## 17. Audit and telemetry
## 18. Security/privacy
## 19. Migrations/indexes/config
## 20. Tests-first sequence
## 21. Exact files create/modify/generated/forbidden
## 22. Verification commands
## 23. Rollout/kill switches
## 24. Production evidence
## 25. JC-162 activation inputs
## 26. Risks/stop conditions
## 27. Prohibited-actions statement
