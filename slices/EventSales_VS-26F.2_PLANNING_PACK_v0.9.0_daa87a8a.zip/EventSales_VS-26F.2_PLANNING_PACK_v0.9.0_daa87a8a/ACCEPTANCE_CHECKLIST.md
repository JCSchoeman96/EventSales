# VS-26F.2 Acceptance Checklist

## Planning/activation
- [ ] Pack reviewed.
- [ ] Plan reviewed.
- [ ] VS-26F.1 certified.
- [ ] JC-162 approved exact interfaces and topology.

## Scheduler
- [ ] One leader path.
- [ ] Cadence configurable, initial ~5 minutes.
- [ ] Bounded source scan.
- [ ] Duplicate/deployment overlap harmless.
- [ ] Calls F.1 facade only.
- [ ] Modes/kill switches respected.
- [ ] No historical/full recovery.

## Admin action
- [ ] Global admin only.
- [ ] Audited.
- [ ] UX-rate-limited.
- [ ] DB/F.1 uniqueness remains authority.
- [ ] Existing active run returned.
- [ ] No Woo call in web process.
- [ ] Clear wording distinct from dashboard rebuild.

## Freshness/status
- [ ] Derived from committed F.1 watermark.
- [ ] Ten-minute initial stale threshold.
- [ ] Settling delay accounted for.
- [ ] Empty success clears stale.
- [ ] Failed/incomplete work does not.
- [ ] Unknown/disabled/blocked/full-recovery states.
- [ ] No fake percentage.

## Live updates
- [ ] Source-scoped topic.
- [ ] Post-commit messages only.
- [ ] Mount/reconnect reloads Postgres.
- [ ] Operations page updates.
- [ ] Dashboard updates freshness.
- [ ] Event Detail updates freshness.
- [ ] Existing event PubSub updates metrics.
- [ ] Missed message harmless.

## Read-model convergence
- [ ] Bounded affected-event set.
- [ ] Unique retryable refresh.
- [ ] No global rebuild every tick.
- [ ] Source fresh and refresh-pending distinguished.

## Security/scope
- [ ] No PII/raw payload/credentials.
- [ ] Safe bounded errors.
- [ ] No new F.1 core.
- [ ] No catalogue/semantic/metric/access/backfill/webhook scope.

## Production
- [ ] Suppressed webhook recovered by schedule.
- [ ] Open page shows queued/running/completed.
- [ ] Affected metrics converge.
- [ ] Source stale clears automatically.
- [ ] Empty canary clears stale.
- [ ] Duplicate schedule/manual request safe.
- [ ] Kill switch verified.
