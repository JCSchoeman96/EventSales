# VS-26F.2 — Scheduled Catch-Up, Queued Refresh and Live Status

## 1. Goal

Turn the certified VS-26F.1 source-wide order recovery core into an operational service without duplicating its durable authority.

## 2. Current repository facts

- Oban has no plugins configured.
- `/admin/sync` is event/date-scoped manual reconciliation.
- Dashboard `Refresh` requests a hot-state rebuild only.
- Dashboard and Event Detail already subscribe to event-scoped hot-state PubSub.
- The stale banner currently reflects hot-cache lifecycle only.
- The admin UX rate limiter is ETS/node-local.
- Current order notifier failures are swallowed after telemetry.

## 3. Required architecture

```text
Oban leader schedule or audited admin request
-> certified F.1 queue facade
-> F.1 durable run/cursor/worker
-> parser + OrderUpserter
-> source lifecycle PubSub
-> affected-event hot-state convergence
-> open LiveViews reload durable operational truth
```

## 4. Scheduling

- initial configurable cadence around five minutes;
- one leader/cron path across nodes;
- bounded active-source scan;
- source/global mode checks;
- no direct Woo call;
- duplicate ticks coalesce through F.1;
- no automatic full/history recovery;
- deployment overlap is harmless.

The planning agent must verify the exact locked Oban plugin and leader semantics.

## 5. Manual queued refresh

Create an admin-only facade for `Check WooCommerce now`.

It must:

- authorise global admin;
- audit the request;
- use ETS rate limiting only for UX;
- call the F.1 queue facade;
- return an existing active run instead of inserting another;
- avoid Woo calls in LiveView/controller;
- expose safe statuses and errors.

## 6. Operational read facade

Add a bounded admin read facade over F.1 cursor/run/failure state.

It must support:

- list active sources;
- source status;
- recent runs;
- current run;
- safe counts/reasons;
- freshness calculation;
- pagination/limits;
- global-admin policy.

Do not return raw payload or customer/payment fields.

## 7. Source freshness

The committed F.1 source watermark is authority.

Normal target is under five minutes and initial stale threshold is ten minutes.

A complete empty run clears source-stale state. A failed/incomplete run does not.

Do not use local order activity as freshness because a quiet store can still be fully checked.

## 8. PubSub

Add source-scoped operational PubSub.

Broadcast post-commit lifecycle hints only. All pages reload durable state.

Existing event-scoped `DashboardPubSub` remains responsible for event metrics.

## 9. UI

Prefer a dedicated source-wide operations page.

### Required page state

- source and schedule mode;
- freshness/watermark/lag;
- active run/window/origin;
- counts;
- retry/block reason;
- queue action;
- recent history;
- affected-event refresh pending if applicable.

### Existing pages

Dashboard and Event Detail must receive source status updates without reload.

Existing dashboard action must be clearly a local read-model rebuild. Add a distinct Woo check action when appropriate.

## 10. Affected-event convergence

A completed catch-up needs reliable bounded read-model convergence.

Use a unique affected-event refresh path rather than a global rebuild every tick.

Source freshness and read-model refresh state are separate.

## 11. Operator controls

Initial safe controls:

- queue now;
- audited schedule enable/disable;
- reviewed retry/requeue;
- inspect blocked/full-recovery-required state.

Force cancellation is excluded unless certified F.1 explicitly supports safe cooperative cancellation.

## 12. Audit and telemetry

Audit manual queue, schedule configuration, retry/requeue and any safe cancellation.

Telemetry is low-cardinality and covers scheduler results, queue origins, run states, freshness states, lag buckets, PubSub failures and affected-event refresh results.

## 13. Security

- global admin only;
- no PII/raw payload/credentials;
- bounded error reasons;
- no REST from web processes;
- no PubSub/cache as truth.

## 14. Tests-first sequence

1. freshness pure functions/read facade;
2. scheduler and leader/duplicate tests;
3. admin facade/auth/audit/rate-limit tests;
4. source PubSub tests;
5. operations LiveView mount/reconnect tests;
6. dashboard/event integration;
7. empty completion stale-clear test;
8. failed run stale-preservation test;
9. affected-event convergence/retry;
10. privacy and boundary tests;
11. rollout canary.

## 15. Non-goals

No new catch-up core, catalogue changes, semantic/metric changes, non-admin roles, backfill, webhook redesign or global rebuild per tick.

## 16. Acceptance

A missed webhook is recovered by the schedule while an admin page is open. The page shows lifecycle updates, affected metrics converge, source freshness advances and stale state clears without reload. Duplicate schedule/manual requests do not create a second active run.
