# Predecessor Contracts

F.2 reuses the certified F.1 cursor, run, failure, queue and OrderUpserter authorities.

Activation must inspect actual F.1 interfaces.

F.2 does not call Catalog Sync inline or redefine product/order-line semantics, metrics, non-admin access, historical backfill or compact webhook contracts.
