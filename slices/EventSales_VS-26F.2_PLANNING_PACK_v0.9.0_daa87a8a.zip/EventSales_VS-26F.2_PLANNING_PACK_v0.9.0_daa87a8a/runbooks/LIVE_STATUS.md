# Live Status Runbook

## Mount/reconnect

- resolve authorised source ids;
- load durable source freshness/current run;
- subscribe to source operational topics;
- subscribe to existing event topics where needed.

## Source message

- treat message as invalidation hint;
- reload source status from Postgres;
- update queued/running/retry/blocked/fresh state;
- never trust counters carried only in PubSub.

## Event message

- use existing DashboardPubSub path;
- reload/replace affected event row or detail.

## Completion ordering

Source completion and event refresh messages may arrive in either order.

UI must tolerate:

- source fresh while read-model refresh pending;
- event update before source completion;
- duplicate/missed messages.

## Quiet completion

Reloaded cursor freshness clears source-stale state even without event messages.
