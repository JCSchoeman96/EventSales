# Rollout and Stop Conditions

## Rollout

1. Deploy read/PubSub/admin surfaces with scheduler disabled.
2. Verify F.1 interfaces and source status reads.
3. Verify source topic on one admin page.
4. Verify manual queue coalescing and audit.
5. Enable scheduler observation/dry operational mode.
6. Verify one leader and duplicate-tick behaviour.
7. Enable one source at conservative cadence.
8. Suppress one webhook and observe open dashboard.
9. Verify changed event convergence.
10. Run an empty window and verify stale clears.
11. Verify failed window does not clear stale.
12. Widen only by explicit approval.

## Kill switches

- remove/disable Cron entry;
- source schedule disabled;
- F.1 source/global mode disabled;
- queue pause;
- affected-event refresh worker pause.

## Stop immediately

- duplicate active F.1 runs;
- scheduler calls Woo directly;
- empty success does not clear freshness;
- failed work clears freshness;
- dashboard rebuild is presented as Woo refresh;
- global rebuild occurs every tick;
- PII/raw payload appears;
- source/run status depends only on PubSub;
- access exceeds global admin.
