# Failure Matrix

| Failure | Durable/UI result | Recovery |
|---|---|---|
| duplicate cron tick | existing F.1 run | coalesced |
| multiple app nodes | one leader/DB uniqueness | no duplicate |
| scheduler queue failure | telemetry/status unchanged | next tick/manual |
| source disabled | skipped | audited enable |
| active run | current run shown | wait |
| manual rate limited | UX message | later retry |
| PubSub missed | stale socket only | reconnect/reload |
| source run failed | source remains stale/failed | reviewed retry |
| empty success | watermark fresh | clear stale |
| affected refresh failed | source fresh, refresh pending | unique retry |
| hot-state rebuild failed | cache warning | separate rebuild |
| F.1 full recovery required | schedule blocked | separate recovery pack |
| unauthorized action | forbidden | audit/security |
