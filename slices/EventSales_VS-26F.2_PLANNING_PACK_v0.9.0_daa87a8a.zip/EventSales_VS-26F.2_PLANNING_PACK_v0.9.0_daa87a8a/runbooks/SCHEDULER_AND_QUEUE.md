# Scheduler and Queue Runbook

1. Oban leader emits one configured tick.
2. Load at most the approved active-source limit.
3. Skip disabled, blocked or full-recovery-required sources.
4. Apply optional bounded jitter.
5. Call certified F.1 queue facade with `scheduled` origin.
6. Treat existing active run as a successful coalesced result.
7. Record low-cardinality telemetry.
8. Never call WooCommerce directly.
9. Never create historical/full recovery automatically.

## Manual queue

1. Authorise global admin.
2. Apply UX rate limit.
3. Write audit/request through approved facade.
4. Call F.1 queue authority.
5. Return queued or existing current run.
6. Broadcast/read durable status after commit.
