# Scheduler and Admin Action Contract

## Scheduler

Configurable cadence, initially around five minutes.

```text
single leader tick
-> bounded active source scan
-> F.1 queue facade(requested_via: scheduled)
-> existing run coalesces safely
```

Requirements:

- verify locked Oban Cron/plugin and leadership;
- no timer per app node;
- no direct Woo call;
- bounded source scan and optional jitter;
- modes respected;
- duplicate/deploy overlap harmless;
- dedicated unambiguous queue if needed;
- no historical/full recovery.

## Admin action

Use explicit wording such as `Check WooCommerce now`.

- global admin only;
- audited facade over F.1 queue;
- ETS limiter is UX only;
- F.1/Postgres uniqueness is authority;
- existing active run returns its state;
- no source calls from web process;
- blocked/disabled state explained safely.

Prefer `/admin/order-catch-up`; `/admin/sync` remains event/date reconciliation.

When both actions appear, label existing dashboard action `Rebuild dashboard`.
