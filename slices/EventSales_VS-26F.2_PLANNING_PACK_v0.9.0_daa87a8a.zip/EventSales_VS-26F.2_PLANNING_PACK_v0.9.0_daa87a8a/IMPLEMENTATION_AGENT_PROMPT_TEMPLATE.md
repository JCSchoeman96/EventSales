# Implementation Agent Prompt Template — VS-26F.2

**Do not use until JC-162 returns APPROVE.**

Activation fills:

- exact main SHA;
- certified F.1 interface names;
- exact scheduler/plugin configuration;
- freshness formula/threshold;
- PubSub messages/topics;
- affected-event refresh design;
- exact routes/files/migrations/indexes/tests;
- rollout and stop conditions.

Write tests first, implement activated scope, open a PR and stop before merge/deployment.
