# Planning Agent Prompt — VS-26F.2

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-26F.2_PLANNING_PACK_v0.9.0_daa87a8a.zip`
Planning baseline: `daa87a8a1693e399c8effeb23297efad159397fd`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, commit, open/merge PRs, run migrations, enable Cron, call WooCommerce, queue catch-up or change production.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory work

Read all files in `FILE_INVENTORY.md`.

Inspect certified VS-26F.1 artifacts. If unavailable, mark every dependent interface unresolved for `JC-162`.

Complete the plan with:

1. actual F.1 queue/cursor/run/failure interfaces;
2. exact Oban scheduler/plugin and leader proof;
3. schedule configuration and source scan bounds;
4. audited admin queue facade;
5. durable source freshness read model/formula;
6. source-scoped PubSub contract;
7. operations page route/read/actions;
8. Dashboard/EventDetail source subscriptions;
9. local rebuild versus Woo refresh wording;
10. affected-event refresh convergence;
11. retry/operator controls;
12. migrations/indexes/config;
13. tests-first sequence;
14. rollout/kill switches;
15. production evidence;
16. exact files and `JC-162` activation inputs.

Finish with `PACK VALID`, `PACK REFRESH RECOMMENDED` or `PACK BLOCKED`, and confirm no prohibited action occurred.
