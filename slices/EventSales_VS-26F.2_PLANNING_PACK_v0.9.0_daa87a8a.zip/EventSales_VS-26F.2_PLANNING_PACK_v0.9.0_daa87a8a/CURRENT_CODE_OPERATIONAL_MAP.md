# Current Code Operational Map

| Current code | Existing behaviour | F.2 implication |
|---|---|---|
| Oban config | `plugins: []` | no recurring scheduler |
| `SyncLive` | event/date manual sync | keep distinct |
| `ManualActionRateLimiter` | ETS/node-local | UX only |
| `DashboardLive` | Refresh rebuilds hot state | not Woo refresh |
| `DashboardPubSub` | event topics only | add source operations topic |
| `EventDetailLive` | event hot-state subscription | add source status |
| `StaleDataBanner` | hot-state only | not source freshness |
| `HotStateAggregator` | five-minute cache stale default | separate lifecycle |
| notifier | per-order event recompute, swallowed failures | add bounded convergence |
| admin read models | source id omitted | expose safe source id/status |
| router | `/admin/sync` occupied | prefer `/admin/order-catch-up` |
