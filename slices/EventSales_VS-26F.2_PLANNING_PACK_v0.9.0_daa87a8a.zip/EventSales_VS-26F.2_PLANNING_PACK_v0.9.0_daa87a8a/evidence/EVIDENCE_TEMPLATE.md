# VS-26F.2 Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- F.1 certified interface:
- Scheduler version/cadence:
- Source id redacted:

## Scheduler
- leader proof:
- tick time:
- queue result:
- duplicate tick result:
- source scan count:

## Open-page canary
- page opened at:
- webhook suppressed:
- source update at:
- queued message:
- running message:
- completed message:
- event hot-state update:
- source watermark before/after:
- stale banner before/after:
- browser reload required: no

## Empty window
- no changed orders:
- watermark advanced:
- source stale cleared:
- event rebuild triggered: no

## Negative proof
- failed window did not clear stale:
- active run coalesced:
- manual rate limit:
- reconnect durable reload:
- notifier failure/affected refresh retry:
- no global rebuild:
- no PII/secrets:
- no direct Woo from web/scheduler:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
