# TOON Prompts — VS-26F.2

## Planning agent
Task: Operationalise certified F.1 with scheduling, source freshness and live status.
Output: Complete implementation plan.
Boundary: No code or production actions.

## Scheduler reviewer
Task: Attack leader, duplicate tick, source scan and queue semantics.
Output: Findings and tests.
Boundary: Scheduler only calls F.1 facade.

## Freshness reviewer
Task: Attack watermark formula and stale-state presentation.
Output: Truth-table verdict.
Boundary: Quiet source can be fresh.

## Live-status reviewer
Task: Attack PubSub/reconnect and affected-event convergence.
Output: Findings.
Boundary: PubSub is a hint, Postgres is truth.

## Activation reviewer
Task: Refresh current main and certified F.1 interfaces/topology.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
