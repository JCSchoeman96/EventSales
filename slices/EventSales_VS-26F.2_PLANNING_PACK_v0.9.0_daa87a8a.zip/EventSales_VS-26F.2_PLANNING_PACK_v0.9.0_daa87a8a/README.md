# EventSales VS-26F.2 Planning Pack

- Slice: `VS-26F.2`
- Name: Scheduled Catch-Up, Queued Refresh and Live Status
- Version: `0.9.0`
- Status: `planning_review_ready`
- Baseline: `daa87a8a1693e399c8effeb23297efad159397fd`
- GitHub: `#123`, umbrella `#80`
- Linear: `JC-157` through `JC-167`

This pack authorises reconnaissance and planning only.

Implementation requires independent pack/plan approval, VS-26F.1 certification and an `APPROVE` verdict from `JC-162`.

## Outcome

Operationalise the certified F.1 core with a recurring schedule, audited admin queue action, source freshness, bounded status, source PubSub and automatic updates in open admin LiveViews.

No second cursor, catch-up engine or Sales writer.

## Critical distinction

```text
Check WooCommerce now -> queues F.1 catch-up
Rebuild dashboard -> local read-model rebuild only
```
