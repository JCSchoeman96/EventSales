# Operator State Matrix

| State | Queue now | Schedule | UI |
|---|---|---|---|
| unknown bootstrap | blocked/explicit seed | disabled | explain incomplete baseline |
| fresh idle | allowed | enabled | show watermark |
| stale idle | allowed | enabled | prominent action |
| queued/running | return current run | no duplicate | live counts |
| retry scheduled | return current run | no duplicate | retry time/reason |
| blocked failure | reviewed retry only | skip new | bounded reason |
| disabled source | blocked | disabled | enable action if authorised |
| full recovery required | blocked | disabled | separate recovery required |
| completed + refresh pending | new run per cadence rules | enabled | source fresh, read model pending |

Force-cancelling executing windows is out of scope unless F.1 proves cooperative cancellation safety.
