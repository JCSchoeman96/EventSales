# Privacy and Forbidden Fields

## Forbidden in compact body

- billing/shipping names;
- email;
- phone;
- street, city, province, postcode, country;
- customer id unless separately proven necessary;
- IP address;
- user-agent;
- order key;
- payment tokens;
- gateway transaction/reference ids;
- PayFast/Paystack/provider payloads;
- account/session tokens;
- ticket codes;
- QR/barcode hashes;
- ticket/download URLs;
- signed URLs;
- arbitrary order metadata;
- arbitrary line metadata;
- order notes;
- free-text refund reasons by default.

## Conditionally allowed

Only after final G evidence:

- low-cardinality `payment_method_code`;
- bounded `created_via`;
- renewal/subscription relationship ids;
- coupon code;
- fee labels;
- product/line display name.

## Presence-aware normalization

The compact adapter omits forbidden optional keys from the canonical map.

It must not populate them as `nil` and accidentally clear legacy durable fields on update.

A separate reviewed privacy migration may purge existing Sales PII; VS-27A does not silently erase it.

## Stored webhook payload

Compact events remain subject to normal payload retention/replay law even though they are PII-minimised.

Legacy payload debug output must use a safe projection rather than exposing forbidden fields.

## Logs and evidence

No raw payload body, customer data, payment reference, ticket token or secret in:

- WordPress logs;
- Phoenix logs;
- telemetry;
- PubSub;
- GitHub/Linear;
- screenshots;
- pack fixtures;
- production evidence.

Use safe ids, hashes, counts, contract family and byte sizes.
