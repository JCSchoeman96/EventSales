# VS-27A Legacy Emission Retirement Supplement

- Compact 100% start:
- Evidence window:
- Peak event cycle covered:
- Native retry horizon:
- EventSales payload retention:
- Legacy stored replay count/status:
- Compact acceptance/failure/lag:
- Canonical mismatch count:
- PII scan:
- Catch-up repair evidence:
- Incident/rollback evidence:
- Current bridge/backend versions:
- Support matrix:
- Source mode after retirement:
- Backend legacy adapter status:
- Runbook/documentation updates:
- Authorization reference:
- Stop conditions:

Verdict:

- APPROVE LEGACY EMISSION DEPRECATION
- APPROVE LEGACY EMISSION RETIREMENT
- EXTEND EVIDENCE WINDOW
- BLOCKED

This does not authorize deletion of the backend legacy parser or stored payloads.
