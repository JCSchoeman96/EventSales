# Catch-Up, Backfill, Import and Correction Handoff

## One canonical order input

The following source adapters converge:

```text
legacy webhook
compact webhook
F catch-up REST
A backfill REST
B15 CSV/XLSX import
```

They do not share transport format, but they share the certified canonical normalized order contract.

## Catch-up

- remains source recovery;
- uses bounded REST;
- keeps current cursor/source-version law;
- can repair a compact webhook failure;
- no contract field required in Woo REST response.

## Backfill

- remains historical completeness authority;
- compact source emission does not alter certified backfill windows;
- backfill payload facts must cover the same canonical required fields.

## Pack 15 import

- imports never masquerade as compact webhook deliveries;
- import file schema may reuse canonical field definitions;
- import conflicts become issues/corrections;
- compact delivery does not grant spreadsheet authority.

## Pack 15 corrections

- a compact source conflict can create/reopen a case under final law;
- webhook transport never applies a manual correction;
- local reviewed attribution/semantic overlay protection remains;
- source-version drift invalidates stale correction proposals.

## Completeness

A compact processed webhook advances near-live truth only.

It cannot certify historical completeness.

## Analytics

All adapters call the same final writer/notifier/contribution path.

No compact-specific metric path.
