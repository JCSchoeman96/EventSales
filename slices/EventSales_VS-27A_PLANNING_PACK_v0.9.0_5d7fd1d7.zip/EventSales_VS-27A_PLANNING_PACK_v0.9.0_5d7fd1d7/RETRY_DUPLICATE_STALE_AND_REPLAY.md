# Retry, Duplicate, Stale and Replay Contract

## Delivery duplicate

Existing unique `delivery_id` and raw payload hash logic remains unchanged.

Same delivery id plus same bytes is ignored as duplicate.

Same delivery id plus different bytes remains a high-risk payload mismatch.

## Resource duplicate

Processing-time duplicate detection currently uses source/resource/id and payload hash.

Legacy and compact representations of the same order have different body hashes. Rollout must avoid dual delivery to the same EventSales endpoint.

## Source stale

`date_modified_gmt` remains required and is used by the existing source-updated guard.

Compact parsing does not introduce a new source version.

## Equal source version

The final writer contract decides equal-version child reconciliation.

Compact full-snapshot and collection-completeness markers must be available to that writer.

## Native retries

A retry remains a native Woo webhook delivery.

Deterministic canary selection prevents one order flipping between legacy and compact because of randomness.

## Stored replay

Admin replay uses the stored payload family and contract.

A legacy stored event remains legacy even after source 100% compact rollout.

A compact stored event remains compact.

## Failed unknown contract

Unknown explicit contract is permanently failed. Correcting it requires source fix and a new native delivery/catch-up, not manual reinterpretation as legacy.

## Catch-up recovery

If compact delivery fails or is rejected, F catch-up remains recovery authority using the certified full REST adapter.

No compact parser performs a source callback.

## Redacted payload

Once payload retention redacts the body, replay remains unavailable as today. Contract metadata and failure evidence remain.
