# VS-27A Redacted Evidence

- Pack/plan/activation:
- Child stage:
- PR/head/deployed SHA:
- Source plugin version/SHA:
- WordPress/Woo/Tickera/Subscriptions versions:
- HPOS:
- EventSales webhook id/topic/API version redacted:
- Contract/schema hash:
- Feature modes/sampling:

## Source preflight
- native Woo source/tag/file evidence:
- delivery/HMAC/retry behaviour:
- legacy payload bytes/cardinality:
- metadata/provenance findings:

## Backend dual-read
- migration/index:
- legacy regression:
- compact synthetic:
- routing unknown/missing:
- duplicate/stale/replay:
- Redis envelope:
- debug/purger:
- product topic:

## WordPress bridge
- disabled proof:
- exact webhook targeting:
- non-target unchanged:
- source snapshot/provenance:
- HPOS/query/performance:
- no extra HTTP:
- rollback:

## Shadow/parity
- candidate order count:
- legacy/compact p50/p95/max bytes:
- canonical mismatch count:
- unsupported sections:
- source-fact basis counts:
- forbidden-field findings:
- catch-up/backfill/import parity:
- builder failures:

## Canary/broadening
- exact supplement:
- step/basis points:
- compact/legacy cohort counts:
- HMAC acceptance:
- processed/permanent/transient:
- source-visible lag:
- buffer-too-large:
- duplicate/stale/mismatch:
- mapping/semantic conflicts:
- catch-up repairs:
- rollback test:

## Privacy
- seeded PII/provider/ticket secrets:
- compact body:
- snapshots:
- WordPress logs:
- WebhookEvent/debug:
- telemetry/PubSub:
- evidence:
- verdict:

## Legacy retirement
- 100% compact start:
- evidence window/peak cycle:
- stored legacy obligations:
- support states:
- source retirement:
- backend legacy parse-only:
- incident rollback:

## Negative proof
- no second writer:
- no custom HTTP/retry/HMAC:
- no non-target webhook mutation:
- no partial payload:
- no name-based identity:
- no source callback:
- no import/correction/metric/completeness bypass:
- no raw production payload attached:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
