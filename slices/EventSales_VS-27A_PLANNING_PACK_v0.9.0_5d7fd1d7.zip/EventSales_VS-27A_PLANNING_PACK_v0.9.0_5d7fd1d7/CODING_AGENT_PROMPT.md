# Planning Agent Prompt — VS-27A

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-27A_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository and source-contract reconnaissance plus implementation planning only.

Do not modify files, dependencies, migrations, WordPress plugins or config. Do not enable compact mode, change a webhook, send/replay a production webhook, call production WordPress/WooCommerce, commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md` and every pack file.

Refresh exact final certified VS-26F, VS-26G, VS-27B, VS-28A and VS-28B contracts. Do not assume planning names survived.

## Required decisions

1. exact current-code gap verification;
2. exact current production WooCommerce/WordPress/Tickera/Subscriptions/HPOS versions to gather at activation;
3. exact native Woo webhook ids/topics/API versions/destination/retry/logging;
4. final canonical normalized order field/presence contract;
5. final G/B paid/refund/fee/tax/relationship source fields;
6. compact v1 exact JSON registry/schema;
7. child collection completeness/removal behaviour;
8. contract classifier/router/error contract;
9. OrderUpserter integration without second writer;
10. legacy parser preservation;
11. compact parser validation/bounds;
12. WebhookEvent contract metadata/migration/index;
13. Redis buffer compatibility;
14. safe webhook debug projection;
15. payload retention/replay implications;
16. dedicated WordPress plugin structure;
17. exact `woocommerce_webhook_payload` targeting;
18. source snapshot hook/meta/provenance;
19. variation/parent/Tickera metadata evidence;
20. HPOS/source performance;
21. deterministic canary/fallback modes;
22. WP-CLI safe preview and testing;
23. native HMAC/delivery compatibility;
24. parity adapters/fixtures/projection hash;
25. catch-up/backfill/import/correction handoff;
26. telemetry and production comparison;
27. feature modes/kill switch;
28. staged PR sequence;
29. tests-first sequence;
30. exact files/dependencies/config/migrations/generated files;
31. PHP/Elixir/static/security/load verification;
32. rollout/canary/evidence/rollback;
33. legacy emission retirement support window;
34. Linear document/gate mapping;
35. risks/stop conditions.

## External source evidence

Use official WooCommerce code/reference and the exact installed source version. Record links/commit/tag in the plan.

## Output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with exactly one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
