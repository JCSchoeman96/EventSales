# Child Collection Completeness

## Problem

The current writer upserts provided lines and coupons but does not delete durable children merely because they are absent from a payload.

A compact payload cannot silently omit collections to save bytes.

## Required marker

Candidate:

```json
"sets": {
  "line_items": "complete",
  "coupon_lines": "complete",
  "fee_lines": "complete",
  "refunds": "complete"
}
```

Allowed states:

- `complete`;
- `unsupported_by_contract`.

`partial`, missing, unknown or false values fail closed for any collection the writer treats as authoritative.

## Rules

- `line_items` must be complete for v1.
- A supported empty collection is `[]` plus `complete`.
- An unsupported collection is not interpreted as empty source truth.
- Duplicate child ids fail.
- Child ordering is not semantic.
- The canonical adapter sorts/fingerprints deterministically.
- The exact same collection status must be available to catch-up/backfill adapters.

## Deletion/reconciliation

Whether a complete set removes missing durable children belongs to the final certified writer contract.

VS-27A does not invent deletion semantics.

Until the writer supports authoritative removal/reversal, a missing previously known child produces a conflict/finding rather than destructive removal.

## Payload patching

No changed-fields-only or line-item-only webhook contract in v1.

A future delta contract requires a different identifier and writer law.
