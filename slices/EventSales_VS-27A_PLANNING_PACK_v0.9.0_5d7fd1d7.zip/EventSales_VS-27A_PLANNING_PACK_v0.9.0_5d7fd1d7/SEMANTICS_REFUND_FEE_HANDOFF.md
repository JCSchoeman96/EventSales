# Semantics, Refund and Fee Handoff

## Principle

The compact contract transports source facts. It does not classify final contribution semantics.

## VS-26G dependency

Activation imports the exact final G registry for:

- ticket entitlement;
- payment plan;
- membership/subscription;
- renewal;
- add-on/bundle;
- fee;
- tax;
- shipping/rounding;
- full and partial refunds;
- reversal/revocation;
- unknown semantics.

## Required source sections

Any source fact required by G must be:

1. present in compact v1;
2. explicitly `unsupported_by_contract`; or
3. cause compact rollout to remain blocked.

No silent loss.

## Paid time

The old issue omitted `date_paid_gmt`.

Final B.1 prefers the approved paid timestamp before completed fallback, so compact v1 must carry the final sale-time source field.

## Refunds

Order status `refunded` alone is insufficient for partial-refund truth.

The final contract must carry approved refund identities, occurrence time and line/order monetary facts required by G/B.

Free-text refund reasons remain forbidden by default.

## Fees and tax

Order total and order total tax alone may not satisfy final reporting.

The registry includes final approved line tax, fee and tax facts.

Unknown fee/refund structures fail closed rather than being discarded.

## Relationships

Payment plans and renewals may require parent/subscription relationship ids.

Only final G-approved relationship fields enter v1.

## Contract freeze gate

Do not finalise JSON Schema or enable WordPress compact mode until the certified G/B field matrix is copied into activation evidence and parity fixtures.
