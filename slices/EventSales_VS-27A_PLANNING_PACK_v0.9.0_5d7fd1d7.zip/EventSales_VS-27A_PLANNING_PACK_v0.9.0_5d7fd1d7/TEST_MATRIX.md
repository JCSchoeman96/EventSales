# VS-27A Test Matrix

## Router

- no contract → legacy;
- exact v1 → compact;
- unknown string → unsupported;
- null/blank/integer/map/list → invalid;
- product topic bypasses order router.

## Compact schema

- required headers;
- strict UTC timestamps;
- Decimal strings;
- status/currency;
- full snapshot marker;
- child collection markers;
- duplicate child ids;
- unknown keys;
- forbidden PII keys;
- string/cardinality/body limits.

## Presence semantics

- compact omission of customer/payment fields does not clear existing legacy data;
- explicit approved nullable fields update according to final writer law;
- legacy parser output unchanged.

## Parity

Fixtures:

- simple ticket;
- variation;
- multiple events in one order;
- ticket plus add-on;
- payment plan/subscription;
- renewal/parent;
- fee and tax;
- coupon;
- on-hold EFT;
- full refund;
- partial refund;
- cancelled/failed;
- event snapshot/fallback/conflict;
- child-set conflict/removal;
- missing paid/completed timestamp.

For each compare canonical projection and writer effects.

## Intake/security

- native HMAC compact body;
- byte tampering;
- duplicate delivery;
- same delivery/different body;
- stale/equal/new modified time;
- invalid JSON;
- over-bound compact body;
- Redis entry envelope;
- Postgres saturation buffer/drain.

## Processing/replay

- compact success;
- permanent compact validation failure;
- transient database retry;
- stored compact replay;
- stored legacy replay after compact rollout;
- redacted payload behaviour;
- notifier/effect parity.

## Debug/privacy

- contract metadata list;
- compact safe projection;
- legacy safe projection;
- seeded PII/provider/ticket secrets absent;
- payload metadata survives purge.

## WordPress builder

- non-order unchanged;
- non-target webhook unchanged;
- exact target compact;
- disabled unchanged;
- shadow unchanged;
- deterministic canary stable;
- exact allowlist;
- builder failure fallback;
- HPOS order APIs;
- source snapshot priority;
- variation/parent fallback;
- source fact provenance;
- no arbitrary metadata;
- body/cardinality limit.

## Integration

- PHP builder output → native JSON/HMAC → Phoenix intake → compact adapter → writer;
- full legacy and compact source state yield same canonical effect;
- catch-up repairs rejected compact delivery;
- no duplicate metrics/effects;
- feature rollback.

## Load

- representative 10k-sales period fixture;
- maximum 500-line order;
- source query count;
- payload p50/p95;
- parser duration/memory;
- Redis entry maximum;
- queue lag.
