# Payload Bounds and Validation

## Current constraints

The degraded Redis buffer limits its encoded entry to 256,000 bytes and embeds the decoded payload plus metadata.

A compact body must leave safe envelope headroom.

## Planning defaults

| Bound | Candidate |
|---|---:|
| Compact raw JSON body | 192 KiB |
| Order line items | 500 |
| Coupon lines | 100 |
| Fee lines | 100 |
| Refund records | 100 |
| Refund line records | 500 |
| Child object keys | exact allowlist |
| Display string | 500 characters |
| Coupon code | 200 characters |
| Contract string | 64 characters |
| JSON nesting | schema-bounded |
| Decimal text | 64 characters |

Activation measures real source maxima and may tighten, not broaden casually.

## Legacy coexistence

Do not impose the compact 192 KiB bound on legacy payloads until production legacy sizes and failure behaviour are measured.

Existing Plug/body limits remain during coexistence.

## Validation phases

### Intake-safe classification

After HMAC and JSON decode:

- top-level map;
- contract family;
- resource id;
- source modified timestamp;
- raw body size.

### Async compact schema validation

- exact keys/types;
- required fields;
- strict dates;
- decimal format/range;
- status/currency;
- child completeness;
- duplicate ids;
- counts/string sizes;
- forbidden fields;
- semantic section versions.

## Forbidden-key scan

Recursively reject known forbidden PII/provider/meta keys.

The allowlist remains primary; forbidden scan is defence in depth.

## Over-bound behaviour

The event is retained with safe contract metadata and fails permanently as invalid compact payload.

Do not partially parse/truncate children.

## Buffer proof

Test the maximum accepted compact body through `RedisWebhookBuffer.entry_from_intake_context/1`; the encoded entry must remain under the configured cap.

If not, lower the compact limit.
