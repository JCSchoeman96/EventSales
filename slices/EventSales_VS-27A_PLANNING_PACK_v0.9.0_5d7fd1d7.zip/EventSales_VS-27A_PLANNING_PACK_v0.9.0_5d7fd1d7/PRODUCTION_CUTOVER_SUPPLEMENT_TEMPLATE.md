# VS-27A Production Compact Cutover Supplement

## Identity

- Certified backend PR/head/deployed SHA:
- Certified WordPress bridge version/SHA:
- Exact source WordPress/Woo/Tickera versions:
- HPOS state:
- EventSales webhook id:
- Topic/API version:
- Delivery URL/path token hash:
- Contract:
- Source mode:
- Exact order allowlist:
- Compact basis points:
- Sampling secret/reference:
- Builder fallback policy:
- Compact body/cardinality limits:
- Authorization reference:
- Operator:
- Planned start/end:

## Preflight

- backend dual-read certified:
- compact parser/schema certified:
- native HMAC staging proof:
- non-EventSales webhook unchanged proof:
- source snapshot/provenance proof:
- Redis buffer proof:
- legacy/compact canonical parity:
- catch-up/backfill parity:
- forbidden-field scan:
- rollback mode tested:
- queue/database/source health:

## Canary expectations

- expected orders:
- expected payload byte reduction:
- acceptable failure/lag thresholds:
- acceptable mapping/semantic deltas:
- canonical mismatch threshold: zero
- buffer-too-large threshold: zero
- PII finding threshold: zero

## Stop conditions

- signature reject;
- permanent compact parse;
- source-version regression;
- canonical mismatch;
- missing required child/source facts;
- PII/provider field;
- elevated lag/failure;
- non-target webhook modified;
- catch-up cannot repair;
- rollback unavailable.

Verdict:

- APPROVE SHADOW ONLY
- APPROVE EXACT COMPACT CANARY
- APPROVE BASIS-POINT BROADENING
- APPROVE 100% COMPACT EMISSION
- REFRESH
- BLOCKED

Approval applies only to the exact webhook, bridge version, contract and sampling configuration.
