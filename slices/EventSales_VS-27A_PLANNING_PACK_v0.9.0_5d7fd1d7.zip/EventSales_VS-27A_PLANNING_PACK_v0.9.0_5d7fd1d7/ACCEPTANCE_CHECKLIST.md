# VS-27A Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-28B certified and closed.
- [ ] Final F/G/B/A/B15 interfaces refreshed.
- [ ] Exact installed source versions recorded.
- [ ] Exact webhook ids/topics/API versions/destination recorded.
- [ ] Activation verdict APPROVE.

## Contract registry
- [ ] Exact `eventsales.order.v1`.
- [ ] Missing contract routes legacy.
- [ ] Unknown explicit contract fails.
- [ ] Full-order snapshot only.
- [ ] Child completeness explicit.
- [ ] Strict dates/Decimals/types.
- [ ] Paid-time field present.
- [ ] Final refund/fee/tax/relationship facts present.
- [ ] Forbidden fields absent.
- [ ] Version compatibility policy.

## Backend dual-read
- [ ] Pure classifier/router.
- [ ] Compact parser.
- [ ] Legacy parser preserved.
- [ ] Product topics unchanged.
- [ ] Presence-aware optional fields.
- [ ] One `upsert_normalized_order`.
- [ ] Permanent errors bounded.
- [ ] Stored legacy/compact replay.
- [ ] No source callback.
- [ ] No second writer.

## WebhookEvent/intake
- [ ] Raw-byte HMAC unchanged.
- [ ] Duplicate/stale semantics unchanged.
- [ ] Contract family/version persisted.
- [ ] Contract metadata survives redaction.
- [ ] Redis entry compatibility.
- [ ] Compact body limit leaves headroom.
- [ ] Safe admin debug projection.
- [ ] Low-cardinality telemetry.

## WordPress bridge
- [ ] Sibling order bridge boundary.
- [ ] Native payload filter.
- [ ] Exact configured webhook ids only.
- [ ] Non-EventSales payload unchanged.
- [ ] No custom HTTP/retry/signature.
- [ ] HPOS-safe order APIs.
- [ ] No remote EventSales call.
- [ ] Snapshot line facts at creation.
- [ ] Event id numeric/no names.
- [ ] Provenance for fallback.
- [ ] Product metadata prefetch/bounds.
- [ ] Disabled by default.
- [ ] Safe WP-CLI preview.
- [ ] No raw payload logs.

## Canary
- [ ] Backend deployed first.
- [ ] Bridge installed disabled.
- [ ] Shadow returns legacy.
- [ ] Deterministic sampling.
- [ ] Exact order allowlist.
- [ ] Legacy fallback on builder failure initially.
- [ ] Source config rollback tested.
- [ ] No dual delivery.
- [ ] 1/5/25/50/100% evidence gates.

## Parity
- [ ] Canonical projection frozen.
- [ ] Legacy compact parity.
- [ ] Catch-up parity.
- [ ] Backfill parity.
- [ ] Import canonical parity.
- [ ] PII fields intentionally excluded.
- [ ] Ticket/variation/mixed/add-on fixtures.
- [ ] Payment plan/membership/renewal fixtures.
- [ ] Fee/tax/coupon fixtures.
- [ ] Full/partial refund fixtures.
- [ ] Child conflict/removal fixtures.
- [ ] Missing/invalid source fact fixtures.

## Security/privacy
- [ ] Recursive allowlist/forbidden-key tests.
- [ ] Customer/address/payment/provider/ticket secrets absent.
- [ ] Tampered HMAC rejected.
- [ ] Unknown contract no fallback.
- [ ] Payload/cardinality/string bounds.
- [ ] HTML/log/telemetry/evidence sanitised.
- [ ] Legacy debug PII redacted.
- [ ] Source WP logs safe.

## Reliability/performance
- [ ] Duplicate delivery tests.
- [ ] payload mismatch tests.
- [ ] stale/equal/new source tests.
- [ ] compact replay tests.
- [ ] redacted replay behaviour.
- [ ] Redis buffer maximum-body test.
- [ ] large mixed order builder/load test.
- [ ] no N+1 source queries.
- [ ] intake/processor latency comparison.
- [ ] catch-up repair canary.

## Production
- [ ] Exact cutover supplement.
- [ ] Staging native signature canary.
- [ ] Production exact-order canary.
- [ ] p50/p95 body reduction.
- [ ] no increased failure/lag/conflict.
- [ ] canonical mismatch zero.
- [ ] forbidden-field scan clean.
- [ ] rollback proven.
- [ ] 100% evidence window.
- [ ] legacy emission retirement decision.
- [ ] backend legacy replay support retained.
