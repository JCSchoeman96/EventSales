# Mandatory File Inventory — VS-27A

## Governance and roadmap
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`
- GitHub #81.

## Final predecessor artifacts
- certified VS-26F.1/F.2;
- certified VS-26G;
- certified VS-27B.1/B.2;
- certified VS-28A.1/A.2;
- certified VS-28B child stages;
- final VS-27D affected-period interfaces.

## Web intake/security
- `lib/event_sales_web/controllers/webhook_controller.ex`
- `lib/event_sales_web/endpoint.ex`
- `lib/event_sales_web/plugs/raw_body_reader.ex`
- `lib/event_sales_web/plugs/webhook_intake_pre_parser_guard.ex`
- `lib/event_sales_web/plugs/rate_limit_webhook_intake.ex`
- `lib/event_sales/ingestion/webhook_intake.ex`
- `lib/event_sales/ingestion/security/webhook_signature.ex`
- `lib/event_sales/ingestion/security/webhook_replay_guard.ex`
- `lib/event_sales/ingestion/webhook_event_store.ex`
- intake/security/controller tests.

## Buffer/enqueue/processor/replay
- `lib/event_sales/ingestion/redis_webhook_buffer.ex`
- buffer drain/store modules;
- `lib/event_sales/ingestion/webhook_enqueue.ex`
- `lib/event_sales/ingestion/workers/process_webhook_worker.ex`
- `lib/event_sales/ingestion/webhook_processor.ex`
- `lib/event_sales/ingestion/webhook_replay.ex`
- all duplicate/stale/replay/buffer tests.

## Webhook resources/debug/retention
- `lib/event_sales/ingestion/resources/webhook_event.ex`
- failure resources;
- `lib/event_sales/ingestion/webhook_debug.ex`
- `lib/event_sales_web/live/admin/webhooks_live.ex`
- `lib/event_sales/maintenance/raw_payload_purger.ex`
- purge worker/config/tests;
- migrations/resource snapshots/indexes.

## Parsers/writer
- `lib/event_sales/ingestion/parsers/woocommerce_order_parser.ex`
- parser fixtures/tests;
- `lib/event_sales/sales/order_upserter.ex`
- `lib/event_sales/sales/source_version_guard.ex`
- `lib/event_sales/sales/order_item_mapper.ex`
- Order/OrderItem/Coupon and final G resources/actions;
- writer tests and full webhook acceptance test.

## Catch-up/backfill/import
- final F REST parser/fetcher/runner;
- final A backfill source adapter;
- final B15 canonical import adapter;
- canonical DTO/projection/effect interfaces.

## Analytics/semantics
- final G field registry;
- final B.1 paid/completed/refund activity contract;
- final B.2 contribution/bucket notifier;
- final completeness/target resolver.

## WordPress current integration
- `integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`
- its README/tests/contract;
- explicit non-goal boundary;
- current product/event metadata SQL and keys.

## WordPress source evidence
At activation inspect exact installed:
- WordPress core;
- WooCommerce core `WC_Webhook`;
- current webhook API version/controller;
- Tickera;
- Tickera WooCommerce Bridge;
- WooCommerce Subscriptions/payment-plan plugins;
- HPOS state;
- EventSales plugins;
- configured webhooks and logs.

## Docs
- `docs/ops/woocommerce_order_payload_contract.md`
- `docs/architecture/webhook-security.md`
- `docs/architecture/idempotency-and-ordering.md`
- telemetry/privacy/fixture docs;
- source plugin runbooks.

## Config/CI
- `mix.exs`, `mix.lock`;
- config/runtime/test;
- Oban/Redis/webhook/maintenance settings;
- Railway/release files;
- architecture manifests/index;
- PHP lint/static tooling;
- no-web-Woo boundary script;
- CI workflows.
