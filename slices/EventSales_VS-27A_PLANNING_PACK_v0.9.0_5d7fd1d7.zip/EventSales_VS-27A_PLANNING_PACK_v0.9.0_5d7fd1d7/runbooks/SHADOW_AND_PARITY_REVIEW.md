# Shadow and Parity Review

## Preconditions

- backend dual-read certified;
- bridge installed in disabled mode;
- source snapshot behaviour certified;
- shadow mode approved;
- no production compact delivery.

## Enable shadow

Set bridge mode `shadow_preview`.

For the exact EventSales webhook only:

1. build the compact candidate;
2. validate schema/bounds/forbidden fields;
3. calculate safe candidate/canonical hashes and counts;
4. return the original legacy payload unchanged.

No second HTTP delivery.

## Collect safe evidence

Aggregate by contract/source plugin version:

- builder success/failure;
- legacy bytes;
- candidate compact bytes;
- reduction ratio;
- line/coupon/fee/refund counts;
- source-fact provenance;
- unsupported G sections;
- forbidden-field failures;
- candidate canonical projection mismatch;
- builder/query duration.

No order/customer ids as telemetry labels.

## Canonical parity

For representative source states compare:

```text
legacy source payload → legacy adapter
shadow compact candidate → compact adapter
```

Then compare with catch-up/backfill canonical projection where available.

Intentional PII omissions are excluded.

## Blockers

- paid/refund/fee/relationship source fact missing;
- collection completeness unknown;
- source event identity conflict rate unacceptable;
- compact over bound;
- any forbidden field;
- canonical mismatch;
- source performance regression;
- native legacy payload changed in shadow.

## Review

Generate a bounded redacted report and decide:

- READY FOR EXACT CANARY;
- EXTEND SHADOW;
- BLOCKED.
