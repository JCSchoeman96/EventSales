# Source Snapshot Verification

## Purpose

Prove that compact line source facts are numeric, bounded, provenance-bearing and stable enough for final EventSales attribution/semantic policy.

## Representative set

Use approved synthetic/staging examples for:

- simple product ticket;
- variation ticket;
- product/variation disagreement;
- mixed ticket/add-on order;
- subscription/payment-plan product;
- renewal order;
- legacy order without snapshot;
- order with existing Tickera metadata;
- missing/invalid event metadata.

## New-order snapshot

For each new line verify:

- snapshot version;
- numeric Tickera event id or explicit none/conflict/invalid;
- exact provenance basis;
- ticket template id where approved;
- product type / is-ticket facts where approved;
- product source updated timestamp;
- no display name used as identity;
- no customer/payment/provider/ticket-secret value.

## Priority test

Seed conflicting values across:

1. existing immutable order-line snapshot;
2. Tickera line metadata;
3. variation metadata;
4. parent metadata.

Verify the documented priority and conflict result.

Never silently choose a lower-priority conflicting value.

## Legacy order fallback

For a pre-bridge order:

- build compact candidate;
- verify `current_product_fallback` provenance;
- compare with current EventSales mapping;
- verify conflict becomes review evidence, not an attribution overwrite.

## Mutation behaviour

Update the product/event after order creation.

Verify a new-order immutable snapshot remains unchanged.

The compact payload may carry updated current-product facts separately only if the final registry allows them; they cannot replace sale-time snapshot provenance.

## Query/performance

Measure source queries for representative and maximum-line orders.

Require bounded prefetch; reject per-line repeated metadata queries that threaten checkout or webhook delivery.

## Evidence

Record safe ids/hashes, provenance counts, conflict counts and timings only.
