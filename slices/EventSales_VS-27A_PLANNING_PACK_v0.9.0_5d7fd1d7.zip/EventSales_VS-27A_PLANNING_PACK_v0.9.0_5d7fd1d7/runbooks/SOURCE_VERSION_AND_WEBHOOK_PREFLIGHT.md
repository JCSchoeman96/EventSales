# Source Version and Webhook Preflight

## Purpose

Capture exact WordPress/WooCommerce/Tickera and webhook facts before any implementation activation or production source change.

## Read-only source facts

Record:

- WordPress core version;
- WooCommerce version and package/source tag;
- WooCommerce HPOS enabled/authoritative/compatibility state;
- Tickera version;
- Tickera WooCommerce Bridge version;
- WooCommerce Subscriptions/payment-plan plugin versions;
- EventSales source plugin versions;
- PHP version;
- database engine/version;
- object cache;
- active theme only where hooks are overridden.

## Webhook inventory

For every Woo webhook record:

- webhook id;
- name;
- status;
- topic;
- resource/event;
- API version;
- delivery URL host/path, redacted path token;
- secret presence only;
- last delivery status/time;
- failure count/disable state;
- owning integration.

Identify the exact EventSales order webhook id(s).

Do not expose the secret or full path token.

## Native behaviour evidence

From the exact installed WooCommerce source:

- payload filter signature/arguments;
- JSON encoding point;
- HMAC generation point/algorithm;
- native headers;
- delivery id generation;
- retry/logging/disable policy;
- payload API version/controller.

Record exact file paths/tag/commit.

## Legacy payload sample

Using approved redacted diagnostics, measure:

- body bytes p50/p95/max;
- line/coupon/fee/refund counts;
- status distribution;
- presence of paid/completed timestamps;
- plugin/meta fields;
- PII/provider/ticket-secret fields;
- event-id metadata quality;
- mixed semantic cases.

Never attach raw production payloads.

## Source metadata evidence

For representative products/variations and orders, determine where these facts exist:

- `_tc_is_ticket`;
- `_event_name`;
- ticket template;
- subscription/payment-plan relationships;
- order-item Tickera metadata;
- refund/fee/tax data;
- variation versus parent inheritance.

## Verdict

- READY FOR FIELD FREEZE;
- REFRESH REQUIRED;
- BLOCKED.

Any unknown required source fact blocks compact schema finalisation.
