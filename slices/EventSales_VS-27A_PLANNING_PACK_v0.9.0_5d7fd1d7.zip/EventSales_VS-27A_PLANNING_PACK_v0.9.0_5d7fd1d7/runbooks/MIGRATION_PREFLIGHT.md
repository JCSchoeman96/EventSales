# Backend Migration Preflight

## Topology

Record:

- exact main/deployed SHA;
- PostgreSQL version and size;
- direct/session-capable migration route;
- pooler mode;
- Railway replicas;
- Oban/Redis health;
- current WebhookEvent row count/index size;
- payload retention backlog.

## Candidate changes

- payload family/contract/version/validation columns;
- optional canonical projection hash;
- indexes for family/version/status/time;
- safe debug DTO changes;
- contract registry/config;
- no source payload rewrite.

## Rules

- additive;
- no full-table payload parse in migration;
- no rewrite of JSON payload;
- existing rows remain legacy/unknown safely;
- index creation/lock strategy reviewed;
- Ash snapshots/migrations deterministic;
- payload purger continues to select/redact;
- replay queries remain indexed;
- rollback disables reads/features rather than deleting metadata.

## Existing data classification

If backfilling family metadata is useful:

- bounded background job after deploy;
- missing `contract` → legacy;
- redacted marker → redacted/unknown family based on existing metadata only;
- no raw payload copied to logs/evidence;
- restartable/idempotent.

Do not classify all rows inside a migration.

## Storage impact

Estimate:

- new column/index bytes;
- query plans;
- write amplification;
- telemetry cardinality;
- payload retention unchanged.

## Stop

- table rewrite/long lock;
- purger/replay incompatibility;
- unavailable direct migration route;
- index invalid;
- family backfill needs raw PII export;
- backend deployment would require simultaneous source cutover.
