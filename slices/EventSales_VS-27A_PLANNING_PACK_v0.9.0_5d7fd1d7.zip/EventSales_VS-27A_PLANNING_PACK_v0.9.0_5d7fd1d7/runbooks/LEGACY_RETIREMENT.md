# Legacy Emission Retirement

## Scope

This runbook retires legacy full-order payload emission from the configured EventSales webhook.

It does not remove the backend legacy parser or purge legacy stored payloads.

## Preconditions

- 100% compact emission certified;
- evidence window completed;
- at least one peak event cycle;
- required semantic/refund/fee/renewal cases observed or synthetically certified;
- no canonical mismatch or privacy finding;
- failure/lag/backpressure acceptable;
- catch-up recovery proven;
- rollback to legacy tested;
- exact retirement supplement approved.

## Review stored obligations

Count safely:

- unprocessed/retryable legacy WebhookEvents;
- failed legacy events eligible for replay;
- legacy events inside raw-payload retention;
- native delayed/retry deliveries;
- operational runbooks relying on legacy payload reveal.

All must have a support decision.

## Change support state

Record:

```text
legacy_woocommerce emission: deprecated/retired
legacy_woocommerce parser: parse_only
eventsales.order.v1 emission: preferred
eventsales.order.v1 parser: accepted/preferred
```

## Source configuration

Keep bridge mode `compact` for exact target webhook ids.

Retain source rollback capability while backend legacy parser remains.

## Documentation/operations

Update:

- source plugin README;
- contract registry;
- incident runbook;
- webhook debug support;
- retention/replay policy;
- ownership/contact;
- source deployment inventory.

## Post-retirement watch

Continue metrics for the reviewed period.

Any legacy source emission is flagged by family/version telemetry, not rejected while parser remains parse-only.

## Parser removal

Not part of this runbook.

Requires separate evidence after stored replay/late-delivery obligations expire.
