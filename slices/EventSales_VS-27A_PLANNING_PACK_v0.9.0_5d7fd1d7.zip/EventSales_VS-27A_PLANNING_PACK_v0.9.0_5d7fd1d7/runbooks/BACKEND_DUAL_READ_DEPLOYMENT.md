# Backend Dual-Read Deployment

## Preconditions

- Pack and implementation plan approved;
- VS-27A.1 activation approved;
- final compact schema hash recorded;
- migrations/indexes reviewed;
- source remains 100% legacy.

## Deploy

Deploy only:

- contract classifier/router;
- compact adapter;
- canonical presence semantics;
- WebhookEvent contract metadata;
- safe debug projection;
- telemetry;
- fixtures/tests/docs.

Do not install or enable the WordPress bridge.

## Migration verification

Confirm:

- new metadata columns/indexes exist and are valid;
- existing rows classify as legacy or unknown without rewriting payloads;
- payload retention still works;
- no table rewrite/lock problem;
- processing queues healthy.

## Legacy regression

Send or replay approved synthetic legacy fixtures and confirm:

- HMAC/intake unchanged;
- duplicate/stale behaviour unchanged;
- canonical Sales effects unchanged;
- dashboard/analytics notifier unchanged;
- product.updated unchanged;
- failure/replay UI unchanged except safer display.

## Compact synthetic validation

Through a controlled non-production or approved staging endpoint:

- sign exact compact body with native-compatible signature;
- persist and process;
- verify contract metadata;
- verify canonical projection;
- replay;
- tamper body;
- test unknown contract;
- test over-bound/forbidden field.

## Source remains legacy

Verify WordPress production webhook bodies and size distribution did not change because of backend deployment.

## Stop

- legacy fixture result drift;
- contract metadata breaks intake;
- stored replay regression;
- payload purger regression;
- product webhook regression;
- queue/error-rate increase.

## Exit

`CERTIFIED — WORDPRESS BRIDGE MAY BE INSTALLED DISABLED`.
