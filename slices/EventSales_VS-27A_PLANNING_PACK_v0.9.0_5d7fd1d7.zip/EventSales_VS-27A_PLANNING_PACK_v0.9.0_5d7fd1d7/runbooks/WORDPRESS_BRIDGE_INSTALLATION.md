# WordPress Bridge Installation

## Preconditions

- backend dual-read certified;
- VS-27A.2 implementation/review approved;
- plugin ZIP/SHA/version certified;
- exact source versions and target webhook ids refreshed;
- mode defaults disabled.

## Install

1. back up current plugin/config inventory;
2. install the exact bridge artifact;
3. configure target EventSales webhook ids;
4. set mode `disabled`;
5. set compact basis points `0`;
6. keep legacy fallback enabled;
7. configure contract/source-snapshot versions;
8. activate plugin;
9. verify no source/customer/payment mutation.

## Disabled proof

Trigger approved staging/synthetic order events and verify:

- payload bytes/hash equal native pre-plugin output for same source state where deterministic;
- every non-EventSales webhook remains unchanged;
- EventSales target webhook remains legacy;
- native delivery headers/signature/retry/logging unchanged;
- no duplicate HTTP request;
- no EventSales callback;
- source query/checkout latency acceptable.

## Snapshot capture

If enabled separately:

- create a new synthetic order;
- verify allowlisted hidden order-line metadata;
- verify no customer/provider/ticket token;
- verify event id and provenance;
- verify variation/parent behaviour;
- verify HPOS compatibility;
- verify metadata survives order update/refund as intended.

Snapshot capture and payload compaction should have independent flags for canary isolation.

## WP-CLI diagnostics

Run only safe commands returning:

- plugin/config versions;
- target webhook ids;
- mode/basis points;
- compact preview counts/bytes/hash;
- source-fact quality;
- forbidden-field verdict.

No raw customer/order payload.

## Stop

- any webhook other than target changes;
- checkout/order creation error;
- extra HTTP delivery;
- source logs contain raw payload/PII;
- snapshot conflicts or broad metadata writes;
- rollback to disabled fails.
