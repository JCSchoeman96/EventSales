# Operational Failure Matrix

| Stage | Failure | Safe response | Operator action |
|---|---|---|---|
| backend deploy | legacy regression | rollback app/disable router feature | investigate exact diff |
| intake | bad HMAC | 401, no persist | source secret/body review |
| intake | unknown contract | persist safe evidence, permanent fail | source fix/catch-up |
| intake | compact over bound | permanent fail | rollback/narrow payload |
| buffer | encoded entry over cap | 503/alert | lower compact limit |
| processor | transient DB | Oban retry | monitor |
| processor | schema/semantic permanent | failed event | source fix/catch-up |
| source install | non-target payload changed | disable plugin | configuration/code fix |
| snapshot | event provenance conflict | explicit conflict/no guessed id | catalog/case review |
| shadow | canonical mismatch | remain legacy | adapter/field fix |
| canary | signature reject | disable compact | HMAC/native source review |
| canary | privacy finding | immediate disable/security incident | purge/repair/evidence |
| canary | elevated lag/failure | disable or lower basis points | capacity/debug |
| canary | builder exception | approved legacy fallback + alert | bridge fix |
| canary | no fallback/strict failure | native delivery failure | immediate rollback |
| production | catch-up cannot repair | compact rollout blocked | canonical adapter fix |
| replay | legacy replay broken | backend rollback/fix | retain legacy support |
| replay | compact replay broken | rollout blocked | parser fix |
| retention | contract metadata lost | fix before retirement | migration/purger fix |
| retirement | unexpected legacy delivery | flag but parse | source inventory review |
| rollback | config does not restore legacy | stop, disable plugin | cache/config repair |
