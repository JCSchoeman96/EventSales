# VS-27A Production Validation

## Backend-only validation

- exact deployed SHA;
- contract metadata migration/index;
- source still legacy;
- legacy acceptance/processing/replay unchanged;
- product.updated unchanged;
- purger/debug safe;
- compact synthetic HMAC/parse/replay/security.

Verdict: backend dual-read certified or rejected.

## Bridge-disabled validation

- exact plugin artifact/version/SHA;
- exact target webhook ids;
- mode disabled/basis points zero;
- native target and non-target payload unchanged;
- no extra request;
- no checkout/source regression;
- rollback/uninstall proof.

Verdict: bridge disabled certified or rejected.

## Shadow validation

- safe candidate build success;
- compact byte distribution;
- source-fact provenance;
- canonical parity;
- final G/B sections;
- forbidden-field scan;
- source duration/query count;
- legacy delivery unchanged.

Verdict: ready for exact canary, extend or blocked.

## Exact canary

- approved webhook/order/config;
- native headers/HMAC/log;
- EventSales family/version/body size;
- canonical Sales effect;
- semantic/mapping/analytics;
- duplicate/stale/replay;
- catch-up recovery;
- privacy;
- source rollback.

Verdict: canary certified or rejected.

## Broadening

For each percentage record:

- time window/order counts;
- cohort coverage;
- failure/lag/body/buffer;
- parity mismatch;
- mapping/semantic conflicts;
- catch-up repairs;
- privacy findings;
- rollback readiness.

## 100% and retirement

- evidence window;
- peak cycle;
- full semantic/refund cases;
- stored legacy obligations;
- support-state update;
- legacy source emission retirement supplement;
- backend legacy parse-only retained.

## Final verdict

- `CERTIFIED — VS-27A COMPLETE`;
- `CERTIFIED WITH ACCEPTED RISK`;
- `REJECTED / BLOCKED`.

No further roadmap feature is implicitly unlocked without a new approved roadmap decision.
