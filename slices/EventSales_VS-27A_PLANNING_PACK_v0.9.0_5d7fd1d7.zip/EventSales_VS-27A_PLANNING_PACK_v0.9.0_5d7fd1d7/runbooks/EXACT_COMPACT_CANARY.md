# Exact Compact Canary

## Preconditions

- separate production cutover supplement says `APPROVE EXACT COMPACT CANARY`;
- exact backend/bridge/source versions match;
- exact EventSales webhook id and exact order allowlist match;
- mode rollback tested;
- source, EventSales, Redis/Postgres/Oban and catch-up healthy.

## Configure

- target only the approved EventSales webhook id;
- mode `canary`;
- basis points `0`;
- exact approved order id(s) allowlisted;
- fallback policy as approved;
- safe diagnostics enabled.

## Trigger

Use an approved synthetic or real low-risk order/update representing the selected semantic case.

Do not duplicate delivery manually unless the runbook explicitly tests native retry with a new delivery.

## Verify native delivery

- standard Woo headers present;
- native delivery id;
- HMAC validates over exact compact bytes;
- topic/resource unchanged;
- Woo delivery log status successful;
- no non-target webhook changed.

## Verify EventSales

- WebhookEvent family/version/size;
- compact schema valid;
- source modified timestamp;
- processor success;
- canonical projection hash;
- order/children/source facts;
- semantic/mapping result;
- analytics/notifier effect;
- no PII/provider/ticket secret;
- no duplicate effect.

## Recovery tests

- repeat same delivery/bytes → duplicate ignored;
- tampered signature → rejected;
- stale source update → ignored;
- compact permanent failure fixture → F catch-up repairs source truth;
- source builder failure → approved fallback/alert behaviour.

## Stop and rollback

At first stop condition set bridge mode `disabled`, confirm new deliveries legacy, and retain backend compact support for queued/stored events.

## Verdict

- CANARY CERTIFIED;
- CANARY REJECTED;
- BLOCKED.
