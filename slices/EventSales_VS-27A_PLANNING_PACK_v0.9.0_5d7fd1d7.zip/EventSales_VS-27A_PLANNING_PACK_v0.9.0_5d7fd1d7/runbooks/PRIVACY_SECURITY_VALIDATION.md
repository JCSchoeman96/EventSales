# Privacy and Security Validation

## Seeded forbidden values

Use distinctive synthetic values for:

- customer name/email/phone/address;
- order key;
- payment method title;
- transaction/reference id;
- provider payload/token;
- ticket code/QR hash;
- ticket/download/signed URL;
- arbitrary order/item metadata;
- HTML/script payload;
- webhook secret/signature.

## Source builder

Inspect compact candidate recursively.

All keys must be allowlisted.

Seeded forbidden values must be absent from:

- compact body;
- snapshot metadata;
- WordPress logs;
- safe diagnostics;
- telemetry;
- evidence;
- error messages.

## Backend

Inspect:

- stored WebhookEvent payload;
- contract metadata;
- parser error;
- failure resource;
- debug DTO/HTML;
- PubSub;
- logs/telemetry;
- replay audit;
- production evidence.

Legacy safe projection must redact the seeded values.

## HMAC

- valid native compact signature accepted;
- one-byte body mutation rejected;
- altered signature rejected;
- missing signature rejected;
- body re-encoding is not used for verification.

## Routing

- unknown explicit contract rejected;
- contract header cannot override body;
- missing contract legacy;
- product topic unchanged.

## Bounds

- over-size body;
- too many lines/children;
- overlong strings;
- deep/unexpected objects;
- duplicate child ids;
- unknown keys.

All fail closed without raw values in messages.

## WordPress isolation

Prove non-target webhooks receive the exact native payload.

Prove bridge creates no second outbound request.

## Static checks

New web/source code must not:

- log raw payloads;
- expose secrets;
- call EventSales from WordPress;
- write Sales outside writer;
- alter metrics/buckets/completeness;
- use name-based event identity.

## Evidence

Record only safe hashes, counts, versions and verdicts.
