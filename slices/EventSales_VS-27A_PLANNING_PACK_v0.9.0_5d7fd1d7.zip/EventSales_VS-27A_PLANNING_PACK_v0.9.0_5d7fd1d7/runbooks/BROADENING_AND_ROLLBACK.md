# Compact Broadening and Rollback

## Broadening ladder

Recommended deterministic compact basis points:

- 100 (1%);
- 500 (5%);
- 2,500 (25%);
- 5,000 (50%);
- 10,000 (100%).

Exact order allowlists may remain for rare semantic fixtures.

Each step requires a review checkpoint; no automatic progression.

## Per-step evidence

Compare compact versus legacy cohorts for:

- accepted/processed/failed;
- permanent/transient errors;
- source-to-visible lag;
- p50/p95/max bytes;
- Redis buffer rejection;
- duplicate/stale/mismatch;
- source builder failures/fallbacks;
- mapping/semantic conflicts;
- canonical mismatch;
- catch-up repair count;
- forbidden-field findings;
- WordPress query/delivery duration.

## Cohort caveat

Deterministic order-id sampling may correlate weakly with order chronology or source patterns. Review event/status/semantic representation, not only aggregate rates.

## Rollback

Set bridge mode `disabled`.

Verify:

- next targeted order emits legacy;
- EventSales continues processing queued compact;
- catch-up remains active;
- no config cache delay;
- non-target webhooks unaffected.

Do not roll back database migrations or remove compact parser during an incident.

## Incident classification

- source builder incident;
- signature/delivery incident;
- backend parse incident;
- semantic/parity incident;
- performance/backpressure incident;
- privacy incident.

Privacy or canonical mismatch forces immediate rollback.

## Resume

After correction:

- new bridge/backend version;
- repeat exact canary;
- restart at a lower reviewed percentage;
- do not reuse stale evidence as authorization.
