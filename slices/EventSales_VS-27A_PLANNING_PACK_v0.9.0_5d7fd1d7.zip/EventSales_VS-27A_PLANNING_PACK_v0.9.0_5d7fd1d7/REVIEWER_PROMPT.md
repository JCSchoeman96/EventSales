# Independent Reviewer Prompt — VS-27A

Review adversarially against exact current repository code, official WooCommerce behaviour and final predecessor contracts.

Block any design that:

- changes Sales, metric, completeness, import or correction authority;
- finalises fields before certified G/B/A/B15 inputs;
- omits paid-time, partial-refund, fee/tax or relationship facts required downstream;
- treats compact as a partial/delta payload;
- lacks explicit child collection completeness;
- falls back unknown explicit contracts to legacy;
- deletes or replaces the legacy parser;
- creates a second writer;
- changes raw-byte HMAC verification;
- implements custom HTTP delivery/retry;
- compacts every Woo webhook globally;
- overloads the catalog-feed plugin without addressing its explicit boundary;
- infers event id from names;
- reads mutable product metadata without provenance;
- lacks immutable order-line source snapshots for new orders;
- includes customer/address/provider/transaction/ticket-token data;
- populates omitted PII keys as nil and clears legacy data accidentally;
- lacks compact body/cardinality limits and Redis envelope proof;
- changes product.updated behaviour;
- delivers both compact and legacy copies to production;
- uses random canary selection;
- enables compact mode by deployment;
- cannot rollback to legacy by source config;
- lacks safe contract observability/debug projection;
- logs raw payloads in WordPress;
- claims parity from raw payload equality;
- omits catch-up/backfill/import adapter parity;
- retires legacy parse support before stored replay obligations expire;
- authorises production canary without exact supplement.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only.
