# WordPress Bridge Boundary

## Current fact

The existing repository integration is named and documented as a Tickera catalog feed. Its README explicitly says it does not shape order webhooks.

## Recommended artifact

Create a sibling plugin:

```text
integrations/wordpress/eventsales-order-webhook-bridge/
```

Do not silently add order mutation/delivery behaviour to the catalog-feed plugin.

## Responsibilities

The order bridge may:

- snapshot allowlisted product/Tickera source facts onto new order lines;
- build compact order payloads;
- target exact configured EventSales webhook ids;
- expose safe WP-CLI preview/diagnostics;
- support disabled/shadow/canary/compact modes;
- emit safe aggregate diagnostics.

It may not:

- send its own HTTP request;
- implement a second retry queue;
- change webhook secret/delivery URL;
- alter other integrations' webhooks;
- call EventSales;
- issue/revoke tickets;
- change payment/order status;
- mutate totals;
- expose customer/provider data;
- query EventSales during checkout or delivery.

## HPOS

Use WooCommerce order and item APIs.

Do not query `wp_posts` for order storage.

Product/Tickera postmeta reads remain source-catalog facts and must be bounded.

## Configuration

Candidate constants/options:

- target webhook ids;
- mode;
- compact basis points;
- exact allowlisted order ids for controlled tests;
- contract version;
- safe diagnostics enabled;
- maximum payload bytes/child counts.

Constants override options.

## Fail closed

If compact building fails for a targeted order:

- in canary mode, return unchanged legacy payload and emit a safe failure metric;
- in strict 100% mode, rollout policy must decide fallback versus delivery failure.

Initial production direction: fallback to legacy to preserve sales visibility, with a high-severity alert and no silent compact claim.

Exact strict-mode behaviour requires activation review.
