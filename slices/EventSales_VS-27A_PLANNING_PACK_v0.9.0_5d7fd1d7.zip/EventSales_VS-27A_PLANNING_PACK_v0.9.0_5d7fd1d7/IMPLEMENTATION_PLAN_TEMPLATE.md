# VS-27A Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Final predecessor interfaces
## 4. Exact production source/version evidence required
## 5. Current-code gap verification
## 6. Child-stage/PR sequence
## 7. Canonical normalized order/presence contract
## 8. Final G/B/A/B15 field registry
## 9. Compact v1 JSON schema
## 10. Child completeness/removal law
## 11. Contract classifier/router
## 12. Compact parser/error/bounds
## 13. Legacy parser preservation
## 14. OrderUpserter integration
## 15. WebhookEvent metadata/migration/index
## 16. Intake/stale/resource extraction
## 17. Redis buffer proof
## 18. Safe debug and retention
## 19. Telemetry/parity observability
## 20. Dedicated WordPress plugin structure
## 21. Native payload filter target checks
## 22. Source order-line snapshots
## 23. Variation/parent/Tickera provenance
## 24. HPOS/source performance
## 25. Deterministic canary and fallback
## 26. WP-CLI preview/diagnostics
## 27. Native HMAC/delivery proof
## 28. Legacy/compact/catch-up/backfill/import parity
## 29. Fixtures and canonical projection hash
## 30. Privacy/forbidden-field controls
## 31. Feature modes/kill switch
## 32. Tests-first sequence
## 33. Exact files/dependencies/config/migrations/generated files
## 34. PHP/Elixir/static/security/load commands
## 35. Rollout/canary/broadening
## 36. Rollback and incident handling
## 37. Legacy emission retirement/support window
## 38. Production supplements/evidence
## 39. Linear document gate mapping
## 40. Risks/stop conditions
## 41. Prohibited-actions statement
