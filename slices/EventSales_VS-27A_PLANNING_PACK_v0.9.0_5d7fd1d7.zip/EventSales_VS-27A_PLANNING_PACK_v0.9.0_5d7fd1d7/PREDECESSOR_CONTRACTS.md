# Predecessor Contracts — VS-27A

## VS-26F.1 / VS-26F.2

Woo webhooks remain the primary near-live path; catch-up is source-recovery authority.

Legacy REST payloads from catch-up and compact webhook payloads must converge on the same canonical normalized order and source-version guard.

VS-27A introduces no cursor, source scheduler, REST recovery or second writer.

## VS-26G

G owns line semantics for ticket, payment plan, membership, renewal, add-on, bundle, fee, tax and refund facts.

The compact field registry is not final until the certified G parser/contribution inputs are known. Source hints never override G policy.

## VS-27B.1 / VS-27B.2

B owns paid/completed sale time, status/refund activity, currency, contribution projection and bucket truth.

The compact contract must include the final source timestamps and source facts needed by B. It does not write metrics or buckets.

## VS-28A.1 / VS-28A.2

Backfill remains historical completeness authority.

Compact webhooks do not backfill history, certify completeness or replace the admin backfill workflow.

## VS-28B

VS-28B owns bounded imports, exports, reconciliation cases and audited corrections.

A compact webhook conflict uses normal source-version and issue/correction law. The transport contract is not an import or correction path.

## Existing legacy webhook

Missing `contract` continues to use the legacy Woo adapter during coexistence.

Stored legacy payload replay remains supported after source compact emission reaches 100%.
