# Current Code Webhook Map

| Current area | Current behaviour | VS-27A implication |
|---|---|---|
| WordPress integration | catalog-only plugin; README explicitly excludes order webhook shaping | create a dedicated order-webhook bridge or separately reviewed package |
| Woo sender | native full REST-style order webhook configured outside repo | preserve native delivery/retry/HMAC |
| Raw body | exact bytes captured before controller | unchanged |
| Signature | Base64 HMAC-SHA256 over raw body | unchanged |
| Intake | path token, signature, JSON, duplicate/stale, persist, enqueue | add classification/observability without weakening gates |
| Resource id | top-level `id` | compact keeps top-level id |
| Stale timestamp | `date_modified_gmt`, fallback `date_modified` | compact keeps strict `date_modified_gmt` |
| WebhookEvent | stores decoded payload and size; no contract family/version | add safe contract fields |
| Redis buffer | 256,000-byte encoded-entry cap; stores payload | compact body budget must leave envelope headroom |
| Processor | order topics call `OrderUpserter.upsert_from_webhook_event` | insert payload router/adapter boundary |
| OrderUpserter | directly invokes legacy parser | preserve public API but route known contract |
| Legacy parser | full Woo order; includes billing/payment PII | compact adapter omits forbidden fields |
| Legacy parser times | created/modified/completed; no paid time | compact field freeze must include final B.1 time |
| Legacy lines | product ids, totals, meta Tickera event id | compact uses explicit fields, not arbitrary meta |
| Legacy child sets | line/coupon lists, no completeness marker | compact declares collection completeness |
| Current writer | upserts incoming lines/coupons; does not delete omitted children | compact cannot be partial or ambiguous |
| Debug UI | admin can reveal stored payload | show contract and safe projection |
| Purger | redacts payload after default 90 days | retain contract metadata after redaction |
| Product webhook | product.updated shares intake/processor | outside compact order routing |
