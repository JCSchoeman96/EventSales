# Source Snapshot and Provenance

## Goal

Preserve sale-time line identity facts without inferring from mutable labels.

## New-order snapshot

Recommended source hook:

```text
woocommerce_checkout_create_order_line_item
```

Before the order line is saved, the bridge captures allowlisted hidden metadata such as:

- `_eventsales_snapshot_version`;
- `_eventsales_tickera_event_id`;
- `_eventsales_tickera_event_basis`;
- `_eventsales_ticket_template_id`;
- `_eventsales_product_type`;
- `_eventsales_tc_is_ticket`;
- `_eventsales_product_source_updated_at`.

The exact keys are versioned and private/hidden.

## Event identity

Priority must be evidence-driven:

1. existing immutable order-item event snapshot;
2. reviewed Tickera order-line metadata;
3. product/variation-parent `_event_name` positive id fallback;
4. no value with explicit `none`;
5. conflict/invalid state with no guessed id.

No event name/title parsing.

## Variation rules

Activation verifies whether Tickera metadata resides on:

- variation;
- parent product;
- both;
- copied order-item metadata.

The builder records the basis.

## Existing orders

Orders created before bridge activation may lack snapshots.

Fallback to current product metadata must be marked:

```text
current_product_fallback
```

It must not pretend to be sale-time immutable evidence.

Existing EventSales mapped attribution remains protected by current conflict rules.

## Source fact quality

Candidate values:

- `order_item_snapshot`;
- `tickera_order_item_meta`;
- `variation_meta`;
- `parent_product_meta`;
- `current_product_fallback`;
- `none`;
- `conflict`;
- `invalid`.

## Performance

At delivery:

- no external HTTP;
- no broad SQL query;
- prefetch/cache product metadata for all line product ids;
- one bounded order traversal;
- no source writes.

Snapshot writes happen during order-line creation, not webhook delivery.
