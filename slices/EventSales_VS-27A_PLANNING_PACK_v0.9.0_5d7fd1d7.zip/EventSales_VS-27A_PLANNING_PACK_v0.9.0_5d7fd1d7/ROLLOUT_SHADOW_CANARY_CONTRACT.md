# Rollout, Shadow and Canary Contract

## Phase 0 — Field freeze

- certify downstream field registry;
- capture production Woo/plugin/webhook versions;
- capture legacy payload size/cardinality;
- verify exact target webhook ids/destination;
- approve plugin boundary.

## Phase 1 — Backend dual-read

Deploy:

- classifier/router;
- compact parser;
- durable contract metadata;
- safe debug projection;
- parity/security tests.

Source remains 100% legacy.

## Phase 2 — WordPress disabled

Install/activate bridge with:

- target ids configured;
- mode disabled;
- zero basis points.

Verify all webhook bodies unchanged.

## Phase 3 — Shadow preview

Build compact candidate in WordPress but return legacy.

Record safe aggregate:

- builder result;
- candidate bytes;
- child counts;
- source-fact quality;
- candidate projection hash;
- forbidden-field result.

No raw body log.

## Phase 4 — Exact canary

Use one reviewed synthetic/staging order or exact production order allowlist under a cutover supplement.

Then optional deterministic basis points:

- 1%;
- 5%;
- 25%;
- 50%;
- 100%.

Each broadening is evidence-driven.

## Compare

- HMAC acceptance;
- permanent/transient failure;
- source-visible lag;
- payload bytes;
- Redis buffer compatibility;
- canonical projection mismatch;
- unmapped/semantic conflict;
- catch-up repairs;
- PII scan.

## Rollback

Set source mode disabled/legacy.

Do not roll back EventSales dual-read while compact events remain queued or replayable.

## No dual webhook delivery

Do not deliver both legacy and compact copies of the same source update to the production endpoint.

Shadow mode returns legacy only.
