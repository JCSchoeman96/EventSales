# Feature Flags and Modes

## EventSales backend

Candidate modes:

- `legacy_only`;
- `dual_read_compact_disabled`;
- `dual_read`;
- `compact_required_for_canary_validation`.

Default deployment: `dual_read` only after tests, while source emits legacy.

Unknown explicit contracts remain invalid in every mode.

## WordPress bridge

Candidate modes:

- `disabled`;
- `shadow_preview`;
- `canary`;
- `compact`.

### disabled

Return every native payload unchanged.

### shadow_preview

Build/validate compact candidate and emit only safe diagnostics; return legacy payload.

### canary

Use exact order allowlist and/or deterministic basis points.

### compact

Return compact for every targeted EventSales order webhook.

## Independent controls

- target webhook ids;
- compact basis points;
- exact order allowlist;
- strict/fallback build failure policy;
- source snapshot capture;
- safe diagnostics;
- contract version.

## Defaults

- snapshot capture disabled until source plugin review;
- payload shaping disabled;
- basis points zero;
- legacy fallback enabled for builder failures;
- compact parser backend deployed before source mode changes.

## Kill switch

Setting WordPress mode to `disabled` restores legacy bodies without EventSales deployment.

Backend dual-read remains available for already queued/stored compact events.

## No request-supplied mode

Mode, webhook ids, sampling and contract version come from trusted server configuration only.
