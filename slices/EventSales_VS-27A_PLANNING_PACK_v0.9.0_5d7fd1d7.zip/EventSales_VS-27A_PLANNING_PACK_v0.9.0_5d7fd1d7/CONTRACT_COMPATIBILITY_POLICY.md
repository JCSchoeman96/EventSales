# Contract Compatibility Policy

## Identifier

`eventsales.order.v1` names one stable semantic contract, not merely one serializer implementation.

## Compatible v1 changes

A change may remain v1 only when all supported v1 consumers can safely ignore it and required meaning does not change.

Examples:

- add an optional allowlisted diagnostic/source-fact field;
- add an optional child property with a documented default;
- tighten source builder output without rejecting previously valid v1 input only after evidence.

## Incompatible changes

Require a new exact contract identifier:

- new required field;
- changed field meaning or units;
- changed timestamp basis;
- changed money sign convention;
- changed child-completeness meaning;
- changed identity;
- removal/renaming of a field;
- partial/delta semantics;
- changed refund/fee relationship law;
- changed unknown-field policy.

## Unknown keys

The compact parser uses an exact allowlist.

Unexpected keys fail by default so source PII or arbitrary plugin metadata cannot leak under a nominal v1 contract.

A reviewed compatibility extension may permit specifically registered optional keys.

## Support states

Each contract family/version has one state:

- development;
- accepted;
- preferred;
- deprecated_emission;
- parse_only;
- retired.

## Source and backend sequencing

Backend support precedes source emission.

Source emission retirement never implies immediate backend parser removal.

## Documentation

The registry records:

- exact JSON Schema hash;
- parser version;
- source builder version;
- first/last supported deployment;
- required predecessor policy versions;
- support state;
- migration/rollback notes.
