# Scope Split Assessment

VS-27A is one source-contract outcome and must be delivered through independently reviewed stages.

## VS-27A.1 — Backend dual-read and observability

- contract classifier/router;
- compact parser;
- canonical presence semantics;
- WebhookEvent contract metadata;
- safe debug projection;
- parity/security tests;
- no WordPress changes.

## VS-27A.2 — WordPress source snapshot and compact builder

- sibling plugin;
- snapshot metadata;
- exact webhook targeting;
- disabled/shadow/canary modes;
- WP-CLI safe preview;
- PHP tests/lint/static checks;
- no production compact emission.

## VS-27A.3 — Production cutover and legacy emission retirement

- exact source/deployed preflight;
- canary supplement;
- deterministic broadening;
- rollback;
- evidence window;
- legacy support status.

## Mandatory split conditions

- final G/B field registry not certified;
- backend and source change in one PR;
- compact mode enabled by deployment;
- existing catalog plugin overloaded without review;
- any custom HTTP sender/retry;
- missing deterministic sampling;
- unknown contract fallback;
- incomplete child-set semantics;
- PII/debug behaviour unresolved;
- no production rollback without deployment.

## Successor

VS-27A is the final listed critical-path source contract. Further features require a new roadmap decision rather than silently extending this pack.
