# Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| missing contract | legacy route | none |
| unknown explicit contract | permanent fail | source fix/new delivery |
| blank/non-string contract | permanent fail | source fix |
| invalid compact schema | permanent fail | source fix/catch-up |
| missing date_modified_gmt | permanent fail | source fix |
| missing paid/completed time | anomaly per B.1 | source/catch-up review |
| unsupported status | permanent fail | contract update/source fix |
| child set missing/partial | permanent fail | full snapshot |
| duplicate child id | permanent fail | source fix |
| unsupported G section | rollout blocked | field registry update |
| forbidden PII key | permanent fail/high alert | source bridge fix |
| payload > compact limit | permanent fail | source fix/legacy fallback |
| Redis encoded entry too large | 503/fallback failure | lower limit/repair |
| signature invalid | 401 | secret/body fix |
| duplicate same delivery/bytes | ignored duplicate | none |
| same delivery/different body | mismatch incident | investigate |
| stale source version | ignored stale | none |
| equal source/different representation | writer/parity contract | investigate |
| compact parser transient DB issue | retry | normal Oban retry |
| compact parser permanent error | failed event | catch-up/source fix |
| source snapshot missing | fallback with provenance or blocker | mapping/source repair |
| source snapshot conflict | no guessed event id | issue/catch-up |
| WordPress builder error in canary | return legacy + safe alert | bridge fix |
| WordPress builder error strict compact | reviewed fallback/fail policy | rollback mode |
| wrong webhook targeted | unchanged payload required | config fix |
| non-EventSales webhook compacted | stop/rollback | bridge fix |
| shadow logs raw payload | security incident | disable/purge |
| parity mismatch | rollout blocked | adapter/registry fix |
| compact failure rate rises | rollback legacy | investigate |
| catch-up cannot reproduce compact truth | rollout blocked | canonical contract fix |
| stored compact replay fails | rollout blocked | backend fix |
| legacy parser removed early | blocked | restore support |
