# EventSales VS-27A Planning Pack

## Identity

- Slice: `VS-27A`
- Name: Compact EventSales Order Webhook Contract
- Pack: `0016_VS-27A`
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#81`
- Linear milestone: `M7 — Compact Source Contract and Privacy Hardening`
- Linear document: `VS-27A — Pack 16 Gate Ledger and Planning Record`
- Created: `2026-07-18T06:31:39Z`

## Authority

This ZIP authorises independent pack review and repository implementation planning only.

It does not authorise:

- code, dependency, migration, WordPress plugin or configuration changes;
- enabling compact webhook emission;
- changing any WooCommerce webhook;
- production delivery, replay, source mutation or payload retention change;
- merge, deployment or production canary.

Implementation remains blocked until:

1. Pack 16 is independently approved;
2. the implementation plan is independently approved;
3. VS-28B is certified and closed;
4. final VS-26F, VS-26G, VS-27B, VS-28A and VS-28B interfaces are refreshed;
5. exact production WooCommerce/plugin/webhook configuration is evidenced;
6. an activation supplement returns `APPROVE`.

Every production compact-emission canary and legacy-emission retirement requires a separate exact cutover supplement.

## Outcome

```text
final certified canonical order facts
→ versioned compact contract
→ backend dual-read and observability
→ dedicated WordPress bridge in disabled mode
→ deterministic compact canary
→ parity and privacy evidence
→ controlled 100% compact emission
→ legacy emission retirement
```

Native WooCommerce delivery identity, topic/resource headers, retries, logs and HMAC over the final JSON body remain intact.

## Critical doctrine

```text
Transport may become smaller.
Sales truth may not change.
Compact does not mean partial.
Missing explicit contract means legacy.
Unknown explicit contract never falls back.
No source PII is required for decision-grade sales truth.
```
