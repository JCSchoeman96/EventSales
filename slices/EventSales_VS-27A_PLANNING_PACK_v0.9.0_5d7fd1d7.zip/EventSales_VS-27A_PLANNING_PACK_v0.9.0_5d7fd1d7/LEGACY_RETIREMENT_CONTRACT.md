# Legacy Emission Retirement Contract

## Meaning

Retire legacy **source emission**, not necessarily the backend legacy parser.

## Preconditions

- compact emission at 100% for the evidence window;
- no parity mismatches;
- no elevated failure/lag/conflict rates;
- catch-up repairs proven;
- payload privacy scan clean;
- source/plugin rollback tested;
- stored compact replay proven;
- operations documentation updated.

## Evidence window

Activation sets a minimum based on:

- Woo native retry/disable horizon;
- EventSales payload retention;
- operational replay practice;
- peak sales periods;
- at least one real mixed semantic/refund case.

Planning default: 30 days plus one peak event cycle.

## Backend legacy reader

Keep legacy adapter for:

- stored historical webhook replay;
- delayed native deliveries;
- incident rollback;
- fixtures;
- catch-up/backfill adapters where applicable.

Removing it requires a separate reviewed migration after all stored legacy replay obligations expire.

## Contract support policy

Document:

- supported;
- preferred;
- deprecated emission;
- parse-only;
- retired.

## Source rollback

Even after retirement approval, bridge configuration can return legacy while backend reader exists.

## Data retention

Do not purge legacy payloads early merely because compact is active.

Existing 90-day redaction remains until separately changed.

## Close gate

VS-27A closes when compact emission is certified and legacy emission is formally deprecated or retired with rollback proof.

Parser deletion is not required.
