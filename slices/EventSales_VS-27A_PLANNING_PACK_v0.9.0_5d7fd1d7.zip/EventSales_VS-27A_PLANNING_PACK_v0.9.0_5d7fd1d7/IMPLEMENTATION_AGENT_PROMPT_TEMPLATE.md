# Implementation Agent Prompt Template — VS-27A

**Do not use until an activation supplement returns APPROVE.**

Activation fills:

- exact current main/deployed SHA;
- exact child stage;
- certified downstream field registry;
- exact WordPress/WooCommerce/Tickera/Subscriptions/HPOS versions;
- exact EventSales webhook ids/topics/API versions/destination;
- exact compact schema and bounds;
- exact router/parser/presence contract;
- exact source snapshot metadata/provenance;
- exact bridge plugin/config/modes;
- exact files/dependencies/config/migrations/tests;
- rollout/stop conditions;
- mapped Linear document gate.

Write tests first.

Implement only the activated child stage.

Open a PR and stop before merge, deployment, WordPress installation, webhook change or production delivery.
