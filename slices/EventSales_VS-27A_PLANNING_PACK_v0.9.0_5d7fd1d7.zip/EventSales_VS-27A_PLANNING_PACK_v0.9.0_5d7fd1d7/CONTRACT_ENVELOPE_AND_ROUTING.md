# Contract Envelope and Routing

## Candidate envelope

The compact v1 body keeps Woo source field names where they are already stable and useful:

```json
{
  "contract": "eventsales.order.v1",
  "snapshot_kind": "full_order",
  "id": 10001,
  "number": "ES-10001",
  "parent_id": 0,
  "status": "completed",
  "currency": "ZAR",
  "date_created_gmt": "2026-05-01T08:00:00Z",
  "date_modified_gmt": "2026-05-01T08:05:00Z",
  "date_paid_gmt": "2026-05-01T08:04:00Z",
  "date_completed_gmt": "2026-05-01T08:05:00Z",
  "total": "900.00",
  "discount_total": "100.00",
  "total_tax": "0.00",
  "shipping_total": "0.00",
  "shipping_tax": "0.00",
  "sets": {
    "line_items": "complete",
    "coupon_lines": "complete",
    "fee_lines": "complete",
    "refunds": "complete"
  },
  "line_items": [],
  "coupon_lines": [],
  "fee_lines": [],
  "refunds": []
}
```

The exact final fields are frozen during activation against certified G/B/A/B15 interfaces.

## Router

Recommended pure boundary:

```text
OrderPayloadRouter.classify(payload)
OrderPayloadRouter.parse(payload)
```

Classification:

| Input | Result |
|---|---|
| no `contract` key | `legacy_woocommerce` |
| `eventsales.order.v1` | `eventsales_order_v1` |
| unknown explicit string | permanent `unsupported_contract` |
| blank/null/non-string explicit value | permanent `invalid_contract` |

## Topic scope

The router is invoked only for:

- `order.created`;
- `order.updated`;
- any later explicitly certified order topic.

`product.updated` remains on its existing handler.

## Intake classification

After HMAC and JSON decode, intake may persist safe metadata:

- payload family;
- contract identifier;
- schema major/version;
- raw body size;
- source updated timestamp extraction result.

Full schema validation remains asynchronous after durable intake.

## Unknown contract handling

Unknown explicit contracts are persisted for operational evidence, then fail permanently.

They are not parsed as legacy.

## Compatibility API

`OrderUpserter.upsert_order/3` may remain public but must delegate to the router.

`upsert_normalized_order/3` remains the single canonical writer entry point.
