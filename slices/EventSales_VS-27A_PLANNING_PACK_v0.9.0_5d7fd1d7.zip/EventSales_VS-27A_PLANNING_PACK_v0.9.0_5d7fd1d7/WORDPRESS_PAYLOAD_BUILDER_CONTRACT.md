# WordPress Payload Builder Contract

## Hook

Use the native WooCommerce payload filter with four arguments:

```text
woocommerce_webhook_payload
(payload, resource, resource_id, webhook_id)
```

Return the original payload unless all target checks pass.

## Target checks

- WooCommerce loaded;
- resource is exactly `order`;
- webhook id is in configured EventSales allowlist;
- delivery destination matches the certified EventSales path/host when independently loaded;
- mode permits compact for this order;
- order object exists;
- source facts and bounds pass.

Never compact every order webhook globally.

## Deterministic canary

Candidate selection:

```text
HMAC_SHA256(canary_secret, order_id)
→ first integer
→ modulo 10,000
→ compare with compact_basis_points
```

The same order remains in the same family across retries/updates.

Exact order-id allowlist may override for a reviewed canary.

No random sampling.

## Builder

Load `WC_Order` and traverse:

- order header/timestamps/totals;
- product lines;
- coupons;
- approved fees;
- approved refunds/relationships.

Use Woo APIs and bounded prefetch.

## JSON types

- ids/quantities as integers;
- money as canonical decimal strings;
- dates strict RFC3339 UTC with `Z`;
- empty supported children as arrays;
- nullable optional dates as null;
- no floats;
- no arbitrary objects.

## Snapshot facts

Read immutable order-item snapshot first.

Fallback reads current product/parent metadata and records provenance.

No name parsing.

## Diagnostics

Safe preview includes:

- contract;
- order id;
- section counts;
- byte size;
- canonical/source-fact hashes;
- forbidden-field scan;
- validation result.

Do not print customer/payment/provider fields.

## Payload filter and signature

The filter returns an array. WooCommerce JSON-encodes the final payload and signs the exact final body through native delivery.

Do not compute or replace the signature.
