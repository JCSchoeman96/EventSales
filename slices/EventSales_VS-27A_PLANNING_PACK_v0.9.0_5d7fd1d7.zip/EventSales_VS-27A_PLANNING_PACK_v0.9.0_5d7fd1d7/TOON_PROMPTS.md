# TOON Prompts — VS-27A

## Planning agent
Task: Design exact staged compact webhook migration from current code.
Output: Complete implementation plan.
Boundary: No code/source operations.

## Contract reviewer
Task: Attack field registry, completeness, presence semantics and version routing.
Output: Contract verdict.
Boundary: Unknown explicit contract fails.

## Woo source reviewer
Task: Verify exact Woo filter/signature/delivery behaviour and installed-version compatibility.
Output: Source evidence verdict.

## Semantics reviewer
Task: Compare compact fields with final G/B refund, fee, tax, sale-time and relationship requirements.
Output: Missing-fact verdict.

## Privacy reviewer
Task: Attack body, source snapshots, stored payload, debug UI, logs, telemetry and evidence.
Output: Leakage verdict.

## Reliability reviewer
Task: Attack duplicate/stale/equal-version/replay/buffer/catch-up behaviour.
Output: Reliability verdict.

## WordPress reviewer
Task: Attack target selection, HPOS, snapshot provenance, performance, canary and rollback.
Output: Bridge verdict.

## Parity reviewer
Task: Compare legacy, compact, catch-up, backfill and import canonical projections.
Output: Parity verdict.

## Activation reviewer
Task: Refresh exact main/deployed/source versions/webhook config and downstream contracts.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
