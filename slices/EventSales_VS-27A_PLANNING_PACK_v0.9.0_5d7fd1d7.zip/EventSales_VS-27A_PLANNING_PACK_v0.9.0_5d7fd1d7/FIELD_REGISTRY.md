# Compact v1 Field Registry

This is the planning registry. Activation freezes the exact final registry.

## Required order identity and state

| Field | Rule |
|---|---|
| `contract` | exact `eventsales.order.v1` |
| `snapshot_kind` | exact `full_order` |
| `id` | positive Woo order id |
| `number` | bounded display/reference string; not identity |
| `parent_id` | non-negative integer where renewal/parent semantics require it |
| `status` | final certified Woo status allowlist |
| `currency` | uppercase ISO-style 3-character code |
| `date_created_gmt` | strict explicit UTC |
| `date_modified_gmt` | strict explicit UTC; source-version basis |
| `date_paid_gmt` | nullable strict UTC; preferred sale-time candidate |
| `date_completed_gmt` | nullable strict UTC |
| `total` | Decimal string |
| `discount_total` | Decimal string |
| `total_tax` | Decimal string |
| `shipping_total` | Decimal string if final G needs it |
| `shipping_tax` | Decimal string if final G needs it |
| `sets` | explicit child completeness |

## Conditional order relationship fields

Candidate fields frozen against G:

- `created_via`;
- `subscription_id`;
- `renewal_order`;
- `payment_method_code`;
- approved order-type/relationship facts.

No payment title or transaction id.

## Line items

Required candidate fields:

- `id`;
- `product_id`;
- `variation_id`;
- `name` as bounded display only;
- `quantity`;
- `subtotal`;
- `subtotal_tax`;
- `total`;
- `total_tax`;
- optional bounded tax-rate breakdown if G requires it;
- `source_facts`.

## Source facts

Candidate allowlist:

- `snapshot_version`;
- `tickera_event_id`;
- `tickera_event_id_basis`;
- `ticket_template_id`;
- `product_type`;
- `tc_is_ticket`;
- `product_source_updated_at`;
- final G subscription/payment-plan relationship fields.

Source facts do not declare final EventSales semantics.

## Coupons

- `code`;
- `discount`;
- `discount_tax`.

Coupon code retention/export use remains governed separately.

## Fees

Candidate final-G fields:

- id;
- name;
- tax class/status;
- total;
- total tax;
- bounded taxes.

## Refunds

Candidate final-G fields:

- refund id;
- created/modified GMT;
- amount/total;
- refunded line identities, quantities and monetary/tax amounts;
- no free-text reason unless separately approved.

## Forbidden extensions

No arbitrary `meta_data`, `extensions`, `raw`, provider or plugin map.

Every new field requires a new reviewed compatible version or explicitly optional allowlisted registry revision.
