# VS-27A — Compact EventSales Order Webhook Contract

## 1. Goal

Reduce near-live WooCommerce order webhook size and source PII exposure while preserving the exact canonical Sales effects produced by certified legacy, catch-up, backfill and import adapters.

## 2. Non-negotiable authority chain

```text
WooCommerce order state
→ native Woo webhook delivery
→ exact raw-byte HMAC verification
→ durable WebhookEvent
→ payload contract router
→ legacy or compact adapter
→ one canonical normalized order
→ existing source-version/semantic writer
→ analytics/completeness authority
```

VS-27A owns only payload transport and adapters.

## 3. Delivery stages

### VS-27A.1 — Backend dual-read and contract observability

- freeze candidate field registry against final predecessors;
- add exact contract classifier/router;
- add compact parser;
- keep legacy parser;
- preserve stored replay;
- add contract family/version/size telemetry and safe debug projection;
- add parity tests;
- deploy with compact emission disabled.

### VS-27A.2 — WordPress source snapshot and compact builder

- dedicated order-webhook bridge;
- immutable line source-fact snapshots for new orders;
- bounded compact builder;
- target only configured EventSales webhook ids;
- disabled/shadow/preview tooling;
- no production compact emission.

### VS-27A.3 — Canary, broaden and legacy-emission retirement

- deterministic order sampling;
- exact production supplement;
- rollback to legacy by configuration;
- compare failures, lag, payload size and Sales parity;
- broaden to 100%;
- retain backend legacy reader for stored replay and late delivery;
- retire legacy emission only after an evidence window.

No single PR should combine all stages.

## 4. Contract identity

Candidate exact identifier:

```text
eventsales.order.v1
```

Rules:

- exact known string routes to compact v1;
- missing contract routes to legacy;
- unknown, blank, non-string or unsupported explicit contract fails permanently;
- no fallback from an explicit unknown contract to legacy;
- product webhook topics do not use the order contract router.

## 5. Compact means complete

A compact payload is a full source snapshot for the included order and every supported child collection.

It includes explicit collection-completeness states. It is never an event delta, changed-field patch or selected ticket-only subset.

A partial payload would leave stale child rows because the current writer does not infer deletion from absence.

## 6. Privacy

The compact contract forbids:

- customer name/email/phone;
- billing or shipping addresses;
- IP/user-agent;
- provider payloads;
- payment tokens;
- transaction/reference ids;
- access codes;
- ticket URLs;
- QR/barcode hashes;
- delivery/download tokens;
- arbitrary order/item metadata.

A conditional low-cardinality payment-method code may be included only if final G proves it necessary.

## 7. Source facts

Source line facts may include:

- product and variation ids;
- immutable Tickera event id snapshot and provenance;
- ticket template id if G requires it;
- product type/subscription relationship facts if G requires them;
- source timestamps for fallback metadata.

Names and labels never establish identity.

## 8. Native Woo compatibility

Use WooCommerce's payload filter only for the exact configured EventSales webhook id(s).

Do not replace native delivery.

WooCommerce continues to own:

- webhook topic/resource/event headers;
- delivery id;
- delivery logging;
- retry/disable behaviour;
- final JSON encoding;
- signature over the final JSON body.

## 9. Canonical parity

Parity compares the canonical source-truth projection, not intentionally removed PII fields.

Required adapters:

```text
legacy Woo webhook
compact v1 webhook
F catch-up REST
A backfill REST
B15 import canonical input
→ canonical normalized order contract
```

Every adapter must produce equivalent required Sales facts for equivalent source state.

## 10. Rollout

Backend dual-read deploys first.

WordPress compact mode starts disabled, then deterministic canary sampling, then gradual broadening.

Changing to compact affects only the configured EventSales webhook. Other Woo integrations receive unchanged payloads.

## 11. Non-goals

- no new webhook endpoint;
- no custom signature scheme;
- no source REST callback from EventSales;
- no catch-up/backfill/import/correction changes;
- no metric/bucket/dashboard work;
- no customer/ticket delivery;
- no arbitrary Woo metadata;
- no immediate deletion of legacy parser;
- no product webhook compaction;
- no production cutover from pack approval.

## 12. Exit gate

A real source order emitted as compact v1 passes native HMAC/intake, produces the same certified canonical Sales effects as its legacy/full representation, contains no forbidden PII, fits bounded intake/buffer limits, survives duplicate/stale/replay tests, and can be rolled back to legacy emission without an EventSales deployment.
