# Webhook Contract Observability

## Durable metadata

Candidate additions to `WebhookEvent`:

- `payload_family`: legacy_woocommerce / eventsales_order;
- `payload_contract`: nullable exact string;
- `payload_contract_version`: nullable bounded string;
- `payload_validation_status`: unvalidated / valid / invalid / unsupported;
- optional `canonical_projection_hash` after parse;
- existing `raw_body_size`.

These remain after payload redaction.

## Intake

Classification happens after exact HMAC and JSON decode.

It must not trust a header instead of body contract.

## Debug list

Show:

- contract family/version;
- raw size;
- validation result;
- processing state;
- safe error code.

## Payload reveal

Return a safe projection:

- compact payload may be shown after allowlist sanitization;
- legacy payload must redact forbidden customer/payment/provider fields;
- no raw arbitrary metadata;
- replay remains server-side and does not require UI raw reveal.

## Telemetry

Low-cardinality labels only:

- family/version;
- topic;
- result;
- failure code;
- accepted via Postgres/Redis.

Measurements:

- body bytes;
- line/coupon/fee/refund counts;
- parse duration;
- processing duration;
- compact ratio;
- validation failures.

No order id, delivery id, event id, payload hash or customer value as telemetry label.

## Dashboard/canary

Production canary evidence compares:

- acceptance rate;
- permanent/transient failure rate;
- source-to-visible lag;
- p50/p95 payload bytes;
- buffer-too-large count;
- duplicate/stale rate;
- canonical projection mismatch count;
- unmapped/semantic conflict rate.

## Purger

Payload redaction preserves contract metadata and processing evidence.

Retention changes are out of scope unless separately reviewed.
