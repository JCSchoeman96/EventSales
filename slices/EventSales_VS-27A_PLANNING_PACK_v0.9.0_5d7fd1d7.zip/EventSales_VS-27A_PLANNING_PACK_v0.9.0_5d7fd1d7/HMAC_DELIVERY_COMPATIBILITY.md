# Native HMAC and Delivery Compatibility

## Locked direction

VS-27A preserves native WooCommerce webhook delivery.

The payload filter changes only the payload array for the configured EventSales webhook.

## Preserved headers and behaviour

- `X-WC-Webhook-Topic`;
- `X-WC-Webhook-Resource`;
- `X-WC-Webhook-Event`;
- `X-WC-Webhook-ID`;
- `X-WC-Webhook-Delivery-ID`;
- `X-WC-Webhook-Signature`;
- source header;
- native HTTP timeout/logging/retry/disable policy.

## Signature

WooCommerce signs the final JSON body after payload construction.

EventSales continues to verify Base64 HMAC-SHA256 over exact raw body bytes.

No canonical JSON re-encoding is used for signature verification.

## Delivery id

Do not generate a custom id.

Existing duplicate-delivery and payload-mismatch semantics remain authoritative.

## HTTP args

Avoid `woocommerce_webhook_http_args` unless a reviewed need exists.

No custom contract header is required for routing; the signed body is authoritative.

## Endpoint

Keep the same EventSales webhook route/path token unless a separate security migration is approved.

## Verification

Production/staging evidence must prove:

- native signature validates for compact body;
- tampered compact bytes reject;
- unchanged non-EventSales webhook payload/signature;
- delivery log records compact body safely under Woo debug policy;
- retries use native behaviour;
- rollback to legacy requires only bridge configuration.
