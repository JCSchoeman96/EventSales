# Backend Dual-Read Contract

## Components

Candidate modules:

```text
EventSales.Ingestion.Parsers.OrderPayloadRouter
EventSales.Ingestion.Parsers.EventSalesOrderV1Parser
EventSales.Ingestion.OrderPayloadContract
```

## OrderUpserter boundary

Current:

```text
OrderUpserter.upsert_order
→ WoocommerceOrderParser
→ upsert_normalized_order
```

Target:

```text
OrderUpserter.upsert_order
→ OrderPayloadRouter
→ legacy or compact adapter
→ upsert_normalized_order
```

No second writer.

## Error contract

Compact parser errors use bounded permanent codes:

```text
invalid_contract
unsupported_contract
invalid_snapshot_kind
missing_required_field
invalid_field
invalid_collection_state
duplicate_child_identity
payload_bound_exceeded
unsupported_semantic_section
```

No raw value in error messages.

## Legacy adapter

The existing parser remains available.

Refactoring it behind a common behaviour must not change existing successful/failed fixture behaviour unless final predecessors explicitly require it.

## Presence semantics

Canonical DTO supports optional-field presence.

Compact omission of forbidden fields does not clear existing legacy attributes.

## Webhook processor

Processor lifecycle, duplicate/stale gates, retries and terminal states remain unchanged.

Only the parser/router seam changes.

## Stored replay

Replaying a stored legacy event still routes legacy.

Replaying a stored compact event still routes compact.

Payload redaction prevents replay as today; contract metadata remains visible.

## Product topics

`product.updated` bypasses the order router and existing behaviour remains unchanged.

## Contract compatibility

Adding an optional field under v1 is allowed only if old parsers ignore it safely and the registry permits it.

Changing required meaning requires a new contract identifier.
