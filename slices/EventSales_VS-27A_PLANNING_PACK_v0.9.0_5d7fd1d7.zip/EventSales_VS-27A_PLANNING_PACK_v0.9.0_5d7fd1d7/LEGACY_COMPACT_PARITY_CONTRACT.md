# Legacy and Compact Parity Contract

## Parity target

Do not compare raw payload equality.

Compare the certified canonical Sales truth projection produced from equivalent Woo source state.

## Canonical projection

Activation freezes fields including:

- source/order identity;
- status/currency;
- source created/modified;
- paid/completed sale timestamps;
- approved order totals;
- complete child-set markers;
- line identities/products/variation/quantity/money/tax;
- source event identity and provenance;
- coupons;
- final G fee/refund/relationship facts;
- semantic input versions;
- no forbidden PII.

## Required comparisons

```text
legacy webhook adapter
compact v1 adapter
F catch-up adapter
A backfill adapter
B15 import adapter
```

All produce the same canonical projection when given the same source facts and completeness.

## Intentional differences

Legacy may produce customer/payment fields that compact intentionally omits.

These fields are outside compact parity unless a later certified domain requirement explicitly keeps them.

## Decimal and time

- Decimal string normalization;
- exact UTC instants;
- no float comparison;
- no timezone-less acceptance;
- nil and absent are distinct where presence semantics matter.

## Source metadata fallback

Parity fixtures include:

- immutable order-line event snapshot;
- valid current-product fallback;
- missing event fact;
- invalid/conflicting event facts;
- variation-parent fallback.

## Semantic fixtures

Final suite includes:

- simple ticket;
- variation ticket;
- mixed ticket and add-on;
- payment plan/subscription;
- renewal;
- fee/tax;
- full refund;
- partial refund;
- coupon;
- on-hold EFT;
- cancelled/failed;
- child removal/conflict;
- missing paid/completed time.

## Proof

For each fixture record:

- legacy payload hash;
- compact payload hash;
- canonical projection hash;
- compact byte reduction;
- forbidden-field scan;
- writer result/effect identity.

A parity mismatch blocks source rollout.
