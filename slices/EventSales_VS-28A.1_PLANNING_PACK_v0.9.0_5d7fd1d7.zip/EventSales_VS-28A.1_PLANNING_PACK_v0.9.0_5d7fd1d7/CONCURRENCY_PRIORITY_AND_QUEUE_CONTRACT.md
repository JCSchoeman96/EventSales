# Concurrency, Priority and Queue Contract

## Queue

Recommended dedicated queue:

```text
historical_backfill: 1
```

Final name/concurrency is activation-controlled.

Do not share the source-critical `webhooks` queue.

## Source authority

One active historical campaign per source through a partial unique database index.

A campaign is active while in:

- preview_queued;
- previewing;
- preview_ready when holding an approved source snapshot;
- execution_queued;
- running;
- pausing;
- paused;
- cancelling.

The plan must decide whether long-lived `preview_ready` blocks another campaign; default yes until expired/cancelled.

## Shared REST limit

WooCommerce REST concurrency remains globally at most two.

The current rate limiter is node-local on current main; activation must consume final F.1/F.2 global topology/guard.

Backfill may use at most one concurrent source request.

## Priority to near-live truth

Before each source request, check certified operational signals:

- active F.1/F.2 catch-up run;
- catch-up lag/stale state;
- webhook queue backlog;
- source circuit breaker;
- production peak guard;
- operator pause.

Planning default:

- if catch-up is running or source lag exceeds five minutes, snooze;
- if webhook backlog exceeds its certified threshold, snooze;
- if circuit open, use source-defined cooldown.

These are policy defaults to validate, not hidden constants.

## Cooperative work

One worker execution performs at most:

- one page fetch and durable page step; or
- one local certification/rebuild poll step.

No unbounded while loop.

Planning wall-time budget: 30 seconds per job.

## Oban uniqueness

Use unique jobs for campaign/window/pass/page/generation.

Database state remains authoritative.

## Cron/scheduling

A.1 core does not require recurring campaign creation.

Repair/stuck-job workers may use maintenance Cron if needed. Activation must merge existing Cron entries rather than overwrite predecessor schedules.

## Multiple nodes

Correctness cannot depend on:

- ETS;
- process-local locks;
- one Railway replica;
- PubSub delivery;
- Oban job uniqueness alone.

Database uniqueness, row locks and generations provide convergence.
