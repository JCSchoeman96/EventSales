# Candidate Order and Mapping Contract

## Source-wide classification

Do not duplicate current event-scoped pre-parser filtering.

Each Woo order is classified once against the immutable selected-event snapshot.

## Relevant line precedence

A line is relevant when one or more apply:

1. valid `tickera_event_id` resolves to a selected event;
2. exact product/variation mapping snapshot resolves to a selected event;
3. the local known order already contains the same Woo line id assigned/pending for a selected event.

Conflicts fail closed.

## Event boundary check

For a resolved selected event:

```text
order.date_created_gmt >= event_scope.source_created_at
```

An earlier order is an anomaly and blocks certification.

## Known order

For an already persisted order:

- always allow current order header/status refresh when the order is relevant to selected scope;
- preserve/include known selected-event line identities;
- include newly relevant lines;
- an empty newly relevant line list may still refresh header/status;
- do not delete old children unless final G writer contract explicitly supports authoritative deletion.

## New order

- relevant lines only are passed to the certified writer contract;
- mixed selected events remain in one order upsert;
- irrelevant line/customer data is not persisted merely because the order was scanned;
- entirely irrelevant order is scan evidence only.

## Mapping conflicts

Examples:

- source Tickera event id and mapping point to different events;
- product/variation maps ambiguously;
- line metadata invalid;
- ticket type event mismatch.

Persist safe failure/finding and block metric completeness.

## Unknown semantics

If a line is confidently attributable to a selected event but G semantics are unknown:

- ingest under the certified pending/unknown path if supported;
- do not count it;
- record event metric completeness `blocked_by_semantics`;
- preserve enough stable source identity for later correction.

## Historical mapping limitation

Current mapping PaperTrail excludes create actions.

Therefore A.1 cannot infer historical mapping truth solely from version rows.

The final implementation must rely on:

- current certified mappings;
- source Tickera event metadata;
- any final G historical semantic evidence;
- explicit unresolved findings.

## Mapping snapshot drift

Execution rejects if the approved mapping/semantic snapshot changed.

A later remap/correction triggers B.2 correction and may supersede the metric certificate.
