# Durable Progress and State Machine

## Campaign resource

Candidate fields:

- source system;
- state;
- frozen lower/upper;
- selection/plan hash;
- requested/approved metadata ids;
- current phase;
- counts;
- safe error;
- started/finished/paused/cancelled timestamps;
- source/candidate/contract versions.

## Campaign states

```text
draft
→ preview_queued
→ previewing
→ preview_ready
→ execution_queued
→ running
→ completed
```

Side states:

- pausing → paused → running;
- cancelling → cancelled;
- blocked;
- failed.

No completed transition unless all event scopes and certification prerequisites have explicit final states.

## Event-scope states

- selected;
- preview_ready;
- executing;
- ingested;
- analytics_pending;
- certified;
- excluded;
- blocked_boundary;
- blocked_source_drift;
- blocked_processing;
- blocked_semantics;
- blocked_catchup;
- blocked_analytics.

Campaign may complete with some explicitly excluded/blocked event scopes only if the approved plan allowed partial campaign completion and no certificate is falsely issued.

Planning default: any selected event blocker blocks campaign completion.

## Window states

- pending_preview;
- preview_scanning;
- preview_ready;
- subdivided;
- pending_execution;
- executing;
- completed;
- drifted;
- too_dense;
- failed;
- cancelled.

## Durable claim

Use database locking/state transitions for one worker claim.

Oban uniqueness is not state authority.

Candidate claim metadata:

- worker/job id;
- lease/claimed_at;
- attempt;
- generation/revision.

Stale lease recovery must be bounded.

## Step transaction

For one page:

1. lock campaign/window and verify generation/state;
2. fetch outside or under a reviewed two-phase lease;
3. persist identity/failure/order results;
4. advance page only after success;
5. commit;
6. enqueue/snooze next step after durable progress.

Network calls should not hold long database transactions.

## Revision/generation

Every refreshed preview/execution generation invalidates stale workers.

A stale worker cannot:

- advance a newer page;
- complete a drifted window;
- issue a certificate;
- regress counts/state.

## Pause

Pause requested:

- stop claiming new source pages;
- allow current bounded page step to finish;
- transition to paused;
- retain all progress.

## Cancel

Cancel requested:

- stop future work at safe step boundary;
- mark remaining windows cancelled;
- retain Sales writes and evidence;
- issue no certificate;
- resume requires new campaign/explicit reviewed rule, not silent uncancel.

## Resume

Paused campaigns resume exact durable window/pass/page and are idempotent.
