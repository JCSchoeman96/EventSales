# Scope Split Assessment

A staged implementation is strongly recommended.

## Stage A — Boundary and preview foundation

- feed/Catalog source-created field;
- campaign/event/window/identity resources;
- page metadata client;
- preview worker and plan hash;
- no Sales writes.

## Stage B — Execution and durable progress

- execution pass;
- final F/G candidate classifier integration;
- parser/OrderUpserter path;
- failures, pause/resume/cancel;
- source priority/concurrency.

## Stage C — Seam, analytics and certificate

- F.1/F.2 seam checks;
- B.2 readiness;
- ingestion/metric certificates;
- supersession/revocation;
- production canary runbooks.

Split is mandatory when:

- source-created feed extension is not independently certified;
- F.1/G/B.2 interfaces are still moving;
- page/window engine and Sales mutation are too broad for one exact-head review;
- production source proof is mixed with code implementation;
- migration/index locks require separate review.

All stages remain one VS-28A.1 authority. VS-28A.2 starts only after core certification.
