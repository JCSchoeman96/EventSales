# Source-Created Event Boundary Contract

## Authority

The default historical lower bound is the Tickera event's source creation timestamp in UTC.

Preferred provenance:

```text
WordPress tc_events post_date_gmt
→ signed catalog feed
→ Catalog Event source_created_at
→ immutable backfill event-scope snapshot
```

## Forbidden substitutes

- EventSales `inserted_at`;
- EventSales `updated_at`;
- event `starts_at`;
- event `ends_at`;
- source `event_source_updated_at`;
- first ProductMapping insertion;
- first locally observed order;
- current date minus arbitrary lookback.

## Feed extension

Candidate field:

```text
event_source_created_at
```

Requirements:

- UTC ISO8601 ending in `Z`;
- sourced from WordPress post creation time;
- no local timezone ambiguity;
- included in event and catalog-row representation as appropriate;
- schema/version compatibility explicit;
- signed response;
- no new PII.

## Local Catalog

Candidate Catalog field:

```text
source_created_at :utc_datetime_usec
```

Rules:

- source-owned update path;
- may be corrected only from stronger source evidence;
- correction is audited/versioned;
- never silently moved later once a completeness certificate exists;
- relationship to external event id/source explicit.

## Existing events

Before preview:

1. refresh certified catalog source;
2. require non-null source-created time;
3. compare with source-updated/start/end for obvious anomalies;
4. record feed schema/snapshot;
5. block invalid/zero dates.

## Conservative earlier override

A.1 core may support an explicit earlier boundary with:

- global-admin workflow supplied later by A.2;
- reason and evidence reference;
- `override <= source_created_at`;
- bounded campaign impact;
- audit;
- immutable scope snapshot.

A later override is forbidden.

## Anomaly

If a relevant order was created before the approved event boundary:

- record `order_before_event_boundary`;
- block event certification;
- refresh/repair boundary;
- do not silently discard the order.
