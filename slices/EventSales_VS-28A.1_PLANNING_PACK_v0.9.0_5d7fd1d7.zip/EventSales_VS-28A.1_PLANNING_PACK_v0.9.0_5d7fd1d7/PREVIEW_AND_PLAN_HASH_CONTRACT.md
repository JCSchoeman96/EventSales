# Preview and Exact Plan Hash Contract

## Purpose

A preview proves bounded source scope before Sales mutation and gives VS-28A.2 a human-reviewable plan.

## Preview pass

For every final leaf window:

1. fetch every bounded page;
2. locally filter exact half-open creation window;
3. persist distinct non-PII identity rows for `pass=preview`;
4. evaluate candidate counts in memory through certified F/G logic;
5. record unresolved boundary/mapping/semantic findings;
6. verify totals and distinct count;
7. mark window preview-complete.

No `OrderUpserter` call.

## Preview outputs

- selected event snapshots;
- lower boundaries and provenance;
- frozen upper;
- window tree;
- source total identities;
- relevant-order and line counts by event;
- unresolved counts/reasons;
- estimated REST pages;
- mapping and semantic versions;
- catch-up/B.2 prerequisites;
- plan hash.

No customer/order PII beyond source order ids needed for identity proof.

## Exact plan hash

Use deterministic canonical serialization of:

- campaign/source;
- event selection snapshot hash;
- boundaries;
- frozen upper;
- final leaf windows;
- each preview identity set hash/count;
- classifier/mapping/semantic versions;
- REST/window bounds;
- expected prerequisites.

Do not hash raw payloads.

## Approval

Execution queue input includes:

- campaign id;
- exact plan hash;
- approval actor/reason added by A.2;
- approval timestamp.

A.1 core rejects:

- missing hash;
- stale hash;
- event-scope drift;
- mapping/semantic version drift;
- changed frozen boundaries/settings.

## Execution verification pass

For each window:

1. clear/create execution identity set;
2. refetch all pages under same window;
3. persist execution identities;
4. process relevant payloads;
5. compare preview and execution identity sets exactly;
6. mark complete only if equal and all relevant processing succeeded.

Identity drift causes:

```text
plan_drifted
```

No completeness certificate is issued. A refreshed preview is required.

## Human delay

A long delay between preview and execution increases drift probability. A.2 must show preview age.

Planning default maximum plan age: 60 minutes.

Activation may tighten based on source behaviour.
