# VS-28A.1 Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] F.1/F.2 certified.
- [ ] G certified.
- [ ] B.1/B.2 certified.
- [ ] Woo/WordPress versions recorded.
- [ ] Railway/Postgres/Oban topology recorded.
- [ ] Activation verdict APPROVE.

## Event boundary
- [ ] Source-created timestamp field exists.
- [ ] Signed feed provenance.
- [ ] Strict UTC parse.
- [ ] Existing selected events refreshed.
- [ ] Missing/invalid boundary blocks.
- [ ] No forbidden substitute.
- [ ] Earlier override only with evidence.
- [ ] Relevant order before boundary blocks.

## Selection/snapshot
- [ ] One source.
- [ ] Explicit public/live events.
- [ ] Private/draft excluded.
- [ ] Old unselected excluded.
- [ ] Eligibility rechecked.
- [ ] Immutable event-scope snapshot.
- [ ] Mapping/semantic versions.
- [ ] Deterministic selection hash.
- [ ] Bounds enforced.

## Source client/windows
- [ ] Page API returns totals.
- [ ] One page/per-page owner.
- [ ] All statuses.
- [ ] UTC date filtering.
- [ ] Local half-open filter.
- [ ] Initial/dense/minimum bounds.
- [ ] Deterministic subdivision.
- [ ] Full limit never success.
- [ ] Header inconsistency blocks.
- [ ] Same-second ids tested.

## Preview
- [ ] No Sales writes.
- [ ] Non-PII identities only.
- [ ] Exact distinct identity proof.
- [ ] Relevant/unresolved counts.
- [ ] Plan hash deterministic.
- [ ] Plan age bounded.
- [ ] Hash/version drift rejects.
- [ ] A.2 DTO safe.

## Execution
- [ ] Exact plan hash required.
- [ ] Execution identity set.
- [ ] Preview/execution set equality.
- [ ] Mixed-event order once.
- [ ] Known-order header/status handling.
- [ ] Final F/G classifier.
- [ ] Existing parser/OrderUpserter only.
- [ ] Irrelevant orders not persisted.
- [ ] Relevant failure blocks page.
- [ ] Partial writer retry repairs.
- [ ] No raw payload evidence.

## State/progress
- [ ] Campaign state machine.
- [ ] Event state machine.
- [ ] Window state machine.
- [ ] One active campaign/source.
- [ ] Durable claim/lease.
- [ ] Generation fence.
- [ ] Page progress after commit.
- [ ] Pause at safe boundary.
- [ ] Cancel no rollback/certificate.
- [ ] Resume exact progress.
- [ ] Stale job cannot regress.

## Priority/concurrency
- [ ] Dedicated queue.
- [ ] Backfill request concurrency one.
- [ ] Global Woo maximum two.
- [ ] Near-live catch-up priority.
- [ ] Webhook backlog guard.
- [ ] Circuit/peak guard.
- [ ] One bounded step/job.
- [ ] Multiple-node safe.

## Failure/evidence
- [ ] Bounded failure resource.
- [ ] No PII/raw payload.
- [ ] Retryable/non-retryable classes.
- [ ] Attempts/backoff.
- [ ] Failure resolution retained.
- [ ] Safe telemetry.

## Seam and analytics
- [ ] Historical upper frozen.
- [ ] F cursor committed through upper.
- [ ] No blocking catch-up failure.
- [ ] B.2 projection caught up.
- [ ] Required range buckets ready.
- [ ] Currency/version parity.
- [ ] Analytics failure blocks metric certificate.

## Completeness
- [ ] Ingestion coverage separate.
- [ ] Metric certificate separate.
- [ ] Per-event `certified_from`.
- [ ] Evidence hashes/counts.
- [ ] One active exact-version certificate.
- [ ] Supersession/revocation.
- [ ] Current freshness remains F.2.
- [ ] D target resolver uses certificate, not copied boolean.

## Tests
- [ ] Boundary exact instants.
- [ ] Missing/invalid source creation.
- [ ] Public/private transition.
- [ ] Dense subdivision/minimum failure.
- [ ] Header/page-limit cases.
- [ ] Preview/execution drift.
- [ ] Duplicate/stale/out-of-order jobs.
- [ ] Interruption/resume.
- [ ] Mixed-event/known order.
- [ ] Mapping conflict/unknown semantics.
- [ ] Partial upserter failure/retry.
- [ ] Catch-up seam.
- [ ] B.2 pending/failure/readiness.
- [ ] Certificate issue/supersede/revoke.
- [ ] Privacy/static boundaries.
- [ ] Full CI.

## Production certification
- [ ] One selected public event.
- [ ] Authoritative source-created boundary.
- [ ] Preview reviewed.
- [ ] Exact plan approved separately.
- [ ] Controlled interruption/resume.
- [ ] No duplicate Sales effects.
- [ ] Source/candidate counts reconciled.
- [ ] Catch-up seam closed.
- [ ] B.2 ready.
- [ ] Certificate recorded.
- [ ] No target armed.
- [ ] Rollback/kill switch tested.
