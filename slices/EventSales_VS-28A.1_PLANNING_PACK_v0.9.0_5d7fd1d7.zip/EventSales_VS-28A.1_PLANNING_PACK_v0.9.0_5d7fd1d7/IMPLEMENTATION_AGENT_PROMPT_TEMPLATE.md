# Implementation Agent Prompt Template — VS-28A.1

**Do not use until an explicit activation supplement returns APPROVE.**

Activation fills:

- exact current main SHA;
- certified F.1/F.2/G/B.1/B.2 interfaces;
- exact Woo/WordPress versions and source API proof;
- final event source-created boundary contract;
- final campaign/window/identity/failure resources;
- final scan/subdivision/plan-hash algorithm;
- final candidate classifier/writer integration;
- final queues/concurrency/priority;
- final seam/B.2/certificate interfaces;
- exact staged PR scope/files/migrations/tests;
- rollout/kill switches/stop conditions;
- mapped implementation gate.

Write tests first.

Implement only the activated stage.

Open a PR and stop before:

- merge;
- deployment;
- source production calls;
- campaign approval/execution;
- completeness certification;
- target activation.
