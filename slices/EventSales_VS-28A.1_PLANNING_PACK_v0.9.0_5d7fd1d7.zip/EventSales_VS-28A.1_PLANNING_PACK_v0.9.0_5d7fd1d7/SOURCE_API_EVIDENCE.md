# WooCommerce Source API Evidence

## Official contract facts to verify at activation

WooCommerce REST v3 documents for order collections:

- `after` and `before`;
- `modified_after` and `modified_before`;
- `dates_are_gmt`;
- `orderby` values including `date` and `modified`;
- `order`;
- `status=any`;
- `page` and `per_page`;
- total resource/page headers `X-WP-Total` and `X-WP-TotalPages`.

## Current client gap

Current `WooCommerceClient`:

- aggregates pages internally;
- ignores response headers;
- injects `page/per_page`;
- stops only on a short page;
- returns pagination limit after a full configured final page.

A.1 requires final F.1 page metadata support or a reviewed extension.

## Production verification

Before implementation activation:

1. record WooCommerce and WordPress versions;
2. run redacted non-mutating requests against a safe bounded interval;
3. verify parameter names;
4. verify UTC interpretation;
5. verify header casing/values;
6. test exact boundary timestamps;
7. test same-second multiple order ids;
8. test all statuses;
9. test final full page and out-of-range page;
10. record no credentials/PII.

## Local correctness

Even after source verification, EventSales locally enforces:

```text
created_at >= window.start
created_at < window.end
```

This prevents source boundary semantics from becoming the internal window contract.
