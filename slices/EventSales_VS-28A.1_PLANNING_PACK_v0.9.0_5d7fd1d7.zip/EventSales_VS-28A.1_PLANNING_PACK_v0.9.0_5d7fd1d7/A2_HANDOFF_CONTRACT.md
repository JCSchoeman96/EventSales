# VS-28A.2 Admin Workflow Handoff

A.1 exposes non-web, actor-neutral or internally authorised core operations.

A.2 adds global-admin web workflows and audit.

## Required A.1 facades

Planning API families:

- prepare campaign from explicit event ids;
- queue preview;
- read preview/progress/findings;
- approve exact plan hash;
- queue execution;
- request pause;
- resume paused campaign;
- request cancel;
- read failures;
- read event coverage/certificates.

Exact names come from implementation.

## Preview DTO

PII-free:

- event names/ids/publication states;
- source-created boundaries/provenance;
- frozen upper;
- scan span;
- windows/pages/order identity counts;
- relevant order/line estimates;
- unresolved findings;
- catch-up/B.2 prerequisites;
- plan hash and age;
- expected limits.

## A.2 responsibilities

- global-admin authorization;
- rate limiting;
- CSRF/session safety;
- human reason;
- exact plan-hash confirmation;
- selection bounds;
- pause/cancel confirmations;
- PubSub/poll progress;
- audit events;
- generic safe errors;
- production canary workflow.

## A.2 prohibitions

- no Woo REST inline from LiveView/controller;
- no raw payload or customer data;
- no editing frozen plan;
- no force certificate;
- no private/draft selection;
- no silent select-all;
- no restart from page 1 when resume exists.

## PubSub

A.1 may broadcast small campaign/event progress hints after commit.

A.2 reloads durable state.

PubSub is not progress authority.
