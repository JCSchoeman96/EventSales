# Independent Reviewer Prompt — VS-28A.1

Review adversarially against current repository code and certified predecessor contracts.

Block any design that:

- uses EventSales insertion time, event start time or mapping creation as event creation boundary;
- starts source calls before exact selection/boundary review;
- runs one duplicate Woo scan per event;
- processes mixed-event orders more than once;
- filters only current active mappings before final F/G classification;
- misses event-attributed unresolved historical lines;
- uses raw labels as identity;
- treats a full page/window limit as success;
- ignores Woo total-page headers;
- depends on page order as identity;
- lacks exact preview/execution set verification;
- stores raw source payload or PII as evidence;
- advances progress after a relevant parse/upsert failure;
- assumes `OrderUpserter` is fully transactional when it is not;
- allows stale workers to regress window/campaign state;
- relies on Oban uniqueness, ETS or PubSub as durable authority;
- exceeds global Woo concurrency two;
- competes with near-live catch-up without yield controls;
- certifies history without F.1/F.2 seam closure;
- certifies metrics without G semantics and B.2 readiness;
- lets a certificate imply permanent current freshness;
- silently excludes private/draft/failed events while calling campaign complete;
- performs destructive Sales reset;
- adds A.2 UI, CSV/XLSX, correction/export or target activation scope;
- lacks safe pause/cancel/resume;
- lacks production source-boundary proof.

Classify findings as blocker, major or minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only. Activation controls implementation.
