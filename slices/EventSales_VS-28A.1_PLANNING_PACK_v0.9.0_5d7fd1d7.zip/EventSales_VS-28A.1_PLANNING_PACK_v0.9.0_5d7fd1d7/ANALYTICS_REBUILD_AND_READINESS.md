# Analytics Rebuild and Readiness Contract

## B.2 authority

A.1 does not calculate metrics or write bucket deltas.

After Sales ingestion/catch-up:

- B.2 contribution projection detects changes;
- affected historical buckets become dirty;
- B.2 rebuilds exact event/ticket-type hour/day buckets;
- B.2 exposes built-through revision/time and completeness state.

## Backfill trigger

Use certified B.2 correction/rebuild interfaces.

Allowed approaches:

- normal contribution projection from each order upsert;
- bounded event/range dirty-key marking after campaign;
- a reviewed combination for efficiency.

Do not bypass B.2 by writing aggregate tables from backfill code.

## Required range

For each selected event:

```text
[event.source_created_at, historical_upper)
```

B.2 may use its own bucket alignment and exact edge rules.

## Readiness conditions

Metric certificate requires:

- contribution projection caught up to all campaign/catch-up revisions;
- no dirty/failed bucket in required event/range/version;
- event and ticket-type bucket parity under B.1;
- correct currency;
- metric and semantic versions match campaign snapshot;
- completeness resolver returns complete for required window.

## Progress

Event scope can move:

```text
ingested → analytics_pending → certified
```

Polling/retry is bounded.

A.1 should not keep a long database transaction while waiting for B.2.

## Rebuild bounds

- exact selected events/range only;
- no all-source/all-history rebuild unless it equals approved campaign scope;
- no raw Sales read from web;
- no unbounded one-job rebuild.

## B.2 failure

- record `blocked_analytics`;
- issue historical ingestion coverage if eligible;
- do not issue metric completeness;
- resume certification after B.2 repair without repeating source scan when evidence remains valid.
