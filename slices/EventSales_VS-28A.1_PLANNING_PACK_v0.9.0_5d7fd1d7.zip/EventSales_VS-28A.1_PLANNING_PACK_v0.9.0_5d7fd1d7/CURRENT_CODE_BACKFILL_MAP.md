# Current Code Backfill Map

| Current area | Current behaviour | A.1 implication |
|---|---|---|
| SyncRun | requires one event | use dedicated source/event-set campaign |
| SyncCursor | one per run, page-based | use durable window/pass progress |
| OrderReconciliation | one event active mappings | replace with final source-wide candidate classifier |
| Page completion | ceiling or short page | full ceiling is failure/subdivision |
| Order failure | count and continue | relevant failure blocks progress |
| Woo client | aggregated lists | require page API with headers |
| Query ownership | caller/client both add page fields | one owner only |
| Parser | requires created/modified timestamps and all lines | reuse |
| OrderUpserter | source/order idempotency and stale guard | sole writer |
| Upserter transaction | order then children actions | retries must repair partial writes |
| Event | no source-created timestamp | source contract extension/blocker |
| Catalog feed | source updated only | add source-created field |
| ProductMapping history | create ignored | cannot infer all historical mappings |
| Analytics | no current B.2 implementation on main | activation consumes final B.2 |
| Completeness certificate | none | add explicit layered evidence |
| Current data | preservation not required | no automatic destructive reset |
