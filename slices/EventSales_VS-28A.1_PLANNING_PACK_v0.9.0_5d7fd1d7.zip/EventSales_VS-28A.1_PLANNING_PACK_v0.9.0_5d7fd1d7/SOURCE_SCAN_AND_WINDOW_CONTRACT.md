# Source Scan and Window Contract

## Axis

Historical discovery uses Woo order creation time (`date_created_gmt`).

Catch-up/freshness uses order modification time and remains F.1/F.2 authority.

## Canonical local window

```text
[created_from_utc, created_before_utc)
```

The local filter is authoritative.

## Source request

Candidate parameters:

- `after`;
- `before`;
- `dates_are_gmt=true`;
- `orderby=date`;
- `order=asc`;
- `status=any`;
- `page`;
- `per_page`.

Because source inclusivity and second precision require verification, requests may use a small boundary overlap. Returned rows are locally filtered by `date_created_gmt`.

## Page API

A.1 requires a certified page-level client result:

```elixir
%{
  items: [map()],
  page: pos_integer(),
  per_page: pos_integer(),
  total_items: non_neg_integer(),
  total_pages: non_neg_integer(),
  response_fingerprint: binary()
}
```

Use `X-WP-Total` and `X-WP-TotalPages` or final certified equivalents.

The caller or client owns `page/per_page`, never both.

## Dense-window planning defaults

- initial duration: 7 days;
- per page: 100;
- maximum pages: 50;
- maximum identities: 5,000;
- minimum duration: 60 seconds;
- maximum subdivision depth: derived from duration/minimum;
- maximum campaign identities: 250,000.

These are planning bounds, not product promises.

## Subdivision

When total pages/rows exceed the bound:

1. split exactly at deterministic UTC midpoint;
2. create left `[start, midpoint)`;
3. create right `[midpoint, end)`;
4. mark parent `subdivided`;
5. process left before right by stable ordering.

If the minimum window still exceeds the bound:

- mark `too_dense`;
- block campaign/event certification;
- do not truncate.

## Header inconsistency

Block/retry when:

- missing/invalid totals;
- page > total pages unexpectedly;
- total pages changes within one pass;
- body count contradicts page metadata beyond defined final-page behaviour;
- duplicate source ids with conflicting creation times.

## Identity and ordering

Page order is not proof.

Distinct identity is:

```text
source_system_id + woo_order_id + date_created_gmt
```

Persist source order id and creation time only for scan proof.

## Frozen upper

At preview preparation:

```text
historical_upper = now_utc - settling_delay
```

Planning default settling delay: 10 minutes.

Execution uses the same upper.

Certification requires F.1/F.2 modified-order catch-up committed through this upper.

## All statuses

Do not limit historical discovery to completed orders. All operational states are ingested; B.1 decides metric contribution.
