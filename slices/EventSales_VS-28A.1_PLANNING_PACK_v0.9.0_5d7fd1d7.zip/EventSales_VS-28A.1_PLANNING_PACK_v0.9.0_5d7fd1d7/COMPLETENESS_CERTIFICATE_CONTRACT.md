# Historical and Metric Completeness Certificate Contract

## Layer 1 — Historical ingestion coverage

Proves:

- source event lower boundary approved;
- frozen creation-time windows fully and stably scanned;
- selected relevant orders durably processed;
- zero unresolved relevant processing failures;
- catch-up seam closed.

Candidate resource:

```text
HistoricalIngestionCoverage
```

## Layer 2 — Metric completeness

Additionally proves:

- relevant lines mapped/classified under certified G policy;
- B.1 metric/semantic versions;
- exact currency;
- B.2 projection/bucket readiness;
- no blocking semantic/source gap.

Candidate resource:

```text
MetricCompletenessCertificate
```

## Identity

Candidate key:

- source system id;
- event id;
- metric contract version;
- semantic policy version;
- currency or metric family;
- certificate generation.

One active certificate per exact key, with supersession history.

## Candidate fields

- campaign id;
- event scope id;
- certified_from;
- historical_scan_through;
- catchup_committed_through;
- analytics_built_through;
- selection snapshot hash;
- plan hash;
- source identity-set hash;
- mapping snapshot hash;
- event boundary evidence hash;
- relevant counts;
- unresolved count;
- issued_at;
- status;
- supersedes id;
- revoked_at/reason.

## Status

- pending;
- certified;
- blocked_boundary;
- blocked_processing;
- blocked_semantics;
- blocked_catchup;
- blocked_analytics;
- superseded;
- revoked.

Blocked states may be represented as event-scope evidence rather than active certificates; final plan decides.

## `certified_from`

For an event:

```text
certified_from = approved source-created lower boundary
```

It may not be moved later to hide missing history.

A conservative earlier scan may produce an earlier certificate if fully proven.

## Current completeness resolver

B.1 combines:

- historical certificate;
- current F.2 freshness/cursor;
- B.2 readiness;
- requested window.

A.1 certificate alone does not claim current freshness.

## Supersession/revocation

Triggers include:

- stronger/corrected event creation boundary;
- historical identity-set breach;
- semantic/mapping correction affecting covered lines;
- discovered unresolved source gap;
- contract-version change;
- destructive data repair.

Old certificate remains immutable evidence.

## VS-27D

A D target can arm only when:

- target start >= active metric certificate `certified_from`;
- target period and versions are covered;
- F.2/B.2 current states are eligible.

No direct boolean copied to target rows bypasses the resolver.
