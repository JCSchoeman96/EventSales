# Planning Agent Prompt — VS-28A.1

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-28A.1_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not:

- modify files;
- run migrations;
- call production WooCommerce or WordPress;
- create or approve a campaign;
- backfill Sales data;
- issue completeness certificates;
- arm targets;
- commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified artifacts for:

- VS-26F.1;
- VS-26F.2;
- VS-26G;
- VS-27B.1;
- VS-27B.2;
- VS-27D completeness consumption.

Do not assume planning names survived implementation.

## Required source verification plan

Record how activation will verify:

- Woo/WordPress versions;
- order page parameters and total headers;
- exact boundary inclusivity;
- event source creation timestamp;
- current public/private event state;
- F.1/F.2 cursor/readiness;
- B.2 projection/bucket interfaces;
- Railway/Postgres/Oban topology.

No source call in the planning phase.

## Required plan decisions

1. final predecessor interfaces/versions;
2. source-created event boundary field and feed schema compatibility;
3. existing-event boundary refresh/backfill;
4. campaign/event/window/identity/failure resources;
5. immutable selection and mapping snapshot;
6. source-wide scan lower/upper;
7. exact source request/local half-open filter;
8. page-level Woo client/header contract;
9. window bounds and deterministic subdivision;
10. preview identity persistence and plan hash;
11. plan expiry/drift semantics;
12. execution identity verification;
13. final F/G candidate classification;
14. known/mixed-event order behaviour;
15. partial OrderUpserter write/retry handling;
16. campaign/window/event state machines;
17. generations/leases/stale-worker protection;
18. page progress transaction;
19. pause/resume/cancel;
20. failure resource and retry bounds;
21. one-active campaign/source;
22. queue/concurrency/priority guards;
23. catch-up seam closure;
24. B.2 rebuild/readiness;
25. ingestion and metric certificate resources;
26. supersession/revocation;
27. data privacy/evidence;
28. A.2 facade/DTO/PubSub handoff;
29. staged PRs;
30. migrations/indexes/lock strategy;
31. tests-first sequence;
32. exact files create/modify/generated/forbidden;
33. verification/load/source-simulator commands;
34. rollout/kill switches;
35. production canary/certification;
36. Linear gate-ledger mapping;
37. risks/stop conditions.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with exactly one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
