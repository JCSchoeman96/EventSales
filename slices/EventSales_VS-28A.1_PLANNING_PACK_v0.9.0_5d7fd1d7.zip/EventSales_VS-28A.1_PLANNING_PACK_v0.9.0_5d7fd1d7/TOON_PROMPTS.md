# TOON Prompts — VS-28A.1

## Planning agent
Task: Design the bounded source-wide historical backfill core from exact current code.
Output: Complete implementation plan.
Boundary: No code or source calls.

## Source-contract reviewer
Task: Attack event creation authority, Woo date/pagination semantics and feed compatibility.
Output: Source-proof findings.
Boundary: No inferred lower bounds.

## Window/concurrency reviewer
Task: Attack subdivision, preview/execution identity sets, stale workers and queue priority.
Output: Race/limit matrix.
Boundary: Full limits never success.

## Sales reviewer
Task: Attack mixed-event classification, mapping history, parser/upserter retries and unknown semantics.
Output: Writer/candidate findings.
Boundary: Existing writer only.

## Completeness reviewer
Task: Attack seam closure, B.2 readiness, certificate meaning and supersession.
Output: Certification verdict.
Boundary: Ingestion coverage is not metric completeness.

## Privacy reviewer
Task: Attack identities, failures, logs, evidence and A.2 DTO.
Output: Leakage verdict.
Boundary: No raw payload/PII evidence.

## Activation reviewer
Task: Refresh current main, source versions, predecessor interfaces and Railway topology.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
