# VS-28A.1 Redacted Evidence

- Pack/plan/activation:
- PR/head/deployed SHA:
- F.1/F.2/G/B.1/B.2 versions:
- Source/plugin versions:
- Campaign/event ids redacted:

## Event boundaries
| Event | Public state | Source-created | Provenance hash | Result |
|---|---|---|---|---|

## Preview
- frozen lower/upper:
- window tree:
- pages/identities:
- relevant orders/lines:
- unresolved:
- source header proof:
- selection/mapping/semantic hashes:
- plan hash/age:
- Sales writes during preview: 0

## Execution
- exact approved hash:
- identity set equality:
- source requests:
- upserted/stale/irrelevant:
- failures:
- interruption/resume:
- duplicate/stale worker:
- pause/cancel tests:
- PII scan:

## Seam
- F.1/F.2 committed-through:
- catch-up status/failures:
- historical upper covered:

## Analytics
- B.2 projection/built-through:
- required range:
- dirty/failed count:
- parity:
- currency/version:

## Completeness
- ingestion coverage:
- metric certificate:
- certified_from:
- hashes/counts:
- active/supersession state:
- B.1 resolver:
- D target armed: no

## Performance
- queue/concurrency:
- page duration:
- total runtime:
- webhook/catch-up impact:
- DB size/identity rows:

## Negative proof
- no forbidden lower bound:
- no private/draft event:
- no truncation:
- no raw payload:
- no destructive reset:
- no UI/import/export scope:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
