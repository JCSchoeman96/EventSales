# Event Selection and Snapshot Contract

## Selection authority

A campaign is explicitly scoped to one source and a bounded list of event ids.

An event is selectable only when the certified Catalog contract says it is currently public/live for launch.

Planning exclusions:

- draft;
- private;
- cancelled unless a later reviewed launch decision includes it;
- archived/old and not selected;
- missing external Tickera event identity;
- missing source-created boundary;
- unresolved source ownership.

## Rechecks

Eligibility is checked at:

1. campaign preparation;
2. preview start;
3. execution start;
4. event certification.

If an event becomes private/draft during execution:

- stop new certification for that event;
- mark its event scope blocked/excluded;
- retain already ingested Sales truth;
- continue other events only when source/window processing remains safe.

## Immutable event-scope snapshot

Candidate fields:

- campaign id;
- source system id;
- event id;
- external Tickera event id;
- source-created lower boundary;
- boundary provenance/evidence hash;
- event publication/lifecycle snapshot;
- source/feed schema version;
- mapping snapshot hash;
- semantic-policy version;
- metric-contract version;
- selected/review state;
- inserted timestamp.

The snapshot is immutable after preview begins.

## Mapping snapshot

Capture all currently certified mapping facts needed by the final F/G classifier:

- source/product/variation identity;
- event/ticket-type identity;
- active/current disposition;
- semantic classification/version;
- source Tickera event identity.

Labels and prices are not identity.

Because current ProductMapping create history is incomplete, mapping snapshot authority is current certified Catalog plus line-level source event metadata. Historical unknowns remain visible and block metric certification.

## Campaign scan lower bound

```text
scan_lower = minimum selected event source-created boundary
```

The classifier applies each event's own boundary. A single early boundary does not make an order relevant to every event.

## Selection hash

Hash deterministic binary/canonical serialization of:

- source id;
- ordered event-scope snapshots;
- boundaries/provenance;
- mapping snapshot;
- contract versions;
- frozen upper;
- scan settings.

UUID ordering follows project-wide deterministic binary UUID ordering when implemented.

## Bounds

Planning defaults:

- maximum selected events: 25;
- exactly one source;
- no implicit select-all beyond the displayed approved set;
- no hidden event expansion due to mapping discovery.

If more events are needed, split campaigns or obtain reviewed bound expansion.
