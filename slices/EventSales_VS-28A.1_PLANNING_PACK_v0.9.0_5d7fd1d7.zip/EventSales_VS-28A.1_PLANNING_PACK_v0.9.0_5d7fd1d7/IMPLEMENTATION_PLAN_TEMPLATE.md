# VS-28A.1 Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified F.1/F.2/G/B.1/B.2 interfaces
## 4. Woo/WordPress/Railway source evidence plan
## 5. Current code gap verification
## 6. Staged delivery recommendation
## 7. Event source-created feed/Catalog contract
## 8. Existing-event boundary refresh/migration
## 9. Campaign and event-scope resources
## 10. Mapping/semantic snapshot
## 11. Frozen scan lower/upper
## 12. Page-level Woo client/header ownership
## 13. Half-open local source filtering
## 14. Window resource/bounds/subdivision
## 15. Preview identity resource/pass
## 16. Plan hash/expiry/approval inputs
## 17. Execution identity verification
## 18. Candidate order classification
## 19. Mixed/known order handling
## 20. OrderUpserter partial-write retry
## 21. Campaign/event/window state machines
## 22. Generation/claim/lease/stale-worker protection
## 23. Page-step transaction/progress
## 24. Pause/resume/cancel
## 25. Failure resource/retry/resolution
## 26. Queue/concurrency/near-live priority
## 27. Catch-up seam closure
## 28. B.2 rebuild/readiness
## 29. Historical ingestion coverage
## 30. Metric completeness certificate
## 31. Supersession/revocation
## 32. Privacy/evidence/telemetry
## 33. A.2 facade/DTO/PubSub handoff
## 34. Migrations/indexes/lock strategy
## 35. Tests-first sequence
## 36. Exact files create/modify/generated/forbidden
## 37. Verification commands/source simulator/load
## 38. Rollout/kill switches
## 39. Production canary/certification evidence
## 40. Linear gate-ledger mapping
## 41. Risks/stop conditions
## 42. Prohibited-actions statement
