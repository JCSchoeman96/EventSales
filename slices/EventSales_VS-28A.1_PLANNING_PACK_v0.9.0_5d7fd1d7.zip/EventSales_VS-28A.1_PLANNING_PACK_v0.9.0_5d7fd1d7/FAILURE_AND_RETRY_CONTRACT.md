# Failure and Retry Contract

## Failure resource

Candidate fields:

- campaign id;
- event scope id when known;
- window id;
- Woo order id when known;
- stage;
- reason;
- retryability;
- attempts;
- state;
- first/last seen;
- resolved_at;
- safe evidence hash.

No raw payload, customer data, addresses, transaction ids, credentials or full exception dumps.

## Stages

- boundary;
- source_request;
- source_headers;
- preview_identity;
- candidate_classification;
- parser;
- order_upsert;
- mapping;
- plan_drift;
- catchup_seam;
- analytics;
- certification.

## Retryable examples

- rate limited;
- timeout;
- transport error;
- queue timeout;
- circuit open;
- transient database conflict;
- worker crash;
- temporary B.2 pending state.

## Blocking/non-retryable examples

- missing source-created boundary;
- private/draft event;
- invalid order creation timestamp;
- malformed payload whose relevance cannot be determined;
- conflicting selected-event identity;
- minimum window too dense;
- plan hash mismatch;
- metric/semantic contract mismatch;
- unsupported currency/semantic state.

## Relevant processing rule

Execution page advances only when every relevant order on the page is:

- upserted successfully;
- stale no-op;
- explicitly irrelevant under certified classification.

A parse/classification failure that prevents proving irrelevance blocks the page.

## Partial `OrderUpserter` writes

Current writer can persist an order before a child action fails.

Therefore:

- failed upsert returns page failure;
- retry reuses source/order and line identities;
- stale/equal source version path must repair children;
- certificate requires zero unresolved failures;
- no compensating delete is attempted.

Activation must refresh this contract against final F/G writer changes.

## Attempts

Use bounded exponential backoff with jitter.

Planning defaults:

- source transient maximum: 25 worker attempts;
- per-order durable failure attempts: 10 before operator review;
- plan drift: no blind retry;
- too-dense: no blind retry.

## Resolution

Failure resolution records:

- resolver type;
- resolved_at;
- replacement campaign/window/correction reference;
- safe reason.

Do not erase the original failure evidence.

## Error surfaces

Workers return low-cardinality safe reasons.

A.2 later presents bounded summaries, not stack traces or raw source bodies.
