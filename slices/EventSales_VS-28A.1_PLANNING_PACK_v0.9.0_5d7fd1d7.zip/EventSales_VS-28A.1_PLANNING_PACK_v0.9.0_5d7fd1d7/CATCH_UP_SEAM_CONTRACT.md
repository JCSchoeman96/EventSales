# Catch-Up Seam Contract

## Two time axes

Historical discovery:

```text
order.date_created_gmt
```

Continuous repair/freshness:

```text
order.date_modified_gmt
```

A historical creation scan alone cannot prove that the latest status/refund/line state has been observed.

## Frozen upper

Campaign captures:

```text
historical_upper
```

Orders created before this boundary are in the historical discovery set.

## Required seam

Before an event can certify:

1. F.1/F.2 source catch-up has a committed modified watermark at or after `historical_upper`;
2. the catch-up cursor is not blocked/full-recovery-required;
3. all relevant failures through that watermark are resolved;
4. final candidate classification/writer versions match;
5. B.2 has processed resulting changes.

## Why this works

The creation scan proves order discovery for the historical interval.

The modification cursor proves changes to those orders were reconciled through the baseline boundary.

Neither proof replaces the other.

## Race during execution

Orders in the frozen creation set may change while backfill runs.

- Backfill execution writes the payload it fetched.
- Source-version guard prevents older payloads overwriting newer webhook/catch-up truth.
- F.1/F.2 catch-up later closes any update gap.
- Certificate waits for the seam.

## Orders created after frozen upper

They belong to normal webhook/catch-up flow.

They are not part of the historical baseline plan.

## Backdated/imported orders

If a new order later appears with `date_created_gmt` before the certified upper:

- normal modified-order catch-up may ingest it if changed after the cursor;
- completeness monitoring must detect a historical identity-set breach when possible;
- certificate may be superseded/revoked;
- a bounded repair campaign may be required.

The implementation plan must define detection using source capabilities. No permanent absolute claim is made against undetectable source backdating.

## Source freshness

A certificate records seam closure at issue time.

Current freshness remains a live F.2 state and can later become stale without invalidating historical `certified_from`.
