# Mandatory File Inventory — VS-28A.1

## Governance and roadmap

- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Certified predecessor artifacts

- final VS-26F.1 pack, plan, activation, PR review and production certification;
- final VS-26F.2 artifacts;
- final VS-26G artifacts;
- final VS-27B.1/B.2 artifacts;
- VS-27D completeness-consumer contract.

## Current historical/reconciliation code

- `lib/event_sales/ingestion/resources/sync_run.ex`
- `lib/event_sales/ingestion/resources/sync_cursor.ex`
- `lib/event_sales/ingestion/order_reconciliation.ex`
- `lib/event_sales/ingestion/manual_sync.ex`
- `lib/event_sales/ingestion/workers/reconcile_orders_worker.ex`
- `lib/event_sales/ingestion/sync_debug.ex`
- `lib/event_sales/maintenance/stale_sync_cleanup_worker.ex`
- related migrations/resource snapshots/tests.

## Woo source boundary

- `lib/event_sales/ingestion/clients/woocommerce_client.ex`
- `lib/event_sales/ingestion/clients/httpc_transport.ex`
- `lib/event_sales/ingestion/clients/woocommerce_error.ex`
- REST rate limiter/circuit breaker/config;
- final F.1 page-metadata client;
- Woo client tests.

## Parser and writer

- `lib/event_sales/ingestion/parsers/woocommerce_order_parser.ex`
- `lib/event_sales/sales/order_upserter.ex`
- `lib/event_sales/sales/order_item_mapper.ex`
- `lib/event_sales/sales/source_version_guard.ex`
- Sales Order/OrderItem/Coupon resources;
- final G candidate/semantic resources;
- parser/upserter/mapping tests.

## Catalog/event boundary

- `lib/event_sales/catalog/resources/event.ex`
- `lib/event_sales/catalog/resources/product_mapping.ex`
- `lib/event_sales/catalog/resources/ticket_type.ex`
- certified event lifecycle/publication resources;
- Tickera catalog discovery/normalizer/apply resources;
- `docs/ops/tickera_catalog_feed_contract.md`
- `integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`
- catalog feed/discovery tests and migrations.

## Analytics/completeness

- certified B.1 completeness resolver/contracts;
- certified B.2 contribution, bucket, rebuild/readiness resources and workers;
- B.2 tests and migrations;
- final D target completeness interface.

## Ingestion/Oban/config

- `lib/event_sales/ingestion.ex`
- `lib/event_sales/application.ex`
- `config/config.exs`
- `config/runtime.exs`
- `mix.exs`
- `railway.toml`
- Oban backlog/runbook and final predecessor Cron/queue configuration.

## Audit/privacy

- `lib/event_sales/audit/logger.ex`
- `lib/event_sales/audit/metadata_sanitizer.ex`
- `lib/event_sales/audit/resources/audit_log.ex`
- PII/static domain-boundary tests.

## Existing admin workflow to preserve for A.2

- current Sync LiveView/routes/tests;
- current import/export routes;
- admin session/rate-limit components;
- no web code may be modified in A.1 except a strictly required shared non-UI boundary approved by activation.

## Tests

- order reconciliation tests;
- sync run/cursor tests;
- worker/manual sync tests;
- Woo client tests;
- parser/upserter tests;
- event/catalog feed tests;
- final F/G/B tests;
- source simulation/transport test support;
- full CI/static boundaries.
