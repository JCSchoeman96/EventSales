# EventSales VS-28A.1 Planning Pack

## Identity

- Slice: `VS-28A.1`
- Name: Current Public Event Historical Backfill Core
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#129`
- Linear milestone: `M6 — Historical Completeness and Data Operations`
- Linear document: `VS-28A.1 — Pack 13 Gate Ledger and Planning Record`
- Created: `2026-07-17T14:16:09Z`

## Authority

This ZIP authorises repository reconnaissance and implementation planning only.

It does not authorise:

- code or migration changes;
- WooCommerce production calls;
- event selection or plan approval;
- Sales backfill;
- completeness certification;
- target activation;
- merge or deployment.

Implementation requires:

1. independent pack approval;
2. independent plan approval;
3. certified VS-26F.1/F.2, VS-26G and VS-27B.1/B.2 interfaces;
4. exact-current-main activation;
5. source-created event boundary evidence;
6. explicit activation verdict `APPROVE`.

## Outcome

```text
approved current public events
        ↓
authoritative event source-created boundaries
        ↓
bounded source-wide order-creation windows
        ↓
preview identity sets + immutable plan hash
        ↓
execution re-verification
        ↓
certified parser + OrderUpserter
        ↓
F.1/F.2 catch-up seam closure
        ↓
B.2 analytics readiness
        ↓
per-event completeness certificate
        ↓
VS-27D target enablement may later proceed
```

## Core rules

- Each Woo order is processed once per source campaign, including mixed-event orders.
- Existing parser and `OrderUpserter` remain the only Sales writer.
- EventSales `inserted_at`, event start time and mapping creation time are not historical lower-bound authority.
- Full page/window limits never mean success.
- Cursor/window progress advances only after durable success.
- No raw Woo payload is stored as backfill evidence.
- Current freshness remains VS-26F.2 authority.
- The admin workflow belongs to VS-28A.2.
