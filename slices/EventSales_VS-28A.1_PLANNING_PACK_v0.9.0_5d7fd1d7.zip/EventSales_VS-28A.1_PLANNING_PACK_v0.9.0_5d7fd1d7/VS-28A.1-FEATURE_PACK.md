# VS-28A.1 — Current Public Event Historical Backfill Core

## 1. Identity

- Pack: `0013_VS-28A.1`
- Version: `0.9.0`
- Baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub: #129
- Milestone: M6
- Predecessors: VS-26F.1, VS-26F.2, VS-26G, VS-27B.1, VS-27B.2
- Successor: VS-28A.2
- Downstream consumer: VS-27D post-backfill enablement
- Execution authority: none

## 2. Goal

Backfill selected current public events from their authoritative source creation boundaries using bounded, restartable WooCommerce REST work, then certify exact historical coverage only after source catch-up and analytics are joined to the baseline.

## 3. Current repository truth

Current `main` has:

- event-scoped `SyncRun` requiring one `event_id`;
- one `SyncCursor` per run;
- current reconciliation filtering raw line items against one event's active mappings before parsing;
- page completion when the configured ceiling is reached, even if the page is full;
- per-order failures counted without stopping page/run completion;
- Woo page aggregation that discards `X-WP-Total` and `X-WP-TotalPages`;
- duplicate page/per-page ownership between caller and client;
- one existing normalized writer, `OrderUpserter`;
- parser support for Woo order creation/modification/completion timestamps and Tickera event metadata;
- current Catalog Event fields for start/end, source update and EventSales insertion, but no source event creation time;
- a signed Tickera feed with source update time but no source creation time;
- ProductMapping create history excluded from PaperTrail;
- no historical campaign, window, plan hash, failure or completeness-certificate resource.

## 4. Product rules

- Initial launch backfill covers selected currently public/live events.
- Private/draft events are excluded.
- Old events not selected for launch are excluded.
- Each event begins at its source creation boundary.
- Work is bounded, durable, restartable and idempotent.
- Existing parser and `OrderUpserter` are mandatory.
- Progress advances only after success.
- Completion records a data-completeness watermark/certificate.
- No unbounded full-store import.

## 5. Source-wide design

Do not run one independent Woo order scan per event.

A campaign has:

- one source;
- an immutable selected-event set;
- a per-event lower boundary;
- one frozen upper boundary;
- one source-wide set of time windows.

The source scan starts at the earliest selected event boundary. Candidate classification assigns selected relevant lines to their event/ticket type. Orders spanning several selected events are processed once.

## 6. Two-phase proof

### Preview

- scans frozen windows;
- records non-PII order identity tuples;
- calculates source totals and event/candidate counts;
- identifies unresolved boundaries/mappings/semantics;
- builds an immutable deterministic plan hash;
- performs no Sales writes.

### Execute

- requires the exact approved plan hash;
- repeats each frozen window;
- verifies the exact distinct identity set;
- processes selected relevant order data;
- blocks on drift instead of silently continuing.

VS-28A.2 later exposes the human preview and plan approval.

## 7. Source lower boundary

Preferred authority:

```text
Tickera event WordPress post creation timestamp
→ signed catalog feed `event_source_created_at`
→ Catalog Event `source_created_at`
```

No substitution with:

- EventSales insertion timestamp;
- event start or end;
- first local order;
- mapping creation time;
- current source update time.

A conservative earlier operator boundary may be supported only with evidence and audit. A later override is forbidden.

## 8. Historical scan axis

Historical discovery uses Woo order creation time.

Continuous repair uses F.1/F.2 order modification time.

The two axes meet at the frozen upper bound.

## 9. Frozen windows

Local canonical windows are half-open:

```text
[created_from, created_before)
```

Source requests may overlap boundaries to avoid depending on undocumented inclusivity, but every returned order is locally filtered into the canonical half-open window by `date_created_gmt`.

Planning defaults:

- initial window: 7 days;
- maximum rows per window: 5,000;
- maximum pages per window: 50 at 100 rows/page;
- minimum subdivided window: 60 seconds;
- maximum selected events: 25;
- maximum campaign identities before manual split: 250,000;
- one page/request step per worker execution.

Activation may tighten these. Broadening requires review.

## 10. Stable-set proof

For each window and pass, persist only:

- Woo order id;
- creation timestamp;
- optional safe source-modified timestamp;
- pass/window identity.

Compare preview and execution distinct sets exactly using database set comparison or equivalent collision-resistant proof.

Page order is not identity.

Any mismatch causes `plan_drifted` and requires a refreshed preview.

## 11. Candidate classification

Use final F.1/G logic.

Relevant lines include:

- valid Tickera event metadata matching a selected event;
- exact selected-event mapping snapshot matches;
- known local selected-event line identities for an already-known order.

Rules:

- mixed-event order processed once;
- known order header/status may update even with an empty newly relevant line list;
- irrelevant orders are not persisted merely because scanned;
- malformed payload whose relevance cannot be proven blocks the window;
- event-attributed unresolved lines remain pending and block metric certification;
- current mapping labels are never historical identity.

## 12. Durable resources

Recommended:

- `HistoricalBackfillCampaign`;
- `HistoricalBackfillEventScope`;
- `HistoricalBackfillWindow`;
- `HistoricalBackfillWindowIdentity`;
- `HistoricalBackfillFailure`;
- `HistoricalIngestionCoverage`;
- `MetricCompletenessCertificate`.

Do not repurpose current `SyncRun`/`SyncCursor` unless the implementation plan proves semantic separation and compatibility.

## 13. Campaign lifecycle

Planning states:

- draft;
- preview_queued;
- previewing;
- preview_ready;
- execution_queued;
- running;
- pausing;
- paused;
- cancelling;
- cancelled;
- blocked;
- completed;
- failed.

One active campaign per source.

## 14. Safe progress

- one claimed window/page step at a time;
- window/pass/page stored durably;
- identity rows commit before cursor movement;
- execution page advances only after every relevant order returns success or stale-noop;
- relevant parse/upsert failure is durable and blocks progress;
- retries are idempotent;
- stale/out-of-order workers cannot regress state;
- pause/cancel occurs at safe boundaries;
- cancel does not undo already ingested Sales truth.

## 15. Source prioritisation

Backfill uses a separate low-priority queue with initial concurrency one.

It must yield when:

- near-live catch-up is active or behind;
- webhook/source queues are unhealthy;
- source circuit breaker is open;
- configured peak guard says pause.

Shared Woo REST concurrency remains at most two.

## 16. Completeness layers

### Historical ingestion coverage

Certifies that all relevant source orders in the selected historical period were discovered and durably processed.

### Metric completeness

Additionally requires:

- all relevant lines semantically resolved under VS-26G;
- B.1 metric/semantic versions fixed;
- B.2 projections/buckets ready for the event period;
- no blocking source/semantic failures.

VS-27D consumes metric completeness, not ingestion coverage alone.

## 17. Seam closure

Before certification:

- F.1/F.2 committed modified watermark must reach or pass the frozen upper bound;
- no unresolved source catch-up failures affect the selected scope;
- B.2 must include all backfilled/catch-up corrections through the baseline;
- current source freshness remains separately reported by F.2.

## 18. Certificate evidence

Per event:

- source/event ids;
- source-created lower boundary and evidence;
- frozen historical upper;
- selection/plan hash;
- window-set fingerprint;
- campaign id;
- mapping and semantic-policy hashes/versions;
- scanned/relevant/upserted/stale/failure counts;
- catch-up committed-through;
- B.2 built-through revision/time;
- certified-from;
- issued/superseded/revoked timestamps;
- safe blocking reasons.

A certificate does not claim that the source is currently fresh forever.

## 19. Source contract extension

Because current feed lacks event creation time, A.1 may require a backward-compatible catalog-feed extension:

- `event_source_created_at`;
- sourced from WordPress/Tickera event post creation in GMT;
- strict UTC parsing;
- new schema version or optional compatible field;
- refreshed local Catalog before preview.

Invalid/zero/missing source dates block that event.

## 20. Privacy

Backfill REST responses may contain normal source PII in memory because the existing Sales writer persists permitted normalized order fields.

Backfill-specific evidence must not store:

- raw payload;
- billing/shipping details;
- customer name/email;
- transaction/payment data;
- secrets or headers.

Failures use order id, stage and low-cardinality reason only.

## 21. No destructive reset

Current Railway data may be superseded by correct re-ingestion, but A.1 does not automatically truncate or delete Sales data.

Any destructive reset requires a separate reviewed production plan.

## 22. Non-goals

No admin UI, CSV/XLSX, imports, exports, corrections, arbitrary old/private events, target arming, email notifications, compact webhook change, WordPress write-back, generic integration platform or full-store history.

## 23. Acceptance

A selected public event:

- receives an authoritative lower boundary;
- previews an exact stable plan;
- executes through the existing writer;
- survives interruption and resumes;
- never truncates at page/window limits;
- processes mixed-event orders once;
- blocks on relevant failures or drift;
- joins to F.1/F.2 catch-up;
- rebuilds B.2;
- receives exact ingestion and metric-completeness evidence.

Private/draft events, missing boundaries, unresolved semantics, unstable windows or incomplete seam/readiness cannot certify.
