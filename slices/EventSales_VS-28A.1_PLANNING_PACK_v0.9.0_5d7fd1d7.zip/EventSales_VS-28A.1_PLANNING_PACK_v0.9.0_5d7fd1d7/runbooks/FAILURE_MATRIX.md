# Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| source-created boundary missing | event blocked | feed/source repair |
| event becomes private/draft | no certificate | remove/repreview if public |
| Woo headers missing/invalid | window retry/block | source/client repair |
| window too dense | subdivide | smaller window/manual split |
| minimum window too dense | block | source-specific plan |
| preview identity duplicate | distinct set + finding | inspect conflict |
| plan expired | reject execution | refresh preview |
| mapping/semantic version drift | reject execution | refresh preview |
| preview/execution set drift | block | refresh preview |
| transient REST failure | retry/snooze | bounded backoff |
| parser relevance unknown | page blocked | source/parser repair |
| OrderUpserter partial failure | page blocked | idempotent retry |
| stale worker | no state change | current generation continues |
| enqueue failure | durable state/outbox | drainer/repair |
| pause | finish current step | resume |
| cancel | no future work/certificate | new campaign |
| catch-up watermark behind | event blocked_catchup | F.2 catches up |
| catch-up blocked | no certificate | F.1/F.2 recovery |
| B.2 dirty/pending | analytics_pending | B.2 rebuild |
| unresolved semantics | ingestion only | G/mapping correction |
| source backdated order after cert | certificate suspect/revoked | repair campaign |
| PubSub missed | durable state unchanged | reload/poll |
