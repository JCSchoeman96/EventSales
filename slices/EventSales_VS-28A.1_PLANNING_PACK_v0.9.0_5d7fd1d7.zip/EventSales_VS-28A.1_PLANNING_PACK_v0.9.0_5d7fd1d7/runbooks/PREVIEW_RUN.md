# Backfill Preview Runbook

## Preflight

- implementation/canary deployment certified;
- source-created boundaries valid;
- selected events explicitly listed and public;
- final mapping/semantic versions recorded;
- F.1/F.2 and source health known;
- queue and REST concurrency safe;
- no other active campaign for source.

## Queue preview

1. Prepare campaign/event-scope snapshot.
2. Capture frozen upper and settling delay.
3. Create initial windows.
4. Commit campaign/windows plus real Oban job atomically or through certified outbox.
5. Record campaign id.

## Worker behaviour

For each preview window:

1. fetch one page;
2. validate total headers;
3. locally filter half-open bounds;
4. persist distinct identity rows;
5. count relevant/unresolved facts without Sales writes;
6. advance page after commit;
7. subdivide if dense;
8. stop at safe limits.

## Completion

- verify all leaf windows preview-ready;
- compare distinct count to source totals;
- calculate event/candidate counts;
- calculate deterministic plan hash;
- mark preview-ready;
- publish small progress hint.

## Review output

- event selection and boundaries;
- frozen upper;
- total span/windows/pages/identities;
- relevant counts by event;
- unresolved findings;
- catch-up/B.2 prerequisites;
- plan hash and expiry;
- warnings/stop conditions.

## Stop

- private/draft drift;
- missing boundary;
- total header inconsistency;
- minimum window too dense;
- campaign identity bound exceeded;
- source/circuit unhealthy;
- unresolved blocker not approved.
