# Migration and Queue Preflight

## Topology

- exact main/deployed SHA;
- Postgres version;
- direct/session migration URL;
- PgBouncer mode;
- Railway replica count;
- Oban version/schema;
- current F/B/D queues and Cron;
- source limiter topology;
- database size/headroom.

## Source contract

- WordPress plugin deployment path;
- feed schema compatibility;
- safe field addition;
- cache invalidation;
- source-created timestamp quality.

## Migration review

Potential additions:

- Catalog `source_created_at`;
- campaign/event/window/identity/failure tables;
- coverage/certificate tables;
- generation/sequence;
- partial unique active campaign index;
- due/pending window indexes;
- identity set unique indexes;
- certificate active-key indexes.

Rules:

- additive;
- no source call or backfill in migration;
- no destructive Sales reset;
- generated Ash migrations/snapshots reviewed;
- FK delete behaviour restrictive/historical-safe;
- identity tables sized/retention assessed;
- populated Catalog index lock reviewed.

## Queue review

- dedicated historical queue;
- concurrency one;
- existing Cron/plugins preserved;
- F.1/F.2 source priority signals available;
- kill switch;
- backlog telemetry;
- stale lease repair.

## Stop

- source field unavailable;
- unresolved Catalog migration;
- active-campaign uniqueness absent;
- identity-set storage unbounded;
- source concurrency not global;
- Cron overwrite;
- no rollback/disable path.
