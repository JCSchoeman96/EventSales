# Production Core Validation Runbook

Use one explicitly approved current public event.

## Read-only preflight

- deployed SHA;
- source/plugin versions;
- source-created boundary;
- publication state;
- mappings/semantics;
- F.1/F.2 state;
- B.2 state;
- queue/backlog/source health.

## Preview

- campaign id;
- event scope;
- boundary/provenance;
- frozen upper;
- windows/pages;
- total identities;
- relevant/unresolved counts;
- plan hash/age;
- no Sales count change.

## Execution

- exact plan supplement;
- start/end;
- source requests;
- one controlled interruption;
- resumed page/window;
- duplicate/stale counts;
- upserted/stale/failure counts;
- identity set equality;
- no PII evidence.

## Seam/analytics

- catch-up committed-through;
- source state;
- B.2 built-through;
- dirty/failure state;
- metric/version/currency parity.

## Certificate

- ingestion coverage id;
- metric certificate id;
- certified_from;
- scan/catch-up/analytics through;
- plan/selection/mapping hashes;
- unresolved zero;
- downstream B.1 resolver result.

## Negative proof

- no private/draft event;
- no unselected old event persistence caused by scan;
- no raw payload;
- no full-page truncation;
- no target armed;
- no A.2 UI exposure.

## Verdict

- CERTIFIED — VS-28A.2 MAY START
- CERTIFIED WITH ACCEPTED RISK
- REJECTED / BLOCKED
