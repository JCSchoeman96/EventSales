# Rollout and Stop Conditions

## Stage rollout

### Stage A

1. Deploy source-created field/feed compatibility and preview resources with all workers disabled.
2. Verify migrations and existing event refresh.
3. Run source simulator preview.
4. Verify no Sales writes.

### Stage B

1. Enable execution in test/staging.
2. Verify parser/OrderUpserter path.
3. Test duplicate, partial failure, pause/resume/cancel.
4. Verify near-live priority.

### Stage C

1. Enable seam/B.2/certificate logic in test.
2. Verify ingestion versus metric completeness.
3. Deploy production with queue disabled.
4. Complete read-only source/topology preflight.
5. Enable one exact canary preview.
6. Human review and separate execution approval.
7. Interrupt/resume canary.
8. Close seam and B.2.
9. Issue one certificate.
10. Keep A.2 UI and D target arming disabled.

## Kill switches

- source-created feed field consumption;
- preview queue;
- execution queue;
- source requests;
- certification;
- B.2 rebuild request;
- PubSub progress.

## Rollback

Disable queues/certification.

Do not delete already ingested Sales truth or issued evidence without reviewed supersession/revocation.

## Stop immediately

- forbidden lower-bound substitution;
- private/draft event included;
- page/window truncation;
- source totals inconsistent;
- raw PII/payload evidence;
- relevant failure followed by progress;
- stale job state regression;
- Woo concurrency above two;
- near-live ingestion degradation;
- plan drift ignored;
- certificate before seam/B.2/semantics;
- destructive reset;
- production execution without exact supplement.
