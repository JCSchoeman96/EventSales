# Backfill Execution and Resume Runbook

## Approval

Require exact:

- campaign id;
- preview plan hash;
- approved event set;
- actor/reason;
- unexpired preview;
- production execution supplement verdict.

## Start

1. Recheck event eligibility.
2. Recheck mapping/semantic versions.
3. Recheck source health and no active campaign conflict.
4. Transition to execution queued/running.
5. Create execution pass state.
6. Queue first exact window/page.

## One execution page

1. Claim campaign/window generation.
2. Fetch one source page.
3. Validate/local-filter.
4. Persist execution identities.
5. Classify each order once.
6. Call certified parser/OrderUpserter for relevant order.
7. Persist bounded failure on error.
8. Advance page only after all relevant results succeed/stale-noop.
9. Commit progress.
10. Queue/snooze next step.

## Window completion

1. Compare preview and execution distinct identity sets.
2. Verify page/header totals.
3. Verify zero unresolved execution failures.
4. Mark completed or `drifted`.

Drift requires new preview; do not silently retry with changed set.

## Controlled interruption test

- stop/kill worker after a committed page;
- restart;
- confirm same next page/window;
- confirm duplicate source page replay is idempotent;
- confirm counts and identity uniqueness.

## Pause

- request pause;
- current page may finish;
- no new page claimed;
- state becomes paused;
- resume from durable cursor.

## Cancel

- request cancel;
- stop at page boundary;
- mark remaining work cancelled;
- preserve Sales/evidence;
- issue no certificate.

## Completion

After all windows complete, proceed to seam closure and analytics readiness. Source scan completion alone is not certification.
