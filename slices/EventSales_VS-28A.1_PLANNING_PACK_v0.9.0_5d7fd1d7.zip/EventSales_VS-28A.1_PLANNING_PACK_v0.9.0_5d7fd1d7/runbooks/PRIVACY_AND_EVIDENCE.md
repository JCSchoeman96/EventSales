# Privacy and Evidence Runbook

## Allowed durable backfill evidence

- campaign/window ids;
- source/event ids;
- Woo order id;
- source created/modified timestamps;
- page/total counts;
- hashes;
- mapping/contract versions;
- low-cardinality errors;
- counts/durations;
- catch-up and B.2 revisions.

## Forbidden

- raw Woo payload;
- customer name/email;
- billing/shipping address;
- phone;
- order key;
- payment method/transaction id;
- coupon code in evidence;
- auth headers/secrets;
- stack trace with source body;
- arbitrary metadata.

The existing Sales domain may persist its already-approved normalized customer/order fields. Backfill-specific evidence remains separate.

## Tests

1. Seed distinctive customer/order/payment secrets in source fixture.
2. Run preview.
3. Inspect campaign/window/identity/failure/audit/telemetry.
4. Assert secrets absent.
5. Run execution failure.
6. Assert safe reason only.
7. Inspect A.2 preview DTO.
8. Inspect PubSub message.
9. Inspect logs.

## Retention

Preview/execution identity rows may be retained for certification evidence or compacted after:

- certificate issued;
- evidence hash preserved;
- review window elapsed;
- no active drift investigation.

Any purge is bounded, cursor-driven and cannot remove rows needed for unresolved campaigns/certificates without a reviewed policy.
