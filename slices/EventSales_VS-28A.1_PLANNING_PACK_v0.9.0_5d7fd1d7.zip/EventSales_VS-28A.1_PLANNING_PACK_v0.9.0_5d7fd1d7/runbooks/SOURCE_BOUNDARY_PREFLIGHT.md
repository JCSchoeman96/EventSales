# Source Boundary Preflight Runbook

## Purpose

Prove the historical lower bound for every selected event before preview.

## Read-only checks

1. Record exact EventSales, WordPress, WooCommerce, Tickera and catalog-feed versions.
2. Fetch the signed catalog feed for each selected event.
3. Verify event is currently public/live under the certified lifecycle contract.
4. Read `event_source_created_at`.
5. Verify strict UTC value and source signature/schema.
6. Compare with:
   - external event id;
   - source updated time;
   - event start/end;
   - local Catalog value.
7. Record feed snapshot/hash and retrieval time.
8. Check for zero/invalid WordPress dates.
9. Check whether any known relevant local order predates the boundary.

## Existing local Catalog

- refresh source-created field before campaign preparation;
- no manual SQL edit;
- stronger source correction requires audited Catalog action;
- no certificate may remain active if the lower boundary is later corrected earlier.

## Missing boundary

Result:

```text
BLOCKED — SOURCE EVENT CREATION TIME REQUIRED
```

Do not use EventSales `inserted_at` or event `starts_at`.

## Earlier override

Only through a later approved A.2 workflow:

- absolute UTC date;
- evidence reference;
- reason;
- must be earlier than or equal to source-created;
- campaign impact preview;
- audit.

## Evidence

Store only event/source ids, timestamps, schema/hash and safe findings.
