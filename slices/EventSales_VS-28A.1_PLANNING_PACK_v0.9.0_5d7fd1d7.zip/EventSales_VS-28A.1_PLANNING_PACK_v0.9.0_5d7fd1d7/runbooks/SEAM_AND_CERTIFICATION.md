# Catch-Up Seam and Certification Runbook

## Historical scan complete

Confirm:

- all selected event scopes eligible;
- all leaf windows completed;
- preview/execution identity sets equal;
- zero unresolved relevant failures;
- source-created boundaries unchanged;
- plan/mapping/semantic versions unchanged.

## Catch-up seam

1. Read F.1/F.2 committed modified watermark.
2. Require watermark >= campaign frozen upper.
3. Require no active blocked/full-recovery state.
4. Require no relevant unresolved catch-up failure.
5. Record source catch-up run/cursor evidence.

Do not queue catch-up automatically from certification unless the certified F.2 workflow explicitly permits a system request. Default is wait/block.

## Analytics

1. Request/read B.2 exact event/range rebuild/readiness.
2. Require contribution projection through all campaign/catch-up revisions.
3. Require no dirty/failed bucket in required range.
4. Verify B.1 metric/semantic versions and currency.
5. Record built-through revision/time.

## Issue coverage

### Historical ingestion coverage

Issue when source scan, processing and seam pass.

### Metric completeness certificate

Issue only when semantics and B.2 also pass.

Use one transaction/explicit domain service so certificate evidence and event-scope final state agree.

## Negative cases

- unresolved unknown line -> ingestion may certify; metric certificate blocked;
- B.2 pending -> analytics_pending;
- event private -> no active certificate;
- source stale after issue -> historical certificate stays, current resolver says stale;
- corrected earlier boundary -> supersede/revoke and run new campaign.

## Downstream

Notify B.1/B.3/D via durable read/invalidation, not direct target activation.
