# Predecessor Contracts — VS-28A.1

## VS-26F.1 / VS-26F.2

F owns:

- source-wide updated-order candidate classification;
- page metadata and bounded source calls;
- source cursor/freshness;
- one active source catch-up run;
- shared Woo concurrency;
- catch-up failure evidence.

A.1 discovers historical orders by creation time, then requires the F cursor to close the modification seam.

## VS-26G

G owns:

- line semantics;
- ticket/add-on/membership/subscription/refund treatment;
- mapping disposition;
- unknown fail-closed behaviour.

A.1 may ingest unresolved event-attributed lines, but metric completeness remains blocked.

## VS-27B.1

B.1 owns:

- metric and semantic versions;
- sale-time and completeness semantics;
- currency;
- exact meaning of `certified_from`.

A.1 supplies historical evidence; it does not redefine completeness.

## VS-27B.2

B.2 owns:

- contribution projection;
- bucket rebuild/readiness;
- built-through revision/time;
- metric-version parity.

A.1 waits for B.2 readiness before metric certification.

## VS-27D

D may use a metric completeness certificate only after its target start is covered.

A.1 never arms targets.

## VS-28A.2

A.2 owns:

- admin authorization;
- selection UI;
- preview presentation;
- exact plan approval;
- queue/pause/resume/cancel controls;
- audit-visible evidence.

A.1 provides the non-web core and facades.
