# Implementation Agent Prompt Template — VS-26F.1

**Do not use until JC-151 returns APPROVE.**

Activation fills:

- exact main SHA;
- certified VS-26E.3 dependencies;
- final cursor/window and candidate rules;
- final resource/action names;
- exact migrations/indexes;
- exact queue/concurrency;
- exact tests/files/stop conditions.

Write tests first, implement activated scope, open a PR and stop before merge/deployment.
