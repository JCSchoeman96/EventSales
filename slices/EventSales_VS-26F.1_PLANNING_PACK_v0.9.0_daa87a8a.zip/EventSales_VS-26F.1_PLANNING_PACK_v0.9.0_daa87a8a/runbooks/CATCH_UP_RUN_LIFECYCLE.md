# Catch-Up Run Lifecycle

1. Internal facade loads active source and cursor.
2. Validate mode, bootstrap and active-run absence.
3. Calculate frozen bounded window.
4. Insert queued run and real Oban job atomically.
5. Worker claims run generation.
6. Fetch stable bounded identity/version scan.
7. Classify candidate orders.
8. Process relevant payloads through OrderUpserter.
9. Persist safe counts/failures.
10. Repeat/verify source scan.
11. Stop on instability or limits.
12. Complete run and advance cursor transactionally.
13. Emit post-commit telemetry/domain event.
14. F.2 later schedules and displays this lifecycle.
