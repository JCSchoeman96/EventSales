# Rollback and Stop Conditions

## Kill switches

- global catch-up disabled;
- source disabled;
- queue pause;
- no recurring scheduler in F.1.

## Stop immediately

- cursor advances after a limit/failure;
- page ceiling truncates;
- scans cannot stabilise;
- known-order status is skipped;
- unrelated products are imported;
- duplicate active run/job occurs;
- direct Sales writes appear outside OrderUpserter;
- REST concurrency exceeds two;
- raw payload/PII/credentials appear in evidence;
- historical completeness is falsely claimed.

Disable new queue requests first and preserve evidence.
