# Failure Matrix

| Failure | Run/cursor behaviour | Recovery |
|---|---|---|
| duplicate queue request | existing active run | no second run |
| Oban insert fails | transaction rollback | retry request |
| timeout/5xx/rate limit | retry scheduled | same window |
| circuit/queue timeout | retry scheduled | bounded backoff |
| invalid JSON/page | failed/blocked | cursor unchanged |
| full max page/too many rows | full recovery required | subdivide/manual |
| unstable repeated scan | retry/blocked | same window |
| relevant parse failure | durable failure | cursor unchanged |
| relevant upsert failure | durable failure | cursor unchanged |
| stale source update | stale success | continue |
| notification failure | durable order remains | safe retry/telemetry |
| source deactivated | cancel/pause | cursor unchanged |
| cursor transaction fails | run not completed | retry window |
