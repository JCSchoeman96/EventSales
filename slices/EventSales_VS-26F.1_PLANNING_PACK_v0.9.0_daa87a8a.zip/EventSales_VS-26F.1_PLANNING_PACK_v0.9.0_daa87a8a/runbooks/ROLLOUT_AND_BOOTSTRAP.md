# Rollout and Bootstrap

1. Deploy resources/worker disabled.
2. Verify migrations and partial unique index.
3. Verify Railway replicas and Woo concurrency.
4. Validate Woo page headers/query semantics.
5. Choose explicit operational bootstrap timestamp/lookback.
6. Record that historical completeness is not claimed.
7. Enable observation mode for one source.
8. Execute the same bounded window repeatedly.
9. Compare fingerprints and candidate counts.
10. Suppress one test webhook update.
11. Enable one catch-up canary.
12. Verify parser/OrderUpserter repair and cursor advance.
13. Repeat the window for idempotency.
14. Keep recurring schedule/admin UI disabled until F.2.
