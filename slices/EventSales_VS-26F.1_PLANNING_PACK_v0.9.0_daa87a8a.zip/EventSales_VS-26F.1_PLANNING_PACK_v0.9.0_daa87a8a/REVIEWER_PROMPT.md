# Independent Reviewer Prompt — VS-26F.1

Block designs that:

- reuse event-scoped cursor as source watermark without proof;
- complete on a full max page;
- advance after relevant parse/upsert failure;
- use unstable offset pages without no-skip proof;
- run once per event;
- lose known-order status after mapping drift;
- import unrelated store products;
- bypass OrderUpserter;
- insert run/job non-atomically without recovery;
- allow two active runs per source;
- assume node-local concurrency is global;
- use unbounded bootstrap or claim historical completeness;
- leak payloads, PII or credentials;
- pull F.2 UI/scheduler or later semantic changes into F.1.

Classify blocker, major and minor.

Verdict: APPROVE / REQUEST CHANGES / BLOCKED.

Approval authorises planning only; JC-151 controls implementation.
