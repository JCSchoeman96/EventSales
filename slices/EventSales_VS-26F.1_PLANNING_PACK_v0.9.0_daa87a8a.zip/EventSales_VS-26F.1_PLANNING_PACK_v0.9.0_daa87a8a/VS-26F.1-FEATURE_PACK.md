# VS-26F.1 — WooCommerce Order Catch-Up Core

## 1. Executive summary

WooCommerce webhooks remain the primary near-live order path.

VS-26F.1 adds a source-wide recovery path for missed/delayed webhooks, deployment windows, later source updates and mappings created after an order was missed.

The repository already contains event-scoped manual reconciliation. This slice reuses its REST, retry and upsert components while separating the source-wide near-live cursor from event-scoped manual/backfill state.

## 2. Existing repository truth

### Woo REST

`WooCommerceClient` provides order fetch/list operations, configurable timeouts/page limits, a rate limiter and circuit breaker.

Defaults are `per_page: 100`, `max_pages: 50`, and `max_concurrency: 2`.

### Manual reconciliation

`OrderReconciliation` uses `modified_after`, `modified_before`, ascending modification order and one page per worker step. It filters line items against active mappings for one event and calls `OrderUpserter`.

`SyncRun`/`SyncCursor` are event-scoped. `ManualSync` creates the run/audit before inserting Oban. `ReconcileOrdersWorker` drives retries and pages.

### Sales authority

`WoocommerceOrderParser` parses current order statuses, source timestamps, totals, line items, coupons and Tickera event metadata.

`OrderUpserter` is the sole Sales writer. It uses source/order and order/line identities, rejects older source versions and invokes current mapping logic.

## 3. Critical gaps

- Cursor is per run, not per source.
- Event id is mandatory.
- A full page at the configured maximum page can be treated as completion.
- Per-order failures can still permit run completion.
- Offset pagination has no no-skip proof.
- Client and caller both influence page/per-page values.
- Run/job insertion is not atomic.
- Candidate filtering is one-event-at-a-time.
- REST concurrency is node-local.
- No source-wide one-active-run constraint exists.

## 4. Target architecture

```text
internal catch-up queue request
-> atomic catch-up run + real Oban job
-> claim per-source cursor
-> freeze bounded source window
-> obtain stable Woo identity/version scan
-> classify relevant orders/lines
-> process through existing OrderUpserter
-> persist bounded failure evidence
-> verify complete stable window
-> transactionally complete run and advance cursor
```

Postgres remains authority.

## 5. Dedicated durable model

The plan should normally add dedicated resources rather than repurpose event-scoped `SyncRun`/`SyncCursor`.

### Catch-up cursor/config

- source system id;
- disabled / observe / enabled mode;
- committed modified watermark;
- overlap and settling delay;
- bootstrap boundary;
- operational completeness start;
- last attempted/successful run/window;
- blocked/full-recovery-required state;
- bounded last error;
- timestamps and generation metadata.

One row per source.

### Catch-up run

- source system id;
- requested via;
- status/retry metadata;
- frozen lower/upper bounds;
- cursor before/after;
- page/row/order/candidate/upsert/stale/skipped/failure counts;
- source totals;
- stable-scan fingerprints;
- Oban job linkage;
- started/finished timestamps.

### Failure evidence

For relevant order failures store only bounded identifiers and reason codes:

- source/run/order id;
- source modified time if available;
- stage;
- safe reason;
- attempt/status/timestamps.

No raw payload, billing/shipping data, credentials or payment secrets.

## 6. Stable-window proof

Woo REST uses offset pages. A plain timestamp plus page counter is insufficient.

Recommended direction:

1. freeze `[lower, upper)`;
2. obtain total rows/pages from Woo response headers;
3. fail or subdivide when limits are exceeded;
4. collect bounded `{woo_order_id, date_modified_gmt}` tuples;
5. repeat the same frozen scan;
6. require an identical deterministic fingerprint before cursor advance;
7. process/reprocess idempotently;
8. replay a bounded overlap in the next window.

An equivalent design is acceptable only with a stronger no-skip proof.

## 7. Candidate orders

Process each Woo order once per source window.

- Existing local order: always update header/status; include known and newly relevant lines.
- New order: process only when a line has a valid source Tickera event identity or active ProductMapping.
- Unknown irrelevant order: skip without persistence.
- Mixed-event order: process once with all relevant lines.
- Known order with no currently relevant new lines: allow header update with an empty filtered line list.

## 8. Cursor advancement

Cursor advancement is allowed only after:

- complete stable source scan;
- no page/row/window ceiling;
- every relevant order is upsert success or stale no-op;
- all durable run/failure writes succeed;
- completion and cursor update commit transactionally.

A parse/upsert failure blocks advancement.

## 9. Atomic queueing and uniqueness

Queue facade must atomically commit one queued run and one real Oban job.

Use a stable partial unique index to enforce one nonterminal run per source.

Do not use mocked job insertion as authority.

## 10. REST page boundary

Add or adapt a single-page order-list function returning:

- decoded orders;
- page/per-page;
- total rows/pages;
- relevant response metadata.

Only one layer owns page/per-page query fields.

## 11. Concurrency

- one active run per source;
- sequential pages by default;
- actual Woo REST concurrency no more than two;
- activation verifies Railway replica count;
- current node-local limiter cannot be assumed globally sufficient.

## 12. Existing idempotency

Keep:

- Order identity: source + Woo order id;
- OrderItem identity: order + Woo line item id;
- source-version guard;
- stale no-op;
- overlap replay safety.

Do not build a second Sales deduplication authority.

## 13. Semantic boundaries

Do not redefine:

- partial refunds;
- removed line/coupon deletion;
- subscription/renewal/membership/add-on semantics;
- fee/tax reporting;
- compact webhook contract.

These belong to later slices.

## 14. F.1/F.2 split

F.1 includes core resources, queue facade, worker/engine, REST metadata, telemetry and a read facade if needed.

F.2 later adds recurring schedule, admin queue action, progress UI, PubSub completion and stale-dashboard behaviour.

## 15. Tests-first sequence

1. resource/index tests;
2. atomic run/job tests;
3. REST page/query metadata tests;
4. stable-window/fingerprint tests;
5. same-timestamp/concurrent-mutation tests;
6. candidate-order tests;
7. parser/upserter integration;
8. failure-blocks-cursor tests;
9. retry/idempotency tests;
10. bootstrap/full-recovery-required tests;
11. topology/concurrency tests;
12. privacy/boundary tests;
13. production canary.

## 16. Acceptance

A deliberately suppressed order webhook is repaired by one bounded source-wide run. The source cursor advances only after complete stable discovery and durable processing. Repeated execution creates no duplicate order/item and no catalogue or unrelated source state changes.
