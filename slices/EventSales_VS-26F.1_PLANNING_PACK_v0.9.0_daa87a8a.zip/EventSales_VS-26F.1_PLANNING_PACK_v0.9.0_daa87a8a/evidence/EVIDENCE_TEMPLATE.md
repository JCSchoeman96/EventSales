# VS-26F.1 Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- Source id redacted:
- Cursor/window contract:
- Queue/config:

## Bootstrap
- operational completeness from:
- lookback:
- historical completeness claimed: no

## Missed-webhook canary
- Woo order id redacted:
- source modified at:
- webhook suppressed:
- window lower/upper:
- source pages/rows:
- fingerprints:
- candidate reason:
- upsert result:
- cursor before/after:
- total recovery time:

## Negative proof
- duplicate rerun:
- stale update:
- full-page ceiling:
- transient failure:
- permanent order failure:
- unrelated product:
- mixed-event order:
- no Catalog Sync inline:
- no direct Sales writes:
- no PII/secrets:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
