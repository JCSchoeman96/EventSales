# Mandatory File Inventory — VS-26F.1

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Existing reconciliation
- `lib/event_sales/ingestion/order_reconciliation.ex`
- `lib/event_sales/ingestion/manual_sync.ex`
- `lib/event_sales/ingestion/resources/sync_run.ex`
- `lib/event_sales/ingestion/resources/sync_cursor.ex`
- `lib/event_sales/ingestion/workers/reconcile_orders_worker.ex`
- `lib/event_sales/ingestion/validations/scoped_manual_sync.ex`
- `lib/event_sales/ingestion/reconciliation_peak_guard.ex`

## Woo REST
- `lib/event_sales/ingestion/clients/woocommerce_client.ex`
- `lib/event_sales/ingestion/clients/woocommerce_error.ex`
- `lib/event_sales/ingestion/woocommerce_rest_config.ex`
- `lib/event_sales/ingestion/rest_rate_limiter.ex`
- `lib/event_sales/ingestion/rest_circuit_breaker.ex`
- `lib/event_sales/ingestion/clients/httpc_transport.ex`
- `config/config.exs`
- `config/runtime.exs`

## Webhook path
- `lib/event_sales/ingestion/webhook_intake.ex`
- `lib/event_sales/ingestion/webhook_processor.ex`
- `lib/event_sales/ingestion/workers/process_webhook_worker.ex`
- `lib/event_sales/ingestion/resources/webhook_event.ex`

## Sales authority
- `lib/event_sales/ingestion/parsers/woocommerce_order_parser.ex`
- `lib/event_sales/sales/order_upserter.ex`
- `lib/event_sales/sales/source_version_guard.ex`
- `lib/event_sales/sales/changes/guard_source_version.ex`
- `lib/event_sales/sales/order_item_mapper.ex`
- `lib/event_sales/sales/resources/order.ex`
- `lib/event_sales/sales/resources/order_item.ex`
- `lib/event_sales/sales/resources/coupon_snapshot.ex`

## Catalog dependency
- `lib/event_sales/catalog/resources/source_system.ex`
- `lib/event_sales/catalog/resources/event.ex`
- `lib/event_sales/catalog/resources/product_mapping.ex`
- `lib/event_sales/catalog/order_attribution_resolver.ex`
- `lib/event_sales/ingestion/workers/missing_catalog_resolution_worker.ex`

## Deployment
- `railway.toml`
- `lib/event_sales/release.ex`
- `docs/architecture/oban-pgbouncer.md`
- `docs/runbooks/oban-queue-backlog.md`
- `docs/deployment/runtime-config.md`

## Tests
- `test/event_sales/ingestion/order_reconciliation_test.exs`
- `test/event_sales/ingestion/workers/reconcile_orders_worker_test.exs`
- `test/event_sales/ingestion/clients/woocommerce_client_test.exs`
- `test/event_sales/ingestion/woocommerce_rest_config_test.exs`
- `test/event_sales/ingestion/webhook_processor_test.exs`
- `test/event_sales/ingestion/parsers/woocommerce_order_parser_test.exs`
- `test/event_sales/sales/order_upserter_test.exs`
- `test/event_sales/sales/source_version_guard_test.exs`
- `test/event_sales/sales/order_item_mapper_test.exs`

## Predecessor evidence
- final VS-26E.3 pack, plan, activation, PR/head and production certification.
