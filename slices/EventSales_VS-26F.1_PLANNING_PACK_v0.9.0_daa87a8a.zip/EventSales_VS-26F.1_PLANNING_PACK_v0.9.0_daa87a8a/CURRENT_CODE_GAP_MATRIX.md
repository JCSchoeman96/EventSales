# Current Code Gap Matrix

| Current code | Useful truth | Gap for source-wide catch-up |
|---|---|---|
| `WooCommerceClient` | bounded REST, rate limiter, circuit breaker | no explicit page metadata; page ownership ambiguity |
| `OrderReconciliation` | modified window, one-page steps, existing upserter | event-scoped; full max page completes |
| `SyncCursor` | durable per-run progress | not per source; no near-live watermark |
| `SyncRun` | lifecycle and counts | event required; no source-wide active uniqueness |
| `ReconcileOrdersWorker` | retry/snooze pattern | event run only |
| `ManualSync` | auth/audit/queue | run and Oban insert not atomic |
| `RestRateLimiter` | local max concurrency two | node-local, not global |
| parser/upserter | current payload authority and stale guard | catch-up must not bypass |
| mapping filter | avoids unrelated products | one-event scope and known-order gaps |
| counts | visibility | order failures may still allow completion |
