# Candidate Order Contract

## Known order

If an EventSales Order already exists for source + Woo order id:

- process the order header/status;
- include locally known line-item ids;
- include newly relevant lines;
- allow an empty filtered line list so header truth still updates.

## New relevant order

Process when at least one line:

- has a valid `tickera_event_id` resolving to this source; or
- exactly matches an active ProductMapping in this source.

Include all relevant lines and let mapping logic leave unresolved lines pending.

## New irrelevant order

If no local order and no relevant line:

- count as observed/skipped;
- do not call OrderUpserter;
- do not persist PII or raw payload.

## Mixed-event order

Process once with all relevant lines across events. Do not run catch-up per event.

## Mapping drift

The plan must either snapshot relevant mapping identities at run start or prove safe eventual behaviour under current-state reads.

Do not classify non-ticket/ignored here; VS-26G owns that.
