# Predecessor Contracts — VS-26F.1

## Catalog automation

By activation, VS-26E.0–E.3 should provide a certified catalogue baseline, targeted updates, conservative catalogue policy and missed-change recovery.

Order catch-up relies on current mapping state but must not:

- call Catalog Sync inline;
- create Event, TicketType or ProductMapping records;
- reuse the catalogue reconciliation cursor;
- inherit catalogue auto-apply authority.

A relevant line may remain `pending_mapping_resolution` for existing recovery.

## Successors

VS-26F.2 consumes the F.1 facade/read model for schedule, admin refresh and LiveView progress.

VS-26G later defines membership, subscription, add-on, refund, fee and tax semantics.
