# VS-26F.1 Implementation Plan

## Baseline proof and files inspected
## Certified VS-26E.3 dependencies
## Current manual reconciliation truth
## Cursor/config resource
## Run/attempt resource
## Failure evidence resource
## State machines and reason codes
## One-active-run constraint
## Atomic run plus Oban insertion
## Woo single-page client contract
## Source window and inclusivity
## Pagination no-skip proof
## Stable scan/fingerprint
## Overlap, settling delay and subdivision
## Bootstrap/completeness
## Candidate-order classification
## Mapping snapshot/drift
## Parser/OrderUpserter integration
## Failure and cursor advancement
## Retry/idempotency/races
## Queue and deployment concurrency
## Telemetry/privacy
## Migrations/index/query plans
## Tests-first sequence
## Exact files create/modify/generated/forbidden
## Verification commands
## Rollout/kill switches
## Production canary/evidence
## VS-26F.2 extension points
## JC-151 activation inputs
## Risks/stop conditions
## Prohibited-actions statement
