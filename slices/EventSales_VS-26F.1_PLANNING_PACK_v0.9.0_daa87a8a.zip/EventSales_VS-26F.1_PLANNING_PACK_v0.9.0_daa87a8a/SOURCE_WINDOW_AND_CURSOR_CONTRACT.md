# Source Window and Cursor Contract

## Window

Recommended:

```text
effective_lower = committed_watermark - overlap
effective_upper = now_utc - settling_delay
window = [effective_lower, effective_upper)
```

Exact Woo inclusivity must be verified.

## Bootstrap

A new source cursor begins uninitialised. Activation chooses an explicit seed or bounded recent lookback and records `operational_completeness_from`.

It must not claim historical completeness; VS-28A handles launch backfill.

## Stable scan

Before cursor advance:

- upper bound remains frozen;
- source total rows/pages are known where supported;
- page and row limits are not exceeded;
- identity/version set is complete;
- repeated scan or equivalent proof confirms stability;
- all relevant orders are durable success or stale no-op.

## Advancement

Advance the committed watermark to the frozen upper bound only in the same durable completion transaction.

Never advance after timeout, rate limit, invalid page, page ceiling, unstable fingerprint, relevant parse/upsert failure, persistence failure or unsupported source state.

## Dense windows

Subdivide deterministically. If the minimum window remains too dense, mark `full_recovery_required`; never truncate.
