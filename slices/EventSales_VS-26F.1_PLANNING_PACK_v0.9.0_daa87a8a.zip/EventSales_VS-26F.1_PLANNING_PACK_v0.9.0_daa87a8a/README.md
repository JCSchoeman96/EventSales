# EventSales VS-26F.1 Planning Pack

## Identity

- Slice: `VS-26F.1`
- Name: WooCommerce Order Catch-Up Core
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `daa87a8a1693e399c8effeb23297efad159397fd`
- GitHub scope: `#122`
- GitHub umbrella: `#80`
- Linear parent: `JC-146`
- Pack: `JC-147`
- Pack review: `JC-148`
- Agent plan: `JC-149`
- Plan review: `JC-150`
- Activation: `JC-151`
- Implementation: `JC-152`

## Authority

This ZIP authorises repository reconnaissance and an implementation plan only.

It does not authorise code changes, migrations, WooCommerce calls, production catch-up runs, merge or deployment.

Implementation requires independent pack and plan approval, VS-26E.3 production certification, and an exact-current-main activation supplement from `JC-151`.

## Outcome

A missed WooCommerce order change is recovered through a bounded source-wide window and routed through:

```text
WoocommerceOrderParser
-> OrderUpserter
-> OrderItemMapper / pending mapping flow
```

No parallel Sales writer is permitted.

VS-26F.2 later adds recurring scheduling, admin refresh, progress UI and LiveView status.
