# TOON Prompts — VS-26F.1

## Planning agent
Task: Design source-wide Woo order catch-up from current code.
Objective: Repair missed webhooks through existing parser/upserter.
Output: Complete implementation plan.
Boundary: No code or Woo calls.

## Window reviewer
Task: Attack pagination, bounds, overlap and fingerprints.
Objective: Prove no cursor skip.
Boundary: Full max page is not success.

## Candidate reviewer
Task: Attack order/line relevance.
Objective: Recover known/ticket orders without unrelated store imports.
Boundary: Process a mixed-event order once.

## Concurrency reviewer
Task: Review active-run, atomic Oban insertion and REST concurrency.
Objective: Prove race safety.
Boundary: Node-local limiter is not assumed global.

## Activation reviewer
Task: Refresh main, E.3 certification and Railway/Woo topology.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
