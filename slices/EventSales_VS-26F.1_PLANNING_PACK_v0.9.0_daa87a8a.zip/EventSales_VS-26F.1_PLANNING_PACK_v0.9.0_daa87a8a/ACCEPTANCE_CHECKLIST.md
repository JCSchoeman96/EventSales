# VS-26F.1 Acceptance Checklist

## Planning
- [ ] Current baseline recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-26E.3 certified.
- [ ] JC-151 approved.

## Resources and queue
- [ ] One cursor per source.
- [ ] Dedicated run history.
- [ ] Bounded failure evidence.
- [ ] One active run per source.
- [ ] Supporting indexes.
- [ ] Atomic run plus real Oban job.

## Window
- [ ] Frozen upper bound.
- [ ] Overlap and settling delay.
- [ ] Explicit bootstrap.
- [ ] No historical completeness claim.
- [ ] Page metadata.
- [ ] Stable-scan/no-skip proof.
- [ ] Dense-window subdivision.
- [ ] Limits fail closed.
- [ ] Cursor advances transactionally.

## Orders
- [ ] Existing OrderUpserter only.
- [ ] Source-version guard unchanged.
- [ ] Known order status recovered.
- [ ] Mixed-event order processed once.
- [ ] Valid Tickera identity preserved.
- [ ] Newly mapped order recovered.
- [ ] Unrelated products skipped.
- [ ] Relevant failure blocks cursor.
- [ ] Duplicate overlap harmless.

## Safety and boundaries
- [ ] Actual Woo concurrency <= 2.
- [ ] Replica topology verified.
- [ ] No REST in web hot paths.
- [ ] No raw payload/credential evidence.
- [ ] No extra PII rendering.
- [ ] No Catalog Sync inline.
- [ ] No direct Sales writes.
- [ ] No F.2 scheduler/UI.
- [ ] No VS-26G semantic expansion.
- [ ] No VS-27A webhook rewrite.

## Production
- [ ] Suppressed webhook canary recovered.
- [ ] Cursor evidence correct.
- [ ] Duplicate rerun safe.
- [ ] Stale update safe.
- [ ] No unrelated mutation.
- [ ] Certification recorded.
