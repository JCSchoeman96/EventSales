# Planning Agent Prompt — VS-26F.1

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-26F.1_PLANNING_PACK_v0.9.0_daa87a8a.zip`
Planning baseline: `daa87a8a1693e399c8effeb23297efad159397fd`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, commit, open/merge a PR, run migrations, call WooCommerce, queue catch-up or change production.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory work

Read all paths in `FILE_INVENTORY.md`.

Inspect certified VS-26E.3 artifacts when available; otherwise mark every dependency for `JC-151` refresh.

Complete the implementation plan with:

1. resource and lifecycle design;
2. one-active-run constraint;
3. atomic run/job insertion;
4. Woo single-page response metadata;
5. frozen window and inclusivity;
6. offset-pagination no-skip proof;
7. overlap/settling/subdivision;
8. bootstrap and completeness;
9. candidate-order/line rules;
10. mapping drift strategy;
11. parser/OrderUpserter integration;
12. failure/cursor semantics;
13. retry/idempotency/races;
14. deployment concurrency;
15. migrations/index/query plans;
16. tests-first sequence;
17. rollout and production canary;
18. VS-26F.2 extension points;
19. `JC-151` activation inputs.

Finish with `PACK VALID`, `PACK REFRESH RECOMMENDED` or `PACK BLOCKED`, and confirm no prohibited action occurred.
