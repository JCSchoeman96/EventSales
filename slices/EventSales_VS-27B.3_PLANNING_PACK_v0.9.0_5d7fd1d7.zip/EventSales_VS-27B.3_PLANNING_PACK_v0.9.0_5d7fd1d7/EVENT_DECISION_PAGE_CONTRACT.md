# Event Decision Page Contract

## Route

```text
/admin/events/:id?tab=overview
```

Default overview is PII-free and reads B.2 only.

## Required overview

### Event context

- name, dates, venue;
- catalogue status and lifecycle;
- source/currency;
- data completeness;
- source and bucket freshness.

### Selected-window KPIs

- net tickets sold;
- net recognised ticket revenue;
- B.1 comparison state/deltas;
- clear selected period label.

### Capacity and remaining

Capacity is catalogue truth.

Current net entitlement and remaining are not selected-window metrics.

Display only when B.1/B.2 provides the required observed/certified cumulative basis.

Labels must distinguish:

- certified sold/remaining;
- observed-to-date sold/remaining;
- unavailable because history is incomplete.

Never subtract a selected-window count from event capacity.

### Trends

- event selected-window series;
- tickets/revenue toggle;
- optional previous-period overlay;
- B.1/B.2 resolution;
- accessible fallback.

### Ticket types

For each certified ticket type:

- capacity;
- selected-window tickets/revenue;
- current observed/certified sold;
- remaining when valid;
- completeness;
- stable sorting.

Do not combine ticket types from labels alone.

### Status context

Use explicit certified units only.

## Operations tab

```text
/admin/events/:id?tab=operations
```

May preserve existing global-admin services:

- recent orders;
- masked/allowed customer data;
- unmapped items;
- imports;
- exports;
- correction links.

Rules:

- loaded only when selected;
- separately authorised;
- not part of decision DTO;
- no decision chart/KPI depends on it;
- existing exports are operational/legacy until VS-28B;
- decision overview does not imply export parity.

## Not-found/forbidden

- invalid UUID: not found or bounded error;
- inaccessible event: do not leak existence;
- source/currency mismatch: explicit error;
- incomplete buckets: overview renders state, not raw fallback.
