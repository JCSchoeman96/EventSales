# PII and Operations Boundary

## Decision DTO denylist

New all-event and event overview DTOs must not contain:

- customer name;
- customer email;
- address;
- phone;
- order number;
- order id unless internal aggregate identity is essential and not rendered;
- transaction/payment identifiers;
- raw order total;
- raw payload;
- coupon code;
- free-form source metadata.

Stable event/ticket ids and aggregate counts are allowed.

## All-event dashboard

Remove order-level content from the decision contract.

Operational links may remain, but recent orders and unmapped rows are not required for the default decision page.

## Event overview

PII-free by default.

Do not call `EventDetail.recent_orders/2` or equivalent during overview mount.

## Operations tab

Global-admin-only in B.3.

Operational reads:

- use existing PII policy/presenters;
- load only after explicit tab selection;
- preserve pagination;
- do not join into analytics DTO;
- do not influence KPI/chart values;
- remain separately testable.

## Future VS-27C

Decision facades must accept `actor` and event scope, but B.3 does not expose non-admin routes.

Revenue visibility fields should be structured so C can mask them without changing metric math.

## Logging and telemetry

No filter, error or telemetry metadata may include PII or arbitrary query values beyond bounded enums/counts.

## Tests

- recursive PII denylist over all decision DTOs;
- rendered HTML denylist with seeded private values;
- overview proves operations services were not called;
- operations tab authorization test;
- no PII in PubSub or chart payload.
