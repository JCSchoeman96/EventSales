# Performance and Bounds

## Product boundary

- approximately twenty current public events;
- approximately 10,000 tickets over weeks;
- fifty concurrent dashboard viewers;
- future scope up to B.1/B.2 event and point limits.

## Read rules

- no raw Sales or contribution scans from LiveView/web code;
- no per-event loop of separate B.2 queries for all-event headline data;
- no N+1 ticket-type names;
- one bounded all-event response or small reviewed parallel read set;
- event ranking pagination independent of total calculation;
- ticket-type pagination explicit;
- series point limits enforced before rendering;
- response payload size measured.

## Planning timing targets

Activation must establish realistic production targets.

Initial review targets:

- all-event initial B.2 read p95 <= 750 ms;
- event detail initial B.2 read p95 <= 500 ms;
- filter patch p95 <= 750 ms;
- PubSub-to-visible-update p95 <= 2 seconds after B.2 commit;
- no more than one reread per debounce window.

These are not promises until topology evidence confirms them.

## Browser bounds

- maximum chart points inherited from B.1/B.2;
- no rendering thousands of table rows;
- paginated rankings;
- no repeated full chart library load;
- no memory leak across LiveView patches;
- mobile layout remains usable.

## Subscription bounds

- prefer one source/scope topic for all-event;
- otherwise at most selected event-limit subscriptions;
- unsubscribe removed topics;
- no subscription accumulation after repeated current/past toggles.

## Query evidence

Require:

- B.2 reader query plans from predecessor;
- LiveView integration timings;
- payload byte sizes;
- fifty-viewer representative load;
- message storm/debounce test;
- event scope above current 50-row compatibility limit;
- contribution history above current 1,000-row compatibility limit.
