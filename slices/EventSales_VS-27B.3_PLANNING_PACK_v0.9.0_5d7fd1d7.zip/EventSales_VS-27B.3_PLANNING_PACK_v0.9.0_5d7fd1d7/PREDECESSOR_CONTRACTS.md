# Predecessor Contracts — VS-27B.3

## VS-27B.1

B.1 owns all public metric and window meaning.

B.3 may format and present values. It may not:

- rename a metric into a different meaning;
- calculate its own comparisons;
- change half-open boundaries;
- infer currency or completeness;
- use float money as authority.

## VS-27B.2

B.2 owns:

- dashboard summary and series reads;
- event and ticket-type bucket reads;
- exact edge-window handling;
- missing/rebuilding/partial states;
- bucket freshness;
- PubSub invalidation topics;
- all-event completeness.

B.3 may not query contribution or Sales tables directly.

## VS-26F.2

F.2 owns:

- source freshness;
- queued/running/retry/blocked state;
- `Check WooCommerce now`;
- source operational PubSub.

B.3 displays and invokes those certified facades only.

## VS-27C

C later owns non-admin routes, event assignment and revenue visibility expansion.

B.3 must prepare actor-aware PII-free decision facades without activating broader access.

## VS-27D and VS-28B

D owns targets/alerts. 28B owns redesigned exports and corrections.

B.3 must not pre-implement either.
