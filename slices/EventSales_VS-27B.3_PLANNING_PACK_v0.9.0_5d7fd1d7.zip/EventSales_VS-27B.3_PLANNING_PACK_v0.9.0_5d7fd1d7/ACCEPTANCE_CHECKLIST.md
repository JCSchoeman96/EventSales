# VS-27B.3 Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-27B.1 certified.
- [ ] VS-27B.2 certified and closed.
- [ ] VS-26F.2 interfaces refreshed.
- [ ] Certified catalogue reportable-event scope refreshed.
- [ ] JC-206 verdict APPROVE.

## URL/query state
- [ ] Typed parser separate from LiveView rendering.
- [ ] Current/past/all scope.
- [ ] 15/30/60/today/yesterday/7d/custom.
- [ ] Inclusive UI custom dates translated to half-open B.1 bounds.
- [ ] Compare/metric/resolution.
- [ ] Stable sorting and pagination.
- [ ] Invalid/excessive inputs safe.
- [ ] Canonical URL/back-forward behaviour.
- [ ] Filter context preserved into event drill-down.

## All-event dashboard
- [ ] B.2-only headline read.
- [ ] Totals independent of visible event page.
- [ ] Exact B.1 comparison states.
- [ ] Real B.2 trend.
- [ ] Event ranking complete/paginated.
- [ ] Ticket-type ranking complete or explicitly bounded.
- [ ] Status units explicit or unavailable.
- [ ] No raw Sales fallback.
- [ ] No PII/order rows in DTO.

## Event overview
- [ ] B.2-only selected-window KPIs.
- [ ] Capacity basis separate from selected window.
- [ ] Observed/certified remaining label.
- [ ] Event trend.
- [ ] Ticket-type performance.
- [ ] Status units explicit.
- [ ] Freshness/completeness.
- [ ] Overview does not load operational services.

## Operations boundary
- [ ] Explicit operations tab.
- [ ] Global-admin-only in B.3.
- [ ] Lazy loading.
- [ ] Existing PII policy/presenters.
- [ ] Exports labelled/moved as operational.
- [ ] Operational data never influences decision metrics.

## Freshness and actions
- [ ] F.2 source freshness shown.
- [ ] B.2 bucket freshness shown.
- [ ] Historical completeness shown.
- [ ] States visually/textually distinct.
- [ ] Check WooCommerce now uses F.2.
- [ ] Refresh view creates no job.
- [ ] No ambiguous Refresh.
- [ ] No inline Woo/bucket rebuild.

## Live updates
- [ ] Exact source/scope or bounded event topics.
- [ ] Event detail topic.
- [ ] F.2 source topic.
- [ ] Subscription reconciliation/unsubscribe.
- [ ] Debounce/coalescing.
- [ ] Async stale-result guard if applicable.
- [ ] Mount/reconnect reload durable truth.
- [ ] Missed/duplicate messages harmless.
- [ ] PubSub-to-visible timing evidence.

## Chart and frontend
- [ ] No CDN.
- [ ] No inline executable chart script.
- [ ] Production CSP remains self-only.
- [ ] Asset bundled/digested.
- [ ] Hook mounted/updated/destroyed or SVG equivalent.
- [ ] No chart instance leak.
- [ ] Tickets/revenue single-metric chart.
- [ ] Previous overlay correct.
- [ ] Accessible summary/table.
- [ ] Keyboard/contrast/reduced-motion checks.
- [ ] Mobile layout.

## Privacy and access
- [ ] Recursive DTO PII denylist.
- [ ] Rendered overview PII denylist.
- [ ] No PII in URL/chart/PubSub/telemetry.
- [ ] Current routes remain admin-only.
- [ ] Facades actor-aware for future C.
- [ ] No target/access/backfill scope.

## Performance
- [ ] No raw Sales refs in decision web/facade path.
- [ ] No N+1 event reads.
- [ ] >50 event test.
- [ ] >1,000 fact test.
- [ ] Point/payload bounds.
- [ ] Fifty-viewer representative load.
- [ ] Message-storm load.
- [ ] Reader timings recorded.

## Cutover
- [ ] Legacy mode.
- [ ] Bounded shadow mode or reviewed alternative.
- [ ] Enabled mode.
- [ ] Rollback without migration reversal.
- [ ] Existing dashboard path unchanged before authorisation.
- [ ] Production canary.
- [ ] JC-210 certification.
