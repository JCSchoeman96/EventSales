# All-Event Dashboard Contract

## Purpose

Answer:

- How many certified net tickets and how much recognised ticket revenue occurred in the selected period?
- How does that compare with the previous equivalent period?
- Which events and ticket types contributed most?
- Is the data fresh, built and historically complete enough to trust?
- Is a Woo catch-up currently queued or required?

## Required response DTO

Candidate top-level sections:

- `query`
- `headline`
- `comparison`
- `series`
- `event_ranking`
- `ticket_type_ranking`
- `status_context`
- `source_freshness`
- `bucket_freshness`
- `completeness`
- `currency`
- `contract_versions`
- `generated_at`
- `warnings`

No PII or order rows.

## Headline

Show selected-window:

- net tickets sold;
- net recognised ticket revenue;
- comparison absolute delta;
- comparison state;
- percentage only when B.1 defines it.

Do not label selected-window values as lifetime or today unless that is the exact selected window.

## Trend

- use B.2 series;
- metric switch between tickets/revenue;
- optional previous-period overlay when certified and readable;
- explicit resolution and timezone;
- no dual-axis chart that implies direct scale comparison;
- empty/missing/rebuilding states distinguished.

## Event ranking

- complete selected scope and window;
- stable id/name;
- net tickets and revenue;
- comparison/velocity only when B.2 supports it;
- explicit completeness/freshness state;
- stable sorting;
- paginated rows;
- headline totals never derived from visible ranking page;
- clicking an event preserves relevant filter parameters.

## Ticket-type ranking

- B.2-backed;
- stable event and ticket-type ids;
- selected-window metrics;
- stable sorting and pagination;
- explicit top-N label only when intentionally bounded;
- no silent 1,000-row or page truncation.

## Status context

Only show certified explicit units:

- distinct orders by current status;
- ticket quantity by current status;
- status/refund activity series if B.1/B.2 supports it.

If not supported, render a clear unavailable state. Never fallback to raw Sales SQL.

## Operations section

Retain links to:

- Events;
- order catch-up/source operations;
- catalog sync;
- mappings;
- reconciliation;
- webhooks;
- Oban.

Do not include recent order numbers or customer data in the decision DTO.

## Event scope

Planning interpretation:

- `current`: certified reportable current/future events;
- `past`: certified reportable past events;
- `all`: current plus past reportable events.

Final status/publication rules come from activated certified catalogue code. Draft/private/cancelled inclusion must not be guessed.
