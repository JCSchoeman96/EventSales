# Independent Reviewer Prompt — VS-27B.3

Block any design that:

- calculates metric/window/comparison logic in LiveView;
- reads Sales or contribution rows from web code;
- derives all-event totals from visible/paginated rows;
- silently truncates events, ticket types or series;
- falls back to raw rows when B.2 data is missing;
- conflates source, bucket and completeness state;
- subtracts selected-window tickets from capacity;
- shows ambiguous status counts;
- sums currencies;
- loads PII operations on overview;
- embeds order/customer data in DTO/chart/PubSub;
- keeps generic `Refresh`;
- calls Woo or rebuilds buckets inline;
- accumulates PubSub subscriptions;
- issues one reread per message storm;
- uses CDN or inline chart JavaScript;
- weakens CSP;
- lacks accessible chart fallback;
- broadens route access before VS-27C;
- introduces targets/notifications/backfill/export redesign;
- lacks cutover rollback.

Classify blocker, major and minor.

Verdict: APPROVE / REQUEST CHANGES / BLOCKED.

Approval authorises planning only. JC-206 controls implementation.
