# Planning Agent Prompt — VS-27B.3

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-27B.3_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, commit, open a PR, change routes/policies, call source systems, switch production dashboard mode, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified B.1/B.2/F.2 artifacts. If B.2 is not certified, mark all actual reader/topic contracts unresolved for JC-206.

## Required plan decisions

1. actual B.2 dashboard/event reader APIs;
2. actual B.2 source/event topics and freshness metadata;
3. typed URL query/filter parser;
4. reportable event scope from certified catalogue code;
5. all-event DTO and read count;
6. event overview DTO;
7. events index migration;
8. comparison and selected-period labels;
9. capacity/current entitlement/remaining basis;
10. status-context support or unavailable state;
11. source/bucket/completeness state component;
12. F.2 queue action and Refresh view;
13. subscription reconciliation and debounce;
14. sync versus async LiveView reads and stale-result guard;
15. chart implementation and asset provenance;
16. CSP/root layout changes;
17. accessibility fallback;
18. PII-free overview and lazy operations tab;
19. legacy/shadow/enabled cutover;
20. exact routes/navigation/links;
21. tests-first sequence;
22. browser/load/security verification;
23. exact files create/modify/generated/forbidden;
24. rollout/rollback/stop conditions;
25. JC-206 activation inputs.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`; or
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
