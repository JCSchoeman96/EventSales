# Route and Navigation Contract

## Existing routes retained

- `/admin/dashboard`
- `/admin/events`
- `/admin/events/:id`

No new public/non-admin route in B.3.

## Dashboard

Page title should describe sales decisions rather than generic administration.

Operations links remain available but secondary to decision state.

## Events index

Planning direction:

- keep as event navigation/list;
- use B.2-backed observed/certified values or remove ambiguous sales columns;
- current/past filter remains URL-driven;
- event links preserve relevant window/compare/metric params;
- pagination never affects all-event dashboard totals.

## Event detail tabs

- `overview`: default decision page;
- `operations`: global-admin operational functions.

The tab is encoded in URL.

## Breadcrumbs/back links

- preserve filter context where practical;
- event overview returns to all-event dashboard or event index without losing the selected period;
- operations tab returns to overview;
- no hidden session-only filter state.

## AdminShell

Keep existing shell and navigation groups unless the implementation plan proves a small reviewed label change.

Potential wording:

- Dashboard -> Sales Dashboard
- Events remains Events.

Do not add target/access/backfill navigation in this slice.

## Export links

Current summary/orders CSV links are operational/legacy.

Move them to the operations tab or label them clearly. Do not imply their metrics are B.1/B.2 certified until VS-28B.

## Not-found/security

The event decision route must not disclose inaccessible event existence to future non-admin actors.

Current B.3 route remains global-admin-only.
