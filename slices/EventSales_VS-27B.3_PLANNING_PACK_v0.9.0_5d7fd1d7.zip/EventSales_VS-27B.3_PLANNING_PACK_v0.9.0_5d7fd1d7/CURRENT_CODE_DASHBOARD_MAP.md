# Current Code Dashboard Map

| Area | Current behaviour | B.3 requirement |
|---|---|---|
| AdminDashboard KPI | sum displayed rows | read complete B.2 all-event result |
| Event limit | 50 | pagination must not limit totals |
| Ticket-type input | max 1,000 recent rows | B.2 bounded aggregate reader |
| Trend | placeholder `daily_buckets` | real B.2 series |
| Refresh | local hot-state rebuild | split Check Woo now / Refresh view |
| Dashboard live update | replace one legacy event row | reread affected B.2 query |
| Topic handling | subscriptions only added | reconcile/unsubscribe |
| Event list | hot/snapshot totals | B.2 summary or catalog-only |
| Event detail summary | raw Sales SQL | B.2 event reader |
| Event detail statuses | ticket quantity under ambiguous label | explicit B.1 units |
| Event detail operations | PII loaded by default | lazy separate operations tab |
| Chart library | CDN + inline JS | self-hosted hook/SVG |
| CSP | production `script-src 'self'` | no external/inline script |
| Root chart script | always loaded | remove global dependency |
| Admin routing | global admin only | retain in B.3 |
| Policies | event-dashboard/revenue helpers already exist | keep facade actor-aware for C |
| Dashboard DTO tests | explicit PII denylist | replace with new decision contract tests |
