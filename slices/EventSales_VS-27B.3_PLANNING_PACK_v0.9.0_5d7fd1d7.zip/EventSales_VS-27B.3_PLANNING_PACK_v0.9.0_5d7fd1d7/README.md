# EventSales VS-27B.3 Planning Pack

## Identity

- Slice: `VS-27B.3`
- Name: All-Event and Event Sales Decision Dashboard
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#126`
- Linear parent: `JC-201`
- Pack: `JC-202`
- Pack review: `JC-203`
- Agent plan: `JC-204`
- Plan review: `JC-205`
- Activation: `JC-206`
- Implementation: `JC-207`

## Authority

This ZIP authorises repository reconnaissance and implementation planning only.

It does not authorise:

- code changes;
- route or policy changes;
- deployment;
- dashboard cutover;
- production source calls;
- bucket writes or rebuilds;
- merge.

Implementation requires:

1. independent pack approval;
2. independent plan approval;
3. VS-27B.2 production certification and `JC-200` closeout;
4. exact-current-main activation through `JC-206`;
5. certified VS-27B.1, VS-27B.2 and VS-26F.2 interfaces;
6. `JC-206` verdict `APPROVE`.

## Outcome

Replace compatibility dashboard reads with a bounded, PII-free decision experience backed exclusively by the certified B.2 reader and B.1 metric contract.

```text
B.1 metric/window law
        ↓
B.2 durable buckets/read facade
        ↓
B.3 URL-driven all-event and event dashboards
```

## Route direction

Keep the existing public admin paths:

- `/admin/dashboard`
- `/admin/events`
- `/admin/events/:id`

The default dashboard and event overview become B.2-backed and PII-free.

Existing global-admin operations such as recent orders, customer details, exports, imports and mapping review remain separately loaded operational functionality and are not part of the decision-dashboard data contract.

## Cutover rule

A feature/configuration mode must preserve a controlled rollback to the current compatibility dashboard until B.3 production certification.
