# Implementation Agent Prompt Template — VS-27B.3

**Do not use until JC-206 returns APPROVE.**

Activation fills:

- exact current main SHA;
- certified B.1/B.2/F.2 interfaces and versions;
- exact filter/query contract;
- exact page DTOs;
- exact source/event topics;
- exact chart asset/hook choice;
- exact operations-tab boundary;
- exact feature-flag modes;
- exact files/tests/browser/load checks;
- rollout/rollback/stop conditions.

Write tests first. Implement only activated scope. Open a PR and stop before merge, deployment or dashboard cutover.
