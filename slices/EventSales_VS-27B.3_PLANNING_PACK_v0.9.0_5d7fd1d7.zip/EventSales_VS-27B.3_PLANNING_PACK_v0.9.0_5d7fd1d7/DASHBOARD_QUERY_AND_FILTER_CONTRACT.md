# Dashboard Query and URL Filter Contract

## Principles

- URL is the canonical user-visible filter state.
- Every read captures one server-side `as_of`.
- URLs never carry customer/order data.
- Invalid inputs are normalized or rejected explicitly.
- Filters cannot widen beyond B.1/B.2 bounds.
- Headline totals are independent of table pagination.

## All-event route

```text
/admin/dashboard
```

Planning query parameters:

- `scope=current|past|all`
- `window=15m|30m|60m|today|yesterday|7d|custom`
- `from=YYYY-MM-DD`
- `through=YYYY-MM-DD`
- `compare=0|1`
- `metric=tickets|revenue`
- `resolution=auto|hour|day`
- `sort=revenue_desc|tickets_desc|name_asc`
- `page=<positive integer>`
- `ticket_page=<positive integer>`

## Event route

```text
/admin/events/:id
```

Use the same window/comparison/metric/resolution parameters plus:

- `tab=overview|operations`

Default tab is `overview`.

## Custom date semantics

The UI uses inclusive local business dates:

```text
from = first included business date
through = last included business date
```

The server converts this to B.1's half-open UTC range:

```text
[from local midnight, day after through local midnight)
```

Reject or normalize:

- missing one custom boundary;
- `from > through`;
- span over B.1 maximum;
- unsupported resolution;
- unsupported timezone;
- excessive page or selected scope;
- event id not accessible.

## Defaults

Planning defaults:

- scope: `current`
- window: `today`
- compare: `1`
- metric: `tickets`
- resolution: `auto`
- page: `1`
- tab: `overview`

Activation may change defaults only with product-owner review.

## Canonicalization

After parsing:

- remove unknown params;
- emit canonical param values;
- reset pagination when scope/window/sort changes;
- preserve filter state when navigating to event detail and back;
- do not include `as_of` in normal URLs;
- avoid repeated redirect loops.

## Browser history

- filter changes use patch/navigation appropriate to user intent;
- back/forward restores the same state;
- form controls reflect URL after reconnect;
- invalid state presents a clear bounded error or safe canonical URL.

## Read request

The facade receives a typed query struct rather than raw params.

Candidate fields:

- actor;
- reportable event scope;
- event id when applicable;
- B.1 window;
- comparison flag;
- metric;
- resolution;
- currency/source;
- ranking sort/page;
- one `as_of`.

Parsing, authorization and B.2 reading remain separate.
