# TOON Prompts — VS-27B.3

## Planning agent
Task: Design B.2-backed decision dashboard cutover from current repository code.
Output: Complete implementation plan.
Boundary: No code or production actions.

## UX reviewer
Task: Attack labels, filters, comparison meaning, states and mobile/accessibility.
Output: UX findings.
Boundary: B.1 meaning unchanged.

## LiveView reviewer
Task: Attack subscriptions, debounce, async races, reconnect and URL state.
Output: Race/state findings.
Boundary: Durable reader is truth.

## Privacy reviewer
Task: Attack DTO, chart, PubSub and operations-tab PII boundaries.
Output: Privacy verdict.
Boundary: Overview PII-free.

## Frontend security reviewer
Task: Attack CSP, chart asset provenance, inline code and lifecycle leaks.
Output: Security findings.
Boundary: Self-hosted assets only.

## Activation reviewer
Task: Refresh actual B.1/B.2/F.2/current code interfaces.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
