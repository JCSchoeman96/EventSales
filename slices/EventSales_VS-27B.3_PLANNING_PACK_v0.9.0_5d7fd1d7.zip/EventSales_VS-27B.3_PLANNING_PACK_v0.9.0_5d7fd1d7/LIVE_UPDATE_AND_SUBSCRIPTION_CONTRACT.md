# Live Update and Subscription Contract

## Authorities

- B.2 PubSub: bucket/read-model invalidation hint.
- F.2 PubSub: source freshness and catch-up status hint.
- Postgres/B.2/F.2 facades: truth.

## All-event dashboard

Preferred subscription:

- certified source/scope bucket topic;
- certified F.2 source-status topic.

If B.2 exposes event topics only:

- subscribe only to the currently selected reportable event ids;
- enforce B.1/B.2 event-count bound;
- reconcile exact subscription set on scope change;
- unsubscribe removed ids.

Do not create an unbounded global topic.

## Event page

Subscribe to:

- exact event bucket topic;
- exact source status topic.

Operations tab subscriptions remain separate if needed.

## Coalescing

Message storms must not launch one query per message.

Planning default:

- schedule a refresh after 250 ms;
- coalesce all invalidations while scheduled;
- maximum delay one second;
- reload one exact current query;
- record last received/loaded revision where B.2 exposes it.

Activation may adjust with load evidence.

## Reload semantics

On invalidation:

1. retain current visible data with an updating indicator;
2. reread B.2/F.2 using the current typed query and one new `as_of`;
3. replace complete DTO atomically;
4. reconcile subscriptions;
5. clear updating state;
6. preserve URL and user focus where possible.

Do not mutate one event row and recompute all-event totals client-side.

## Mount and reconnect

Every mount/reconnect:

- parses URL;
- authorizes;
- reads durable state;
- subscribes after connection;
- does not rely on replayed PubSub history.

## Duplicate/missed/out-of-order messages

Harmless because the facade reloads current durable state.

## Async reads

If implementation uses `start_async`/tasks:

- include query generation/request id;
- discard stale completion for an old URL;
- cancel/ignore prior work on filter change;
- never update the socket with older data.

Synchronous reads must remain bounded and meet activation timing evidence.
