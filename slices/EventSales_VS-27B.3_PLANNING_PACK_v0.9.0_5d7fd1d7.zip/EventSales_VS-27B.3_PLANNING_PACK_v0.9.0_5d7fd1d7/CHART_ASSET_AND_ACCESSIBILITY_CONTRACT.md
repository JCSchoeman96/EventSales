# Chart Asset and Accessibility Contract

## Current problem

The repository currently:

- loads Chart.js from `cdn.jsdelivr.net`;
- embeds inline JavaScript in the chart component;
- uses `phx-update="ignore"`;
- has production CSP `script-src 'self'`.

The current chart path is therefore not an acceptable production design.

## Approved implementation families

The implementation plan must choose one:

1. self-hosted/bundled chart library with a LiveView hook; or
2. accessible server-rendered SVG chart.

No external CDN or inline executable script.

## Self-hosted hook requirements

Candidate structure:

```text
assets/vendor/<reviewed chart asset>
assets/js/hooks/sales_chart.js
assets/js/app.js
LiveView component with phx-hook
```

Hook lifecycle:

- `mounted`: create chart;
- `updated`: replace data/config without duplicate instances;
- `destroyed`: destroy and release observers;
- handle theme/resize where applicable;
- no global polling for library availability.

All assets pass through the existing build/digest pipeline.

## Data transport

- bounded series only;
- JSON data attributes or a reviewed DOM payload;
- no PII;
- stable point ordering;
- currency and period labels;
- chart numbers are display projections only;
- Decimal values remain authoritative server-side.

## Chart behaviour

- one primary metric at a time: tickets or revenue;
- optional previous-period overlay;
- avoid misleading tickets/revenue dual axes;
- explicit timezone/resolution;
- clear empty, rebuilding and incomplete states;
- theme-aware colours from CSS variables or reviewed tokens;
- no colour-only comparison meaning.

## Accessibility

Provide:

- chart title and description;
- summary of selected period/current/previous;
- keyboard-accessible metric/filter controls;
- accessible table or list of points;
- status changes announced appropriately;
- contrast verification;
- reduced-motion-safe behaviour;
- tooltips not required to understand essential values.

## CSP tests

Verify:

- root layout contains no external Chart.js script;
- no inline chart script;
- production CSP remains self-only;
- compiled asset loads in production;
- LiveView updates chart without full reload;
- browser console has no CSP violations.
