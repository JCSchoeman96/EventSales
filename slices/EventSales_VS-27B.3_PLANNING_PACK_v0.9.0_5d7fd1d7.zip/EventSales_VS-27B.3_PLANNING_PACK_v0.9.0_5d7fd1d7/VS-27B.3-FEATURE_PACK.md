# VS-27B.3 — All-Event and Event Sales Decision Dashboard

## 1. Identity

- Pack: `0010_VS-27B.3`
- Version: `0.9.0`
- Baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub: #126
- Linear: JC-201 through JC-211
- Predecessor: VS-27B.2
- Execution authority: none

## 2. Goal

Provide decision-grade all-event and event-specific sales visibility without raw Sales scans, ambiguous labels, silent truncation, mixed currency, hidden incompleteness or customer PII.

## 3. Current repository truth

### `/admin/dashboard`

Current behaviour:

- loads at most fifty events;
- derives headline KPIs by summing displayed event rows;
- derives ticket-type totals from at most 1,000 recent line rows;
- has no real trend data;
- shows a generic `Refresh` action that requests local hot-state rebuild;
- subscribes to displayed event topics and accumulates subscriptions;
- updates one compatibility event row on PubSub;
- includes recent orders and unmapped operational data.

### `/admin/events`

Current event list:

- paginates at twenty-five;
- reads hot/snapshot summaries;
- shows lifetime-like sold and revenue without completeness language;
- links to the event detail page.

### `/admin/events/:id`

Current event detail:

- directly aggregates raw Sales tables;
- uses ambiguous status labels;
- mixes decision metrics with customer name/email order tables;
- links to exports/imports;
- reloads detail after event hot-state PubSub.

### Chart/assets

Current chart:

- has placeholder data;
- loads Chart.js from a CDN;
- embeds inline JavaScript;
- uses `phx-update="ignore"`;
- is incompatible with the repository's self-only production script CSP.

## 4. Dependency contract

- B.1 owns metrics, windows, comparisons, currency and completeness.
- B.2 owns bucket/read APIs, bucket freshness and invalidation topics.
- F.2 owns source freshness and queued Woo catch-up.
- C later broadens access. B.3 remains admin-routed but actor-aware and PII-free.
- D later owns targets and alerts.
- 28B later owns redesigned exports/corrections.

## 5. Route and page direction

### All-event

`/admin/dashboard`

Decision data only by default:

- selected-window KPI cards;
- previous-equivalent comparisons;
- trend;
- event ranking;
- ticket-type performance;
- explicit status context if B.2 certifies it;
- source, bucket and completeness state;
- operations links.

### Event index

`/admin/events`

Use a bounded B.2-backed event summary or catalog-only navigation.

Any sold/revenue figure must carry an explicit observed/certified basis.

### Event detail

`/admin/events/:id`

Default `overview` is PII-free and B.2-backed.

An explicit global-admin `operations` tab may lazily load current recent-order, unmapped, import and export functions. It is outside the decision DTO and must not load by default.

## 6. Required filters

- reportable event scope: current, past or all;
- B.1 window preset;
- bounded custom business-date range;
- comparison on/off;
- tickets/revenue chart metric;
- reviewed resolution;
- source/currency metadata;
- stable event/table sort and pagination.

All filter state is URL-driven, validated and shareable.

## 7. Required metrics

Use only B.1 public names and B.2 output.

Planning concepts:

- net tickets sold;
- net recognised tax-inclusive ticket revenue;
- previous-period absolute and percentage/state;
- event and ticket-type totals;
- explicit distinct-order and ticket-quantity status units;
- capacity/current net entitlement/remaining where complete enough.

Do not show target or pacing fields.

## 8. Required state presentation

Keep separate:

1. source freshness from F.2;
2. bucket/read-model freshness from B.2;
3. historical completeness from B.1/B.2;
4. page loading/error/empty state.

A green source-fresh state cannot imply historical completeness.

## 9. Live update architecture

- source/scope topic for all-event view where B.2 certifies one;
- event topic for event detail;
- F.2 source-status topic;
- bounded subscription reconciliation and unsubscribe;
- debounce/coalesce invalidation messages;
- reload durable B.2/F.2 state;
- mount/reconnect always reconstruct truth;
- no raw recomputation in LiveView;
- missed/duplicate messages harmless.

## 10. Refresh actions

- `Check WooCommerce now`: certified F.2 queue action;
- `Refresh view`: reread durable state only;
- no ambiguous `Refresh`;
- no bucket rebuild or Woo call from web code.

## 11. Chart/security

Use a self-hosted/bundled CSP-compliant chart hook or accessible server-rendered SVG.

No CDN, inline script or `unsafe-inline` dependency.

Provide text summary and tabular fallback.

## 12. Privacy and future access

Decision DTOs exclude:

- customer name/email;
- address;
- transaction/payment identifiers;
- raw payload;
- order-level details unless separately authorised.

Facades accept an actor and explicit event scope even though the current routes remain admin-only.

## 13. Compatibility/cutover

Planning mode examples:

- `legacy`;
- `shadow`;
- `enabled`.

Legacy compatibility remains available for rollback until B.3 is certified.

Shadow mode must be bounded and must not double expensive work for every production request without review.

## 14. Performance

- fifty concurrent dashboard viewers;
- complete all-event scope;
- no N+1 event reads;
- no raw Sales scan;
- bounded point/event/ticket-type counts inherited from B.1/B.2;
- stable table pagination independent of headline totals;
- representative query/read timings and browser payload size;
- PubSub storms coalesced.

## 15. Non-goals

No metric changes, bucket writes, source calls, target logic, notifications, non-admin route access, backfill, acquisition dimensions, broad export redesign or catalog semantics.

## 16. Acceptance

For one exact URL and `as_of`, all-event and event pages render certified B.2 values, comparisons, series, currency, freshness and completeness. Open pages update after source/bucket changes, reconnect safely, contain no decision PII, satisfy CSP/accessibility, and rollback cleanly to the compatibility path.
