# Failure Matrix

| Failure | Safe UI | Recovery |
|---|---|---|
| B.2 reader unavailable | error/stale prior data | retry/rollback |
| bucket missing | missing/rebuilding | B.2 repair |
| source stale | stale warning + catch-up action | F.2 queue |
| source fresh, bucket dirty | updating analytics | B.2 convergence |
| history incomplete | observed/incomplete label | backfill later |
| mixed currency | grouped/error | narrow scope |
| invalid URL | canonical/default or bounded error | user correction |
| PubSub missed | unchanged until reconnect/refresh | durable reload |
| message storm | one coalesced read | debounce |
| async old result | discarded | generation guard |
| subscription scope changed | unsubscribe old | reconcile |
| chart asset missing | accessible table/error | rollback/fix |
| CSP violation | no chart, data still textual | rollback asset |
| PII detected | release blocked | remove boundary leak |
| operations service fails | overview unaffected | operations error |
| B.2 series too large | bounded error | narrower range |
| legacy/new mismatch | shadow finding | review semantics |
| cutover regression | legacy mode | rollback |
