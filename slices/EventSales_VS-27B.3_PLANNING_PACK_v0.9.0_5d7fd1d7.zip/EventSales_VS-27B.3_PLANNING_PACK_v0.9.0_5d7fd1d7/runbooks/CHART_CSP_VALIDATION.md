# Chart and CSP Validation Runbook

1. Confirm chosen chart library/version/source and licence.
2. Verify asset exists inside repository/build inputs.
3. Build production assets.
4. Inspect digested output.
5. Confirm root layout contains no CDN chart script.
6. Confirm chart component contains no inline executable script.
7. Start app with production CSP.
8. Load empty, hourly and daily series.
9. Change window, metric and comparison without full reload.
10. Trigger PubSub update.
11. Navigate away/back repeatedly.
12. Inspect console for CSP errors and duplicate chart instances.
13. Verify accessible summary/table and keyboard controls.
14. Test reduced motion, contrast, narrow viewport and large allowed series.
15. Record asset bytes and browser evidence.

Stop on any external network dependency or CSP weakening.
