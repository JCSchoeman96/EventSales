# Live Invalidation Runbook

## Mount

1. Parse/authorise typed query.
2. Read B.2 decision DTO and F.2 source status.
3. Render state.
4. On connected socket, subscribe to exact topics.
5. Record subscription set and query fingerprint.

## Invalidation message

1. Validate source/event/revision shape.
2. Mark page updating.
3. If no refresh scheduled, schedule one after debounce.
4. Coalesce later messages.
5. At refresh, reread current query once.
6. Replace DTO atomically.
7. Reconcile subscriptions.
8. Clear updating state.

## Filter change

1. Increment query generation.
2. Cancel/ignore old async result.
3. read new query;
4. unsubscribe topics no longer needed;
5. subscribe new topics;
6. update URL/render.

## Reconnect

Reload durable state before trusting future messages.

## Failure

Keep prior values with explicit stale/error indicator where safe. Never fabricate zero or raw fallback.
