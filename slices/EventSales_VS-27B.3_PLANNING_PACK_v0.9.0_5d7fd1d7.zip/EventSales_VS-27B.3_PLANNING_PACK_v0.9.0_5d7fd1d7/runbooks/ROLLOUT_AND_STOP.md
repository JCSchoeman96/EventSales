# Rollout and Stop Conditions

## Rollout

1. Deploy code/assets in legacy mode.
2. Verify no route behaviour changed.
3. Run CSP/chart and PII checks.
4. Enable bounded shadow reads.
5. Verify B.2 timings and semantic compatibility.
6. Enable one event overview.
7. Verify all filters and operations separation.
8. Enable all-event dashboard for one admin.
9. Verify F.2 catch-up/live update.
10. Verify reconnect/subscription cleanup.
11. Expand admin access.
12. Certify at JC-210.
13. Keep legacy mode available until later cleanup.

## Stop immediately

- raw Sales/contribution query in decision path;
- truncated totals shown as complete;
- selected-window tickets used for remaining capacity;
- mixed currency summed;
- source/bucket/completeness conflated;
- PII in overview/chart/URL/PubSub;
- operations loaded by default;
- CDN/inline chart or weaker CSP;
- event subscription leak;
- one read per PubSub message storm;
- non-admin route exposed;
- target/backfill/export redesign enters scope;
- rollback mode fails.
