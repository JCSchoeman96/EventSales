# Production Validation Runbook

Use redacted aggregate evidence only.

## All-event

- exact canonical URL;
- selected scope/window/resolution;
- B.2 result id/version;
- event count represented;
- event ranking page count;
- ticket-type count;
- headline values;
- comparison state;
- series point count;
- currency;
- source freshness;
- bucket freshness;
- completeness;
- generated/read timing.

## Event

- event id redacted;
- capacity/current entitlement basis;
- selected-window values;
- ticket types represented;
- status support;
- operations not loaded;
- overview PII scan.

## Live update

- page open time;
- source catch-up queued/running/completed;
- B.2 commit/invalidation time;
- visible update time;
- browser reload required: no;
- messages coalesced;
- reconnect result.

## Browser/security

- production asset hash;
- CSP errors: none;
- external requests: none;
- chart updates;
- accessibility fallback;
- mobile result.

## Rollback

- enabled -> legacy switch;
- route recovery;
- B.2 data unaffected.
