# URL Filter State Runbook

## Parse

1. Receive raw params.
2. Whitelist supported keys.
3. Normalize enums and positive integers.
4. Validate custom date pair.
5. Enforce B.1/B.2 span, point and event bounds.
6. Resolve actor/reportable scope.
7. Build one typed query.
8. Capture one `as_of`.
9. Produce canonical URL params.

## Change handling

- window/scope/custom/metric/resolution change resets table pages;
- table sort preserves metric/window;
- event drill-down preserves window/compare/metric;
- returning from event restores filter context;
- operations tab preserves event overview filters;
- no hidden session-only filter values.

## Invalid input

- unknown enum -> safe default;
- malformed date -> visible filter error and default/unchanged valid query;
- span too large -> bounded error, no read;
- inaccessible event -> not found;
- excessive page -> empty final page or canonical clamp;
- repeated params -> deterministic last/first rule documented.

## Test matrix

Every parameter individually and in combinations, including browser back/forward and reconnect.
