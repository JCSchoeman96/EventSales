# PII and Operations Validation Runbook

## Overview

1. Seed distinctive customer name/email/transaction/address values.
2. Load all-event dashboard and event overview.
3. Inspect DTO, rendered HTML, chart data, URL, logs and PubSub.
4. Assert no seeded/private values or denylisted keys.
5. Assert recent-order/unmapped services were not called on overview.

## Operations tab

1. Open explicit operations tab as global admin.
2. Verify separate authorization.
3. Verify current presenter/masking behaviour.
4. Verify pagination and links.
5. Return to overview and ensure operations data is removed/not retained in decision assigns where practical.

## Non-admin negative

B.3 routes remain denied to non-admin. Actor-aware facade tests may exercise future-safe denial but must not open routes.

## Telemetry

Inspect metadata keys for bounded enums/counts only.
