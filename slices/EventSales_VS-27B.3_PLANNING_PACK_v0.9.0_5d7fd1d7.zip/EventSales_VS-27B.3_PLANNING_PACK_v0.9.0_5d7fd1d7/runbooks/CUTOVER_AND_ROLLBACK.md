# Dashboard Cutover and Rollback Runbook

## Preflight

- B.1/B.2/F.2 certified;
- B.2 queues healthy and no significant dirty backlog;
- selected window complete enough;
- chart asset/CSP passes;
- PII tests pass;
- feature mode defaults legacy;
- rollback operator identified.

## Shadow

1. Enable bounded sample.
2. Compare only compatible fields.
3. Record expected semantic differences separately.
4. Monitor reader timing and payload size.
5. Stop shadow if it doubles unsafe load.

## Canary

1. Enable event overview for one admin/source.
2. Test every preset and one custom range.
3. Test compare toggle and event navigation.
4. Test source catch-up and bucket update.
5. Test reconnect and message storm.
6. Enable all-event page.
7. Test >50 events/large history fixture.
8. Verify operations tab.

## Rollback

1. Set mode legacy.
2. Confirm routes render compatibility pages.
3. Do not alter B.2 data/queues.
4. Record reason and timestamps.
5. Preserve evidence for fix/re-review.

## Completion

Only JC-210 certification permits JC-211 closeout.
