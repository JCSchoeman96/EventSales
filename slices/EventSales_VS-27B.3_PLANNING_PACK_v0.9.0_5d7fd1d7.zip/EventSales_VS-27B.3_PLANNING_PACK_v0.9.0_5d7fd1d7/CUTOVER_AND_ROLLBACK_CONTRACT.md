# Cutover and Rollback Contract

## Modes

Use one reviewed configuration boundary, for example:

- `legacy`: current AdminDashboard/EventDetail compatibility path;
- `shadow`: current pages remain visible while bounded new reads are compared;
- `enabled`: B.2-backed decision pages visible.

Exact setting name and runtime mechanism are activation decisions.

## Shadow rules

Shadow mode must:

- be sampled or admin-limited;
- avoid doubling expensive work for every request;
- compare only semantically compatible fields;
- record metric/window/version context;
- never expose shadow results;
- never log PII;
- tolerate expected differences caused by certified new semantics.

## Cutover sequence

1. Deploy new code/assets with `legacy`.
2. Verify CSP asset loading and browser hooks.
3. Enable sampled shadow reads.
4. Verify B.2 health/completeness and compare compatible fixtures.
5. Enable new event overview for one admin/source.
6. Enable new all-event dashboard.
7. Verify LiveView updates and F.2 actions.
8. Keep operations tab separate.
9. Certify at JC-210.
10. Remove legacy only in a later reviewed cleanup.

## Rollback

Switch mode to `legacy` without schema rollback.

Rollback must not:

- alter B.2 bucket data;
- queue source calls;
- drop new assets/tables;
- require migration reversal.

## Stop conditions

- B.2 reader missing/uncertified;
- headline result truncated or incomplete without warning;
- raw Sales read appears in decision path;
- PII enters decision DTO/chart/PubSub;
- Chart/CSP failure;
- subscription leak;
- ambiguous refresh action;
- current/past/all scope wrong;
- comparison/window mismatch;
- operations loaded by default;
- rollback flag ineffective.
