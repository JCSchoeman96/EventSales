# Mandatory File Inventory — VS-27B.3

## Governance and predecessor artifacts
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`
- final VS-27B.1 pack/plan/activation/PR/certification;
- final VS-27B.2 pack/plan/activation/PR/certification;
- final VS-26F.2 pack/plan/activation/PR/certification;
- certified catalogue lifecycle/publication files from E slices.

## Current dashboard/read facades
- `lib/event_sales/analytics/admin_dashboard.ex`
- `lib/event_sales/analytics/event_detail.ex`
- `lib/event_sales/analytics/snapshot_reader.ex`
- `lib/event_sales/analytics/dashboard_pub_sub.ex`
- `lib/event_sales/analytics/hot_state_aggregator.ex`
- certified B.2 BucketReader/resources/PubSub files;
- certified F.2 source-status/read/action files.

## Current LiveViews
- `lib/event_sales_web/live/admin/dashboard_live.ex`
- `lib/event_sales_web/live/admin/events_live.ex`
- `lib/event_sales_web/live/admin/event_detail_live.ex`
- `lib/event_sales_web/live/admin/session.ex`
- `lib/event_sales_web/live/admin/manual_action_rate_limiter.ex`
- certified F.2 operations LiveView.

## Components/layout/assets
- `lib/event_sales_web/live/admin/components/sales_chart.ex`
- `lib/event_sales_web/live/admin/components/stat_card.ex`
- `lib/event_sales_web/live/admin/components/stale_data_banner.ex`
- `lib/event_sales_web/live/admin/components/status_badge.ex`
- `lib/event_sales_web/live/admin/components/order_table.ex`
- `lib/event_sales_web/live/admin/components/unmapped_item_alert.ex`
- `lib/event_sales_web/components/admin_shell.ex`
- `lib/event_sales_web/components/layouts/root.html.heex`
- `assets/js/app.js`
- `assets/css/app.css`
- `assets/css/safelist.txt`
- `assets/vendor/`
- `config/config.exs`
- `config/runtime.exs`
- `mix.exs`

## Routing/policy/privacy
- `lib/event_sales_web/router.ex`
- `lib/event_sales/accounts/policies.ex`
- `lib/event_sales/accounts/pii_policy.ex`
- `lib/event_sales_web/presenters/customer_presenter.ex`
- `lib/event_sales/catalog/event_lifecycle.ex`
- `lib/event_sales/catalog/resources/event.ex`
- `lib/event_sales/catalog/resources/event_dashboard_setting.ex`

## Current operations/exports
- `lib/event_sales_web/controllers/admin/event_export_controller.ex`
- `lib/event_sales/exports/event_sales_csv.ex`
- current event recent-order and unmapped read paths.

## Tests
- `test/event_sales/analytics/admin_dashboard_test.exs`
- `test/event_sales/analytics/admin_dashboard_contract_test.exs`
- `test/event_sales/analytics/event_detail_test.exs`
- `test/event_sales_web/live/admin/dashboard_live_test.exs`
- `test/event_sales_web/live/admin/events_live_test.exs`
- `test/event_sales_web/live/admin/event_detail_live_test.exs`
- `test/event_sales_web/components/admin_shell_test.exs`
- `test/event_sales_web/router_test.exs` where present;
- certified B.1/B.2/F.2 tests;
- asset/CSP/browser test infrastructure if present.

## Static boundary checks
- `scripts/check_no_web_woocommerce_refs.sh`
- project index/module manifest files;
- CI quality aliases in `mix.exs`.
