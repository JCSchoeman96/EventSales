# Freshness and Completeness UI Contract

## Separate states

### Source freshness — F.2

Examples:

- unknown;
- fresh;
- stale;
- queued;
- running;
- retry scheduled;
- blocked;
- failed;
- disabled;
- full recovery required.

### Bucket/read-model freshness — B.2

Examples:

- ready;
- updating;
- dirty/pending;
- rebuilding;
- partial;
- missing;
- failed.

### Historical completeness — B.1/B.2

Examples:

- unknown;
- observed from date;
- certified from date;
- complete for selected window;
- incomplete for selected window;
- blocked by semantics;
- blocked by source gap.

These states must never collapse into one badge.

## Page presentation

Use one compact data-status region above decision metrics.

It should answer:

- Has WooCommerce been checked recently?
- Are the selected analytics buckets current?
- Is the requested history complete?
- What action is available?

## Actions

### Check WooCommerce now

Visible to current authorised admin under the F.2 action contract.

It queues work asynchronously and shows queued/running/retry/blocked status.

### Refresh view

Rereads current durable state only.

No job creation.

### Updating analytics

Informational state while B.2 dirty/rebuild work is pending.

Do not advise another Woo catch-up when source is already fresh.

## Label rules

Examples:

- `Source checked 3 minutes ago`
- `Analytics updated 20 seconds ago`
- `Complete for selected period`
- `Observed from 5 July 2026`
- `History incomplete before 5 July 2026`

Do not use:

- `Live` without defined freshness;
- `Up to date` when history is incomplete;
- `Lifetime` without certification;
- green colour as the only state cue.

## Degraded rendering

- source stale + bucket ready: display existing data with stale warning;
- source fresh + bucket updating: show updating analytics;
- bucket missing: no fabricated zero;
- incomplete history: show observed values and warning where B.1 allows;
- blocked semantics: exclude and explain bounded anomaly count.
