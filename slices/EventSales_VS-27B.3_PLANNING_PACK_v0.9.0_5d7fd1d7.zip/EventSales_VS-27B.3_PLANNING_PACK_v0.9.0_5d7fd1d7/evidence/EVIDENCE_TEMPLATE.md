# VS-27B.3 Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- B.1/B.2/F.2 versions:
- Cutover mode:
- Source/event ids redacted:

## URL/query
- canonical URL:
- as_of:
- scope/window/comparison/resolution:
- invalid/bound tests:

## All-event result
- event count represented:
- headline tickets/revenue:
- comparison state:
- trend points:
- event ranking pages:
- ticket-type pages:
- status support:
- currency:
- source freshness:
- bucket freshness:
- completeness:
- read duration/payload size:

## Event result
- selected metrics:
- capacity basis:
- current sold/remaining basis:
- ticket types:
- operations loaded on overview: no
- PII scan:

## Live updates
- topic topology:
- subscription count before/after scope change:
- messages sent:
- reads executed:
- coalescing:
- visible latency:
- reconnect:

## Chart/CSP/accessibility
- asset/source/version/hash:
- external request: no
- inline script: no
- CSP errors: none
- update/destroy:
- fallback:
- keyboard/contrast/mobile:

## Cutover/rollback
- shadow sample:
- canary:
- enabled:
- rollback:
- legacy recovered:

## Negative proof
- no raw Sales reads:
- no mixed-currency sum:
- no silent truncation:
- no PII:
- no non-admin access:
- no targets/backfill/export redesign:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
