# VS-27B.3 Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified B.1/B.2/F.2 interfaces
## 4. Certified reportable-event scope
## 5. Current dashboard/event/assets truth
## 6. Route and cutover strategy
## 7. Typed URL query contract
## 8. All-event facade/DTO
## 9. Event index migration
## 10. Event overview facade/DTO
## 11. Capacity/current-entitlement basis
## 12. Status-context support decision
## 13. Source/bucket/completeness UI state
## 14. Check Woo now and Refresh view
## 15. Subscription topology
## 16. Debounce/async race handling
## 17. Chart implementation/asset provenance
## 18. CSP/root layout changes
## 19. Accessibility/mobile
## 20. Operations-tab and PII boundary
## 21. Navigation/export handling
## 22. Legacy/shadow/enabled modes
## 23. Tests-first sequence
## 24. Browser/security/load verification
## 25. Exact files create/modify/generated/forbidden
## 26. Verification commands
## 27. Rollout/rollback
## 28. Production evidence
## 29. JC-206 activation inputs
## 30. Risks/stop conditions
## 31. Prohibited-actions statement
