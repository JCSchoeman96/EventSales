# Independent Reviewer Prompt — VS-27C

Review adversarially.

Block any design that:

- weakens `AdminOnly` or exposes `/admin/*` to event users;
- uses raw role atoms directly in web/templates;
- trusts roles/grants/event ids from session or URL;
- authorizes after event existence lookup;
- permits global staff without explicit event grant;
- exposes revenue when any represented event is hidden;
- sums only visible revenue and labels it total;
- allows hidden revenue into assigns, DOM or chart payload;
- activates order-number or PII flags;
- exposes orders, exports, imports, corrections, mappings, source refresh or admin tools;
- uses legacy `EventScopedDashboard` instead of certified B.3;
- stores/logs plaintext invitation token/password;
- permits open self-registration;
- lets invitation token reset an existing user's password;
- lacks atomic audit for access mutations;
- deletes/overwrites grant history;
- adds FK without orphan preflight;
- relies only on PubSub for revocation;
- cannot revoke/deactivate an open page within the certified bound;
- adds per-event N+1 authorization;
- introduces targets, notifications, backfill, SSO or anonymous links;
- enables portal before cutover flag/canary.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only. Activation controls implementation.
