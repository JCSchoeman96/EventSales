# Current Code Access Map

| Current area | Existing behaviour | VS-27C implication |
|---|---|---|
| Global roles | `admin`, `staff` | no new global marketing role |
| Event roles | `event_owner`, `event_staff` | compatibility map to management/marketing |
| Event grant | active, expiry, partial unique index | retain and harden |
| Event FK | UUID only, no relationship | add after orphan preflight |
| Grant actions | generic create/update/revoke | replace public workflow authority |
| PaperTrail | create ignored | access creation needs audit |
| Policies | direct SQL, Postgres authority | centralize capabilities/scope |
| Revenue flags | owner/staff, fail closed | map to management/marketing |
| Other flags | order numbers/PII | remain dormant |
| PiiPolicy | event roles `:none` | preserve |
| EventScopedDashboard | legacy hot/snapshot | replace with B.3 facade |
| Admin login | authenticates admin only | add separate portal login |
| Admin router | `AdminOnly` | never weaken |
| Event exports | admin-only but legacy raw SQL | no portal export |
| Open LiveViews | no access heartbeat | bounded reauthorization |
| Audit logger | generic sanitized log API | add allowlisted access events |
