# Grant Administration Runbook

## Preflight

- actor is global admin;
- target user active;
- event exists and is portal-eligible under certified policy;
- profile maps to stored role;
- expiry future or nil;
- reason valid;
- no active duplicate.

## Grant

1. Begin transaction.
2. Create new grant episode with active true.
3. Write allowlisted `event_access_granted` audit.
4. Commit.
5. Broadcast user/event access invalidation.
6. Re-read effective capabilities for confirmation.

## Change expiry

1. Lock/read active grant.
2. Validate new expiry.
3. Update through explicit action.
4. Audit before/after and reason in same transaction.
5. Broadcast.

## Revoke

1. Lock/read active grant.
2. If already inactive, return deterministic no-op.
3. Set active false through explicit action.
4. Persist revocation evidence/audit.
5. Commit.
6. Broadcast.

## Regrant

Create a new grant row. Do not reactivate historical inactive row.

## Revenue setting

1. Validate event and booleans.
2. Update management/marketing flags only.
3. Leave order-number/PII flags inaccessible.
4. Audit before/after.
5. Broadcast event access invalidation.

## Failure

No partial mutation without audit. PubSub failure does not undo committed access; heartbeat provides bounded convergence.
