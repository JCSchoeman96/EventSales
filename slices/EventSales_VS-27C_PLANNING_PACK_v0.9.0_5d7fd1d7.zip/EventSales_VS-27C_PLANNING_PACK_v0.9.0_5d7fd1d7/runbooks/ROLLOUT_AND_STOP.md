# Rollout and Stop Conditions

## Rollout

1. Deploy Stage A policies/migrations with portal disabled.
2. Verify grants/FK/indexes/audit.
3. Deploy admin access workflow disabled.
4. Enable for one admin.
5. Create/revoke a canary grant.
6. Deploy invitation flow disabled.
7. Create/redeem one canary invitation.
8. Enable portal for one management user.
9. Verify no revenue by default.
10. Enable revenue and verify.
11. Add marketing user; verify default hidden.
12. Test assigned multi-event scope.
13. Test unassigned event enumeration.
14. Test revoke, expiry, deactivation and missed PubSub.
15. Validate privacy/load.
16. Expand portal canary.
17. Certify before general enablement.

## Kill switches

- portal routes/login;
- invitation creation/redemption;
- admin access management;
- access PubSub hints;
- feature mode/canary allowlist.

Disabling a hint does not disable heartbeat authorization.

## Stop immediately

- admin routes weakened;
- B.3 uncertified;
- raw role/session authorization;
- invitation token/password logged or stored plaintext;
- open registration;
- audit not atomic;
- FK orphans unresolved;
- hidden revenue present client-side;
- PII/order/export/source controls exposed;
- revoke/deactivate exceeds bound;
- N+1 authorization/load unsafe;
- portal cannot rollback cleanly.
