# Invitation Flow Runbook

## Create

1. Global admin opens `/admin/access`.
2. Selects existing event(s), management/marketing profile and optional grant expiry.
3. Enters email/name and bounded reason.
4. Workflow normalizes email and checks existing user/invite conflicts.
5. Generate at least 32 random bytes.
6. Store digest only.
7. Store invitation assignment rows.
8. Persist invitation and audit in one transaction.
9. Show copy link once.
10. Never log the link/token.

## Redeem — new user

1. Receive token in path.
2. Hash token and find pending, unexpired invitation.
3. Render generic password form without disclosing extra assignments.
4. Validate password/confirmation.
5. In one transaction:
   - create active user;
   - create grant episodes;
   - mark invitation accepted;
   - write audit.
6. Renew session.
7. Enter portal.
8. Broadcast access invalidation after commit.

## Redeem — existing user

1. Token resolves to invitation whose email matches existing account.
2. Require normal sign-in as that account.
3. Do not reset password.
4. Transactionally create missing grant episodes and accept.
5. Generic failure on mismatch.

## Revoke/expire

- admin can revoke pending invitation;
- expiry is checked using one captured `now`;
- cleanup may mark expired asynchronously, but validation does not depend on cleanup;
- accepted/revoked/expired token is never reusable.

## Race tests

- two simultaneous redemptions;
- manual grant created during redemption;
- invitation revoked during password submission;
- user deactivated during acceptance;
- duplicate invitation for same email/event/profile.

## Evidence

Record ids/hashes only; never capture token or password.
