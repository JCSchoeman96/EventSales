# Failure Matrix

| Failure | Safe outcome | Recovery |
|---|---|---|
| invalid credentials/no grant | generic login error | admin grants access |
| inactive user | no session/access | reactivate through admin |
| expired grant | generic no access | new grant episode |
| duplicate grant | one DB winner | reread |
| orphan event id | migration blocked | reviewed repair/revoke |
| invitation expired/revoked | generic unavailable | new invitation |
| invitation double redeem | one winner | use accepted state |
| existing-user token used anonymously | require sign-in | authenticate |
| audit write fails | mutation rolls back | retry |
| PubSub fails | DB mutation valid | heartbeat |
| heartbeat DB error | retain no new access; warning/logout policy | retry |
| revenue setting removed | revenue stripped | reload |
| mixed profile grants | deterministic union | capability resolver |
| B.3 read fails | bounded error, no raw fallback | retry |
| hidden event URL | generic forbidden/not found | none |
| portal feature disabled | no route/access | admin path unaffected |
| login throttler unavailable | fail-safe reviewed mode | restore protection |
