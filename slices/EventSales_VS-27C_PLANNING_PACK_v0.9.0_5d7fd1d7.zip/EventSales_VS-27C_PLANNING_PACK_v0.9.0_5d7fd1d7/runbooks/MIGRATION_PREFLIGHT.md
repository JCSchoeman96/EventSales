# Access Migration Preflight

## Read-only checks

- current main/deployed SHA;
- Postgres version and migration route;
- users by active status;
- global roles/user roles;
- grants by role/active/expired;
- duplicate active grants;
- orphan `event_id` values;
- dashboard settings and dormant flags;
- grant/version table constraints;
- audit event type constraints;
- session/cookie runtime settings;
- B.3 deployed feature mode;
- existing login rate protection.

## FK decision

For every orphan:

- identify cause;
- repair to correct event only with evidence;
- revoke/archive grant with audit; or
- block migration.

Never silently delete.

## Index review

Candidate access paths:

- active grants by `user_id`;
- active grants by `event_id`;
- expiry filtering;
- invitation digest/status/expiry;
- invitation assignments.

Use representative `EXPLAIN`.

## Deployment

- additive schema;
- portal flag false;
- invitation endpoints unavailable until code/config ready;
- no data backfill inside migration;
- rollback limitations explicit.

## Stop

Topology unknown, orphan unresolved, generated migration drift, lock risk, audit enum conflict or plaintext secret column.
