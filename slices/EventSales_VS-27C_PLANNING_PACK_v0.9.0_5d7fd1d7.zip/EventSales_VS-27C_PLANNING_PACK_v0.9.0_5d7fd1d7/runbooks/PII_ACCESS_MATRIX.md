# PII and Access Matrix Validation

| Surface | Admin | Management | Marketing |
|---|---|---|---|
| Admin dashboard | yes | no | no |
| Portal assigned events | yes | assigned | assigned |
| Ticket/status aggregates | yes | yes | yes |
| Revenue | yes | event flag | event flag |
| Source status | yes | read-only | read-only |
| Check Woo now | yes | no | no |
| Customer PII | existing admin policy | no | no |
| Order numbers | existing admin operations | no | no |
| Recent orders | yes | no | no |
| Exports | yes under current policy | no | no |
| Imports/corrections/mappings | yes | no | no |
| Access admin | yes | no | no |
| Targets | later D | no in C | no in C |

## Validation method

Seed unique secret values for:

- customer name/email;
- order number;
- transaction id;
- invitation token;
- grant reason;
- hidden revenue.

Inspect:

- decision DTO;
- socket assigns where testable;
- HTML;
- chart attributes/events;
- URL;
- PubSub message;
- telemetry/log capture;
- error pages.

Management/marketing surfaces must contain none of the seeded values except revenue when explicitly permitted.
