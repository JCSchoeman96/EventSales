# Revocation and Session Validation Runbook

## Grant revoke

1. Sign in as management user.
2. Open assigned event page and capture no PII.
3. Revoke grant as admin.
4. Verify immediate access-change hint path.
5. Verify page clears/redirects.
6. Repeat with PubSub intentionally suppressed.
7. Verify heartbeat removes access within approved maximum.

## Grant expiry

- use deterministic clock;
- page open before expiry;
- cross expiry;
- verify next heartbeat denies;
- no event existence detail in response.

## Revenue visibility

1. Open page with visible revenue.
2. Disable relevant flag.
3. Verify raw revenue removed from assigns, DOM and chart.
4. Suppress PubSub and verify heartbeat.
5. Re-enable and verify server-side reload.

## User deactivation

- deactivate user in audited workflow;
- verify open portal logs out/redirects;
- next request loads no current user;
- admin session behaviour remains unchanged.

## Event eligibility

- change event to ineligible certified state;
- verify access list/event page update;
- grant history retained.

## Subscription cleanup

- after redirect, verify old event/user subscriptions removed;
- no future decision update reaches old page process.

## Target

Record p50/p95/max revocation duration and confirm maximum bound.
