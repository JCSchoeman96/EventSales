# Capability Model Contract

## Why capabilities

Stored role names are compatibility identifiers. UI code must never ask:

```elixir
role == :event_owner
```

Instead it asks a central resolver for explicit capabilities.

## Profiles

### Global admin

Profile: `admin`

Capabilities:

- all portal decision capabilities;
- all existing admin operations through existing admin policy;
- all event revenue.

### Management

Stored role: `event_owner`

User-facing profile: `management`

Capabilities:

- list assigned events;
- view assigned-event decision dashboards;
- view assigned-event ticket/status metrics;
- use bounded filters/comparisons/charts;
- refresh durable view;
- view revenue only when per-event management revenue is enabled.

### Marketing

Stored role: `event_staff`

User-facing profile: `marketing`

Capabilities:

- same PII-free decision capabilities;
- revenue only when per-event marketing revenue is enabled.

Marketing receives no implicit order/customer/export capability.

## Resolution

Recommended API:

```elixir
EventSales.Accounts.EventCapabilities.for_event(actor, event_id)
EventSales.Accounts.EventCapabilities.assigned_scope(actor, opts)
```

Return a typed structure:

- actor/user id;
- event id;
- effective profile;
- capability set;
- revenue visibility;
- grant ids/versions used for audit/debug, not rendered;
- access expires at;
- scope fingerprint/version.

## Precedence and union

1. global admin;
2. management;
3. marketing;
4. none.

When both management and marketing grants exist:

- effective profile is management;
- capabilities are unioned;
- revenue is visible if any active profile's corresponding revenue flag permits it;
- explicit deny is not introduced in v1.

## Fail-closed inputs

Return no capabilities when:

- actor missing/inactive;
- invalid event id;
- no active grant;
- grant expired;
- event excluded by certified portal eligibility;
- policy/config unknown;
- database read fails.

## Static boundaries

- templates and LiveViews cannot reference stored role atoms directly;
- no capability calculation in JavaScript;
- no role list stored in session;
- no hidden CSS-only authorization;
- no capability based on event labels/slugs.
