# Migration and Rollout Contract

## Expected additive changes

Potential additions:

- event FK/relationship on grants;
- invitation and invitation-assignment resources;
- optional immutable revocation fields;
- access query indexes;
- audit event support;
- access PubSub;
- portal controllers/plugs/LiveViews/shell;
- admin access-management page;
- portal feature flag/config.

Do not change B.1/B.2 metrics or B.3 buckets.

## Preflight

Read-only checks:

- current users/global roles;
- grant count by active/expired/role;
- orphan event ids;
- duplicate active grants;
- dashboard setting count/flags/expiry;
- current admin accounts;
- session/cookie config;
- production ingress/login throttling;
- B.3 route/components/facades;
- Postgres direct migration route.

## Migration rules

- additive first;
- no automatic grant deletion;
- no plaintext token migration;
- no mass account creation;
- no public route before flag;
- FK only after orphan decision;
- generated Ash migrations reviewed;
- populated indexes assessed for locks.

## Rollout

1. Deploy schema/policies with portal disabled.
2. Verify grant/FK/audit migrations.
3. Enable admin access page for one admin.
4. Create one test invitation/grant.
5. Validate token/redemption.
6. Enable portal for one management user.
7. Verify revenue hidden.
8. Enable management revenue and verify immediate remask.
9. Add marketing user and verify default hidden revenue.
10. Test wrong-event enumeration.
11. Revoke access while page open.
12. Deactivate user while page open.
13. Verify no admin/PII/source operations.
14. Expand canary.
15. Certify before general portal enablement.

## Rollback

Disable portal/access feature flags.

Do not:

- drop grants/invitations;
- reverse B.3;
- alter bucket truth;
- restore revoked access;
- expose admin routes.

## Stop conditions

- B.3 not certified;
- authorization cached in session;
- portal reuses AdminOnly routes by weakening policy;
- invitation token plaintext/logged;
- audit not atomic;
- grant FK orphans unresolved;
- hidden revenue reaches assigns/DOM;
- revocation bound fails;
- PII/order/export/source action exposed;
- self-registration enabled.
