# Route and UI Contract

## Separate shells

### Admin shell

Existing `/admin/*`.

Remains protected by `AdminOnly`.

Adds global-admin access-management navigation only after activation.

### Portal shell

New `/portal/*`.

Contains only:

- assigned events;
- event decision dashboard;
- profile/account/logout;
- help/no-access messaging.

No admin, imports, mappings, reconciliation, webhooks, Oban, exports or source controls.

## Portal home

`/portal`

- assigned current/past/all filters;
- complete assigned-scope ticket metrics;
- revenue masked under the all-events visibility rule;
- event ranking limited to assigned events;
- source/bucket/completeness status;
- no `Check WooCommerce now`;
- `Refresh view` only.

## Event page

`/portal/events/:id`

- reuses B.3 overview components and URL filters;
- no operations tab;
- no export/import links;
- no recent orders/unmapped items;
- generic forbidden/not-found behaviour.

## User-facing labels

- `event_owner` renders as `Management`;
- `event_staff` renders as `Marketing`;
- raw stored role atoms never appear in UI.

## Access management page

Recommended `/admin/access`.

Sections:

- users/invitations;
- event assignments;
- revenue visibility;
- audit timeline.

Use bounded search/pagination.

## Navigation

Admin may enter portal in a separate link for support.

Portal never displays an admin link merely because the actor has an event grant. A global admin may receive a clearly separated “Admin” link.

## Accessibility

- role/profile and permission state expressed in text;
- expiry shown with absolute date/time;
- confirmation for revoke;
- keyboard-usable forms/dialogs;
- errors tied to fields;
- no colour-only revenue/expiry state;
- generic access-denied messaging.
