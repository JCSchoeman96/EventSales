# VS-27C — Event-Scoped Management and Marketing Access

## 1. Identity

- Pack: `0011_VS-27C`
- Version: `0.9.0`
- Baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub: #127
- Linear: JC-212 to JC-214; remaining gates pending workspace capacity
- Predecessor: VS-27B.3
- Successor: VS-27D
- Execution authority: none

## 2. Goal

Allow an authenticated user to see only explicitly assigned events through the certified B.3 decision UI, with server-side revenue masking and no admin operations, customer PII, order data, source controls or cross-event leakage.

## 3. Current repository truth

The current repository already provides useful infrastructure:

- global roles `admin` and `staff`;
- event grants with `event_owner` and `event_staff`;
- active and optional expiration state;
- partial unique active grant index;
- grant PaperTrail for update/revoke, but create is ignored;
- policies that query Postgres rather than trusting session roles;
- authorize-before-existence event dashboard logic;
- per-event owner/staff revenue flags;
- PII policy returning `:none` for event roles;
- PII-free legacy `EventScopedDashboard`;
- global-admin-only `/admin/*` routes and login.

Current gaps:

- no portal routes or non-admin login;
- no assigned-event list/read facade;
- legacy scoped dashboard reads snapshots/hot state rather than B.3;
- no capability abstraction;
- no event foreign key on grants;
- default grant create/update actions require no actor or reason;
- no secure onboarding/invitation workflow;
- no access administration UI;
- no immediate/bounded revocation handling for open LiveViews;
- dormant order-number/PII setting flags are not a safe permission contract;
- no transactional operational audit for every access mutation.

## 4. Capability model

### Durable compatibility mapping

```text
event_owner -> management
event_staff -> marketing
```

These are internal compatibility mappings, not permission checks in templates.

### Capability names

Planning names:

- `view_assigned_event_decisions`;
- `view_assigned_event_status`;
- `view_assigned_event_revenue`;
- `refresh_assigned_view`;
- `list_assigned_events`.

Global admin receives all portal capabilities.

Management and marketing receive all shared capabilities except revenue, which is event-setting dependent.

### Explicit denials

Event-scoped profiles cannot:

- access `/admin/*` or `/internal/*`;
- view customer PII or order numbers;
- read recent orders/order lines;
- export data;
- import/correct/remap/reconcile;
- request Woo catch-up;
- rebuild analytics;
- administer users/access;
- configure targets/notifications.

## 5. Portal boundary

Separate routes:

```text
/portal/login
/portal
/portal/events/:id
/portal/logout
```

Do not weaken the `AdminOnly` plug.

Use a separate portal shell with no admin navigation.

Reuse B.3 typed filters, render-only components, charts and decision DTOs.

## 6. Assigned scope

- Postgres remains access authority.
- Session stores only user id.
- Global staff requires an event grant.
- Active user plus active/unexpired grant is required.
- URL ids never widen scope.
- Event existence is checked only after authorization.
- Global admin may view all certified reportable events in the portal.
- Management outranks marketing for display when both grants exist.
- Effective capabilities are a deterministic union.
- Certified catalogue activation decides draft/private/archived/cancelled eligibility.

## 7. Revenue

- global admin always sees revenue;
- management sees event revenue only when `revenue_visible_to_event_owner` is true and unexpired;
- marketing sees event revenue only when `revenue_visible_to_event_staff` is true and unexpired;
- missing setting fails closed;
- hidden revenue must not enter assigns, HTML, chart payload or PubSub;
- assigned-scope aggregate revenue is visible only when every represented event is revenue-visible, unless a later reviewed partition contract exists;
- never sum a visible subset and label it as total.

## 8. PII and operations

B.3 decision DTO remains PII-free.

The portal has no operations tab in v1.

The existing B.3 admin operations tab remains global-admin-only.

`order_numbers_visible` and `pii_visible` remain dormant/deprecated and are not exposed as portal capabilities.

## 9. Access administration

Add global-admin-only workflows for:

- list/search portal users;
- list event assignments;
- create management/marketing grants;
- optional expiry;
- revoke a grant;
- grant again as a new grant episode;
- edit management/marketing revenue flags;
- preview effective capabilities;
- create/revoke secure invitations when needed;
- view sanitized audit history.

Every mutation requires:

- authenticated global admin actor;
- bounded human reason;
- transactionally coupled audit;
- after-commit access invalidation.

No generic direct public create/update action may bypass the workflow.

## 10. Secure onboarding

Preferred v1 when no certified provisioning flow exists:

- hashed random single-use invitation token;
- short bounded expiry;
- copy-link delivery by admin;
- no plaintext token storage/logging;
- no open self-registration;
- new user sets password at redemption;
- existing user must authenticate before attaching an invitation;
- invitation acceptance and grants commit atomically;
- double redemption is impossible;
- generic invalid/expired response.

No email-delivery integration is required in this slice.

## 11. Grant integrity

- preflight existing orphan event ids;
- add Catalog Event relationship/FK with restrict semantics;
- preserve inactive historical grant episodes;
- grant create defaults active true;
- revoke sets inactive and immutable revocation evidence;
- do not reactivate an old grant row; create a new episode;
- user deactivation fails closed;
- grant create must be audited as well as update/revoke;
- concurrent duplicate active grant attempts converge to one success.

## 12. Open-session revocation

- user/event access PubSub is an invalidation hint;
- open portal LiveViews reauthorize immediately on hint;
- bounded heartbeat reauthorizes even if PubSub is missed;
- planning maximum revocation/deactivation delay: 60 seconds;
- lost access clears decision assigns and redirects generically;
- revenue changes reproject/mask before render;
- reconnect always reloads from Postgres.

## 13. Performance

- assigned-event query is set-based, not N+1 policy checks;
- B.3/B.2 handles aggregate reads;
- portal adds no raw Sales query;
- heartbeat uses one bounded scope/event authorization read;
- event/grant indexes support user-active-expiry and event lookups;
- fifty concurrent viewers remain the initial target;
- no actor-specific customer data cache.

## 14. Non-goals

No metric/bucket changes, source calls, PII/order access, exports, corrections, target logic, notifications, backfill, anonymous/public links, social login, SSO, external identity provider or role-platform redesign.

## 15. Acceptance

A management or marketing user can authenticate, list only assigned events and render exact B.3 decision data with correct revenue masking. Unassigned access does not reveal event existence. Expiry, revocation, user deactivation and visibility changes affect open pages within the certified bound. Every mutation is audited. Admin routes remain admin-only. Portal data, HTML, URL, chart, PubSub and telemetry contain no customer/order PII.
