# Audit and Privacy Contract

## Required audit event families

Planning names:

- `portal_invitation_created`;
- `portal_invitation_revoked`;
- `portal_invitation_accepted`;
- `event_access_granted`;
- `event_access_expiry_changed`;
- `event_access_revoked`;
- `event_revenue_visibility_changed`;
- `portal_user_deactivated` when changed through the workflow.

Exact enum/storage compatibility is an activation decision.

## Transactionality

Security mutations and their operational audit event must commit together.

If audit persistence fails, the access mutation fails.

PubSub happens only after commit.

## Metadata allowlist

Allowed examples:

- invitation/grant id;
- actor user id;
- target user id;
- event id;
- profile/role;
- expiry before/after;
- reason;
- setting flags before/after;
- source=`admin_access`.

Do not include:

- invitation token;
- plaintext password;
- customer/order data;
- raw request params;
- arbitrary metadata;
- target user email unless a separately reviewed hashed representation is required.

## Reason

- required for grant, expiry, revoke and revenue-setting changes;
- trimmed;
- minimum/maximum length;
- no HTML;
- sanitized through existing metadata boundary;
- visible only to admins in audit UI.

## Portal privacy

Decision paths may include:

- current user's display name where needed;
- event/ticket aggregate data;
- source/freshness/completeness metadata.

They exclude:

- customer PII;
- order numbers/ids;
- invitation email lists;
- grant reasons;
- admin identities;
- raw role/grant records.

## Telemetry/logging

Use bounded enums/counts and hashed request context.

Never log:

- login password;
- invite token;
- raw email query;
- full URL when it contains a token;
- hidden revenue values;
- customer/order data.

Invitation redemption routes must scrub token paths from telemetry where necessary.
