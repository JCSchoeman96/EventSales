# Grant Lifecycle and Integrity Contract

## Current weakness

`accounts_event_access_grants.event_id` has no Catalog foreign key.

The resource permits broad create/update actions, and PaperTrail ignores create.

## Migration direction

After read-only preflight:

1. find orphan grant event ids;
2. decide repair/archive/reject with evidence;
3. add `belongs_to :event`;
4. add FK to `catalog_events`;
5. use `ON DELETE RESTRICT`;
6. retain existing indexes;
7. add/query-plan indexes for active user scope and expiry where needed.

No migration may silently delete orphan grants.

## State model

Planning states remain represented by:

- `active = true/false`;
- optional `expires_at`.

Derived effective states:

- active;
- expired;
- revoked;
- invalid because user inactive;
- invalid because event ineligible.

## Explicit actions

Recommended workflow actions:

- `grant_access`;
- `change_expiry`;
- `revoke_access`.

Each requires actor/reason and cannot accept arbitrary `active`.

## Revocation evidence

At minimum preserve through audit:

- grant id;
- actor user id;
- target user id;
- event id;
- profile/role;
- prior/new expiry;
- reason;
- occurred_at.

Optional dedicated fields such as `revoked_at` and `revoked_by_user_id` may be added if the reviewed plan proves value.

## Create history

Grant creation must be represented by:

- PaperTrail create version where technically appropriate; and
- operational audit event.

If PaperTrail create cannot safely support the resource, operational audit plus immutable grant row is mandatory.

## Concurrency

- partial unique active role index remains database authority;
- concurrent same grant create yields one success;
- invitation redemption and manual grant race converge safely;
- revocation idempotently handles already inactive state without duplicate misleading audit;
- expiry boundary uses one captured `now`.

## Event lifecycle

Archiving/cancelling an event does not delete grant history.

Portal eligibility is reevaluated from certified Catalog state.
