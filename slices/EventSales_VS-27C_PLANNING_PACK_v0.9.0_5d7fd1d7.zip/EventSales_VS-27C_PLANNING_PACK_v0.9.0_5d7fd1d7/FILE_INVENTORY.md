# Mandatory File Inventory — VS-27C

## Governance and predecessor artifacts
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`
- final VS-27B.1/B.2/B.3 pack, plan, activation, PR and certification;
- final VS-26F.2 artifacts;
- certified Catalog lifecycle/reportable-event artifacts.

## Accounts and policies
- `lib/event_sales/accounts.ex`
- `lib/event_sales/accounts/policies.ex`
- `lib/event_sales/accounts/pii_policy.ex`
- `lib/event_sales/accounts/resources/user.ex`
- `lib/event_sales/accounts/resources/role.ex`
- `lib/event_sales/accounts/resources/user_role.ex`
- `lib/event_sales/accounts/resources/event_access_grant.ex`
- `test/event_sales/accounts/authentication_roles_event_access_test.exs`
- `test/event_sales/accounts/pii_policy_test.exs`

## Catalog access settings
- `lib/event_sales/catalog/resources/event.ex`
- `lib/event_sales/catalog/resources/event_dashboard_setting.ex`
- `lib/event_sales/catalog/event_lifecycle.ex`
- certified publication/private lifecycle code.

## Existing scoped dashboard
- `lib/event_sales/analytics/event_scoped_dashboard.ex`
- `test/event_sales/analytics/event_scoped_dashboard_test.exs`
- certified B.3 decision facades/DTOs/components/topics/tests.

## Authentication/router/session
- `lib/event_sales_web/router.ex`
- `lib/event_sales_web/plugs/load_current_user.ex`
- `lib/event_sales_web/plugs/admin_only.ex`
- `lib/event_sales_web/plugs/internal_only.ex`
- `lib/event_sales_web/controllers/admin_session_controller.ex`
- admin session HTML/templates/tests;
- endpoint/session/runtime cookie configuration;
- existing rate-limit plugs/modules/tests.

## B.3 web surface
- certified dashboard/events/event-detail LiveViews;
- certified decision shell/components/chart hooks/assets;
- `lib/event_sales_web/components/admin_shell.ex`
- `assets/js/app.js`
- `assets/css/app.css`

## Operations that must remain denied
- `lib/event_sales_web/controllers/admin/event_export_controller.ex`
- `lib/event_sales/exports/event_sales_csv.ex`
- imports/mappings/reconciliation/webhooks/Oban routes and policies;
- F.2 source refresh action/facade.

## Audit
- `lib/event_sales/audit/logger.ex`
- `lib/event_sales/audit/metadata_sanitizer.ex`
- `lib/event_sales/audit/resources/audit_log.ex`
- audit tests and event-type constraints.

## Migrations/snapshots
- `priv/repo/migrations/20260514170056_slice_2_accounts.exs`
- `priv/repo/migrations/20260514170139_slice_2_accounts_indexes.exs`
- `priv/repo/migrations/20260515111828_slice_3_catalog.exs`
- `priv/repo/migrations/20260517091713_slice_8_8_papertrail_operational_audit_split.exs`
- all later B.3/accounts/catalog migrations;
- resource snapshots for users/grants/settings/audit.

## Tests/boundaries
- router/admin access tests;
- dashboard/event LiveView tests;
- static no-web-Woo checks;
- domain boundary and PII tests;
- session fixation/login tests;
- PubSub/reconnect testing infrastructure.
