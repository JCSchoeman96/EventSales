# Assigned Event Scope and Query Contract

## Scope authority

The event scope is derived from Postgres grants, not URL parameters or session state.

### Non-admin actor

Eligible event ids are the intersection of:

- active user;
- active grant;
- `expires_at` nil or future;
- existing event;
- certified portal-eligible catalog status/lifecycle;
- active/certified source constraints when required.

### Global admin

May use the certified B.3 reportable event scope.

## Portal list

`/portal` lists only assigned event ids for non-admin users.

Supported lifecycle filters may mirror B.3:

- current;
- past;
- all assigned.

The final inclusion of draft/private/cancelled/archived events is an activation decision from certified Catalog code. Planning default:

- draft excluded;
- active current/future included;
- archived/past included when explicitly assigned;
- cancelled shown only under an explicit reviewed state.

## Event route

For `/portal/events/:id`:

1. cast id;
2. authorize actor/event;
3. only then check/read event existence;
4. call B.3 event decision facade with actor and exact scope.

Unauthorized and nonexistent event responses must not allow enumeration.

## Assigned aggregate

For users with multiple events:

- headline ticket totals may aggregate across the complete assigned selected scope;
- revenue aggregate is visible only if every represented event is revenue-visible;
- otherwise return `revenue_scope_state: :partially_hidden` and no aggregate revenue value;
- per-event revenue remains independently masked;
- no sum of only visible events may be labelled as total.

## Bounds

- event scope count inherits B.1/B.2 maximum;
- scope query is set-based;
- pagination affects only displayed event rows, not headline totals;
- no N+1 call to `Policies` per event;
- exact selected ids passed to B.3/B.2;
- excessive scope returns a bounded explicit error rather than truncation.

## Scope fingerprint

For LiveView reauthorization, return a deterministic fingerprint/version derived from relevant durable access state, without embedding PII.
