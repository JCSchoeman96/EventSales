# Implementation Agent Prompt Template — VS-27C

**Do not use until an explicit activation supplement returns APPROVE.**

Activation fills:

- exact main SHA;
- certified B.1/B.2/B.3/F.2 interfaces;
- final capability/scope/revenue contracts;
- final portal routes/session/login protection;
- final invitation/onboarding design;
- final grant/audit/FK migration;
- final revocation topics/heartbeat;
- exact staged scope/files/tests;
- rollout/rollback/stop conditions;
- mapped Linear implementation gate.

Write tests first. Implement only the activated stage. Open a PR and stop before merge, deployment, invitation creation or portal enablement.
