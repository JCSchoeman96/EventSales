# Scope Split Assessment

A staged implementation is strongly recommended.

## Stage A — Access law and integrity

- capability resolver;
- assigned-event scope;
- revenue masking;
- grant explicit actions;
- audit events;
- FK/index migration;
- unit/property/concurrency tests.

No portal route yet.

## Stage B — Secure onboarding and admin access management

- invitation resources/token flow;
- admin access page;
- grant/settings workflows;
- audit timeline;
- access PubSub.

Portal remains disabled.

## Stage C — Portal and live revocation

- portal login/session/plugs;
- portal shell/routes;
- B.3 component/facade reuse;
- heartbeat/revocation;
- browser/privacy/load tests;
- feature-flag canary.

Split is mandatory if:

- B.3 interfaces are still moving;
- invitation flow cannot be reviewed independently;
- FK/orphan migration has unresolved data;
- one PR becomes too broad for exact-head security review.

All stages remain under one VS-27C authority and final certification.
