# Planning Agent Prompt — VS-27C

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-27C_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, create invitations/grants, run migrations, open routes, commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified VS-27B.3, B.2, B.1 and F.2 artifacts. Do not assume planning names survived implementation.

## Required decisions

1. actual B.3 actor-aware DTO/component/query interfaces;
2. capability module and exact names;
3. compatibility mapping for stored grant roles;
4. assigned-event set query and portal eligibility;
5. all-assigned revenue masking rule;
6. global staff/admin behaviour;
7. exact portal routes/pipelines/session flow;
8. login throttling;
9. invitation necessity and resource/token design;
10. existing-user invitation redemption;
11. admin grant/settings workflows;
12. actor/reason/audit transaction;
13. grant FK/orphan/index migration;
14. explicit grant lifecycle actions;
15. access PubSub topics;
16. heartbeat/revocation bound;
17. revenue removal from assigns/chart;
18. portal shell and B.3 component reuse;
19. static privacy/policy boundaries;
20. staged PRs;
21. tests-first sequence;
22. exact files create/modify/generated/forbidden;
23. verification commands;
24. rollout/rollback/stop conditions;
25. activation inputs and unresolved Linear gate mapping.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with `PACK VALID`, `PACK REFRESH RECOMMENDED`, or `PACK BLOCKED`.

Confirm no prohibited action occurred.
