# VS-27C Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- B.1/B.2/B.3/F.2 versions:
- Portal mode:
- User/event ids redacted:

## Capability matrix
| Actor/profile | Event | Tickets | Revenue | Admin ops | Result |
|---|---|---:|---:|---:|---|

## Scope
- assigned events:
- lifecycle filters:
- unassigned probe:
- existence leak:
- query count/plan:
- bounds:

## Authentication
- generic error:
- session renewed:
- session fields:
- login throttle:
- admin login preserved:

## Invitation
- digest algorithm:
- token length:
- expiry:
- single-use:
- existing-user path:
- concurrent redemption:
- token in logs/DB: no

## Grant/audit
- orphan preflight:
- FK:
- grant/revoke/expiry:
- audit transaction:
- reason allowlist:
- duplicate race:

## Revocation
- PubSub path duration:
- missed-PubSub heartbeat duration:
- expiry:
- user deactivation:
- revenue removal:
- reconnect:

## Privacy
- PII seeded:
- DTO:
- assigns/HTML/chart:
- URL/PubSub/logs:
- orders/exports/source controls absent:

## Rollout
- management canary:
- marketing canary:
- rollback:
- admin routes unchanged:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
