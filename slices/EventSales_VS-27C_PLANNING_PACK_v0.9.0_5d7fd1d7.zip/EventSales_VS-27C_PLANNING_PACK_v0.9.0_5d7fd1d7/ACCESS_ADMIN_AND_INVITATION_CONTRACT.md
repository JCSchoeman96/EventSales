# Access Administration and Invitation Contract

## Admin boundary

Global-admin-only route, recommended:

```text
/admin/access
```

Do not expose through the portal.

## Admin functions

- search active/inactive users by bounded email/name query;
- list a user's current/historical grants;
- list an event's assignments;
- create management/marketing grant;
- choose optional expiry;
- revoke active grant;
- grant again as a new episode;
- edit management/marketing revenue visibility;
- preview effective capabilities;
- create/revoke invitation;
- view sanitized audit timeline.

No bulk grant/import in v1.

## Workflow authority

Use a dedicated Accounts workflow/facade.

Every mutation requires:

- current global-admin actor;
- exact target user/event/profile;
- bounded reason;
- validation before mutation;
- database transaction;
- operational audit in the same transaction;
- after-commit access invalidation.

Resource default create/update actions must not remain an unguarded public authority.

## Grant episodes

- create always creates a new grant record;
- active defaults true and is not user-supplied;
- revoke never destroys;
- old inactive grant is not reactivated;
- expiry change uses explicit action and audit;
- duplicate active role is rejected safely.

## Preferred invitation model

When no certified user-provisioning path exists, add:

### Invitation

- id;
- email;
- display name;
- token digest;
- status;
- expires_at;
- invited_by_user_id;
- accepted_by_user_id;
- accepted_at;
- revoked_at;
- inserted/updated timestamps.

### Invitation assignment rows

- invitation id;
- event id;
- stored grant role;
- optional grant expiry.

Avoid arbitrary JSON capability payloads.

## Token rules

- at least 32 random bytes;
- URL-safe encoding;
- store SHA-256/HMAC digest only;
- unique digest;
- default expiry 48 hours or tighter activation-approved value;
- single use;
- constant/generic invalid response;
- never log token;
- copy link shown once.

## Redemption

### New email

- token valid/pending;
- set name/password;
- create user and grants transactionally;
- mark accepted;
- audit;
- renew session and enter portal.

### Existing user

- token alone must not reset or replace password;
- require sign-in as the matching account;
- then transactionally attach grants and accept invite.

### Conflicts

- invitation email mismatch: deny generically;
- duplicate active grant: treat deterministically under reviewed rule;
- expired/revoked/accepted: generic unavailable response;
- concurrent redemption: one winner.

## Out of scope

No outbound email, SSO, magic-link login, open registration or password-reset programme.
