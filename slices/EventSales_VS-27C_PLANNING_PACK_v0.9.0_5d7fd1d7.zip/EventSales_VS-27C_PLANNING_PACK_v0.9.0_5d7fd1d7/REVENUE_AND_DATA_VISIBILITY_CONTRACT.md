# Revenue and Data Visibility Contract

## Revenue mapping

Current fields remain the durable compatibility source:

- `revenue_visible_to_event_owner` -> management;
- `revenue_visible_to_event_staff` -> marketing.

`access_expires_at` is interpreted only as the expiry of the event-level revenue visibility configuration, not the grant itself.

## Fail-closed rules

Revenue hidden when:

- no dashboard setting;
- relevant flag false;
- setting expired;
- actor/grant invalid;
- B.3/B.2 returns mixed currency or incomplete unsupported state;
- capability resolution fails.

## Server-side projection

Revenue is removed/masked before the DTO reaches:

- LiveView assigns;
- render components;
- chart payload;
- URL;
- PubSub;
- telemetry;
- client-side hooks.

Do not render hidden values and conceal them with CSS.

## Assigned multi-event scope

Allowed v1 options:

1. show aggregate revenue only when all represented events are revenue-visible;
2. return no aggregate revenue with `:partially_hidden`.

Do not partition visible/hidden sums unless a later reviewed UI contract explicitly labels them.

## Ticket and status visibility

Ticket quantities, PII-free status context and completeness/freshness are visible to both profiles when the event grant is valid.

Unknown semantic/anomaly details remain bounded and PII-free.

## Dormant fields

`order_numbers_visible` and `pii_visible`:

- are not portal capabilities;
- are not exposed in the new admin access UI;
- are ignored by portal policy;
- should be documented as dormant/deprecated;
- may only be activated by a separate reviewed pack.

## Exports and operational records

All current exports and recent-order views remain global-admin-only regardless of these settings.
