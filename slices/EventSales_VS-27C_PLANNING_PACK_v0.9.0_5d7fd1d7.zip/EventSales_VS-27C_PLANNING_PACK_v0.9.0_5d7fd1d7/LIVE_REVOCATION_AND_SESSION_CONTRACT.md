# Live Revocation and Session Contract

## Threat

An open LiveView currently holds an authenticated user struct and may continue rendering after:

- grant revocation/expiry;
- user deactivation;
- event revenue-setting change;
- event eligibility change.

## Durable authority

Postgres policies and scope queries remain truth.

PubSub is an immediate hint, not the sole revocation guarantee.

## Topics

Recommended low-cardinality topics:

- user access topic;
- event access/settings topic.

Messages contain only:

- user/event ids;
- change kind;
- durable revision/timestamp where available.

No email, token, role reason, PII or revenue value.

## After-commit invalidation

Only broadcast after the access mutation and audit commit.

## Heartbeat

Each connected portal LiveView schedules bounded reauthorization.

Planning target:

- interval no greater than 60 seconds;
- jitter permitted to avoid synchronized load;
- one set-based scope or exact-event authorization query;
- no B.2/Sales recomputation just to authorize.

## On access loss

- clear decision DTO/chart data from assigns;
- unsubscribe old topics;
- redirect to `/portal` or generic no-access/logout page;
- do not reveal whether the event still exists;
- record low-cardinality telemetry.

## Revenue-only change

Reauthorize and reload through the access-aware B.3 projection.

Never retain previously visible revenue in socket assigns after access is removed.

## User deactivation

- broadcast user invalidation where workflow supports it;
- heartbeat checks current active state;
- redirect/logout;
- next HTTP request also fails through `LoadCurrentUser`.

## Missed/duplicate/out-of-order messages

- heartbeat bounds missed hint exposure;
- messages trigger re-read rather than direct capability mutation;
- duplicate/out-of-order messages are harmless;
- reconnect rebuilds current truth.

## Security target

Production evidence must demonstrate revocation and deactivation enforcement within the approved maximum bound.
