# Portal Authentication and Session Contract

## Routes

```text
GET/POST /portal/login
DELETE /portal/logout
GET /portal
GET /portal/events/:id
```

## Authentication

Use the existing AshAuthentication password strategy.

Portal login accepts any active user who is:

- global admin; or
- assigned at least one active/unexpired portal-eligible event grant.

Global `staff` alone is insufficient.

Use one generic error for:

- unknown email;
- wrong password;
- inactive user;
- no portal access;
- expired-only access.

Do not reveal account or assignment existence.

## Session

- renew session id on successful login;
- store only `current_user_id`;
- never store roles, grants, capabilities or event ids;
- current-user loading rechecks `active`;
- logout clears/drops session;
- portal and admin may share the same user session identity;
- `/admin/login` remains admin-specific and unchanged unless a reviewed shared helper preserves behaviour.

## Redirects

- portal login success -> `/portal`;
- admin visiting portal login may redirect to `/portal`;
- authenticated user with no current assigned scope -> generic no-access page/logout path;
- admin login success remains `/admin/dashboard`.

## Brute-force protection

Activation must verify existing ingress/application protections.

If no certified protection exists, implement bounded portal-login throttling using:

- IP/request-context hash;
- normalized account-key hash, never raw email in telemetry;
- generic response;
- no user-existence leak;
- bounded reset/cooldown.

An ETS-only limiter may be a UX layer but cannot be the sole durable security claim across nodes.

## Password/onboarding

- no public self-registration;
- no plaintext stored temporary password;
- invitation acceptance uses normal password hashing/validation;
- existing user invitation redemption requires authentication as that user;
- password-reset functionality is not silently invented.

## CSRF and cookie safety

Preserve existing browser CSRF/session protections and production secure-cookie settings. Activation records exact runtime configuration.
