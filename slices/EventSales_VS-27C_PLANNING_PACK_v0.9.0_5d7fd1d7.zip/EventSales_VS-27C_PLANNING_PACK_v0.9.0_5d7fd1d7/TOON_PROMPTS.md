# TOON Prompts — VS-27C

## Planning agent
Task: Design secure assigned-event access on top of certified B.3.
Output: Complete implementation plan.
Boundary: No code or access mutations.

## Authorization reviewer
Task: Attack capability, scope, existence-hiding and revenue masking.
Output: Access matrix findings.
Boundary: Postgres is truth.

## Invitation reviewer
Task: Attack token storage, expiry, redemption, existing users and races.
Output: Security verdict.
Boundary: No plaintext tokens or open registration.

## LiveView reviewer
Task: Attack revocation, heartbeat, reconnect, stale assigns and subscriptions.
Output: Revocation findings.
Boundary: Maximum exposure bound explicit.

## Privacy reviewer
Task: Attack DTO, HTML, chart, URL, PubSub, logs and operations links.
Output: PII/revenue leakage verdict.
Boundary: Event portal aggregate-only.

## Migration reviewer
Task: Attack orphan grants, FK, indexes, audit history and rollback.
Output: Migration verdict.
Boundary: No silent deletion.

## Activation reviewer
Task: Refresh current main plus final B.3/B.2/B.1/F.2 interfaces.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
