# EventSales VS-27C Planning Pack

## Identity

- Slice: `VS-27C`
- Name: Event-Scoped Management and Marketing Access
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#127`
- Linear parent: `JC-212`
- Pack: `JC-213`
- Pack review: `JC-214`
- Remaining gate identifiers: pending Linear capacity
- Created: `2026-07-17T13:27:14Z`

## Authority

This ZIP authorises repository reconnaissance and implementation planning only.

It does not authorise:

- code or migration changes;
- portal route exposure;
- invitations;
- grant changes;
- account provisioning;
- production access changes;
- merge or deployment.

Implementation requires:

1. independent pack approval;
2. independent implementation-plan approval;
3. VS-27B.3 production certification and closeout;
4. exact-current-main activation;
5. certified B.1/B.2/B.3/F.2 interfaces;
6. explicit activation verdict `APPROVE`.

## Outcome

Expose the certified B.3 decision experience to assigned event-scoped users while preserving strict separation from admin operations.

```text
B.3 PII-free actor-aware decision DTO
        ↓
C capability and assigned-event scope
        ↓
separate authenticated portal
        ↓
management / marketing views
```

## Compatibility decision

Current stored grant values remain unchanged:

- `event_owner` maps to user-facing **Management**;
- `event_staff` maps to user-facing **Marketing**.

Web and workflow code must consume explicit capabilities, not raw role values or UI labels.

## Linear capacity note

The workspace reached its free issue limit after `JC-214`.

The intended remaining gates are still normative:

```text
PLAN
PLAN REVIEW
ACTIVATE
IMPLEMENT
PR REVIEW
MERGE/DEPLOY
VALIDATE
CLOSE
```

They are recorded in this pack and must be created or mapped before activation. Lack of a Linear card never grants execution authority.
