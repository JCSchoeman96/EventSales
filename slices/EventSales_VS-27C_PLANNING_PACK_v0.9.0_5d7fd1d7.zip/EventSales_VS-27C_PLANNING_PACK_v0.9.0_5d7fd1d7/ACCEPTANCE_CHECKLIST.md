# VS-27C Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-27B.3 certified and closed.
- [ ] B.1/B.2/F.2 interfaces refreshed.
- [ ] Remaining Linear gates mapped.
- [ ] Activation verdict APPROVE.

## Capabilities
- [ ] Stored role compatibility mapping.
- [ ] Central capability resolver.
- [ ] Admin > management > marketing precedence.
- [ ] Global staff requires grant.
- [ ] No raw role checks in web/templates.
- [ ] Unknown/failure denies.

## Assigned scope
- [ ] Active user required.
- [ ] Active/unexpired grant required.
- [ ] Portal-eligible event contract.
- [ ] Authorize before existence.
- [ ] Set-based assigned-event query.
- [ ] URL cannot widen scope.
- [ ] Bounds/no truncation.
- [ ] Multi-event scope tested.

## Revenue
- [ ] Admin always.
- [ ] Management explicit flag.
- [ ] Marketing explicit flag.
- [ ] Missing/expired setting hides.
- [ ] Partially hidden aggregate returns no total.
- [ ] Hidden revenue absent from assigns/DOM/chart/PubSub/logs.
- [ ] Order/PII flags dormant.

## Authentication
- [ ] Separate portal login/routes.
- [ ] Admin login preserved.
- [ ] Generic login error.
- [ ] Active/access check.
- [ ] Session renewal.
- [ ] Session stores only user id.
- [ ] Logout clears session.
- [ ] Login throttling certified.
- [ ] No self-registration.

## Invitation/onboarding
- [ ] Token >=32 random bytes.
- [ ] Digest only.
- [ ] Single use and expiry.
- [ ] Token absent from logs/audit.
- [ ] New-user transaction.
- [ ] Existing-user authentication.
- [ ] Concurrent redemption test.
- [ ] Revocation test.
- [ ] No plaintext temporary password.

## Grant integrity
- [ ] Orphan preflight.
- [ ] Event FK/relationship.
- [ ] Restrict delete.
- [ ] Explicit grant/expiry/revoke actions.
- [ ] Actor and bounded reason.
- [ ] Create audit.
- [ ] Mutation + audit atomic.
- [ ] New episode on regrant.
- [ ] Duplicate concurrency safe.
- [ ] User deactivation fail closed.

## Portal UI
- [ ] Separate shell.
- [ ] Assigned events only.
- [ ] B.3 components/DTO reused.
- [ ] No operations tab.
- [ ] No admin navigation.
- [ ] Refresh view only.
- [ ] Generic forbidden/not-found.
- [ ] Profile labels management/marketing.
- [ ] Accessibility/mobile.

## Revocation
- [ ] User/event access topics.
- [ ] After-commit broadcast.
- [ ] Heartbeat <= approved bound.
- [ ] Clears assigns on loss.
- [ ] Revenue remasked.
- [ ] Reconnect reauthorizes.
- [ ] PubSub-missed test.
- [ ] Deactivated user test.

## Privacy/security
- [ ] Recursive PII denylist.
- [ ] Seeded secret rendered-page test.
- [ ] No orders/order numbers.
- [ ] No exports/imports/corrections/source controls.
- [ ] Token URL telemetry scrub.
- [ ] Audit metadata allowlist.
- [ ] Admin routes remain admin-only.
- [ ] Static no-role/no-Sales/no-Woo web checks.

## Performance
- [ ] No N+1 authorization.
- [ ] Fifty-viewer test.
- [ ] Heartbeat query load.
- [ ] Scope query plan.
- [ ] Grant indexes.
- [ ] Access change storm bounded.

## Rollout
- [ ] Portal disabled by default.
- [ ] Admin access canary.
- [ ] Invitation canary.
- [ ] Management/marketing canaries.
- [ ] Revenue toggle live test.
- [ ] Revocation/deactivation live test.
- [ ] Rollback flag.
- [ ] Production certification.
