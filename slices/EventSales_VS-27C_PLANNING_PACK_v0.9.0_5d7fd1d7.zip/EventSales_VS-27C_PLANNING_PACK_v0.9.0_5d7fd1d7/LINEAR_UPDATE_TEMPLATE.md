# Linear Update — VS-27C

- Gate/status:
- Linear gate mapping:
- Pack/plan/access version:
- Baseline/head:
- ZIP SHA:
- PR:
- B.1/B.2/B.3/F.2 versions:
- Stage/portal mode:
- Verdict/findings:
- Production access change authorised:
- Next gate/blockers:
