# Predecessor Contracts — VS-27C

## VS-27B.1

B.1 owns metric names, windows, comparisons, currency and completeness.

C may hide a field. It may not reinterpret it.

## VS-27B.2

B.2 owns durable buckets, query bounds and freshness.

C may narrow event scope. It may not query Sales rows or rebuild buckets.

## VS-27B.3

B.3 owns:

- typed filter/query state;
- PII-free actor-aware decision DTOs;
- all-event and event render components;
- chart implementation;
- subscription/reload behaviour;
- source/bucket/completeness presentation;
- admin decision routes and operational separation.

C reuses those contracts for assigned-event portal routes.

C may not copy metric logic into a second portal implementation.

## VS-26F.2

F.2 source catch-up remains global-admin-only.

Portal users may see source status but cannot request catch-up.

## VS-27D

D adds targets and notifications only after C and B.3 are certified.

C must not add target configuration or notification recipients.
