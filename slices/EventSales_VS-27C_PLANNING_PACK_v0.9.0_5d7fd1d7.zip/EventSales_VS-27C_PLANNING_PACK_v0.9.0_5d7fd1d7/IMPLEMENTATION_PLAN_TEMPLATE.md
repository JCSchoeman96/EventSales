# VS-27C Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified B.1/B.2/B.3/F.2 interfaces
## 4. Current accounts/grant/settings truth
## 5. Staged delivery recommendation
## 6. Capability names and compatibility mapping
## 7. Assigned-event scope and portal eligibility
## 8. Revenue projection and partial visibility
## 9. Global admin/staff behaviour
## 10. Portal routes/pipelines/session
## 11. Login throttling
## 12. Portal shell and B.3 reuse
## 13. Invitation necessity and data model
## 14. Token generation/storage/redemption
## 15. Existing-user onboarding
## 16. Admin access-management workflow
## 17. Grant explicit actions/lifecycle
## 18. Audit transaction and metadata
## 19. Event FK/orphan/index migration
## 20. Access PubSub topics
## 21. Heartbeat/revocation bound
## 22. Revenue clearing/remasking
## 23. Privacy/static boundaries
## 24. Tests-first sequence
## 25. Exact files create/modify/generated/forbidden
## 26. Verification commands
## 27. Rollout/rollback
## 28. Production evidence
## 29. Activation inputs
## 30. Linear gate mapping
## 31. Risks/stop conditions
## 32. Prohibited-actions statement
