# VS-26E.3 Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- Feed/window version:
- Scheduler mode:
- Source id redacted:

## Source-window proof
- from/to:
- continuation pages:
- row/change counts:
- same-timestamp test:
- concurrent-edit test:
- tombstone/status test:
- repeat result hash:

## Cursor proof
- before:
- observed-through:
- dispositioned-through:
- attempt status:
- resulting run:
- disposition:
- after:

## Missed-trigger canary
- source edit time:
- trigger intentionally absent:
- reconciliation detected:
- dry-run ready:
- policy/human result:
- total delay:

## Negative proof
- duplicate tick:
- active-run defer:
- review blocking:
- failed page:
- limit exceeded:
- no direct Apply:
- no duplicate durable effects:
- no PII/secrets:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
