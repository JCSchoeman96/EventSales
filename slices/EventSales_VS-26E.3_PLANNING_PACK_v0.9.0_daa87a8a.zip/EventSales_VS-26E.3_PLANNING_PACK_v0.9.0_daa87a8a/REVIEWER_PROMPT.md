# Independent Reviewer Prompt — VS-26E.3

Review adversarially.

Block on any design that:

- advances a cursor over unstable offset pagination;
- lacks an upper source-window bound;
- cannot prove same-timestamp pagination;
- loses private/draft/deletion changes;
- stores cursor only in Oban/cache/config;
- creates a second VS-26E.1 coordinator;
- bypasses VS-26E.2 policy or Applier;
- makes reconciliation origin auto-eligible implicitly;
- reuses attendee reconciliation names ambiguously;
- allows overlapping attempts or scheduler duplication;
- skips a review-ready/failed technical window;
- treats a broad full feed as automatic recovery;
- exceeds downstream 5,000-pair planning bounds;
- cannot stop safely during deployment/version skew.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only. JC-140 controls implementation activation.
