# Cursor Recovery Runbook

## Retry same window

Use when:

- timeout;
- rate limit;
- server error;
- invalid page;
- technical cancellation;
- failed dry-run;
- persistence failure.

## Block for review

Use when:

- dry-run ready and ineligible/manual;
- unexpected source changes;
- risky/tombstone transition;
- manual disposition required.

## Mark full reconciliation required

Use when:

- cursor gap exceeds approved automatic range;
- page/row/window ceiling;
- incompatible feed version;
- ordering/continuation proof fails;
- repeated deterministic failure.

Never jump the cursor to current time to clear an incident.
