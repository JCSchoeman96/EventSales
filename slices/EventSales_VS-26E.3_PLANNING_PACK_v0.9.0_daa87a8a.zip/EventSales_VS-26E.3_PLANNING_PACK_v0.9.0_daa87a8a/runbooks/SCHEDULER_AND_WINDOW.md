# Scheduler and Window Runbook

1. Scheduler leader emits one bounded tick.
2. Load at most configured enabled sources.
3. Insert one unique per-source attempt.
4. Lock/reload cursor.
5. Stop when source inactive, blocked or full reconciliation required.
6. Calculate window from dispositioned/observed state and overlap.
7. Freeze window upper bound before source calls.
8. Fetch deterministic pages.
9. Persist completion counters and source contract identity.
10. Submit work through the shared catalogue coordinator.
11. Link resulting run or durable defer reason.
12. Await policy/human disposition.
13. Advance watermarks transactionally under matrix rules.
14. Schedule next work with jitter.
