# Failure Matrix

| Failure | Durable state | Cursor | Recovery |
|---|---|---|---|
| duplicate scheduler tick | existing attempt | unchanged | discard |
| active attempt | blocked/duplicate | unchanged | wait |
| active Catalog Sync | deferred | unchanged | auto-resume |
| source timeout/5xx | retryable | unchanged | retry same window |
| rate limit | scheduled retry | unchanged | backoff |
| invalid/unsupported feed | failed/full-required | unchanged | upgrade/manual |
| incomplete pagination | failed | unchanged | retry/manual |
| row/window ceiling | full-required | unchanged | reviewed recovery |
| review-ready run | blocked-review | observed only | human/policy |
| applied run | completed | advance both | next window |
| acknowledged no-apply | completed | advance both | next window |
| technical revoke | retry required | do not advance dispositioned | recompute |
| Apply failure | blocked/error | observed only | repair/review |
| cursor write failure | error | unchanged | transaction retry |
