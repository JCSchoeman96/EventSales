# Rollout and Stop Conditions

## Rollout

1. Deploy feed contract disabled/compatible.
2. Verify WordPress query plans and deterministic pagination.
3. Deploy cursor/attempt tables and scheduler disabled.
4. Verify migrations/indexes and one leader.
5. Enable observation for one source.
6. Run fixed test windows repeatedly.
7. Prove identical logical results and no cursor movement in observation mode.
8. Enable one bounded scheduled source.
9. Deliberately suppress one trigger.
10. Verify reconciliation recovery.
11. Verify review blocking and resume.
12. Widen only by explicit approval.

## Stop immediately

- cursor advances after incomplete fetch;
- same-timestamp rows are skipped;
- concurrent edits can move between pages;
- tombstones disappear;
- duplicate coordinator/run appears;
- reconciliation origin bypasses policy;
- attendee reconciliation queue/resource is corrupted;
- automatic full feed starts unexpectedly;
- limits or secrets/PII protections fail.
