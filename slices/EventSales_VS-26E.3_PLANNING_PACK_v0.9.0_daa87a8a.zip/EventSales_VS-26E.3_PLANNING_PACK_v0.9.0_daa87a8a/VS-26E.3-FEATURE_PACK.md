# VS-26E.3 — Periodic Catalog Reconciliation Sweep

## 1. Executive summary

VS-26E.1 provides the primary near-live catalogue-change signal. VS-26E.2 decides whether a completed dry-run is safe to auto-apply.

VS-26E.3 is the safety net.

It periodically discovers changes that were missed because a WordPress hook, async delivery, network call, deployment or coordinator transition failed. It must not become a second primary ingestion path or a broad unbounded full-feed poller.

The central invariant is:

```text
durable bounded source window
-> existing shared catalogue-work coordinator
-> reconciliation-origin Catalog Sync dry-run
-> existing policy/human disposition
-> durable cursor advancement under explicit rules
```

## 2. Predecessor contract

### VS-26E.1 targeted trigger

The final implementation may differ from the planning pack. Activation must inspect the certified result.

Required inherited behaviour:

- durable signal receipt;
- stable target identity;
- deduplication/coalescing;
- active-run defer/replay;
- narrow system-authorised Catalog Sync queue facade;
- no parallel catalogue writer.

VS-26E.3 must use the same work-coordination boundary. It may add a new work origin and window scope, but not a second pending-work table or independent active-run rule.

### VS-26E.2 conservative auto-apply

Required inherited behaviour:

- explicit run origin;
- fail-closed versioned policy;
- durable decision/audit;
- exact-hash Apply;
- global/source/observation modes;
- human review for unsupported or risky runs.

Initial VS-26E.2 posture normally allows only `targeted_trigger`. Therefore reconciliation-origin dry-runs remain manual unless a later reviewed policy version explicitly enables them.

VS-26E.3 never calls the Applier directly.

## 3. Current repository truth

### Oban

Current configuration:

- `plugins: []`;
- `tickera_sync: 1`;
- `tickera_reconciliation: 1`;
- other queues for order reconciliation, webhooks, analytics and maintenance.

The existing `tickera_reconciliation` queue belongs to attendee reconciliation through `ReconcileTickeraAttendeesWorker`. Catalogue reconciliation must not silently reuse that name.

### WordPress feed client

Current client:

- signed GET feed;
- default page size 100;
- default maximum 50 pages;
- recursively fetches all pages;
- aggregates all pages in memory;
- supports `updated_since`;
- treats pagination-limit as an error.

### Current feed limitations

The current WordPress feed:

- has only a lower `updated_since` bound;
- uses `>` comparisons;
- has no explicit upper modification bound;
- uses offset pagination;
- orders catalogue rows by event title, product title and IDs rather than modification cursor;
- returns `events[]` and `catalog_rows[]` with different query shapes;
- reports `has_more` from catalogue rows;
- has no deterministic continuation token;
- has no explicit tombstone/deletion stream;
- caches exact queries for 30–300 seconds.

That contract is not sufficient for a durable advancing cursor.

### Source system

`SourceSystem` currently stores:

- name;
- kind;
- base URL;
- active state.

It has no catalogue schedule, cursor or reconciliation state.

### Catalog Sync

One nonterminal run per source is enforced across:

- queued;
- discovering;
- retry scheduled;
- dry-run ready;
- applying.

A review-ready run intentionally blocks replacement work until Apply or revocation.

## 4. Goal and observable outcome

A catalogue change deliberately omitted from the targeted-trigger path is found by the next eligible reconciliation window.

Proof must show:

- no skipped boundary rows;
- no duplicate durable catalogue effects;
- no second active run;
- no cursor advancement after incomplete discovery;
- clear blocked-review state;
- automatic continuation after an allowed disposition;
- reconciliation origin preserved;
- no direct or implicit auto-apply.

## 5. Deterministic source-window contract

A cursor may advance only against a source contract that proves a stable finite window.

The implementation plan must choose and justify one of:

1. one unified ordered change stream; or
2. independently cursorable event and catalogue-row streams with a complete no-skip proof.

Minimum requirements:

- explicit lower and upper modification bounds;
- documented half-open semantics;
- source UTC timestamps;
- stable effective-modified timestamp;
- deterministic identity tie-breakers;
- keyset/continuation pagination or equivalent stable snapshot;
- versioned continuation token;
- same window identity on every page;
- bounded pages and rows;
- private/draft/trash/deleted representation;
- explicit empty-window response;
- unsupported-version failure;
- no dependence on page offsets during concurrent edits.

Recommended logical ordering:

```text
effective_modified_at ASC
entity_kind ASC
tickera_event_id ASC
woo_product_id ASC NULLS FIRST
woo_variation_id ASC NULLS FIRST
```

The planning agent must verify how WordPress/MySQL null ordering and timestamp precision affect the exact implementation.

## 6. Window semantics

Recommended model:

```text
window = [from_inclusive, to_exclusive)
```

A repeated overlap may intentionally re-read rows. Durable planning and coordinator idempotency must make those duplicates harmless.

The plan must define:

- initial bootstrap boundary;
- schedule interval;
- overlap duration;
- maximum automatic window width;
- maximum automatic backlog age;
- source clock-skew allowance;
- WordPress cache-TTL interaction;
- same-timestamp tie handling;
- late transaction handling;
- daylight-saving irrelevance through UTC;
- behaviour when source timestamps are absent or invalid.

## 7. Durable resources

The plan should normally separate mutable per-source cursor/config from immutable attempt history.

### Cursor/config concepts

- source system id;
- mode: disabled / observe / enabled;
- schedule version;
- interval seconds;
- overlap seconds;
- maximum window seconds;
- observed-through timestamp;
- dispositioned-through timestamp;
- current state;
- blocked run id;
- last attempt id;
- last success/error time;
- stale/full-reconciliation-required state;
- lock/generation metadata.

### Attempt concepts

- attempt id;
- source system;
- requested via scheduled/manual/system;
- window from/to;
- cursor before;
- feed/contract version;
- status;
- owner attempt/max attempts;
- page/row/change counters;
- continuation state if durable pagination is used;
- resulting Catalog Sync run id/hash;
- policy/disposition outcome;
- cursor after;
- bounded error/reason code;
- timestamps.

Postgres is authority. Oban args, Redis and application config are not cursor truth.

## 8. Dual-watermark model

The pack recommends two durable boundaries:

### `observed_through`

The source window was fetched completely and represented by a persisted reviewable Catalog Sync dry-run.

### `dispositioned_through`

The dry-run was:

- applied; or
- explicitly acknowledged as intentionally not applied under an approved disposition.

This separation prevents both silent skipping and repeated source reads while a run awaits review.

The planning agent may propose another model only with an equivalent proof.

## 9. Cursor/disposition rules

See `CURSOR_STATE_MATRIX.md`.

The cursor must never advance when:

- pagination was incomplete;
- the feed contract/version was unsupported;
- a page failed;
- row/window ceilings were exceeded;
- source timestamps were invalid;
- the dry-run could not be persisted;
- an active-run conflict was not durably deferred;
- a technical revoke/failure occurred;
- successor coverage was not proven.

## 10. Scheduler

Preferred shape:

```text
single recurring leader tick
-> bounded active source scan
-> per-source idempotent attempt job
-> frozen window calculation
-> shared VS-26E.1 coordinator request
-> wait/defer/link
-> disposition-driven cursor transition
```

The agent must verify the locked Oban version and whether `Oban.Plugins.Cron` is available.

Requirements:

- one scheduler leader across nodes;
- no one-timer per node;
- strict source scan limit;
- jitter;
- per-source job uniqueness;
- no overlapping attempts;
- new unambiguous queue name such as `catalog_reconciliation`;
- actual Catalog Sync remains on `tickera_sync`;
- bounded retries/backoff;
- no source call in controller, LiveView or component;
- global/source kill switches;
- observation mode first.

## 11. Active-run and manual-review behaviour

When any Catalog Sync run is active:

- reconciliation attempt becomes durably deferred/blocked;
- no second active run is inserted;
- VS-26E.1 trigger work remains coalesced;
- the current blocking run and age are visible;
- next retry is bounded;
- automatic resume occurs after an allowed terminal transition;
- cursor remains conservative.

A review-ready risky run may intentionally stall automatic catalogue progression. This is safer than skipping it.

The plan must include stale-review alerts without enabling broad automatic revocation.

## 12. Interaction with auto-apply

Reconciliation produces origin `reconciliation`.

Default:

- VS-26E.2 evaluates or observes according to its final contract;
- reconciliation origin is ineligible unless explicitly enabled by an approved policy version;
- VS-26E.3 records the result but never broadens policy;
- human Apply/revoke remains available;
- exact-hash Apply remains final mutation authority.

## 13. Incremental versus full reconciliation

V1 is bounded incremental reconciliation.

The system must mark `full_reconciliation_required` rather than automatically launching a broad full feed when:

- cursor is missing beyond the approved bootstrap rule;
- cursor lag exceeds automatic catch-up limit;
- contract version changes incompatibly;
- page/row limits are exceeded;
- source ordering cannot be proven;
- repeated window failure exhausts retries.

A full audit requires a separately reviewed/manual recovery plan.

## 14. Private/draft/deleted changes

A reconciliation safety net that sees only published rows is incomplete.

The final predecessor/source contract must provide reviewable representation of:

- event publication-state changes;
- product publication-state changes;
- variation publication-state changes;
- trash/deletion/tombstone identity;
- product moved to another event;
- entity removed from the source catalogue.

These remain manual/risky by default and must not disappear from the cursor window.

## 15. Performance and bounds

The plan must lock:

- scheduler interval range;
- source scan cap;
- max one active attempt per source;
- max automatic window width;
- max catch-up windows per tick;
- page size;
- max pages;
- max rows/change identities;
- HTTP timeout;
- retry limits;
- historical-impact pair limit interaction;
- in-memory aggregation limit or streaming replacement;
- database query/index shapes;
- admin pagination;
- telemetry cardinality.

Current historical-impact planning supports at most 5,000 touched pairs and processes exact-pair aggregate batches of 25. Reconciliation must stop before accidentally exceeding downstream limits.

## 16. Failure and recovery

Cover:

- cron/scheduler duplicate tick;
- scheduler leader failover;
- source deactivated;
- cursor row absent;
- clock skew;
- cache replay;
- source edit during pagination;
- page duplication;
- page omission;
- invalid continuation token;
- unsupported feed version;
- rate limit/timeout/server error;
- page/row/window ceiling;
- active Catalog Sync;
- review-ready blocking run;
- trigger backlog;
- dry-run failure/cancel/revoke/apply;
- policy observation/ineligible/error;
- cursor transaction failure;
- deployment during attempt;
- queue pause;
- stale cursor;
- full-reconciliation-required escalation.

## 17. Tests-first sequence

1. source-window contract tests;
2. same-timestamp/keyset pagination tests;
3. concurrent-edit no-skip tests;
4. private/draft/tombstone tests;
5. cursor resource/state-machine tests;
6. attempt uniqueness/ownership tests;
7. scheduler singleton tests;
8. VS-26E.1 coordinator integration;
9. active-run defer/resume;
10. dual-watermark disposition tests;
11. VS-26E.2 origin/default-manual tests;
12. limits/backlog/full-required tests;
13. admin health/PubSub tests;
14. rollout/production evidence.

## 18. Explicit non-goals

- no order catch-up;
- no broad scheduled full feed;
- no direct Applier call;
- no new catalogue writer;
- no duplicate trigger coordinator;
- no reuse of attendee reconciliation resource/queue without explicit redesign;
- no automatic revocation of risky runs;
- no PII/order/payment data;
- no dashboard redesign;
- no second-source implementation beyond forward-compatible schema.

## 19. Acceptance

A missed source change is recovered through a deterministic bounded window. The window is represented by one existing Catalog Sync dry-run, safely blocked or disposed, and cursor state advances only under approved rules.

No duplicate mutation, skipped row, unbounded source scan or authority bypass is possible.
