# VS-26E.3 Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified VS-26E.1 coordinator contract
## 4. Certified VS-26E.2 policy/origin contract
## 5. Current feed/pagination truth
## 6. Deterministic source-window design
## 7. Event/catalog/tombstone stream model
## 8. Timestamp precision and tie-breakers
## 9. Continuation/keyset contract
## 10. Cache, overlap and clock-skew rules
## 11. Cursor/config resource
## 12. Attempt-history resource/state machine
## 13. Observed/dispositioned watermarks
## 14. Full cursor transition matrix
## 15. Scheduler leadership and Oban configuration
## 16. Per-source uniqueness and ownership
## 17. Coordinator defer/coalescing integration
## 18. Auto-apply/human-review interaction
## 19. Bounds and full-reconciliation-required
## 20. Admin health/PubSub/telemetry
## 21. Migrations/indexes/query plans
## 22. Tests-first sequence
## 23. Exact files create/modify/generated/forbidden
## 24. Verification commands
## 25. Rollout/kill switches
## 26. Production evidence
## 27. JC-140 activation inputs
## 28. Risks and stop conditions
## 29. Prohibited-actions statement
