# Deterministic Source Window Contract

## Problem with current v1 feed

Current lower-bound plus offset pagination can skip or duplicate rows when records change while pages are read. The returned source snapshot timestamp does not freeze MySQL state.

## Required v2 properties

- versioned request and response;
- explicit `[from, to)` UTC window;
- stable ordering;
- continuation token tied to window and contract version;
- no mutable offset-only pagination;
- complete event and product/variation state;
- tombstones/status transitions;
- page count/row bounds;
- same window id on each page;
- final-page proof;
- safe repeat of the same window.

## Candidate request

```json
{
  "window_from": "2026-07-17T07:00:00.000000Z",
  "window_to": "2026-07-17T07:15:00.000000Z",
  "cursor": null,
  "per_page": 100,
  "include_non_public": true
}
```

## Candidate response

```json
{
  "schema_version": "<reviewed-version>",
  "window_id": "<deterministic-or-signed-id>",
  "window_from": "...",
  "window_to": "...",
  "next_cursor": "<opaque-or-null>",
  "has_more": false,
  "changes": []
}
```

The exact shape is not locked by this planning pack; the agent must prove it composes with the final feed normalizer/planner.

## Cache rule

Cache keys must include all window and continuation values. A repeated page must be byte/logically stable for the same window contract, or the client must detect incompatible change.
