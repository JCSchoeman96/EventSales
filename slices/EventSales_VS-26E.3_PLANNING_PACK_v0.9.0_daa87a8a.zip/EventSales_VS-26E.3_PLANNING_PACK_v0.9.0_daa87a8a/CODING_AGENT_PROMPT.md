# Planning Agent Prompt — VS-26E.3

Repository: `JCSchoeman96/EventSales`

Planning pack: `EventSales_VS-26E.3_PLANNING_PACK_v0.9.0_daa87a8a.zip`

Planning baseline: `daa87a8a1693e399c8effeb23297efad159397fd`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not change files, commit, open/merge a PR, deploy, migrate, configure a scheduler, change WordPress, queue Catalog Sync/Apply or alter production state.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

Inspect the two direct baseline commits and record whether they caused any material tree or deployment-state difference.

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Also inspect the final certified VS-26E.1 and VS-26E.2 artifacts when available. If they are not implemented yet, mark every dependent interface as activation-time unresolved truth.

## Required plan decisions

1. exact deterministic source-window contract;
2. event plus product/variation pagination model;
3. tombstone/private/draft representation;
4. half-open boundaries and timestamp precision;
5. keyset/continuation design;
6. cache and overlap behaviour;
7. per-source cursor/config resource;
8. attempt-history resource/state machine;
9. observed versus dispositioned watermark semantics;
10. cursor transition for every Apply/revoke/failure status;
11. first-run bootstrap;
12. backlog/full-reconciliation-required rules;
13. scheduler leader and Oban plugin;
14. new queue naming and concurrency;
15. source scan/window/page/row bounds;
16. VS-26E.1 coordinator integration;
17. VS-26E.2 origin and default-manual behaviour;
18. admin blocked/stale health;
19. migrations/indexes/query plans;
20. tests-first sequence;
21. rollout/kill switches;
22. production evidence;
23. `JC-140` activation inputs.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`; or
- `PACK BLOCKED`.

State explicitly that no prohibited action was performed.
