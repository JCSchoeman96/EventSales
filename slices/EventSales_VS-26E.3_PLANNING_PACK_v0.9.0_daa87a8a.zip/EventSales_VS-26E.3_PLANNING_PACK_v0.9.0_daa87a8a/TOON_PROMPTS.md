# TOON Prompts — VS-26E.3

## Planning agent
Task: Design deterministic periodic catalogue reconciliation from current repo truth.
Output: Complete implementation plan.
Boundary: No code or system changes.

## Source-contract reviewer
Task: Attack window, ordering, pagination, cache and tombstone semantics.
Output: No-skip/no-duplicate verdict.
Boundary: Offset-only pagination is insufficient.

## Cursor reviewer
Task: Attack watermark advancement and disposition rules.
Output: State-transition findings.
Boundary: Incomplete/technical failure never advances.

## Concurrency reviewer
Task: Review scheduler singleton, per-source attempt uniqueness and active-run integration.
Output: Race findings and tests.
Boundary: One active Catalog Sync remains authoritative.

## Activation reviewer
Task: Refresh current main plus certified VS-26E.1/2 interfaces.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
Boundary: No implementation.

## Production validator
Task: Prove a missed trigger is recovered through a bounded window.
Output: CERTIFIED / RISK / REJECTED.
Boundary: No direct or implicit auto-apply.
