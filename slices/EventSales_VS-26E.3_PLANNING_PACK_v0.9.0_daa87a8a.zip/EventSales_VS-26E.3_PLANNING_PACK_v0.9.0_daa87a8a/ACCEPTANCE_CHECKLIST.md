# VS-26E.3 Acceptance Checklist

## Predecessors
- [ ] VS-26E.1 certified interface inspected.
- [ ] VS-26E.2 certified interface inspected.
- [ ] No duplicate coordinator.
- [ ] Reconciliation origin default policy confirmed.

## Source contract
- [ ] Explicit lower/upper UTC window.
- [ ] Half-open semantics.
- [ ] Stable ordering.
- [ ] Same-timestamp tie-breakers.
- [ ] Keyset/continuation pagination.
- [ ] Window/version identity.
- [ ] Page/row bounds.
- [ ] Private/draft/trash/deletion representation.
- [ ] Concurrent edit no-skip proof.
- [ ] Cache/overlap proof.

## Cursor
- [ ] Durable per-source config/cursor.
- [ ] Durable attempt history.
- [ ] Observed/dispositioned semantics.
- [ ] Transactional advancement.
- [ ] Every run status/revoke reason mapped.
- [ ] Retry/rewind rules.
- [ ] Full-reconciliation-required state.
- [ ] No Redis/cache/config-only truth.

## Scheduler
- [ ] Single leader.
- [ ] Per-source uniqueness.
- [ ] Dedicated unambiguous queue.
- [ ] Jitter.
- [ ] Strict source/window/page/job bounds.
- [ ] Disabled/observe/enabled modes.
- [ ] Kill switches.

## Integration
- [ ] VS-26E.1 defer/coalescing reused.
- [ ] No second active Catalog Sync.
- [ ] VS-26E.2 policy not bypassed.
- [ ] Existing Applier only.
- [ ] Review-ready blocking visible.
- [ ] Automatic resume after disposition.

## Tests
- [ ] bootstrap/boundaries/ties;
- [ ] concurrent pagination edits;
- [ ] overlap duplicates;
- [ ] cache and clock skew;
- [ ] tombstones/status transitions;
- [ ] limits/version errors;
- [ ] scheduler/attempt races;
- [ ] trigger/reconciliation coalescing;
- [ ] cursor disposition matrix;
- [ ] observation/disabled modes;
- [ ] admin health;
- [ ] full CI.

## Production
- [ ] missed trigger canary recovered.
- [ ] no duplicate durable effects.
- [ ] no skipped rows.
- [ ] no second active run.
- [ ] cursor evidence correct.
- [ ] kill switch verified.
- [ ] redacted certification recorded.
