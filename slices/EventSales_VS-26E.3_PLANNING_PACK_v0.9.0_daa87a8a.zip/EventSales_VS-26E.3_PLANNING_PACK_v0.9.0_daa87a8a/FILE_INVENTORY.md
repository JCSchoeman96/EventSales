# Mandatory File Inventory — VS-26E.3

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Current catalogue source
- `integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`
- `integrations/wordpress/eventsales-tickera-catalog-feed/README.md`
- `docs/ops/tickera_catalog_feed_contract.md`
- `docs/ops/tickera_catalog_feed_eventsales_adapter.md`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_signature.ex`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_client.ex`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_response.ex`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_discovery_source.ex`
- `lib/event_sales/catalog/tickera_catalog/configured_discovery_source.ex`

## Catalog Sync
- `lib/event_sales/ingestion/tickera_catalog_sync.ex`
- `lib/event_sales/ingestion/resources/tickera_catalog_sync_run.ex`
- `lib/event_sales/ingestion/resources/tickera_catalog_sync_finding.ex`
- `lib/event_sales/ingestion/workers/discover_tickera_catalog_worker.ex`
- `lib/event_sales/ingestion/workers/apply_tickera_catalog_worker.ex`
- `lib/event_sales/catalog/tickera_catalog/normalizer.ex`
- `lib/event_sales/catalog/tickera_catalog/planner.ex`
- `lib/event_sales/catalog/tickera_catalog/applier.ex`
- `lib/event_sales/ingestion/tickera_catalog_historical_impact.ex`
- `lib/event_sales_web/live/admin/catalog_sync_live.ex`

## Source/config
- `lib/event_sales/catalog/resources/source_system.ex`
- `lib/event_sales/catalog.ex`
- `lib/event_sales/ingestion.ex`
- `config/config.exs`
- `config/runtime.exs`
- `mix.exs`
- `mix.lock`

## Existing reconciliation patterns
- `lib/event_sales/ingestion/resources/sync_run.ex`
- `lib/event_sales/ingestion/reconciliation_peak_guard.ex`
- `lib/event_sales/ingestion/resources/tickera_reconciliation_run.ex`
- `lib/event_sales/ingestion/workers/reconcile_tickera_attendees_worker.ex`
- `docs/runbooks/reconciliation.md`
- `docs/runbooks/oban-queue-backlog.md`
- `docs/architecture/oban-pgbouncer.md`

## Deployment
- `railway.toml`
- `lib/event_sales/release.ex`
- `docs/architecture/db-topology.md`
- `docs/deployment/pgbouncer.md`

## Tests
- `test/event_sales/catalog/tickera_catalog/wordpress_feed_client_test.exs`
- `test/event_sales/catalog/tickera_catalog/wordpress_feed_response_test.exs`
- `test/event_sales/catalog/tickera_catalog/wordpress_feed_discovery_source_test.exs`
- `test/event_sales/ingestion/tickera_catalog_sync_test.exs`
- `test/event_sales/ingestion/tickera_catalog_sync_concurrency_test.exs`
- `test/event_sales/ingestion/workers/discover_tickera_catalog_worker_test.exs`
- `test/event_sales/ingestion/workers/apply_tickera_catalog_worker_test.exs`
- `test/event_sales/ingestion/tickera_catalog_historical_impact_test.exs`
- `test/event_sales/ingestion/workers/reconcile_tickera_attendees_worker_test.exs`
- `test/event_sales/ingestion/tickera_reconciliation_runs_test.exs`

## Predecessor artifacts
- final VS-26E.1 pack/plan/activation/PR/certification;
- final VS-26E.2 pack/plan/activation/PR/certification.
