# Implementation Agent Prompt Template — VS-26E.3

**Do not use until JC-140 returns APPROVE.**

Activation must fill:

- exact current main SHA;
- certified VS-26E.1 coordinator interface;
- certified VS-26E.2 origin/policy interface;
- exact feed schema/window contract;
- exact cursor/attempt resources;
- exact disposition matrix;
- exact scheduler/queue configuration;
- exact files/migrations/indexes;
- exact tests and rollout;
- exact stop conditions.

Write tests first, implement only activated scope, open a PR and stop before merge/deployment.
