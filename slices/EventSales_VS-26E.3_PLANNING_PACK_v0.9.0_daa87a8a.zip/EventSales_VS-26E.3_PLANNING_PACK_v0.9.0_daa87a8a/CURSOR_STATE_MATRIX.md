# Cursor and Disposition Matrix

| Catalog/attempt outcome | observed-through | dispositioned-through | Next action |
|---|---:|---:|---|
| complete empty window | advance | advance | schedule next |
| complete dry-run, auto-applied | advance | advance | schedule next |
| complete dry-run, human applied | advance | advance | schedule next |
| complete dry-run, explicitly acknowledged no-apply | advance | advance | schedule next |
| complete dry-run, still review-ready | advance | hold | blocked by review |
| active run prevented submission | hold | hold | durable defer |
| discovery failed/retryable | hold | hold | retry same window |
| pagination/window limit | hold | hold | mark full/manual recovery required |
| unsupported feed version | hold | hold | stop/upgrade |
| cancelled: source changed | invalidate attempt | hold | recompute/retry |
| cancelled: incorrect scope | invalidate attempt | hold | fix/retry |
| cancelled: unexpected changes | hold | hold | human decision |
| cancelled: operator error/other | hold | hold | human decision |
| cancelled: superseded | conditional | conditional | advance only with successor coverage proof |
| Apply failed | observed stays | hold | repair/review |
| source deactivated | hold | hold | pause |

A new explicit `acknowledged_no_apply` disposition is preferable to overloading generic cancellation reasons.
