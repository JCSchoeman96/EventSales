# Predecessor Contracts

## VS-26E.1

Expected planning intent:

- PII-free targeted WordPress signal;
- durable receipt;
- target coalescing;
- active-run defer/replay;
- system-authorised Catalog Sync queueing;
- no auto-apply.

Activation must replace these expectations with certified implementation truth.

## VS-26E.2

Expected planning intent:

- explicit run origin;
- pure fail-closed AutoApplyPolicy;
- durable policy decision;
- exact-hash existing Apply worker;
- targeted-trigger origin only by default;
- observation and kill switches.

VS-26E.3 may not silently make reconciliation origin eligible.

## Composition rule

```text
VS-26E.1 = prompt change detection and work coordination
VS-26E.2 = safe disposition policy
VS-26E.3 = missed-change recovery and durable cursor
```

No pack may duplicate another pack's authority.
