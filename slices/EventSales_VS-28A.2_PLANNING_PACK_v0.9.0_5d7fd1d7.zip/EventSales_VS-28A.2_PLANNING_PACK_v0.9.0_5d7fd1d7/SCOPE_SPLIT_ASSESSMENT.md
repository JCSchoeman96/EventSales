# Scope Split Assessment

A staged implementation is recommended.

## Stage A — Read-only operator surface

- routes, AdminShell navigation and feature mode;
- index/detail DTO rendering;
- selection UI;
- preview queue command;
- campaign PubSub/reconnect;
- privacy/accessibility tests.

Production remains preview-only.

## Stage B — Exact execution and controls

- exact plan confirmation;
- reason/reference;
- execution queue command;
- pause/resume/cancel/revoke;
- audit timeline;
- race/idempotency tests.

Execution remains disabled until canary authorization.

## Stage C — Production canary and certification

- mode/canary scope;
- one preview;
- separate exact execution supplement;
- workflow evidence;
- closeout.

Split is mandatory if:

- A.1 interface extensions are required;
- execution controls cannot be reviewed independently;
- audit/schema changes are needed;
- feature-mode/canary implementation is broad;
- one PR mixes route rollout with production execution.

No stage authorises source calls or execution by itself.
