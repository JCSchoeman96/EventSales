# Predecessor Contracts — VS-28A.2

## VS-28A.1

A.1 owns selectable-event eligibility, source-created boundaries, campaign/event/window/failure resources, preview and exact plan hash, plan age and drift, execution, pause/resume/cancel state, source priority, catch-up seam, B.2 readiness, completeness certificates, read DTOs and campaign PubSub.

A.2 is an actor-aware web workflow over those exact interfaces.

## VS-26F.1 / VS-26F.2

A.2 may display catch-up seam/freshness from A.1 DTOs. It cannot alter near-live catch-up through hidden coupling.

## VS-26G / VS-27B.1 / VS-27B.2

A.2 displays semantic and analytics blockers. It cannot resolve mappings, redefine metrics or rebuild analytics directly.

## VS-27D

A.2 displays whether metric completeness exists. It never arms targets.

## VS-28B

CSV/XLSX import, exports, corrections and broader reconciliation remain VS-28B.
