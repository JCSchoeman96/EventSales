# Migration and Rollout Contract

## Expected code changes

Potential additions:

- admin backfill route(s);
- LiveView modules and render-only components;
- A.2 actor-aware workflow facade if not part of A.1;
- audit event allowlist/methods;
- feature-mode configuration;
- campaign PubSub subscription adapter;
- tests and navigation entry.

A.2 should require little or no new database schema when A.1 handoff is complete.

## Schema changes

Only when final A.1 lacks necessary durable operator evidence, such as:

- requested/approved actor id;
- reason/reference fields;
- command idempotency state;
- audit event type support.

Any such addition must be treated as a predecessor handoff correction, additive and independently reviewed.

## Route rollout

1. Deploy with feature mode `disabled`.
2. Verify route protection and navigation hidden.
3. Enable read-only/index for one admin if supported.
4. Enable `preview_only`.
5. Run source-free test fixtures/staging.
6. Queue one separately approved production preview.
7. Review exact plan.
8. Enable `canary_execution` only after Pack 13 supplement.
9. Execute one exact campaign.
10. Validate pause/resume/cancel and final status.
11. Enable broader operation only after workflow certification.

## Navigation

Add `Backfills` to AdminShell Ops group only when route mode is visible.

The nav item may render disabled-status text where feature mode requires.

## Rollback

- set mode to disabled/preview-only;
- remove/hide navigation;
- keep A.1 campaign/evidence;
- do not delete Sales writes;
- do not mutate certificates;
- running work may be cooperatively paused/cancelled through A.1 before disabling controls.

## Stop conditions

- A.1 not certified;
- web code must query A.1 tables directly;
- execution audit/job not atomic;
- plan hash not server-revalidated;
- mode/canary scope trusts form;
- PII/raw payload reaches DTO/HTML/PubSub/log;
- cancel semantics imply rollback;
- force certificate/target action appears;
- direct Woo/Oban control in web;
- route protection differs from AdminOnly.
