# UI Component and State Contract

## Recommended components

Render-only components:

- campaign status badge;
- selected-event summary;
- source boundary table;
- preview progress panel;
- finding list;
- exact plan panel;
- action confirmation dialog;
- failure summary;
- completeness status matrix;
- audit timeline.

Components receive DTOs and emit no domain calls.

## Page states

### Index

- empty state;
- feature disabled;
- campaigns available;
- load error.

### New

- selectable rows;
- selection validation;
- source mismatch;
- boundary blocker;
- active campaign conflict;
- queue confirmation.

### Show

- preview queued/running;
- preview ready;
- execution queued/running;
- pausing/paused;
- cancelling/cancelled;
- blocked/failed;
- completed/certified.

## Status wording

Use operator-accurate labels:

- Preparing preview
- Scanning source for preview
- Preview ready for review
- Execution queued
- Backfill running
- Pause requested
- Paused after a safe step
- Cancellation requested
- Cancelled; prior writes remain
- Waiting for catch-up seam
- Waiting for analytics
- Historical ingestion covered
- Metric completeness certified
- Blocked

## Progress wording

Avoid generic `75% complete` unless A.1 supplies a stable denominator and exact definition.

Prefer:

- 14 pages scanned
- 3 of 5 stable windows verified
- 1,248 approved identities observed
- 320 relevant orders processed
- waiting for source catch-up through 17 July 2026 20:00 SAST

## Dialog safety

High-impact dialogs:

- no click-away accidental submit;
- explicit cancel button;
- focus trap;
- submit disabled until server-valid form state where possible;
- server remains final validator.
