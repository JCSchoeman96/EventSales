# Pause, Resume and Cancel Contract

## Common rules

- current global admin;
- server-loaded campaign;
- current state filter/lock;
- bounded reason;
- transactionally coupled audit;
- after-commit PubSub;
- duplicate request idempotent;
- no direct Oban job cancellation or retry.

## Pause

UI wording:

```text
Pause after the current bounded step
```

The dialog states that the current source page or local certification step may complete.

A request may transition to `pausing`, not immediately `paused`.

## Resume

UI shows the exact durable next phase/window summary.

Resume is unavailable when:

- plan expired/drifted;
- campaign cancelled;
- event no longer eligible;
- source/contract version requires new preview;
- feature mode is preview-only;
- A.1 reports a blocker requiring human correction.

## Cancel

Reason codes planning set:

- incorrect_event_selection;
- source_changed;
- plan_unexpected;
- operational_load;
- superseded;
- operator_error;
- external_authorization_revoked;
- other.

`other` requires details.

Cancellation dialog states:

- existing Sales writes remain;
- no certificate will be issued;
- a new campaign is required to continue.

## Preview revoke

For `preview_ready`, use wording `Revoke preview plan`, not `Cancel execution`.

The plan hash becomes non-executable.

## Failure during request

If audit/transition/job insertion fails, no misleading accepted flash is shown.

The page reloads current durable state.
