# Planning Agent Prompt — VS-28A.2

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-28A.2_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, run migrations, call sources, create/preview/execute campaigns, manipulate Oban, issue certificates, commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified VS-28A.1 pack, plan, implementation, PR review, deployment and core certification. Do not assume planning resource/action names survived.

## Required decisions

1. exact A.1 read/command/DTO/PubSub interfaces;
2. whether any A.1 handoff extension is required;
3. route/module design;
4. AdminOnly/session/current-user use;
5. feature modes and canary scope authority;
6. campaign list filters/pagination;
7. selectable-event query/search/pagination;
8. explicit selection state across pages;
9. preparation reason/confirmation;
10. preview queue transaction/result;
11. detail DTO sections/progress semantics;
12. finding/failure presentation;
13. PubSub subscribe/reconnect/debounce;
14. exact execution form/hash/phrase;
15. plan age/drift/mode validation;
16. external authorization reference;
17. execution command transaction/idempotency;
18. pause/resume/cancel/revoke actions;
19. safe action matrix from A.1;
20. audit event types/metadata/transactionality;
21. UX rate limiter boundary;
22. privacy/static guards;
23. accessibility/mobile;
24. staged PRs;
25. tests-first sequence;
26. exact files create/modify/generated/forbidden;
27. migration/config changes;
28. verification commands/browser/load;
29. rollout/kill switch;
30. production canary/evidence;
31. Linear gate-ledger mapping;
32. risks/stop conditions.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
