# Audit and Operator Reason Contract

## Mutation audit events

Planning event types:

- `historical_backfill_campaign_prepared`;
- `historical_backfill_preview_requested`;
- `historical_backfill_execution_requested`;
- `historical_backfill_pause_requested`;
- `historical_backfill_resume_requested`;
- `historical_backfill_cancel_requested`;
- `historical_backfill_preview_revoked`;
- `historical_backfill_retry_requested` if supported.

A.1 system worker transitions are durable evidence and need not generate a user audit event for every page.

## Transactionality

For every admin mutation:

```text
A.1 state transition + audit + real job/outbox
```

must commit under one reviewed transaction or equivalent durable repair proof.

A web call must not write a separate audit before discovering that the state transition failed.

## Allowlisted metadata

- campaign id;
- source id;
- event ids or deterministic selection hash;
- selected event count;
- plan hash;
- campaign generation/revision;
- reason code;
- reason;
- authorization reference;
- prior/new state;
- requested action;
- result;
- feature mode.

Avoid copying:

- preview plan body;
- source findings details beyond codes/counts;
- order ids unless necessary;
- event names;
- source URLs;
- PII;
- raw request params.

## Actor context

- actor type=user;
- actor user id from session;
- actor role=admin;
- source=admin;
- request IP/user-agent hashed by existing logger where available.

## Reason validation

- required on prepare, execution, pause, resume, cancel/revoke;
- 10–500 characters;
- trim;
- no HTML/control characters;
- Unicode text accepted under bounded byte/character policy;
- not shown to non-admin surfaces.

## Audit UI

A.2 may show a bounded campaign-specific audit timeline with:

- action;
- actor display-safe identity;
- occurred at;
- state transition;
- reason/reference.

No raw metadata dump.
