# Test and Security Matrix

## Router/authentication

- unauthenticated cannot access any backfill route;
- non-admin cannot access;
- global admin can access;
- existing admin routes remain unchanged;
- portal/event-scoped users cannot access;
- CSP and CSRF protections preserved.

## Selection

- only selectable A.1 events render;
- private/draft/missing-boundary events excluded or blocked;
- forged event id rejected;
- mixed-source selection rejected;
- maximum selection enforced;
- pagination preserves explicit selection safely;
- no hidden select-all;
- event eligibility changed before submit is rechecked.

## Preview

- prepare/queue calls A.1 facade only;
- no Woo client reference in web modules;
- duplicate clicks create one campaign/job;
- existing active source campaign returns safe state;
- PubSub updates already-open page;
- reconnect reloads current state;
- plan expiry is shown;
- no Sales write from preview path.

## Execution

- exact hash required;
- changed/stale/expired hash rejected;
- confirmation phrase exact;
- reason/reference bounds;
- acknowledgement required;
- feature mode checked server-side;
- canary scope checked server-side;
- duplicate submit converges;
- transaction/audit/job failure does not show accepted success;
- no direct Oban insert from LiveView if command facade owns it.

## Actions

- pause only valid states;
- current step may finish wording;
- resume exact progress;
- resume blocked on drift/mode/eligibility;
- cancel/revoke reason codes;
- cancel leaves writes;
- no certificate after cancel;
- stale page action rejected after another admin transition;
- two admins racing converge.

## PubSub

- subscribe/unsubscribe lifecycle;
- after-commit hints;
- duplicate/missed/out-of-order;
- debounce storm;
- payload PII-free;
- message does not directly mutate truth.

## Privacy

- seeded customer/payment secrets absent;
- escaped source labels;
- no raw errors;
- no source credentials/URLs;
- no full audit metadata;
- no hash in URL/telemetry;
- safe failure references only.

## Accessibility/browser

- keyboard selection/dialogs;
- focus and error summary;
- mobile layout;
- state text;
- accessible progress/live region;
- no color-only state;
- exact confirmation copy control.

## Static boundaries

- no Woo client references under new web paths;
- no Sales resources/Repo queries in LiveView/components;
- no Oban Job direct control;
- no B.2 writes;
- no certificate mutation;
- no target activation.

## Load

- bounded event list/search;
- bounded campaign list;
- detail query count;
- PubSub storm coalescing;
- fifty concurrent read-only viewers if relevant;
- no N+1 per event/window/failure.
