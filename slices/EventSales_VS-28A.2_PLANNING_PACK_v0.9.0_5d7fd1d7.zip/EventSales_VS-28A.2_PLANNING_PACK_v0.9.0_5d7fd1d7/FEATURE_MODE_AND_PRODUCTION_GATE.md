# Feature Mode and Production Gate Contract

## Server modes

Candidate config:

```text
disabled
preview_only
canary_execution
enabled
```

## Disabled

- routes may be hidden/404 or show a disabled admin page;
- no mutation command available;
- existing evidence may remain accessible only if explicitly approved.

## Preview only

- list, selection, preview and read-only evidence;
- execution/pause/resume controls hidden or disabled;
- cancel/revoke preview may remain available.

Default initial production mode.

## Canary execution

Execution requires:

- exact A.1 plan;
- event/source canary scope;
- authorization reference;
- Pack 13 production execution supplement;
- server-side allowlist or equivalent reviewed canary guard.

The implementation plan must decide how the exact canary scope is represented. It must not trust form input.

## Enabled

Normal certified production operation, still subject to exact hash and all A.1 blockers.

## Feature checks

Check on:

- route/mount;
- every command;
- worker/certification where A.1 requires;
- resume after mode change.

Changing from enabled to preview-only:

- prevents new execution/resume;
- does not kill a current page;
- operators can still request safe pause/cancel if policy permits.

## External authorization reference

A reference is audit evidence, not system proof.

For the first production campaign, the external Pack 13 supplement remains the actual approval authority.

## No certificate override

No mode enables force certification.

A.1 law remains unchanged.
