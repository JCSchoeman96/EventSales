# Current Code Admin Workflow Map

| Current area | Current behaviour | VS-28A.2 decision |
|---|---|---|
| Router | `/admin/*` uses AdminOnly | add separate admin routes |
| AdminShell | Ops group has Sync/Catalog/Reconciliation | add Backfills item |
| SyncLive | event/date scoped, confirmation, paginated runs | preserve; do not relabel |
| SyncLive live updates | none | A.2 uses campaign PubSub |
| CatalogSyncLive | exact hash dry-run/apply, run PubSub | reuse interaction pattern |
| TickeraCatalogSync | atomic run + real job for dry-run | A.1 command must match strength |
| ManualActionRateLimiter | ETS, 30 seconds | UX only |
| HTTP manual limiter | excludes LiveView events | not durable mutation protection |
| Audit Logger | sanitized operational log | extend allowlisted events |
| Audit event types | closed resource allowlist | reviewed additions required |
| Admin session | server-loaded current user | preserve |
| Oban Web | admin tool | never use as backfill control surface |
| Historical backfill UI | none | new route/facade/DTO |
