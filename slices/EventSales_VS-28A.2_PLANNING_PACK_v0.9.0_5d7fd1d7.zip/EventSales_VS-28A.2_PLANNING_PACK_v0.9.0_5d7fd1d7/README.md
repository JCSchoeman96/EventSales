# EventSales VS-28A.2 Planning Pack

## Identity

- Slice: `VS-28A.2`
- Name: Historical Backfill Admin Preview and Control Workflow
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#130`
- Linear milestone: `M6 — Historical Completeness and Data Operations`
- Linear document: `VS-28A.2 — Pack 14 Gate Ledger and Planning Record`
- Created: `2026-07-17T20:36:49Z`

## Authority

This ZIP authorises repository reconnaissance and implementation planning only.

It does not authorise code, migrations, source calls, campaign creation, preview, execution approval, pause/resume/cancel, certification, merge, deployment or production mutation.

Implementation requires independent pack and plan approval, certified VS-28A.1, exact-current-main activation, refreshed A.1 interfaces and an explicit `APPROVE` verdict.

Production execution still requires Pack 13's exact campaign/hash execution supplement.

## Outcome

```text
global admin
→ explicit bounded public-event selection
→ A.1 prepare/queue preview
→ durable PII-free progress
→ exact plan-hash review
→ typed confirmation + reason + authorization reference
→ A.1 queue execution
→ cooperative pause/resume/cancel
→ seam, analytics and certificate status
```

## Web boundary

- Route family: `/admin/backfills`
- Existing `/admin/sync` remains event/date reconciliation.
- Existing `/admin/catalog-sync` remains catalog authority.
- No Woo, Sales-table, Oban-table or certificate mutation from LiveView.
- PubSub is a reload hint only.
- A.1 Postgres state and constraints are authority.
