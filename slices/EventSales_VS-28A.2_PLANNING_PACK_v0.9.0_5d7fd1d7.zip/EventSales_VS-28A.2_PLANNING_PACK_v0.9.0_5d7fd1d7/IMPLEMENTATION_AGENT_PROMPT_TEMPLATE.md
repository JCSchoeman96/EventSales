# Implementation Agent Prompt Template — VS-28A.2

**Do not use until an explicit activation supplement returns APPROVE.**

Activation fills:

- exact main SHA;
- certified A.1 interfaces and deployed/core-certification evidence;
- final routes/modules/DTOs;
- final feature modes/canary authority;
- final selection/preview flow;
- final exact execution confirmation;
- final pause/resume/cancel action matrix;
- final audit/privacy/PubSub contracts;
- exact staged scope/files/config/migrations/tests;
- rollout/stop conditions;
- mapped implementation gate.

Write tests first. Implement only the activated stage. Open a PR and stop before merge, deployment, production preview or execution.
