# Certified VS-28A.1 Interface Handoff Required

A.2 must consume the final A.1 implementation rather than invent resource queries.

## Required query families

- list selectable current public events;
- list campaign summaries with bounded filters/pagination;
- get one campaign detail DTO;
- get preview plan/findings;
- get safe failure summaries;
- get event coverage/certificate summaries;
- read feature/mode and safe action availability.

## Required command families

- prepare and queue preview;
- approve exact plan and queue execution;
- request pause;
- resume;
- request cancel or revoke preview;
- optional safe retry only when A.1 implements it.

## Required command input

Every mutating command includes server-resolved actor and bounded audit context.

Execution includes campaign id, exact plan hash, confirmation phrase, reason, optional authorization reference and request-context hashes through the existing audit boundary.

## Required result shape

Commands return a bounded current campaign summary and whether the request created a transition, coalesced with an accepted request or was rejected with a safe reason.

## Required PubSub

- campaign topic;
- bounded revisioned invalidation message;
- after-commit only;
- missed/duplicate/out-of-order safe.

## Stop condition

If A.1 lacks a sufficient command/read boundary, planning may propose a small A.1 handoff extension in a separate reviewed stage. Web code may not compensate by querying or mutating A.1 tables directly.
