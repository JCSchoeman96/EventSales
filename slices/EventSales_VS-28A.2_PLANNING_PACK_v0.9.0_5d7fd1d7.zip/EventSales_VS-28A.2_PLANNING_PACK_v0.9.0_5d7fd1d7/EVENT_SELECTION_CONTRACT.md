# Event Selection Contract

## Source and eligibility

The selection page consumes the A.1 selectable-event facade.

Each row includes only safe operational fields:

- event id/name;
- source id/name;
- public/live lifecycle;
- source-created timestamp;
- boundary provenance state;
- event start/end;
- mapping readiness;
- semantic readiness;
- existing active campaign conflict;
- safe blocker codes.

## Rules

- exactly one source per campaign;
- explicit event ids only;
- maximum count from A.1;
- no private/draft rows;
- no implicit inclusion of related/old events;
- no custom date lower bound in v1;
- no checkbox value trusted without server revalidation;
- no select-all across unseen pages.

## Search and pagination

- bounded text search over event name/slug/external id;
- stable ordering;
- server-side pagination;
- selected ids held in bounded socket state;
- selected rows reloaded before preparation;
- missing/ineligible row removes itself and surfaces a safe warning.

## Select-all semantics

V1 options:

- select only displayed eligible rows; or
- omit select-all entirely.

A global “all current events” action is excluded unless A.1 returns one immutable exact set and its size is within the bound.

## Preparation reason

Required before queueing preview:

- 10–500 characters;
- plain text;
- trimmed;
- no HTML;
- audited;
- not included in PubSub.

## Confirmation before preview

Preview is read-only relative to Sales, but it makes source calls and can be expensive.

The final submit dialog shows:

- source;
- selected event count/names;
- earliest boundary;
- estimated maximum campaign span;
- statement that preview performs bounded Woo reads but no Sales writes.

Typed phrase is not required for preview, but an explicit confirm button is.

## Concurrent selection change

After campaign creation, event selection is immutable.

Changing selection creates a new draft/campaign rather than editing the existing one.
