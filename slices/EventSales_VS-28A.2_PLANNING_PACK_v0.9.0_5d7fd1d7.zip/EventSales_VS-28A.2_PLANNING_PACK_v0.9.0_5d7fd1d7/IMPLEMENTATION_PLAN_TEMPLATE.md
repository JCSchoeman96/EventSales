# VS-28A.2 Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. A.1 certification and exact interfaces
## 4. Required A.1 handoff extensions
## 5. Staged delivery recommendation
## 6. Routes/modules/navigation
## 7. Authorization/session/feature mode
## 8. Campaign index filters/pagination
## 9. Selectable-event facade/search/pagination
## 10. Explicit selection state and validation
## 11. Preview preparation reason/confirmation
## 12. Preview queue command transaction
## 13. Campaign detail DTO and progress semantics
## 14. Findings/failures/completeness presentation
## 15. PubSub/reconnect/debounce
## 16. Exact execution form/hash/phrase
## 17. Plan age/drift/eligibility/mode validation
## 18. External authorization reference/canary authority
## 19. Execution transaction/idempotency
## 20. Pause/resume/cancel/revoke
## 21. Safe action matrix
## 22. Audit event types/metadata/transactionality
## 23. Rate limiter UX boundary
## 24. Privacy/static architecture guards
## 25. Accessibility/mobile
## 26. Feature/config/migration changes
## 27. Tests-first sequence
## 28. Exact files create/modify/generated/forbidden
## 29. Verification commands/browser/load
## 30. Rollout/kill switch/rollback
## 31. Production preview/execution canary
## 32. Evidence/certification
## 33. Linear gate-ledger mapping
## 34. Risks/stop conditions
## 35. Prohibited-actions statement
