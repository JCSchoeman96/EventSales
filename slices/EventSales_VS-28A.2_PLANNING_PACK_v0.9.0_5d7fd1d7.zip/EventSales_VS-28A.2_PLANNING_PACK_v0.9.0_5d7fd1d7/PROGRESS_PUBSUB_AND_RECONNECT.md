# Progress, PubSub and Reconnect Contract

## Durable truth

A.1 Postgres state is the only progress authority.

PubSub is an invalidation hint.

## Topic

Recommended:

```text
historical_backfill:<campaign_id>
```

Optional bounded index topic:

```text
historical_backfill:admin:index
```

The index topic may carry only a campaign id/revision hint and must not become a broadcast of every page detail.

## Message

Recommended shape:

```elixir
{:historical_backfill_changed, campaign_id, revision, occurred_at}
```

Allowed additions are low-cardinality phase/state only.

No:

- event names;
- Woo order ids;
- counts that the UI would trust without re-read;
- plan hash;
- reason/details;
- error text;
- certificate contents;
- PII.

## After-commit

Broadcast only after durable transition/progress commits.

## LiveView behaviour

- subscribe when connected;
- load durable DTO;
- on hint, schedule a short debounce;
- coalesce multiple hints;
- reload once;
- compare revision;
- update streams/assigns;
- reconcile subscription when campaign changes.

## Reconnect race

Recommended sequence:

1. initial durable read;
2. subscribe;
3. immediate second lightweight revision read or full reload;
4. continue from latest durable revision.

An equivalent proof is acceptable.

## Missed/duplicate/out-of-order

- missed message is repaired by manual refresh/reconnect and subsequent messages;
- duplicate message causes harmless reload/coalesce;
- older revision never regresses UI;
- message payload never directly applies a state transition.

## Polling fallback

No constant polling while PubSub works.

A slow bounded fallback refresh may be considered for long silent-running phases, but it must be justified and stop when disconnected.
