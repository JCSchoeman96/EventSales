# Operator Action Matrix

| Campaign state | Preview | Execute | Pause | Resume | Cancel/revoke | Refresh |
|---|---:|---:|---:|---:|---:|---:|
| draft | queue | no | no | no | yes | yes |
| preview_queued | no | no | request if A.1 supports | no | yes | yes |
| previewing | no | no | yes | no | yes | yes |
| preview_ready | no | exact-hash only | no | no | revoke plan | yes |
| execution_queued | no | no | yes | no | yes | yes |
| running | no | no | yes | no | yes | yes |
| pausing | no | no | no-op | no | yes | yes |
| paused | no | no | no | yes | yes | yes |
| cancelling | no | no | no | no | no-op | yes |
| cancelled | create new campaign | no | no | no | no | yes |
| blocked | new preview or reviewed A.1 recovery | no | maybe | maybe only if A.1 says | yes | yes |
| failed | create new or reviewed A.1 retry | no | no | only if certified action | no | yes |
| completed | no | no | no | no | no | yes |

A.1 `available_actions` is authoritative. This matrix is a planning default and must be refreshed at activation.
