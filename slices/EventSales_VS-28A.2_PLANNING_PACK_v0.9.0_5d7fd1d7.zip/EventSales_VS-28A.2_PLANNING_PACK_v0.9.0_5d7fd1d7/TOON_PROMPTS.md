# TOON Prompts — VS-28A.2

## Planning agent
Task: Design the admin workflow over the exact certified A.1 core.
Output: Complete implementation plan.
Boundary: No code or operations.

## Authorization reviewer
Task: Attack routes, actor sourcing, forged ids, feature modes and canary scope.
Output: Access findings.
Boundary: Global admin only.

## Workflow reviewer
Task: Attack selection, preview, hash confirmation, pause/resume/cancel and duplicate clicks.
Output: State/action matrix findings.
Boundary: A.1 is authority.

## LiveView reviewer
Task: Attack subscriptions, reconnect, debounce, stale socket state and multi-admin races.
Output: Convergence findings.
Boundary: PubSub is a hint.

## Privacy reviewer
Task: Attack DTOs, HTML, URLs, audit, logs and failure rendering.
Output: Leakage verdict.
Boundary: No source payload/PII.

## Accessibility reviewer
Task: Attack keyboard/dialog/progress/mobile/state wording.
Output: UX findings.
Boundary: No fake progress.

## Activation reviewer
Task: Refresh exact main, A.1 implementation/certification and production modes.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
