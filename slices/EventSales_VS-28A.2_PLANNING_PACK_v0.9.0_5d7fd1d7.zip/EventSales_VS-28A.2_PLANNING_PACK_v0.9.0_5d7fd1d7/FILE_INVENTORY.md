# Mandatory File Inventory — VS-28A.2

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Certified predecessor
- final VS-28A.1 pack;
- implementation plan;
- activation supplement;
- implementation report;
- exact-head PR review;
- deployed/core-certification evidence;
- production execution supplement template and final A.1 runbooks.

## Router/auth/session
- `lib/event_sales_web/router.ex`
- `lib/event_sales_web/plugs/load_current_user.ex`
- `lib/event_sales_web/plugs/admin_only.ex`
- admin session controller/session helpers/tests;
- browser/session/CSP configuration.

## Current admin UI patterns
- `lib/event_sales_web/components/admin_shell.ex`
- `lib/event_sales_web/live/admin/sync_live.ex`
- `test/event_sales_web/live/admin/sync_live_test.exs`
- `lib/event_sales_web/live/admin/catalog_sync_live.ex`
- CatalogSync LiveView tests;
- `lib/event_sales_web/live/admin/pagination.ex`
- `lib/event_sales_web/live/admin/session.ex`
- shared admin components/styles/assets.

## Current exact-hash facade pattern
- `lib/event_sales/ingestion/tickera_catalog_sync.ex`
- Catalog Sync run/resource/workers/PubSub/tests;
- atomic run/job queue implementation.

## Rate limiting
- `lib/event_sales_web/live/admin/manual_action_rate_limiter.ex`
- `lib/event_sales_web/plugs/rate_limit_manual_actions.ex`
- `lib/event_sales_web/rate_limiting/ets_sliding_window.ex`
- limiter tests/config.

## Audit
- `lib/event_sales/audit/logger.ex`
- `lib/event_sales/audit/metadata_sanitizer.ex`
- `lib/event_sales/audit/resources/audit_log.ex`
- audit migrations/snapshots/tests.

## A.1 final implementation
- domain/facade modules;
- campaign/event/window/failure resources;
- preview/execution workers;
- read DTOs;
- PubSub;
- feature/config modules;
- coverage/certificate resources;
- tests/migrations/indexes.

## Static/security
- web-to-Woo guards;
- domain-boundary tests;
- PII tests;
- architecture manifests;
- CI scripts.

## Config/deployment
- `config/config.exs`
- `config/runtime.exs`
- `config/test.exs`
- `railway.toml`
- release migration helpers;
- feature-flag precedent;
- final Oban queues/plugins.

## Browser tests
- LiveView test helpers;
- any Playwright/browser suite;
- accessibility/assets build commands.
