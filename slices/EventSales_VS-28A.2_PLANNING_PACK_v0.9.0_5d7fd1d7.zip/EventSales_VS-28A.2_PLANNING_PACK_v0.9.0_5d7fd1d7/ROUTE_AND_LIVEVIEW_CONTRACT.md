# Route and LiveView Contract

## Routes

Recommended:

```elixir
live "/backfills", Live.Admin.BackfillsLive.Index
live "/backfills/new", Live.Admin.BackfillsLive.New
live "/backfills/:id", Live.Admin.BackfillsLive.Show
```

Equivalent single-module `live_action` design is acceptable when tests and complexity remain clear.

All routes remain in the existing `[:browser, :admin_dashboard]` pipeline.

## Index state

URL-driven bounded filters:

- `state`;
- `source`;
- `from`;
- `to`;
- `page`.

Invalid values normalize or return a clear bounded error.

## New selection state

The selected event set may be LiveView form state until campaign preparation.

Rules:

- event ids come only from the current selectable DTO;
- hidden arbitrary ids are revalidated server-side;
- selection survives server-side pagination;
- selection count and source consistency shown;
- no unbounded query-string serialization.

## Show state

Route id is cast and passed to A.1 read facade with actor. The LiveView does not load resources directly.

## Subscriptions

- subscribe only when connected;
- subscribe to selected campaign id;
- unsubscribe/reconcile if route id changes;
- PubSub payload triggers reload;
- debounce bursts;
- reconnect loads before/after subscription to avoid missed transition ambiguity.

## Refresh

Button wording: `Refresh view`.

It reloads durable state only.

## Flash/error wording

Use bounded operator messages:

- Preview queued.
- Execution queued for the approved plan.
- Pause requested; the current bounded step may finish.
- Campaign paused.
- Resume queued.
- Cancellation requested.
- Plan expired; create a new preview.
- Plan changed; refresh preview.
- Action unavailable in the current state.

Do not render raw exception text.
