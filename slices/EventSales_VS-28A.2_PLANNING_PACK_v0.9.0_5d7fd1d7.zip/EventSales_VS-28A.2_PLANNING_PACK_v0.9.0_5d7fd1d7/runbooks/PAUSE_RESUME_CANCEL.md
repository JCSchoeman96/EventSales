# Pause, Resume and Cancel Runbook

## Pause

1. Confirm current state allows pause.
2. Enter reason.
3. Submit `Pause after current bounded step`.
4. Expect `pausing`, then `paused`.
5. Verify no new source page begins after safe boundary.
6. Existing writes remain.

## Resume

1. Verify paused state.
2. Verify same plan/generation and execution mode.
3. Review next durable step.
4. Enter reason.
5. Submit resume.
6. Verify exact next step, not restart.

## Cancel

1. Review state-specific cancellation wording.
2. Choose reason code/details.
3. Confirm existing writes remain and no certificate will issue.
4. Submit.
5. Expect cancelling/cancelled at safe boundary.
6. Verify remaining work stops.

## Preview revoke

For preview-ready campaigns, revoke the preview plan. No execution was started.

## Forbidden

- direct Oban cancel/retry;
- DB status edit;
- deletion of campaign/Sales evidence;
- force certificate;
- resume cancelled campaign.

## Evidence

Record timestamps, state transitions, progress before/after and audit ids.
