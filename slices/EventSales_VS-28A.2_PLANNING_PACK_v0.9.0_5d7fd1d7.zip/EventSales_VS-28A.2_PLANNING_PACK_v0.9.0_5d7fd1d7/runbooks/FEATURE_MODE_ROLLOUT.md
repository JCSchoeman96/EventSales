# Feature Mode Rollout Runbook

## Disabled

- deploy code/config;
- routes hidden or safe-disabled;
- verify admin/other routes unaffected.

## Preview-only

- enable for one admin;
- show Backfills nav;
- queue one approved preview;
- verify execution controls absent;
- verify no Sales writes.

## Canary execution

Only after exact supplement:

- server-side exact source/event/campaign/hash guard;
- authorization reference required;
- one admin;
- one campaign;
- pause/resume/cancel test;
- inspect evidence.

## Enabled

Only after workflow certification.

## Downgrade mode

From enabled/canary to preview-only:

- block new execution/resume;
- keep read access;
- permit safe pause/cancel if policy requires;
- current bounded page may finish.

## Kill switch evidence

Record config change, route/action behaviour and durable campaign state. Do not delete evidence.
