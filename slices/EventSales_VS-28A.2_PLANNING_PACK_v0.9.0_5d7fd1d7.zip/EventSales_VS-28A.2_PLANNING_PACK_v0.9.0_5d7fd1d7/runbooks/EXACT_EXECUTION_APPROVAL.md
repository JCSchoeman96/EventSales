# Exact Execution Approval Runbook

## Preconditions

- campaign preview-ready;
- exact plan hash displayed;
- plan unexpired;
- no blocker/drift;
- events still eligible;
- mode allows canary/enabled execution;
- Pack 13 exact campaign/hash supplement approved when production;
- authorization reference available.

## Operator review

Review:

- selected events and boundaries;
- frozen upper;
- window/page/identity totals;
- relevant/unresolved counts;
- source/mapping/semantic versions;
- catch-up/B.2 prerequisites;
- plan generated/expiry;
- plan hash.

## Submit

1. Open execution dialog.
2. Enter generated phrase.
3. Enter reason.
4. Enter authorization reference when required.
5. Check durable-write acknowledgement.
6. Check forward-only cancel acknowledgement.
7. Submit once.

## Server checks

A.1 reloads/locks and verifies all current facts.

Accepted result must include current queued/running summary.

## Lost response

Refresh/reconnect. Do not submit a different hash or create a new campaign until durable state is read.

Repeated identical request must converge.

## Evidence

- campaign/hash;
- actor/reason/reference;
- prior/new state;
- audit id;
- job/outbox id;
- feature mode;
- no raw form params or PII.
