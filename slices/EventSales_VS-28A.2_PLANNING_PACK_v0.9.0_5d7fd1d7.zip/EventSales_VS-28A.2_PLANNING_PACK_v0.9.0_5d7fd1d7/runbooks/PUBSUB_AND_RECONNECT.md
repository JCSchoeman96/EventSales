# PubSub and Reconnect Validation Runbook

## Live update

1. Open campaign page.
2. Confirm campaign topic subscription.
3. Advance campaign through a test worker.
4. Verify one or coalesced durable reload.
5. Verify updated state without browser refresh.

## Duplicate storm

Broadcast many revision hints.

Expected:

- debounce/coalesce;
- bounded reads;
- latest state rendered;
- no direct counter accumulation from messages.

## Missed message

Suppress one broadcast.

Expected:

- manual Refresh view or reconnect loads durable state;
- later message also repairs;
- no stale mutation accepted because command revalidates server truth.

## Reconnect race

1. Disconnect before a transition.
2. Commit transition.
3. Reconnect.
4. Verify latest revision/state.

## Route change

Navigate between campaign ids.

Verify old topic unsubscribed and new topic subscribed.

## Privacy

Inspect message payload. It contains no PII, plan hash, reason, error body or certificate data.
