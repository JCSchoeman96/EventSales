# Admin Preview Workflow Runbook

## Preconditions

- VS-28A.1 deployed and core-certified;
- feature mode allows preview;
- global admin authenticated;
- selected source healthy enough for preview;
- no conflicting active campaign;
- source-created boundaries available;
- no production execution authorisation implied.

## Steps

1. Open `/admin/backfills/new`.
2. Choose one source.
3. Search and explicitly select eligible public events.
4. Review boundary/readiness rows.
5. Enter preparation reason.
6. Confirm that preview performs bounded source reads and no Sales writes.
7. Submit.
8. A.2 calls A.1 prepare/queue preview command.
9. Redirect to campaign detail.
10. Subscribe to campaign PubSub.
11. Reload durable state on hints.
12. Review findings, windows, counts, plan hash and expiry.

## Expected safe errors

- event no longer eligible;
- boundary missing;
- mixed source;
- too many events;
- campaign already active;
- preview disabled;
- queue failed;
- source temporarily blocked.

## Evidence

- campaign id;
- selected event ids/count;
- reason;
- audit id;
- real job id where safe;
- no Sales count change during preview;
- DTO/HTML PII scan.
