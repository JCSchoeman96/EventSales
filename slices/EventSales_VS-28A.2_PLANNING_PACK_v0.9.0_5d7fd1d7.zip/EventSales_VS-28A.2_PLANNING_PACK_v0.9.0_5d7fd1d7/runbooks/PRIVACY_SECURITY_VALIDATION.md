# Privacy and Security Validation Runbook

## Seeded secrets

Use test fixtures with distinctive:

- customer name/email/phone;
- address;
- transaction id;
- order key;
- payment method;
- Woo credentials;
- raw source error body.

## Inspect

- selectable-event DTO;
- campaign summary/detail DTO;
- preview/failure DTO;
- HEEx HTML;
- flash messages;
- browser URL;
- PubSub;
- audit metadata;
- logs/telemetry;
- error pages.

Expected: seeded values absent.

## Authorization

- unauthenticated route;
- non-admin user;
- event-scoped portal user;
- inactive admin;
- forged campaign id;
- forged event selection;
- stale session.

Expected: denied through existing admin policy and command authorization.

## Static scans

No references from new web modules to:

- WooCommerceClient;
- Sales resources/Repo;
- Oban.Job control;
- B.2 write APIs;
- certificate issue APIs;
- target activation APIs.

## Escaping

Inject HTML/script-like event names and safe error text. Verify escaped output and CSP remains effective.
