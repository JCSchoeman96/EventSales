# Failure Matrix

| Failure | Safe UI result | Recovery |
|---|---|---|
| unauthenticated/non-admin | deny | authenticate/admin |
| feature disabled | safe disabled/404 | enable reviewed mode |
| event no longer public | selection rejected | refresh selection |
| missing source boundary | blocked row | source/A.1 repair |
| mixed source | form error | split campaign |
| max selection exceeded | form error | reduce selection |
| active source campaign | link current campaign | wait/cancel |
| preview queue fails | no accepted flash | retry after repair |
| PubSub missed | stale until reload | refresh/reconnect |
| plan expired | execute hidden/rejected | new preview |
| plan hash changed | rejected | refresh/new preview |
| blocker appears | execution unavailable | resolve/new preview |
| mode downgraded | execution/resume rejected | reviewed re-enable |
| duplicate submit | existing accepted state | reload |
| audit/job transaction fails | no transition | repair/retry |
| pause request race | current state returned | reload |
| resume after drift | rejected | new preview |
| cancel while step running | cancelling | wait safe boundary |
| raw A.1 error | generic safe message | inspect server logs |
| certificate pending | show seam/analytics state | wait/repair A.1/B.2 |
