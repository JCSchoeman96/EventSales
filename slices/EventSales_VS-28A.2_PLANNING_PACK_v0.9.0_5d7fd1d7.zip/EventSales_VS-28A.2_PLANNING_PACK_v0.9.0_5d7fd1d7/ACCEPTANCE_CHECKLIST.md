# VS-28A.2 Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-28A.1 implemented, reviewed, deployed and core-certified.
- [ ] Exact A.1 read/command/DTO/PubSub interfaces refreshed.
- [ ] Activation verdict APPROVE.

## Routes and authorization
- [ ] Separate `/admin/backfills` route family.
- [ ] Existing AdminOnly pipeline unchanged.
- [ ] Unauthenticated denied.
- [ ] Non-admin denied.
- [ ] Portal/event roles denied.
- [ ] Existing Sync/Catalog routes unchanged.
- [ ] AdminShell navigation feature-gated.

## Selection
- [ ] A.1 selectable-event facade only.
- [ ] Public/live only.
- [ ] Source-created boundary visible.
- [ ] Missing boundary blocks.
- [ ] One source per campaign.
- [ ] Explicit selection.
- [ ] No hidden select-all.
- [ ] Forged ids revalidated.
- [ ] Maximum count enforced.
- [ ] Server-side search/pagination.
- [ ] Reason required.
- [ ] No arbitrary dates.

## Preview
- [ ] Queue through A.1 command only.
- [ ] Atomic campaign + job/outbox.
- [ ] Duplicate request coalesces.
- [ ] No Sales write.
- [ ] Durable progress DTO.
- [ ] Safe findings and limits.
- [ ] Full plan hash and expiry.
- [ ] No PII/raw payload/order detail.
- [ ] Preview age visible.
- [ ] Expired plan cannot execute.

## Execution confirmation
- [ ] Exact full hash posted and server-compared.
- [ ] Campaign/generation reloaded and locked.
- [ ] Server-generated confirmation phrase.
- [ ] Reason bounds.
- [ ] Authorization reference policy.
- [ ] Irreversible-write acknowledgement.
- [ ] Cancellation-forward-only acknowledgement.
- [ ] Event eligibility rechecked.
- [ ] Drift/blocker/mode rechecked.
- [ ] State + audit + real job atomic.
- [ ] Duplicate submit returns accepted state.

## Pause/resume/cancel
- [ ] Available actions supplied by A.1.
- [ ] Pause cooperative.
- [ ] Current step may finish wording.
- [ ] Resume exact progress.
- [ ] Resume checks mode/drift/eligibility.
- [ ] Cancel preserves writes/evidence.
- [ ] No certificate after cancel.
- [ ] Preview revoke distinct.
- [ ] Reason code/details.
- [ ] Multi-admin race safe.
- [ ] No direct Oban job control.

## PubSub/reconnect
- [ ] Campaign topic.
- [ ] After-commit hints.
- [ ] Bounded message.
- [ ] No PII/hash/reason/error.
- [ ] Subscribe only when connected.
- [ ] Reconcile subscriptions.
- [ ] Debounce/coalesce.
- [ ] Durable reload on hint.
- [ ] Reconnect race closed.
- [ ] Missed/duplicate/out-of-order safe.

## Audit
- [ ] Reviewed event types.
- [ ] Transactional with mutations.
- [ ] Server actor.
- [ ] Reason/reference allowlist.
- [ ] Request context hashed.
- [ ] No raw params/PII.
- [ ] Bounded audit timeline.

## Feature modes
- [ ] Disabled.
- [ ] Preview-only.
- [ ] Canary execution.
- [ ] Enabled.
- [ ] Server-side only.
- [ ] Default preview-only or stricter.
- [ ] Canary scope cannot come from form.
- [ ] Mode checked on every command.
- [ ] Pack 13 execution supplement required.

## Privacy/static boundaries
- [ ] Dedicated PII-free DTOs.
- [ ] No raw Ash resources to HEEx.
- [ ] Escaped source strings.
- [ ] No Woo references in web modules.
- [ ] No Sales/Repo query in LiveView.
- [ ] No B.2 write.
- [ ] No certificate mutation.
- [ ] No target activation.
- [ ] No credentials/source URLs.
- [ ] Seeded secret regression test.

## UX/accessibility
- [ ] Text state labels.
- [ ] Keyboard checkboxes/dialogs.
- [ ] Focus/error management.
- [ ] Accessible live progress.
- [ ] Absolute timezone timestamps.
- [ ] Plan expiry clear.
- [ ] No fake progress.
- [ ] Mobile layout.
- [ ] High-impact action explanation.

## Performance
- [ ] Bounded campaign list.
- [ ] Bounded selectable events.
- [ ] No N+1.
- [ ] Detail query bounded.
- [ ] PubSub storm coalesced.
- [ ] Fifty read-only viewers where required.
- [ ] No polling storm.

## Rollout
- [ ] Deploy disabled.
- [ ] Route/auth proof.
- [ ] Preview-only canary.
- [ ] Exact preview review.
- [ ] Separate execution authorization.
- [ ] Canary execution.
- [ ] Pause/resume/cancel proof.
- [ ] Seam/analytics/certificate display.
- [ ] Rollback mode tested.
- [ ] No target armed.
- [ ] Production workflow certification.
