# Read DTO and Privacy Contract

## Web DTO boundary

A.2 receives dedicated PII-free DTOs from A.1.

Do not pass Ash resources containing raw metadata/payload fields directly to HEEx.

## Campaign summary DTO

Candidate fields:

- id;
- source id/name;
- selected event count;
- state/phase;
- requested-by display-safe admin identity or id;
- timestamps;
- plan hash prefix;
- preview generated/expires;
- safe counters;
- blocker/failure count;
- event certificate counts;
- available actions;
- durable revision.

## Campaign detail DTO

Candidate sections:

- immutable selection;
- event boundaries/provenance;
- frozen upper;
- source/mapping/semantic versions;
- window/progress summaries;
- preview plan hash;
- safe findings;
- action availability;
- event coverage/seam/analytics/certificate status;
- safe audit timeline where supported.

## Forbidden fields

- Woo payload;
- customer name/email/phone/address;
- order key;
- payment method/transaction id;
- credentials/source URL;
- raw error/stack;
- arbitrary metadata;
- full plan internal serialization;
- raw audit request context.

Woo order ids may be displayed only in a narrowly reviewed safe failure context and preferably only as a numeric source reference. Default UI should aggregate failures.

## Escaping

All source/event labels and safe error text are normal escaped text.

No `raw/1` rendering.

## Hash display

- full plan hash may be displayed/copyable on the detail page;
- hash is not a secret;
- no hash in telemetry label;
- list pages show prefix only;
- URLs do not include the hash.

## PII regression test

Seed unique PII/payment secrets in source fixtures and assert absence from:

- DTOs;
- socket-rendered HTML;
- PubSub;
- flash errors;
- audit metadata;
- logs/telemetry;
- browser URLs.
