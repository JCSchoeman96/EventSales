# Rate Limit and Idempotency Contract

## Existing controls

`ManualActionRateLimiter` is ETS-backed and node-local.

The browser HTTP limiter does not protect LiveView events.

Therefore neither is durable safety.

## UX throttle

A.2 may call:

```elixir
ManualActionRateLimiter.allow?(user_id, action)
```

with distinct action keys:

- prepare_preview;
- execute_backfill;
- pause_backfill;
- resume_backfill;
- cancel_backfill.

Suggested windows:

- preview: 30 seconds;
- execution: 60 seconds;
- pause/resume/cancel: 5–10 seconds.

These are UX choices, not security/uniqueness contracts.

## Durable convergence

A.1 must provide:

- one active campaign per source;
- exact state filters;
- exact plan hash/generation;
- atomic real job insertion/outbox;
- idempotent command semantics;
- unique work identities.

## Request identity

A.2 may generate a client/request nonce for observability, but A.1 correctness cannot depend on socket memory.

A repeated request after timeout/reconnect must return current accepted state.

## Button state

Disable buttons while the event is being handled, but test duplicate events and multiple nodes regardless.

## Brute-force relevance

This is an authenticated global-admin operation, not a public endpoint. Rate limiting mitigates mistakes and abuse but does not replace authorization or database constraints.
