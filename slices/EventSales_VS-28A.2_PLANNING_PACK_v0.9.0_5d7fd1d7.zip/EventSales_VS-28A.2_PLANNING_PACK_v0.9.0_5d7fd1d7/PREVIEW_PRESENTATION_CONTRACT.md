# Preview Presentation Contract

## Summary

Show:

- campaign id/state;
- source;
- selected events;
- earliest and per-event source-created boundaries;
- frozen upper;
- preview generation;
- plan generated/expiry time;
- full plan hash with copy control;
- plan hash prefix in summaries;
- source/feed/mapping/semantic versions.

## Progress

Before total leaf windows are stable, show counts without percentage:

- windows pending/scanning/subdivided/ready/failed;
- pages read;
- identities found;
- relevant orders/lines;
- unresolved findings;
- elapsed time;
- last durable update.

After A.1 supplies a stable denominator, an explicitly named ratio may be shown, such as `approved identity verification`, not generic completion.

## Findings

Group safe findings by severity and scope:

- blocker;
- warning;
- information.

Rows include:

- code;
- affected event/window;
- bounded count;
- operator guidance;
- whether execution is blocked.

No raw payload, customer/order detail or dynamic exception.

## Plan comparison

When a refreshed preview supersedes an earlier campaign, the UI may compare safe totals and hashes.

It must not imply that two different hashes are equivalent because counts match.

## Plan expiry

Show absolute expiry and remaining time.

After expiry:

- execution control disappears;
- page remains read-only evidence;
- action offered: `Create new preview`;
- old campaign is not silently refreshed in place.

## External execution authorization

The preview page may show:

- required/not required;
- authorization reference field requirement;
- canary/normal mode.

It does not claim an entered reference has been externally approved.
