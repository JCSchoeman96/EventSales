# Independent Reviewer Prompt — VS-28A.2

Review adversarially.

Block any design that:

- duplicates or reimplements A.1 campaign/window/certificate law;
- queries/mutates A.1 resources directly from LiveView;
- calls WooCommerce/WordPress from web code;
- directly inserts/cancels/retries Oban jobs from web;
- weakens AdminOnly or exposes portal/non-admin access;
- mixes `/admin/sync` or Catalog Sync semantics with backfill;
- permits arbitrary event ids, dates, private/draft events or implicit select-all;
- lets socket/hidden fields define source, feature mode or eligibility;
- executes without exact current full plan hash;
- lacks server-generated typed confirmation and reason;
- accepts expired/drifted/blocked plan;
- treats authorization reference as proof or secret;
- separates audit from accepted state/job transaction;
- relies on ETS/button disabling for uniqueness;
- applies PubSub payload as truth;
- shows fake progress percentage;
- exposes raw payload, PII, credentials, stack traces or unsafe source HTML;
- implies pause/cancel undoes writes;
- force-issues certificates or activates targets;
- lacks reconnect and multi-admin race tests;
- enables production execution by default;
- omits Pack 13 exact campaign/hash production supplement.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only.
