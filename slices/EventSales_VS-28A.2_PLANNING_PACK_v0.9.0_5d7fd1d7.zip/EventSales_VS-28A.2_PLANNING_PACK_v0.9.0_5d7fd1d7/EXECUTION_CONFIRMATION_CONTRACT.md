# Exact Execution Confirmation Contract

## Why stronger confirmation is required

Execution writes durable Sales truth across a historical period. Cancellation stops future work but does not undo completed writes.

## Required current server values

At form render and submission:

- campaign id;
- exact plan hash;
- event count;
- plan expiry;
- campaign revision/generation;
- current state;
- safe action availability.

Submission reloads/locks A.1 truth. Socket assigns are not authority.

## Form fields

- exact hidden/current plan hash;
- typed confirmation;
- reason;
- authorization reference when required;
- checkbox acknowledging irreversible durable writes;
- checkbox acknowledging cancellation is forward-only.

## Confirmation phrase

Recommended deterministic phrase:

```text
BACKFILL <N> EVENTS <HASH12>
```

Where:

- `N` is the current selected-event count;
- `HASH12` is uppercase first 12 hex characters.

For one event, use `1 EVENT` grammatically if desired, but the exact implementation must be deterministic and tested.

## Reason

- required;
- 10–500 characters;
- no HTML;
- stored in audit, not campaign PubSub;
- cannot be only the authorization reference.

## Authorization reference

- optional outside canary/production execution policy;
- required when server mode says so;
- 3–100 characters;
- allowlisted characters;
- example: `VS-28A.1-PROD-EXEC-001`;
- not treated as a secret or proof by itself.

## Server validation order

1. global-admin authorization;
2. rate-limit UX check optional;
3. load/lock campaign;
4. exact state/action availability;
5. plan hash equality;
6. plan not expired;
7. generation unchanged;
8. selected event eligibility;
9. blocker/drift checks;
10. feature mode/external reference requirement;
11. confirmation phrase;
12. acknowledgement flags;
13. reason/reference validation;
14. atomic transition/audit/job.

Errors remain bounded.

## Duplicate submit

If the first request committed and the response was lost, a repeated identical request returns the already queued/running campaign rather than creating duplicate work.

If inputs differ, return `action_already_accepted` or equivalent safe state.
