# Linear Gate Ledger — VS-28A.2

The Linear workspace free issue limit prevents the normal child-issue chain.

Mandatory gates:

1. PACK
2. PACK REVIEW
3. PLAN
4. PLAN REVIEW
5. ACTIVATE IMPLEMENTATION
6. IMPLEMENT
7. PR REVIEW
8. MERGE/DEPLOY
9. ADMIN WORKFLOW CANARY
10. PREVIEW PRODUCTION
11. PREVIEW REVIEW
12. APPROVE EXACT EXECUTION
13. VALIDATE WORKFLOW
14. CLOSE / UNLOCK VS-28B

Tracking:

- GitHub #130;
- immutable Pack 14 ZIP/SHA;
- Linear document `VS-28A.2 — Pack 14 Gate Ledger and Planning Record`;
- M6 milestone comments/status.

No document/comment state silently authorises a later gate.
