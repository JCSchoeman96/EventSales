# VS-28A.2 — Historical Backfill Admin Preview and Control Workflow

## 1. Identity

- Pack: `0014_VS-28A.2`
- Version: `0.9.0`
- Baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub: #130
- Milestone: M6
- Predecessor: VS-28A.1
- Successor: VS-28B
- Execution authority: none

## 2. Goal

Provide a global-admin-only, auditable and fail-closed workflow for selecting current public events, queueing A.1 preview, reviewing an exact PII-free plan, approving the exact current plan hash, controlling cooperative execution and inspecting completeness evidence.

## 3. Current repository truth

Current `main` already has:

- `/admin/*` protected by `LoadCurrentUser` and `AdminOnly`;
- separate admin routes for Sync, Catalog Sync, imports, mappings and reconciliation;
- `CatalogSyncLive` exact dry-run hash Apply and run-scoped PubSub patterns;
- `TickeraCatalogSync` atomic run plus real Oban job creation;
- `/admin/sync` event/date-scoped manual reconciliation with no PubSub;
- `ManualActionRateLimiter`, an ETS per-user/action UX throttle;
- HTTP route limiting that does not cover LiveView events;
- `AdminShell` Ops navigation;
- operational audit with metadata sanitization;
- no historical-backfill route, LiveView, selection DTO, confirmation workflow or progress topic.

At the planning baseline, A.1 is not implemented. Activation must replace every planning interface name with the certified A.1 implementation.

## 4. Authority chain

```text
LiveView event
→ A.2 global-admin workflow facade
→ certified A.1 command facade
→ A.1 DB state/constraints/transaction
→ real Oban job or cooperative state request
→ after-commit PubSub hint
→ LiveView reloads A.1 read facade
```

The browser never constructs Woo params, calls WooCommerce, inserts A.1 resources directly, manipulates Oban jobs, writes Sales/B.2 or issues certificates.

## 5. Routes

Recommended:

```text
/admin/backfills
/admin/backfills/new
/admin/backfills/:id
```

Campaign selection is not encoded as an unbounded URL list.

## 6. Index

`/admin/backfills` shows bounded campaign history:

- source;
- selected event count;
- state/phase;
- requested by;
- inserted/started/finished;
- plan hash prefix;
- preview age;
- progress counters;
- blocker/failure summary;
- certificate summary;
- next safe action.

Stable pagination/filtering may cover state, source, inserted date and campaign id. No order/customer search.

## 7. New selection workflow

`/admin/backfills/new`:

- loads only A.1-certified selectable public/live events;
- one source at a time;
- explicit checkboxes;
- no silent select-all;
- server-side bounded search/pagination;
- selected set remains explicit across pages;
- maximum count comes from A.1;
- displays source-created boundary and provenance;
- displays mapping/semantic readiness;
- blocks missing/invalid boundary;
- requires bounded preparation reason;
- queues preview through A.1 only.

The UI does not accept arbitrary start/end dates in v1.

## 8. Preview page

`/admin/backfills/:id` in preview phases shows:

- immutable selected events;
- source-created lower boundaries;
- frozen historical upper;
- mapping/semantic versions;
- feed/source snapshot;
- windows, pages and identity counts;
- relevant order/line estimates;
- unresolved findings;
- source/request limits;
- catch-up seam prerequisite;
- B.2 prerequisite;
- plan hash and generated/expiry times;
- safe state and last transition.

No raw payload, customer PII, payment details or full order rows.

## 9. Preview progress

Open pages subscribe to campaign-scoped PubSub only after connection.

Messages are small invalidation hints. On every message, the LiveView debounces/coalesces and reloads the campaign DTO from A.1. Mount, reconnect and `Refresh view` reload durable truth.

## 10. Exact execution approval

Execution is shown only when:

- state is preview-ready;
- plan hash exists;
- plan not expired;
- no blocking finding;
- selected events remain eligible;
- mapping/semantic snapshot remains current;
- A.1 execution feature mode permits it;
- external production authorization mode permits the campaign where required.

Required input:

- exact campaign id;
- exact full plan hash echoed by the form;
- typed confirmation derived from current plan;
- bounded human reason;
- bounded external authorization reference for production/canary;
- acknowledgement that execution writes durable Sales truth and cannot be undone by cancellation.

Recommended phrase:

```text
BACKFILL <event_count> EVENTS <first_12_hash_chars>
```

Server regenerates and compares it. Client-side validation is advisory only.

## 11. Queue execution transaction

A.2 calls one A.1 command that:

- reauthorizes global admin;
- locks/reloads campaign;
- verifies hash, age, state, eligibility and feature mode;
- records actor/reason/authorization reference;
- claims/queues execution atomically with a real Oban job or certified outbox;
- returns existing accepted state for duplicate submission;
- writes audit transactionally;
- broadcasts after commit.

No separate web-layer audit-then-enqueue sequence.

## 12. Pause

Available only when A.1 reports cooperative pause is valid.

- request pause, do not cancel the executing Oban job;
- current bounded page may finish;
- no new source page starts;
- state becomes pausing/paused;
- reason required;
- duplicate request idempotent;
- audit transactionally.

Pause does not revoke already persisted Sales truth.

## 13. Resume

Available only from paused state when the plan/generation remains valid, source/event eligibility still holds, feature mode permits execution and no A.1 blocker requires a refreshed preview.

Reason required. Resume queues the exact durable next step and never resets progress.

## 14. Cancel/revoke

- draft/preview queued/previewing: cooperative cancel;
- preview-ready: revoke the plan;
- execution queued/running/paused: cooperative cancel;
- completed/cancelled/failed: unavailable.

Cancellation stops future work at A.1 safe boundary, never deletes Sales writes, never issues a certificate, requires reason code/details and keeps immutable evidence. A refreshed run requires a new campaign.

## 15. Failures and blockers

Show only A.1 safe summaries:

- stage;
- low-cardinality reason;
- safe event/window/order-id reference;
- attempts;
- retryability;
- first/last seen;
- resolution state.

No stack trace or source body. A reviewed retry action may exist only when A.1 explicitly supports it.

## 16. Completeness

Show separate event-level states:

- historical ingestion coverage;
- catch-up seam;
- analytics readiness;
- metric completeness certificate;
- certificate generation/status/supersession.

The UI cannot force certification, edit `certified_from`, mark failures resolved or arm targets.

## 17. Audit

Required event families:

- campaign prepared;
- preview queued;
- execution queued;
- pause requested;
- resume requested;
- cancel/revoke requested;
- safe retry if supported;
- execution authorization reference recorded.

Every mutation requires current global admin, bounded reason and transactionally coupled audit through the workflow.

## 18. Rate limiting and duplicate clicks

- `ManualActionRateLimiter` may reduce accidental repeated clicks;
- buttons disable while a request is pending;
- neither is durable authority;
- A.1 state, unique constraints and exact-hash compare ensure convergence;
- reconnect/replay remains harmless.

## 19. Feature modes

Recommended server-side configuration:

- `disabled`;
- `preview_only`;
- `canary_execution`;
- `enabled`.

Default production after deployment: `preview_only` or stricter.

Feature mode is not accepted from form input.

## 20. PubSub

Campaign topic example:

```text
historical_backfill:<campaign_id>
```

Safe message:

```text
historical_backfill_changed(campaign_id, revision, occurred_at)
```

No customer/order fields, plan payload, reason details, raw error, certificate values or credentials.

## 21. Security and privacy

- global admin only;
- CSRF/session protections preserved;
- actor loaded from server session;
- campaign id cast and authorized before read;
- no source URL/credentials;
- no raw payload/customer PII;
- no unsafe HTML from source labels/errors;
- bounded reason/details;
- authorization reference is not a secret.

## 22. Accessibility and UX

- high-impact actions use dialogs and text explanations;
- state is not colour-only;
- confirmation phrase is copyable;
- focus moves to errors/dialog;
- progress has text and accessible live region;
- no fake percentage unless A.1 supplies a stable approved denominator and semantics;
- mobile tables collapse to cards;
- timestamps are absolute and timezone-labelled;
- plan expiry is explicit.

## 23. Non-goals

No A.1 engine changes unless a certified handoff is missing, no Woo calls, arbitrary date override, private/old event expansion, CSV/XLSX, corrections/exports, target activation, portal access, external notifications, generic job controller or direct Oban Web reuse.

## 24. Acceptance

An authenticated global admin can select one explicit eligible public event, queue exactly one preview, watch durable progress, inspect a PII-free exact plan, submit exact hash/confirmation/reason/reference, queue exactly one execution, pause/resume without losing progress, cancel without undoing writes or certifying, and inspect seam/analytics/certificate states.

Stale, changed, blocked, expired or unauthorised plans cannot execute. No web module calls Woo or writes backfill state directly.
