# Import Scope and Authority Contract

## Import kinds

Planning v1 kinds:

- `source_history_reconstruction`;
- `operational_missing_line_repair`;
- `correction_proposal_only`.

Unknown kinds fail closed.

## Source history reconstruction

Purpose: add source-shaped orders/lines proven absent from EventSales.

Rules:

- source system is explicit;
- Woo order/line ids required;
- source timestamps required;
- file must contain a complete certified representation for the selected import kind;
- no existing conflicting source record may be overwritten;
- final parser/G semantic contract applies;
- source version guard applies;
- later Woo webhook/catch-up remains authoritative.

## Missing-line repair

Allowed only when final writer contract proves safe merging into an existing order without changing source-owned header truth or deleting other children.

Default until proven: preview-only conflict.

## Correction-proposal-only

Rows describe intended changes or discrepancies but never apply directly. They create issue/correction proposals after validation.

## Event scope

Current import is event-scoped. V1 may retain explicit one-event batches initially.

Multi-event files require:

- one source;
- explicit event identity per row;
- deterministic mixed-order grouping;
- final G mapping;
- stronger review.

Default implementation order: one event first.

## Forbidden authority

Imports may not:

- move an existing source order to a different source;
- invent source timestamps;
- overwrite newer/equal conflicting Woo truth;
- mark a refund/ticket/fee semantic without G support;
- delete orders/items;
- change customer/payment fields;
- claim historical completeness;
- bypass A.1/F.1/F.2 recovery.
