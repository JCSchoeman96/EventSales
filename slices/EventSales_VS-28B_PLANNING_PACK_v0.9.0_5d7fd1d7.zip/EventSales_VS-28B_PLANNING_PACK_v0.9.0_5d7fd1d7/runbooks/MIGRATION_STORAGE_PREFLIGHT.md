# Migration and Storage Preflight

## Topology

Record:

- exact main/deployed SHA;
- PostgreSQL version/size;
- direct/session migration route;
- PgBouncer mode;
- Railway replicas;
- Oban queues/plugins;
- object-storage region/provider/encryption/versioning;
- egress/storage limits;
- backup/retention policy.

## Potential migrations

- import file/batch/group/row-effect/failure resources;
- upload storage metadata;
- export definition/artifact/progress resources;
- data issue/case/evidence/transition resources;
- correction/effect/event resources;
- audit event allowlist;
- feature/config fields;
- partial unique active-job indexes;
- keyset/export indexes;
- B.2 effect linkage.

## Rules

- additive;
- no file parsing/data backfill in migration;
- no destructive legacy row deletion;
- current CSV batches remain readable;
- concurrent/index lock strategy reviewed;
- generated Ash migrations/snapshots reviewed;
- FK deletion preserves audit/correction history;
- large JSON/map migration avoided;
- retention purge jobs bounded.

## Legacy import rows

Current rows may contain raw PII.

Before rollout:

1. count batches/rows and estimate JSON size;
2. inspect PII exposure with approved production access;
3. define read-only legacy adapter;
4. define purge/redaction migration as a separate reviewed operation;
5. never copy raw rows into new evidence automatically.

## Storage canary

- upload exact fixture;
- verify SHA and encryption;
- restart app/worker;
- read exact bytes;
- generate/download/purge artifact;
- verify signed URL expiry;
- verify no URL/credentials in logs.

## Stop

- no durable encrypted store;
- local temp disk required for authority;
- migration blocks production unacceptably;
- identity/index absent;
- retention cannot protect active evidence;
- legacy PII migration uncontrolled.
