# Failure Matrix

| Failure | Safe state/result | Recovery |
|---|---|---|
| unsupported file/schema | dry_run_blocked | corrected file/schema |
| file SHA mismatch | failed/block | re-upload exact bytes |
| storage unavailable | retryable | storage repair |
| ZIP bomb/traversal/macro/XXE | rejected | none; safe file required |
| row/column/sheet/cell limit | blocked | split/reduce file |
| malformed CSV/XLSX | blocked | correct file |
| timezone-less timestamp | invalid row/group | explicit offset |
| duplicate exact row | identical/collapsed | no mutation |
| conflicting duplicate | blocked issue | correction/re-file |
| mapping/semantic unknown | blocked issue | G/catalog resolution |
| existing source conflict | correction proposal | reviewed correction |
| local source newer/input stale | skip/no-op | none |
| parser worker crash | retry same chunk | bounded retry |
| plan expired/version drift | Apply rejected | new dry-run |
| Apply enqueue/audit failure | no accepted transition | repair/retry |
| writer success then progress failure | replay exact no-op | repair progress |
| later group permanent failure | partial_applied truth | issue/new plan |
| pause | stop after group | resume |
| cancel | future work stopped | new batch/plan |
| B.2 pending/failure | analytics_pending | rebuild/repair |
| completeness superseded | blocked downstream | recertify |
| export filter invalid/unbounded | rejected | narrow filter |
| export row/byte limit | explicit truncated artifact | narrow/split |
| artifact storage failure | failed, partial hidden | retry |
| download unauthorized/expired | deny | authenticate/regenerate |
| formula-like text | escaped output | policy evidence |
| recurrent resolved finding | explicit recurrence/reopen | operator review |
| correction target/source drift | proposal blocked | refresh preview |
| correction Apply partial transaction | rollback/no effect | repair |
| reversal conflict | blocked new proposal | refresh current state |
