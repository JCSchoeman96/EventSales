# Privacy and Security Validation

## Seeded sensitive fixtures

Use distinctive values for:

- customer name/email/phone/address;
- order key;
- transaction/payment method;
- storage credential/signed URL;
- formula payload;
- HTML/script label;
- raw exception/source body.

## Import checks

Inspect:

- file metadata;
- canonical row/group evidence;
- failures;
- plan snapshot;
- DTO/HTML;
- PubSub;
- audit;
- logs/telemetry;
- production evidence.

Seeded PII/payment values must be absent unless an explicitly approved encrypted source file is being inspected by authorised runtime code.

## XLSX malicious fixtures

- ZipSlip;
- excessive compression;
- excessive entries/uncompressed bytes;
- DTD/XXE;
- external relationship;
- macro package;
- formula cell;
- hidden row/sheet;
- malformed shared strings;
- duplicate entries;
- encrypted workbook.

All fail closed with safe reason codes.

## Export checks

- CSV formula neutralization;
- typed XLSX cells;
- no hidden data;
- manifest completeness;
- PII policy enforcement;
- signed URL not logged;
- authorization on every download;
- expired artifact denied.

## Correction checks

- arbitrary field/type rejected;
- before/effect snapshots PII-minimized;
- reason escaped/bounded;
- source drift rejected;
- no direct SQL/dynamic field;
- no bucket/certificate/target write.

## Static boundaries

New web code may not reference:

- WooCommerceClient;
- direct Sales write resources;
- Oban Job manipulation;
- B.2 write tables;
- certificate issue/update internals;
- target-state override internals.

## Evidence

Record only safe ids/hashes/counts and verdicts.
