# Correction Preview, Apply and Reversal Runbook

## Create proposal

From a case or exact target:

1. choose an allowlisted correction type;
2. load exact target/source version;
3. capture immutable before snapshot/hash;
4. enter reason/evidence;
5. calculate proposed after state;
6. calculate ticket/money/B.2/completeness/target effect;
7. classify risk tier;
8. generate exact approval hash and expiry.

No mutation occurs.

## Review

Verify:

- target identity;
- source version/fingerprint;
- before fields;
- requested patch/overlay;
- after fields;
- effect deltas;
- old/new bucket keys;
- certificate/target blocking;
- case result;
- reversal feasibility;
- proposer/approver separation for Tier 2.

## Apply

Require exact supplement, hash, typed confirmation and current admin.

The type-specific service:

- locks/rechecks target;
- rejects drift;
- applies one idempotent effect;
- writes immutable correction/effect/audit;
- queues B.2 rebuild;
- marks analytics pending;
- broadcasts after commit.

## Complete

Wait for:

- B.2 projection/buckets;
- completeness reassessment;
- VS-27D resolver;
- case transition.

Then mark completed.

## Reversal

1. create a new correction linked as reversal;
2. snapshot current corrected state;
3. preview return/replacement state and effects;
4. approve exact new hash;
5. apply through the same type-specific service;
6. retain original correction as reversed/superseded evidence.

Never delete or edit the original history.

## Stop

- arbitrary field/table input;
- source status/money direct overwrite;
- stale before snapshot;
- mutation without audit/effect;
- B.2 direct edit;
- force certificate/target;
- reversal by history deletion.
