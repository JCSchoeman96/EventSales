# Reconciliation Case Triage Runbook

## Open case

A detector/import/backfill/export integrity finding creates or links to a stable case.

Review:

- case kind/version;
- source/event scope;
- linked findings/evidence;
- severity/current state;
- first/last observed;
- source/mapping/semantic/completeness context;
- recommended next action.

## Triage actions

### Resolve without correction

Use only when evidence proves no durable Sales change is required.

Enter reason and evidence reference.

### Ignore

Use when the finding is accepted under a documented policy.

Require reason and optional expiry/review date.

### Reopen

Use when new evidence invalidates a prior disposition.

Require reason; previous history remains immutable.

### Propose correction

Create a separate correction proposal. The case does not mutate Sales.

## Recurring detector

When the same fingerprint reappears:

- update observation evidence;
- do not silently erase resolution;
- apply explicit reopen policy;
- show recurrence to operator.

## History

Every action creates:

- immutable disposition event;
- current-state projection update;
- operational audit.

These commit together.

## Privacy

Use safe ids, codes and bounded details. Do not place customer PII or raw source payload into case summaries/reasons.

## Close

A correction-linked case resolves only when:

- correction effect durable;
- B.2 complete;
- completeness/target impact resolved;
- final evidence attached.

Otherwise use `analytics_pending` or equivalent truthful state.
