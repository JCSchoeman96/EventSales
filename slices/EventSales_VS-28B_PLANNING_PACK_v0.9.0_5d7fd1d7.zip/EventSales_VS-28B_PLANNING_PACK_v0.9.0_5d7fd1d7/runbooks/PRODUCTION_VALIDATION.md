# VS-28B Production Validation Runbook

## Import dry-run canary

Use one bounded, non-sensitive approved fixture.

Record:

- deployed SHA and modes;
- storage/file SHA/type/size;
- source/event/import kind;
- schema/parser/policy versions;
- dispositions and effect preview;
- exact plan hash/expiry;
- zero Sales mutation;
- PII/security/load proof.

Repeat with equivalent CSV and XLSX. Canonical plan hashes must match.

## Exact import Apply canary

Under a separate supplement:

- apply only allowlisted missing/no-op groups;
- simulate duplicate click;
- interrupt/restart worker;
- verify exact durable progress and no duplicates;
- verify partial-state truth where tested;
- verify B.2/completeness/target convergence;
- verify audit/effect evidence.

## Export canary

Generate:

1. one B.2 decision CSV;
2. one bounded operational CSV;
3. one XLSX only after separate approval.

Verify:

- definition/filter hash/as_of;
- metric/currency/timezone/completeness;
- keyset consistency;
- row/byte counts;
- complete/truncated manifest;
- formula protection;
- artifact SHA/expiry/download audit.

## Case/disposition canary

- triage one finding;
- resolve or ignore with reason;
- reopen;
- verify every immutable transition and audit;
- verify Sales unchanged.

## Correction canary

Use one Tier 1 attribution/semantic fixture:

- exact before/after/effect preview;
- approval hash;
- duplicate Apply;
- B.2/completeness/target pending and recovery;
- issue resolution;
- create/apply reversal;
- verify original correction retained.

## Negative proof

- no arbitrary source money/status edit;
- no import conflict overwrite;
- no raw PII;
- no portal access;
- no direct Woo/web operation;
- no force certificate/target;
- no unbounded scans/files/artifacts.

## Verdict

- CERTIFIED — VS-27A MAY START
- CERTIFIED WITH ACCEPTED RISK
- REJECTED / BLOCKED
