# Exact Import Apply Runbook

## Preconditions

- certified VS-28B.2 deployment;
- exact production import supplement approves the batch/hash;
- feature mode `canary_apply` or `enabled`;
- plan unexpired and blocker-free;
- final source/mapping/semantic versions unchanged;
- source/catch-up/analytics queues healthy.

## Operator confirmation

Review the exact dry-run, then enter:

- server-generated typed phrase;
- human reason;
- authorization reference;
- acknowledgement that applied groups persist;
- acknowledgement that cancellation is forward-only.

## Queue

The command must atomically:

1. authorize/lock/revalidate;
2. claim exact plan;
3. create real job/outbox;
4. write audit;
5. transition state.

## Observe execution

Track:

- group cursor;
- groups/rows processed;
- created orders/lines;
- identical no-ops;
- stale/local-newer skips;
- issues/failures;
- current generation/job;
- last committed group.

No fake percentage beyond the approved stable denominator.

## Interruption test

For canary:

1. stop worker after one committed group;
2. restart;
3. confirm exact next group;
4. replay one completed group;
5. confirm no duplicate order/item/effect;
6. confirm progress repairs.

## Pause/cancel

- pause after group boundary;
- resume exact durable cursor;
- cancel stops future groups;
- already applied truth remains;
- batch records partial status/counts.

## Downstream

After final writer effects:

- B.2 dirty/rebuild requests complete;
- completeness/certificates reassess;
- target-period state becomes eligible or explicitly blocked;
- issues are linked;
- batch reaches completed only after required convergence.

## Stop

- any existing conflict mutates Sales;
- source version regresses;
- direct Sales insert;
- duplicate durable effect;
- progress advances after failed group;
- partial Apply hidden;
- PII appears in logs/evidence.
