# Import Dry-Run Review Runbook

## Start

1. Verify batch/file identity and feature mode.
2. Confirm file-security scan passed.
3. Queue or observe asynchronous validation.
4. Watch durable progress through PubSub hints and re-read.

## Review canonical scope

- import kind;
- source system;
- event scope;
- schema/parser/policy versions;
- timezone/currency;
- file SHA;
- generated/expiry times.

## Review dispositions

For every order/entity group verify aggregate counts for:

- create absent order;
- create absent line;
- identical no-op;
- stale/local-newer skip;
- conflict;
- incomplete/invalid;
- mapping/semantic unknown;
- correction proposal;
- unsupported entity.

Inspect bounded row/group samples only. Never download raw source data into GitHub/Linear evidence.

## Review effects

- expected order/line creates;
- ticket/revenue/tax/fee/refund deltas;
- old/new B.2 keys;
- completeness/certificate impact;
- VS-27D target impact;
- issues/corrections to be created.

## Exact plan

Record:

- full plan hash;
- plan generated/expires;
- canonical group count/hash;
- blocker/warning count;
- file/schema/mapping/semantic versions.

## Decision

- blockers > 0 → no Apply;
- unexpected conflicts → issue/correction workflow;
- changed source/mapping/semantic version → refresh dry-run;
- equivalent CSV/XLSX canary hashes differ → reject implementation;
- safe allowlisted plan → eligible for separate exact Apply supplement.

## No mutation proof

Confirm Sales, B.2 buckets and certificates were not changed by dry-run.
