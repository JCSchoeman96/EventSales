# Import Upload Preflight Runbook

## Purpose

Prove that an uploaded CSV/XLSX is bounded, immutable and safe enough to enter asynchronous dry-run validation.

## Preconditions

- certified VS-28B.1 deployment;
- import mode `dry_run_only` or stronger;
- authenticated global admin;
- durable encrypted upload store healthy;
- parser/schema versions enabled;
- no active conflicting batch under the final uniqueness contract.

## Browser preflight

The web layer checks only cheap bounded facts:

- one file;
- allowlisted extension;
- client-declared size within limit;
- selected source/event/import kind;
- reason present.

The web layer does not parse rows or trust MIME/extension as final type.

## Server preflight

1. stream exact upload bytes to the certified durable store;
2. calculate SHA-256 while writing;
3. detect actual file type/magic;
4. verify compressed size;
5. create immutable file record;
6. sanitize filename;
7. record actor/reason and retention policy;
8. atomically queue one scan/validation job;
9. return batch/file identity.

## CSV checks

- UTF-8/BOM policy;
- RFC4180 header parse;
- byte/line length limits;
- schema manifest/header version;
- no unsupported delimiter/encoding;
- no file-level PII outside selected schema.

## XLSX checks

- OOXML signature;
- extension/type match;
- ZIP entry/path/size/ratio limits;
- no macros, encryption, external links or prohibited relationships;
- required sheets only;
- no malicious XML/formula condition.

## Failure

A rejected file records:

- file id/SHA/size/type;
- safe reason code;
- actor/time;
- purge date.

Do not retain raw error bodies or file content in logs/evidence.

## Evidence

- exact file SHA/size/type;
- storage adapter/version;
- scan/schema/parser versions;
- queue/job id;
- retention date;
- safe verdict.
