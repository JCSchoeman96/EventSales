# Filtered Export Generation Runbook

## Prepare definition

Select:

- export kind/version;
- CSV/XLSX;
- source/events/ticket types;
- half-open time range and timestamp axis;
- status/semantic/mapping filters;
- currency;
- PII mode;
- row/byte bounds.

Capture one `as_of`, business timezone, metric/semantic versions and completeness/freshness evidence.

## Validate

- global admin;
- supported kind/format;
- range/event bounds;
- no mixed-currency aggregate;
- final B.2 reader available for decision export;
- operational reader/keyset certified;
- storage healthy;
- feature mode permits format.

## Queue

Create definition, audit and real generation job atomically.

## Generate

- read one bounded page;
- use B.2 for decision metrics;
- use keyset for operational rows;
- stream to partial encrypted artifact;
- neutralize CSV formulas;
- persist cursor/row/byte progress;
- enforce limits;
- finalize SHA/size/row count/manifest;
- hide partial artifact until ready.

## Review artifact manifest

- export id/kind/version;
- filters/filter hash;
- `as_of`;
- timezone/currency;
- metric/semantic versions;
- completeness/freshness;
- emitted rows/bytes;
- complete/truncated and reason;
- SHA-256;
- generated/expires.

## Download

Authorize current admin, audit the download and use a short-lived signed URL or bounded server stream.

## Failure/expiry

Failed partial artifacts are purged. Expired artifacts cannot download. Regeneration produces a new definition/artifact and `as_of`.
