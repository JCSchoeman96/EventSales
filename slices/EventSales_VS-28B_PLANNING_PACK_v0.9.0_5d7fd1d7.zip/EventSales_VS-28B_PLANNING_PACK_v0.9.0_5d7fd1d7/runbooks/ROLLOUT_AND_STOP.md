# Rollout and Stop Conditions

## Stage VS-28B.1 — Dry-run only

1. Deploy storage/file/schema/parser resources with import mode disabled.
2. Run migrations and storage canary.
3. Enable `dry_run_only`.
4. Validate bounded CSV fixtures.
5. Validate malicious XLSX fixtures.
6. Validate semantically equivalent CSV/XLSX plan hashes.
7. Confirm zero Sales mutation.

## Stage VS-28B.2 — Safe Apply

1. Deploy Apply/progress services with `dry_run_only`.
2. Validate exact-hash Apply in test/staging.
3. Enable `canary_apply` for one exact batch/hash.
4. Interrupt/resume.
5. Verify no duplicate effects and truthful partial state.
6. Verify B.2/completeness convergence.
7. Broaden only after evidence certification.

## Stage VS-28B.3 — Exports

1. Deploy definitions/artifacts disabled.
2. Enable bounded CSV.
3. Verify B.2 decision export parity.
4. Verify operational keyset consistency.
5. Test formula protection, truncation manifest and expiry.
6. Enable XLSX canary separately.

## Stage VS-28B.4 — Cases

1. Deploy immutable disposition history.
2. Preserve/seed legacy finding baseline.
3. Validate resolve/ignore/reopen history.
4. Confirm no Sales mutation.

## Stage VS-28B.5 — Corrections

1. Deploy in `issue_only`.
2. Validate preview/effect with no mutation.
3. Enable one Tier 1 canary under exact supplement.
4. Apply, rebuild and complete.
5. Create and apply reversal.
6. Keep Tier 2 disabled.

## Kill switches

- import upload;
- parser/validation;
- import Apply;
- export generation;
- XLSX input/output;
- issue transitions;
- correction proposal;
- correction Apply;
- B.2 convergence;
- PubSub.

## Rollback

Disable new commands/workers while retaining:

- files under retention;
- import plans/effects;
- artifacts/manifests;
- cases/history;
- corrections/effects/audit;
- Sales truth already applied.

Do not delete or restore production data automatically.

## Stop immediately

- import overwrites existing conflicting source truth;
- source timestamp/identity invented;
- G semantics bypassed;
- malicious XLSX accepted;
- raw PII leaks;
- full file/data set loaded unbounded;
- Apply/audit/job not atomic;
- duplicate/partial effects hidden;
- legacy raw SQL called decision-grade;
- truncation hidden;
- finding history erased;
- arbitrary correction editor;
- source money/status directly changed;
- B.2/certificate/target directly edited;
- production operation lacks exact supplement.
