# Import Dry-Run and Exact Plan Hash

## Lifecycle

Recommended states:

- uploaded;
- scan_queued;
- scanning;
- validation_queued;
- validating;
- dry_run_ready;
- dry_run_blocked;
- apply_queued;
- applying;
- applied;
- applied_analytics_pending;
- completed;
- failed;
- revoked;
- cancelled.

## Async validation

The web layer only stores the file and queues work.

Workers:

1. verify file identity and safety;
2. parse bounded chunks;
3. canonicalize rows;
4. validate group consistency;
5. batch-load existing identities/source versions;
6. classify dispositions;
7. persist safe row/group evidence;
8. calculate effects and plan hash;
9. mark ready/blocked.

No Sales mutation.

## Evidence rows

Do not persist the full original raw row by default.

Candidate evidence:

- row number/sheet;
- canonical identity;
- canonical fingerprint;
- disposition;
- safe reason codes;
- error field codes;
- expected action;
- target event/ticket references;
- source timestamp;
- PII classification;
- correction-case link.

Sensitive raw cells remain in encrypted source file and are not copied unless necessary.

## Plan snapshot

Contains:

- file SHA;
- schema/parser/policy versions;
- import kind;
- source/event scope;
- mapping/semantic versions;
- canonical group hashes;
- counts by disposition;
- expected creates/no-ops/skips/issues;
- monetary/ticket delta preview;
- affected B.2 keys;
- completeness impact;
- warnings/blockers;
- bounds;
- generated/expires.

## Plan hash

Hash deterministic canonical serialization.

Ordering follows project-wide deterministic UUID/binary and numeric source identity rules.

Do not hash presentation labels or raw file path.

## Expiry

Planning default: 24 hours for import plans.

Expiry or version/source/mapping/semantic drift requires a new dry-run.

## Exact approval

Apply command includes:

- batch id;
- exact full plan hash;
- server-generated typed confirmation;
- reason;
- authorization reference where required;
- acknowledgement of source-history rules.

The server reloads/locks and revalidates all facts.
