# Analytics, Completeness and Target Integration

## B.2 authority

VS-28B never edits bucket rows directly.

Import/correction services emit exact durable dirty/rebuild requests through final B.2 interfaces.

## Affected keys

Record:

- old event/ticket type/time/currency/semantic key;
- new event/ticket type/time/currency/semantic key;
- metric/semantic version;
- correction/import effect id.

Both old and new keys are dirtied when attribution/time/semantic/currency changes.

## Completeness

An effect inside a certified period may:

- set certificate state pending/superseded;
- create a completeness issue;
- block downstream decision claims;
- require a replacement certificate.

No UI may force the certificate active.

## VS-27D

While affected period is pending:

- performance evaluations are blocked or re-evaluated under D law;
- no false behind/met/missed notification;
- prior notification evidence remains immutable;
- recovery occurs after B.2/completeness convergence.

## Export interaction

An export generated before a correction remains an immutable artifact labelled with old `as_of` and versions.

It is not silently replaced.

## Completion evidence

Correction/import final completion requires:

- writer effect durable;
- B.2 projection/rebuild through effect revision;
- no failed dirty key;
- completeness state explicitly resolved;
- target resolver no longer pending where applicable.
