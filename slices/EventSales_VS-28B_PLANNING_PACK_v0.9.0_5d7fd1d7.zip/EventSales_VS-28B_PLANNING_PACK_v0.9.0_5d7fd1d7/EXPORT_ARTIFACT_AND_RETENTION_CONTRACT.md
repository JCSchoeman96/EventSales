# Export Artifact and Retention Contract

## Artifact store

Use the same certified durable encrypted blob adapter family as imports where practical.

Do not depend on Railway temporary disk for completed artifacts.

## Artifact record

Candidate fields:

- export definition id;
- storage key/version;
- content type;
- format;
- filename;
- byte size;
- SHA-256;
- row count;
- complete/truncated;
- generated at;
- expires at;
- downloaded count/last downloaded at;
- encryption/storage policy version;
- state.

## Generation

- one bounded worker step/page;
- keyset cursor durable;
- file writer supports streaming/multipart;
- no full dataset in memory;
- final SHA/size committed before ready;
- partial artifacts hidden and purged on failure.

## Download

- authenticated global admin;
- authorize on every request;
- short-lived signed download or server streaming;
- audit request and result;
- content-disposition sanitized;
- no storage credentials exposed.

## Retention

Planning default: 7 days.

Expired artifacts become unavailable and are purged through bounded maintenance.

Definition/audit metadata may remain longer.

## Regeneration

A regenerated export is a new definition/artifact with new `as_of` and hash. It never silently replaces an older audited artifact.
