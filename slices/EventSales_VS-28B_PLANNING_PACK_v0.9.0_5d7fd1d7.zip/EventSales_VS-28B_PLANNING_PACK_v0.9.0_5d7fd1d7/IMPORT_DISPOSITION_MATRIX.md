# Import Disposition Matrix

| Disposition | Meaning | V1 Apply |
|---|---|---:|
| `create_absent_order` | complete order and all imported lines absent | allow after full contract proof |
| `create_absent_line` | order exists, exact line absent | preview-only until merge contract certified |
| `identical_noop` | local durable record matches canonical input | no mutation, success |
| `local_source_newer` | local source version is newer | skip, issue only if unexpected |
| `input_stale` | imported source version older | skip |
| `existing_conflict` | same identity, differing source-owned fields | block; correction proposal |
| `header_inconsistent` | rows for order disagree | block |
| `semantic_unknown` | G cannot classify | block or issue, no Apply |
| `mapping_unknown` | no certified event/ticket identity | block or issue |
| `currency_conflict` | mixed/inconsistent currency | block |
| `incomplete_order` | required order representation missing | block |
| `duplicate_in_file` | repeated canonical identity | exact duplicate collapses; conflicting duplicate blocks |
| `invalid_row` | schema/type/range error | block group |
| `unsupported_entity` | fee/refund/coupon/etc. not implemented | block |
| `correction_proposal` | requested change to existing truth | no import Apply |
| `irrelevant` | outside exact approved scope | skip with evidence |

## Group authority

Disposition is decided at the order/entity group level where one row can affect header consistency.

A batch may be `dry_run_ready` only when every Apply-target group is allowlisted and blockers are zero.

## Partial batch Apply

Default v1: all-or-nothing plan eligibility, but execution commits bounded groups idempotently.

A future operator-selectable subset requires a new plan hash; the UI cannot simply uncheck rows after dry-run.
