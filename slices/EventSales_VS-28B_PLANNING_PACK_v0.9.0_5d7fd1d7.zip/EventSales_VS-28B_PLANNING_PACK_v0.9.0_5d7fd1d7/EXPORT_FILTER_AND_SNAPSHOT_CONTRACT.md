# Export Filter and Snapshot Contract

## Common filters

Only certified dimensions:

- source system;
- event ids;
- ticket type ids;
- order status;
- semantic kind;
- mapping status;
- currency;
- half-open time range;
- timestamp axis;
- reconciliation issue status/severity/type;
- correction status/type.

No coupon/UTM/campaign dimension until separately certified.

## Bounds

Planning defaults:

- custom range maximum: 366 days;
- selected events maximum: 25;
- synchronous CSV maximum: 10,000 rows and 25 MB;
- asynchronous artifact maximum: 100,000 rows and 100 MB;
- time-series point maximum: B.1/B.2 contract;
- export retention: 7 days.

Activation may tighten.

## `as_of`

Every export captures one UTC `as_of`.

Decision readers use that value through B.2.

Operational rows use a reviewed consistency contract:

- repeatable-read transaction while artifact is built; or
- stable source/version predicate plus keyset;
- exact method recorded in manifest.

## Keyset

Do not use offset pagination for mutable operational rows.

Candidate key:

```text
(updated_at_source, order_id, woo_line_item_id)
```

or a final immutable/source-version key proven by the plan.

## Truncation

Never rely only on an HTTP header.

The artifact manifest and file include:

- requested row limit;
- emitted row count;
- complete/truncated;
- next-page/cursor unsupported or available;
- reason.

## Currency

No mixed-currency sum.

Rows may include mixed currencies only when not aggregated and when currency is explicit.

## Filters hash

Hash canonical filter serialization plus kind/version/as_of/contract versions.

File name and audit reference the export id, not raw filters.
