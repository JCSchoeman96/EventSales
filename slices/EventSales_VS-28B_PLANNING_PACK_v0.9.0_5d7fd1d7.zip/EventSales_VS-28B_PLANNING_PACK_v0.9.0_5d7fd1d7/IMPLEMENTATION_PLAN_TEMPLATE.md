# VS-28B Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Final predecessor interfaces
## 4. Current-code gap verification
## 5. Child-slice/PR sequence
## 6. Import kinds and authority
## 7. Common schema/version
## 8. CSV adapter
## 9. XLSX dependency/security
## 10. Durable upload/artifact store
## 11. File bounds/retention
## 12. Import resources/state machine
## 13. Async parse/chunk workers
## 14. Canonical row/group evidence
## 15. PII minimisation/legacy fields
## 16. Batch existing-identity/source-version lookup
## 17. Disposition matrix
## 18. Plan snapshot/hash/expiry
## 19. Exact Apply command
## 20. Writer/G integration
## 21. Progress/generation/retry/pause/cancel
## 22. Partial Apply representation
## 23. B.2/completeness/target convergence
## 24. Export kinds/filters/bounds
## 25. Decision versus operational read authority
## 26. Keyset/snapshot consistency
## 27. Artifact generation/storage/download
## 28. CSV/XLSX output security
## 29. Generic issue/case resources
## 30. Finding disposition history/cutover
## 31. Correction type/risk matrix
## 32. Before/after/effect preview/hash
## 33. Tier 1 Apply and reversal
## 34. Source-update conflict policy
## 35. Audit event types/metadata/transactionality
## 36. Feature modes/production supplements
## 37. Migrations/indexes/storage costs
## 38. Tests-first sequence
## 39. Exact files/dependencies/config/migrations
## 40. Verification/security/load commands
## 41. Rollout/kill switches/rollback
## 42. Production canaries/evidence
## 43. Linear gate mapping
## 44. Risks/stop conditions
## 45. Prohibited-actions statement
