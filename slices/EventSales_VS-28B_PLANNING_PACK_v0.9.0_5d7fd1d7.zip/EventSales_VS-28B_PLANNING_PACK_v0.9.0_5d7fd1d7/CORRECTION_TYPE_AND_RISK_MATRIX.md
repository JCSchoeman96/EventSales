# Correction Type and Risk Matrix

| Type | Example | Tier | V1 direction |
|---|---|---:|---|
| issue_disposition | resolve/ignore/reopen finding | 0 | implement |
| event_attribution | move one line to certified event/ticket type | 1 | implement after final G |
| semantic_classification | classify one line under reviewed ProductSemantic | 1 | implement through G service |
| imported_missing_line | add one proven absent line | 1 | only if import merge contract certified |
| source_status_override | change Woo order status | 3 | forbidden |
| source_money_override | change source totals/tax/refund | 3 | forbidden as direct mutation |
| metric_adjustment_overlay | explicit reviewed adjustment | 2 | plan only unless B.1/B.2 supports |
| bulk_attribution | bounded set of lines | 2 | disabled initially |
| delete_order_or_line | destructive removal | 3 | forbidden |
| customer/payment correction | PII/payment fields | 3 | out of scope |
| completeness_override | move certified_from/force complete | 3 | forbidden |
| target-result override | force behind/met state | 3 | forbidden |

## Tier 0

One admin, reason, immutable transition.

## Tier 1

- exact preview/hash;
- typed confirmation;
- global admin;
- one target or tightly bounded group;
- atomic mutation + correction event + audit;
- B.2/completeness convergence.

## Tier 2

Requires:

- separate proposer and approver;
- bounded impact report;
- maximum target/row/delta thresholds;
- production supplement;
- disabled by default.

## Tier 3

Not implementable through VS-28B UI or import file.

A separate legislative/data-migration process would be required.
