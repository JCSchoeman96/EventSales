# Predecessor Contracts — VS-28B

## VS-28A.1

A.1 owns source historical recovery and completeness certificates. VS-28B may import missing approved data only when it does not pretend to be A.1 source recovery.

## VS-28A.2

A.2 owns the backfill operator workflow. VS-28B may reuse exact-hash, typed-confirmation, PubSub-reload and audit patterns, but must use separate resources and routes.

## VS-26F.1 / VS-26F.2

F owns current Woo source cursor, source version and freshness. An imported row must never overwrite a newer or conflicting source record.

## VS-26G

G owns semantic kind, entitlement, payment-plan, membership, add-on, fee, tax and refund treatment. VS-28B may not force all imported lines to `ticket/mapped`.

## VS-27B.1 / VS-27B.2

B owns metric names, sale windows, currency, contribution projection and buckets. Decision exports use B.2. Corrections dirty/rebuild B.2.

## VS-27C

Operational imports, exports, issue management and corrections remain global-admin-only in v1.

## VS-27D

A correction affecting a target period blocks/re-evaluates target truth until B.2 and completeness are ready.

## VS-27A

Compact webhook contract remains the next roadmap slice. VS-28B does not change webhook payloads.
