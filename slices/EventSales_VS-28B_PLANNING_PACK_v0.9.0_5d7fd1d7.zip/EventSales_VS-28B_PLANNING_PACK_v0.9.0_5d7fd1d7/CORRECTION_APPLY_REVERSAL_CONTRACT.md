# Correction Apply and Reversal Contract

## Apply command

One command must:

1. authorize current global admin;
2. load/lock proposal and targets;
3. verify exact approval hash and expiry;
4. recheck before snapshot/source versions;
5. verify risk/feature mode/approval requirements;
6. transition and queue/perform type-specific action atomically;
7. write immutable correction event and audit;
8. broadcast after commit.

## Type-specific service

Each correction type has one narrow service.

No dynamic table/field name or arbitrary patch map reaches Ash/SQL.

## Mutation versus overlay

Prefer overlay/superseding records for source-owned monetary/status truth.

A direct local row mutation is acceptable only when:

- field is local attribution/semantic state;
- source ingestion will not silently overwrite it;
- before/after history is immutable;
- final G/B contract approves the mutation.

## Idempotency

One Apply effect per correction id/hash.

Repeated jobs return current effect.

## Analytics

After mutation:

- durable correction effect records old/new bucket keys;
- B.2 dirty/rebuild request commits;
- correction state becomes `applied_analytics_pending`;
- completion waits for B.2 and completeness resolver.

## Reversal

Reversal creates a new correction:

- references original;
- before snapshot is current corrected state;
- proposed after state is original or a reviewed replacement;
- has its own effect preview/hash/reason/approval;
- applies through same safeguards.

Original correction remains `reversed`/superseded evidence, never deleted.

## Conflict after source update

If Woo/source changes after a correction:

- detect source-version drift;
- block stale correction;
- create/reopen issue;
- do not automatically reapply overlay unless policy explicitly supports it.

## Failure

A partial mutation without correction/audit/effect evidence is forbidden.

Use one transaction or durable outbox/repair proof.
