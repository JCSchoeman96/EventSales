# Import Schema and Format Contract

## Common canonical model

CSV and XLSX adapters emit the same canonical records.

Recommended document layers:

1. manifest;
2. order headers;
3. order lines;
4. optional coupons/fees/refunds only when final G supports them.

A flat one-row-per-line CSV may be supported as an adapter, but canonical validation separates header and line consistency.

## Version

Every import declares:

```text
import_schema_version
import_kind
source_system_key
business_timezone
currency
semantic_policy_version
```

Unsupported versions fail closed.

## Identity

Order:

```text
source_system + woo_order_id
```

Line:

```text
source_system + woo_order_id + woo_line_item_id
```

No filename, label, row number or event name is identity.

## Required source fields

At minimum:

- Woo order id;
- Woo line id;
- product id;
- optional variation id;
- source order status;
- source created timestamp;
- source modified timestamp;
- currency;
- quantity;
- reviewed monetary fields;
- event/ticket identity evidence required by final G.

## Timestamp policy

- strict ISO8601 with explicit offset or `Z`;
- no timezone-less timestamp interpreted silently;
- normalized to UTC;
- original offset may be retained in safe evidence if required.

## Monetary policy

Use Decimal.

Field names follow final G/B.1 net/tax/gross contract. Legacy ambiguous fields may be accepted only under an explicit legacy schema version and adapter.

## Consistency

All rows for one order must agree on source-owned header fields.

Conflicts block the order group.

## CSV

- UTF-8;
- RFC4180;
- BOM handling explicit;
- delimiter fixed by schema;
- duplicate/missing/unknown headers fail according to version policy;
- formulas rejected as input values when inappropriate.

## XLSX

- `.xlsx` only initially;
- required sheet names/version;
- typed cells normalized deterministically;
- formulas not evaluated;
- hidden sheets/rows do not silently add data;
- merged cells unsupported in data sheets;
- date serial interpretation explicit and tested.

## Equivalent-plan requirement

Semantically equivalent CSV and XLSX canonical records must produce identical canonical fingerprints and plan hash.
