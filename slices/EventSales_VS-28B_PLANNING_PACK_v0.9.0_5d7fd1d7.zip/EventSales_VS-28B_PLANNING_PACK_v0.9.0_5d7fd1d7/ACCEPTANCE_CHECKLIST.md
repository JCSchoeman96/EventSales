# VS-28B Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-28A.1/A.2 certified and closed.
- [ ] Final G/B.1/B.2/D interfaces refreshed.
- [ ] Storage and XLSX dependency reviewed.
- [ ] Activation verdict APPROVE.

## Upload and file identity
- [ ] Durable encrypted store.
- [ ] Exact byte SHA-256.
- [ ] Sanitized filename/content type.
- [ ] Magic/signature detection.
- [ ] Size/row/column/sheet/cell bounds.
- [ ] Retention/purge state.
- [ ] No temporary-disk authority.

## XLSX security
- [ ] `.xlsx` only.
- [ ] No macros/encryption/external links.
- [ ] ZipSlip/ZIP-bomb limits.
- [ ] DTD/XXE disabled.
- [ ] Formulas not evaluated.
- [ ] Hidden data policy.
- [ ] Date system tested.
- [ ] Malicious fixtures fail closed.

## Canonical schema
- [ ] Versioned import kind/schema.
- [ ] Strict source/timezone/currency.
- [ ] Explicit source timestamps.
- [ ] Final G monetary/semantic fields.
- [ ] Order-header consistency.
- [ ] CSV/XLSX equivalence.
- [ ] Unknown versions fail.

## Dry-run
- [ ] Async worker, no long LiveView parsing.
- [ ] Durable chunk progress.
- [ ] Batched identity lookups.
- [ ] No N+1.
- [ ] PII-minimised row evidence.
- [ ] Deterministic dispositions.
- [ ] Immutable plan snapshot.
- [ ] Exact plan hash/expiry.
- [ ] No Sales writes.
- [ ] Drift revalidation.

## Import Apply
- [ ] Exact hash and confirmation.
- [ ] Safe allowlist only.
- [ ] Existing conflict cannot overwrite.
- [ ] Final writer/G authority.
- [ ] Atomic claim/job/audit.
- [ ] Bounded group steps.
- [ ] Durable generation/cursor.
- [ ] Crash replay safe.
- [ ] Partial Apply represented truthfully.
- [ ] stale/noop is success.
- [ ] pause/cancel forward-only.
- [ ] B.2/completeness convergence.

## Exports
- [ ] Versioned export kinds.
- [ ] B.2 decision authority.
- [ ] Bounded operational readers.
- [ ] One as_of/timezone/currency/version.
- [ ] Canonical filter hash.
- [ ] Keyset, not offset.
- [ ] Row/byte/date/event bounds.
- [ ] Explicit complete/truncated metadata.
- [ ] Async artifact for large/XLSX.
- [ ] Artifact SHA/size/expiry.
- [ ] Auth on download.
- [ ] Audit request/generation/download.
- [ ] CSV formula injection protected.
- [ ] No mixed-currency sum.

## Reconciliation cases
- [ ] Existing findings preserved.
- [ ] Generic case/evidence links.
- [ ] Stable fingerprint.
- [ ] Bounded list/history.
- [ ] Immutable disposition events.
- [ ] Recurring finding reopen policy.
- [ ] Resolve/ignore does not mutate Sales.
- [ ] Actor/reason/audit.

## Corrections
- [ ] Type/version/risk allowlist.
- [ ] No arbitrary field editor.
- [ ] Exact target/source version.
- [ ] Before/after/effect snapshots/hashes.
- [ ] Metric/bucket/certificate/target impact.
- [ ] Exact approval/expiry.
- [ ] Tier requirements.
- [ ] Atomic type-specific Apply/audit/effect.
- [ ] Source update drift blocks.
- [ ] Analytics pending state.
- [ ] Reversal is superseding correction.
- [ ] Original history retained.

## Privacy/security
- [ ] Default no-PII schema/export.
- [ ] Legacy PII adapter decision.
- [ ] No raw rows in logs/PubSub/evidence.
- [ ] Encrypted storage.
- [ ] Signed URLs not logged.
- [ ] Escaped UI content.
- [ ] Static no-web-Woo/Sales-write guards.
- [ ] Formula/CSV injection tests.

## Performance
- [ ] 25k-row dry-run bounded.
- [ ] 10k-sales representative canary.
- [ ] Worker wall-time bounded.
- [ ] Artifact streaming.
- [ ] No full-memory dataset.
- [ ] Indexed queries/keysets.
- [ ] Queue concurrency reviewed.
- [ ] Storage/DB growth measured.

## Production
- [ ] Dry-run-only deployment.
- [ ] CSV canary.
- [ ] XLSX equivalent canary.
- [ ] Exact import Apply supplement.
- [ ] Export artifact canary.
- [ ] Issue transition canary.
- [ ] Tier 1 correction supplement.
- [ ] Reversal canary.
- [ ] B.2/completeness/target proof.
- [ ] Kill switches tested.
- [ ] No VS-27A work included.
