# VS-28B Production Correction Supplement

## Identity

- Certified implementation PR/head/deployed SHA:
- Correction id:
- Correction type/version:
- Risk tier:
- Linked issue/case:
- Source/event/order/item scope:
- Source version/fingerprint:
- Exact before hash:
- Exact proposed-after hash:
- Exact effect hash:
- Exact approval hash:
- Proposal generated/expires:
- Admin proposer:
- Required approver:
- Authorization reference:
- Human reason/evidence:

## Impact preview

- Field/overlay changes:
- Ticket quantity delta:
- Ticket revenue delta:
- Ancillary/fee/tax/refund delta:
- Old/new event/ticket type:
- Affected B.2 keys:
- Completeness certificate impact:
- VS-27D target-period impact:
- Source-update conflict check:
- Linked issue final state:
- Reversal plan:

## Execution controls

- Typed confirmation:
- Feature/canary mode:
- Queue/database health:
- Atomic mutation/audit/effect proof:
- B.2 rebuild/readiness plan:
- Rollback/kill switch:
- Evidence destination:
- Stop conditions:

Verdict:

- APPROVE PREVIEW ONLY
- APPROVE EXACT CORRECTION APPLY
- REFRESH PREVIEW
- BLOCKED

Approval applies only to the exact correction and approval hash.
