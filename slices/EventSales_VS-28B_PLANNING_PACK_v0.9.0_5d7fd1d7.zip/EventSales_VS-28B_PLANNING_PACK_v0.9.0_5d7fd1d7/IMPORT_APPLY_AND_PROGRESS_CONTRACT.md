# Import Apply and Progress Contract

## Command transaction

One reviewed command must atomically:

- lock and claim the exact ready plan;
- record actor/reason/hash;
- create the real Apply job or durable outbox;
- write the audit event;
- transition batch state.

No job-before-audit sequence.

## Worker shape

One worker step handles a bounded group/page.

Planning defaults:

- maximum 100 order groups per job step;
- maximum 1,000 rows per step;
- wall-time target under 30 seconds;
- queue concurrency one initially.

## Durable progress

Candidate fields:

- generation;
- next group key/cursor;
- processed groups/rows;
- created orders/lines;
- no-ops/skips/issues/failures;
- last committed group;
- current job/attempt;
- started/paused/completed times.

## Writer authority

Use final certified parser/normalizer and `OrderUpserter`/type-specific services.

No direct Sales insert/update from import worker.

No forced `ticket/mapped` semantics.

## Restart safety

For each group:

1. lock batch/generation;
2. load canonical group/effect;
3. recheck disposition and source version;
4. call writer transactionally;
5. persist effect/result;
6. advance cursor after success/no-op;
7. enqueue next step after commit.

A crash after writer success but before progress must replay to an exact no-op and repair progress.

## Partial completion

Previously applied groups remain durable if a later group fails.

The batch state and plan evidence must say `partially_applied` or equivalent, with exact counts. It must not mark the entire file failed as though no effects occurred.

## Pause/cancel

Cooperative pause/cancel may be supported only at group boundaries.

Cancel stops future groups and never rolls back applied truth.

## Completion

Apply completion triggers:

- affected B.2 dirty/rebuild requests;
- issue creation for conflicts/skips requiring review;
- completeness reassessment;
- PubSub invalidation;
- final audit/evidence.
