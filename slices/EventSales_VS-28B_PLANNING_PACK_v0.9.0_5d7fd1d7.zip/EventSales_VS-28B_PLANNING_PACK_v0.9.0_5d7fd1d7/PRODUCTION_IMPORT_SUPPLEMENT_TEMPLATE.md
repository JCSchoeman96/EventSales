# VS-28B Production Import Supplement

## Identity

- Certified implementation PR/head/deployed SHA:
- Activated import mode:
- Import schema/parser/policy versions:
- Storage adapter/policy:
- Source system:
- Event scope:
- Import kind:
- File id:
- Sanitized filename:
- Exact file SHA-256:
- File type/size:
- Batch id:
- Exact dry-run plan hash:
- Plan generated/expires:
- Authorization reference:
- Admin actor:
- Human reason:

## Dry-run evidence

- Canonical order/line groups:
- Disposition counts:
- Expected creates:
- Exact no-ops:
- Stale/local-newer skips:
- Conflicts/issues:
- Blockers/warnings:
- Ticket/revenue/tax/refund effect preview:
- Affected B.2 keys:
- Completeness/target impact:
- PII classification:
- File-security verdict:
- Runtime/load evidence:

## Apply controls

- Exact confirmation phrase:
- Feature/canary scope:
- Queue/source health:
- Chunk/group limits:
- Pause/cancel plan:
- Rollback/kill switch:
- Evidence destination:
- Stop conditions:

Verdict:

- APPROVE DRY-RUN ONLY
- APPROVE EXACT IMPORT APPLY
- REFRESH DRY-RUN
- BLOCKED

Approval applies only to the exact file, batch and plan hash.
