# Upload Storage and Retention Contract

## Current gap

LiveView currently consumes a temporary uploaded CSV and validates it in the web process. Railway local disk and temporary upload paths are not durable campaign evidence.

## Required lifecycle

```text
browser upload
→ strict preflight
→ durable upload store
→ file SHA-256 and metadata
→ async parser job
→ canonical row evidence
→ retention/purge lifecycle
```

## Durable store

Activation must choose and certify one production adapter:

- encrypted S3-compatible object storage;
- another managed encrypted blob store;
- bounded Postgres byte storage only if size, backup and bloat costs are explicitly accepted.

Local filesystem is dev/test only unless Railway persistence and single-node constraints are proven.

## File record

Candidate fields:

- id;
- original filename sanitized;
- content type;
- detected type;
- byte size;
- SHA-256;
- storage key;
- encryption/storage policy version;
- uploaded by;
- uploaded at;
- retention state;
- expires/purged at;
- scan status;
- safe error.

No secret signed URL persists in normal logs/evidence.

## Bounds

Planning defaults:

- maximum compressed file: 10 MB;
- maximum canonical rows: 25,000;
- maximum columns per table: 60;
- maximum cell text: 10,000 characters;
- one active parse per file;
- one active Apply per batch.

Activation may tighten but not broaden without review.

## Retention

Recommended:

- rejected/unparseable source file: purge within 7 days;
- dry-run source file: purge 30 days after expiry/cancel;
- applied source file: encrypted retention 90 days unless legal policy differs;
- canonical plan/effect evidence: durable according to audit policy;
- PII-bearing raw rows: purge as soon as no longer required.

## Integrity

- SHA calculated from exact uploaded bytes before parsing;
- file cannot be replaced under same record;
- parser reads by immutable storage key/version;
- Apply rechecks file and plan identity;
- purge never removes evidence required by an active plan/correction.
