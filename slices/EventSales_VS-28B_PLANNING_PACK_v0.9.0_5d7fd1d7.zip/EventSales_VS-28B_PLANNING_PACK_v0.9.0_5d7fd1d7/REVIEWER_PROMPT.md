# Independent Reviewer Prompt — VS-28B

Review adversarially against current repository code and final predecessor contracts.

Block any design that:

- treats a spreadsheet as authoritative over existing Woo truth;
- lets import update a conflicting existing order/item;
- forces ticket/mapped semantics outside G;
- uses current synchronous LiveView validation for large files;
- stores raw PII rows without explicit encrypted retention;
- lacks file SHA, schema/policy version, exact plan hash or expiry;
- lets CSV and XLSX equivalent data produce different plans;
- permits XLSX macros, formulas, external links, XXE, ZipSlip or unbounded decompression;
- performs per-row N+1 duplicate/source lookups;
- loads all rows/groups/artifacts in memory;
- has non-atomic Apply claim/job/audit;
- cannot resume after writer success/progress failure;
- hides partial Apply;
- uses stale_noop as corruption/failure;
- uses legacy raw SQL for decision export metrics;
- uses offset pagination for mutable export rows;
- hides truncation only in a response header;
- lacks CSV formula-injection protection;
- assembles large reconciliation export fully in memory;
- overwrites finding disposition history;
- resolving/ignoring a finding mutates Sales;
- generalizes the order 113834 fix into arbitrary editing;
- lacks exact before/after/effect preview and hash;
- directly edits source-owned status/money;
- reverses by deleting history;
- bypasses B.2/completeness/target blocking;
- exposes operations to portal roles;
- has no staged implementation;
- enables production Apply/correction by default.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only.
