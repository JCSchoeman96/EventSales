# Export Product Contract

## Export families

Planning v1:

1. `decision_summary`;
2. `decision_time_series`;
3. `event_ticket_type_performance`;
4. `operational_order_lines`;
5. `reconciliation_findings`;
6. `data_issues`;
7. `correction_audit`.

Unknown export kinds fail closed.

## Formats

- CSV required;
- XLSX may be enabled after the same dependency/security/storage certification used for imports;
- no PDF export in this slice.

## Authorization

Global admin only in v1.

VS-27C portal users receive no operational export access.

## Decision exports

Use final B.2 read facade and B.1 metric/window semantics.

They include:

- metric and semantic versions;
- currency;
- business timezone;
- `as_of`;
- window/comparison;
- completeness/freshness;
- resolution;
- filters.

No legacy raw SQL summary is authoritative.

## Operational exports

Use dedicated bounded readers over normalized durable data.

They never become a metric authority.

PII-free by default.

## Definition resource

Candidate fields:

- kind/version;
- format;
- filter snapshot;
- filter hash;
- actor;
- PII policy;
- `as_of`;
- metric/semantic versions;
- currency/timezone;
- completeness/freshness snapshot;
- row/byte limits;
- state;
- artifact id;
- expiry;
- safe error.

## Lifecycle

- draft;
- queued;
- generating;
- ready;
- expired;
- failed;
- cancelled.

## Small synchronous exports

May remain only when:

- rows/bytes are predictably small;
- snapshot semantics are acceptable;
- generation is bounded;
- no XLSX;
- audit/download behaviour is exact.

Default direction for filtered/raw/XLSX exports: asynchronous artifact.
