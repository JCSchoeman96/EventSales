# Finding Disposition History Contract

## Current gap

Current reconciliation findings store one mutable status, resolution reason and resolved timestamp. Reopen clears prior reason/timestamp, losing operator history.

## Required immutable event

Candidate `FindingDispositionEvent`:

- finding/case id;
- prior state;
- new state;
- action;
- actor user id/role;
- reason code;
- reason;
- evidence reference;
- occurred at;
- request context hashes;
- transition hash.

## Actions

- resolve;
- ignore;
- reopen;
- triage;
- assign;
- supersede;
- link correction;
- correction applied;
- analytics completed.

## Current-state projection

Finding/case may retain current state for indexed reads, but it is derived/updated transactionally with the immutable event.

## Transaction

```text
state transition + disposition event + operational audit
```

commit together.

## Reasons

- required for resolve/ignore/reopen;
- 10–500 characters;
- optional structured reason code;
- no raw PII;
- immutable after commit.

## Existing findings

Migration strategy must preserve current status/reason as a synthetic baseline event with explicit `legacy_import` provenance, or document why a non-destructive cutover starts history from deployment.

No current reason may be silently discarded.
