# Correction Proposal Contract

## Purpose

A correction proposal describes one reviewed change to derived/local truth while preserving source history.

## Candidate resource

`DataCorrection`

Fields/concepts:

- id;
- correction type/version;
- risk tier;
- source/event/order/item targets;
- source version/fingerprint;
- linked issue/case;
- state;
- before snapshot/hash;
- requested patch/overlay;
- after preview/hash;
- effect preview/hash;
- policy/semantic/metric versions;
- reason/evidence;
- proposed by/at;
- approved by/at;
- applied by/job/at;
- supersedes/reverses;
- failure;
- analytics/completeness state.

## States

- draft;
- preview_ready;
- blocked;
- awaiting_approval;
- approved;
- apply_queued;
- applying;
- applied_analytics_pending;
- completed;
- rejected;
- failed;
- superseded;
- reversed.

## Before snapshot

Capture only allowlisted fields needed to prove exact current state.

Include source version and target row revision.

No customer/payment PII unless the correction type explicitly requires it and policy allows it.

## Effect preview

At minimum:

- target field changes;
- ticket quantity delta;
- recognized ticket revenue delta;
- ancillary/fee/tax/refund delta where supported;
- old/new event/ticket type;
- affected hour/day buckets;
- affected certificates/targets;
- issue/case result.

## Exact hash

Approval hash covers:

- correction id/type/version;
- exact targets;
- before hash;
- patch/overlay;
- after/effect hashes;
- policy versions;
- risk tier;
- reason/evidence;
- expiry.

## Expiry/drift

Any target/source/version change invalidates the proposal and requires a new preview.

## No arbitrary editor

Correction types define their exact accepted fields and validation. Unknown fields/types are rejected.
