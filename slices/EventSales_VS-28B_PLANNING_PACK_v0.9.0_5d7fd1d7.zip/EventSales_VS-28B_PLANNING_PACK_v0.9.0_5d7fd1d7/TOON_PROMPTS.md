# TOON Prompts — VS-28B

## Planning agent
Task: Design staged data operations from exact current code.
Output: Complete implementation plan.
Boundary: No code or data operations.

## Import reviewer
Task: Attack file authority, canonical schema, dispositions, restart safety and source conflicts.
Output: Import findings.
Boundary: No silent overwrite.

## XLSX security reviewer
Task: Attack archive/XML/formula/external-link/parser limits.
Output: Security verdict.
Boundary: Malicious files fail closed.

## Export reviewer
Task: Attack metric authority, filters, snapshot consistency, pagination, truncation and artifacts.
Output: Export findings.
Boundary: B.2 owns decision metrics.

## Reconciliation reviewer
Task: Attack case identity, recurring findings and immutable disposition history.
Output: Case findings.
Boundary: Disposition is not correction.

## Correction reviewer
Task: Attack type allowlist, before/after, approval, source drift, reversal and downstream convergence.
Output: Correction verdict.
Boundary: No arbitrary editor.

## Privacy reviewer
Task: Attack files, row evidence, DTOs, exports, logs, audit, PubSub and retention.
Output: Leakage verdict.

## Activation reviewer
Task: Refresh exact main, predecessor interfaces, storage/dependency and deployment topology.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
