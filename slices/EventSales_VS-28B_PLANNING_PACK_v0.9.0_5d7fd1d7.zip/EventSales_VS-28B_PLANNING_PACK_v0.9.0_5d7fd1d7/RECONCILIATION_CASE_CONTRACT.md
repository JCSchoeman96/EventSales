# Reconciliation Case Contract

## Purpose

Current Tickera/Woo findings are detector outputs. VS-28B adds an operator case layer that groups evidence and tracks review without mutating Sales truth.

## Candidate resources

- `DataIssueCase`
- `DataIssueEvidenceLink`
- `DataIssueTransition`
- optional `DataIssueAssignment`

## Case identity

A case has:

- source system;
- event;
- case kind/version;
- stable scope/fingerprint;
- severity;
- current state;
- summary code;
- opened/last observed;
- owner where supported;
- linked findings/import rows/backfill failures/orders/items/corrections.

## Case kinds

Planning set:

- reconciliation_mismatch;
- import_conflict;
- source_gap;
- semantic_conflict;
- mapping_conflict;
- completeness_gap;
- correction_required;
- export_integrity_failure.

Unknown kinds fail closed.

## States

- open;
- triaged;
- correction_proposed;
- awaiting_approval;
- applying;
- analytics_pending;
- resolved;
- ignored;
- reopened;
- superseded.

## Detector recurrence

A recurring finding may:

- update `last_seen_at` and evidence link;
- reopen a resolved/ignored case only under an explicit policy;
- create a new case if the fingerprint/version materially differs.

Do not silently reset operator resolution merely because the detector reruns.

## Operator actions

- triage;
- assign/unassign where supported;
- resolve without correction;
- ignore with reason and optional expiry;
- reopen;
- create correction proposal;
- link duplicate/superseding case.

Every action creates an immutable transition.

## Resolution meaning

`resolved` means the operator verified the discrepancy no longer requires action.

It does not mean Sales truth was changed unless a linked correction Apply succeeded.

## Bounds

- bounded list/search/filter;
- bounded evidence links;
- no raw payload;
- no customer PII in case summary;
- stable pagination;
- full history loaded separately and paginated.
