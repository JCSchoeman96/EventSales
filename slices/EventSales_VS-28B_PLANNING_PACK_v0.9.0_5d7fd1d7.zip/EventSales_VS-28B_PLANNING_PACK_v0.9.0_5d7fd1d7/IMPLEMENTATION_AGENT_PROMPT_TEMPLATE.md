# Implementation Agent Prompt Template — VS-28B

**Do not use until an activation supplement returns APPROVE.**

Activation fills:

- exact current main/deployed SHA;
- exact child stage;
- final G/B/A interfaces;
- final file/artifact storage;
- final CSV/XLSX dependency and security bounds;
- final resources/actions/workers;
- final disposition/plan hash;
- final writer/export/correction seams;
- exact files/dependencies/config/migrations/tests;
- feature modes/rollout/stop conditions;
- mapped Linear gate.

Write tests first.

Implement only the activated child stage.

Open a PR and stop before merge, deployment, production upload/dry-run/Apply/export/correction.
