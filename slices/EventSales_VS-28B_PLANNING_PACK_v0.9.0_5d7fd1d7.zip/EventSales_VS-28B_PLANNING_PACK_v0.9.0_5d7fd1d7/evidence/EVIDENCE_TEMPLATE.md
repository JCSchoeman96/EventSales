# VS-28B Redacted Evidence

- Pack/plan/activation:
- Child stages/PRs/heads/deployed SHAs:
- Predecessor versions:
- Feature modes:
- Storage/XLSX dependency versions:

## File/storage security
- file ids/SHA/size/type redacted:
- encryption/retention:
- malicious fixture results:
- signed URL/log proof:

## Dry-run
- import kind/schema/parser/policy:
- source/event scope redacted:
- canonical groups:
- disposition counts:
- expected effects:
- blockers/warnings:
- exact plan hash prefix:
- CSV/XLSX equivalence:
- Sales mutations: 0
- PII scan:

## Apply
- exact supplement/hash:
- groups/rows:
- creates/no-ops/skips/issues/failures:
- duplicate/replay:
- interruption/resume:
- partial-state proof:
- audit/effect:
- B.2/completeness/target convergence:

## Exports
- definitions/filter hashes/as_of:
- B.2 parity:
- operational keyset proof:
- row/byte/complete/truncated:
- CSV formula protection:
- XLSX typed/security:
- artifact SHA/expiry:
- download audit/authorization:

## Cases
- finding/case fingerprint:
- disposition transitions:
- reasons/audit:
- recurring finding behaviour:
- Sales mutation: none

## Corrections
- type/tier:
- before/after/effect hashes:
- approval hash:
- source drift proof:
- Apply idempotency:
- B.2/completeness/target:
- reversal:
- original history retained:

## Performance
- dry-run rows/runtime/memory:
- Apply chunk/runtime:
- export rows/bytes/runtime:
- database/storage growth:
- queue impact:

## Negative proof
- no conflict overwrite:
- no arbitrary correction:
- no source money/status edit:
- no raw PII/log leak:
- no unbounded operation:
- no direct bucket/certificate/target edit:
- no VS-27A scope:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
