# Scope Split Assessment

VS-28B remains one roadmap outcome but must be implemented as staged child slices/PRs.

## Recommended split

### VS-28B.1 — Import contract and asynchronous dry-run

- durable file;
- common CSV/XLSX schema;
- security parser;
- canonical row/group evidence;
- exact plan hash;
- no Sales mutation.

### VS-28B.2 — Safe import Apply and progress

- exact approval;
- disposition allowlist;
- writer integration;
- progress/failure;
- B.2 convergence.

### VS-28B.3 — Versioned filtered exports

- definitions;
- B.2 decision exports;
- operational keyset readers;
- artifact storage/download.

### VS-28B.4 — Issue and finding disposition history

- generic cases;
- immutable transitions;
- migration/cutover of current findings.

### VS-28B.5 — Tier 1 corrections

- proposal/effect preview;
- exact approval;
- narrow attribution/semantic services;
- reversal;
- B.2/completeness/target integration.

## Mandatory split conditions

- XLSX dependency/storage not independently approved;
- import dry-run and Sales Apply in one broad PR;
- export artifact store and correction engine mixed;
- generic arbitrary correction proposal;
- missing final G/B interfaces;
- migrations/indexes too large for one exact-head review;
- production canary coupled to implementation PR merge.

## Order

Do not start B.5 until B.4 and final G/B correction seams are certified.

VS-27A remains locked until VS-28B closes.
