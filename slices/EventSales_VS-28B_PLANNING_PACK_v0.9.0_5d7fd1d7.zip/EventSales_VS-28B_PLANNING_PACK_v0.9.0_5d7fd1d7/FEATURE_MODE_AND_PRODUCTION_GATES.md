# Feature Modes and Production Gates

## Server modes

Candidate independent modes:

### Imports
- disabled;
- dry_run_only;
- canary_apply;
- enabled.

### Exports
- disabled;
- CSV_only;
- canary_XLSX;
- enabled.

### Corrections
- disabled;
- issue_only;
- tier1_canary;
- tier1_enabled;
- tier2_canary.

## Default rollout

- imports: dry-run only;
- exports: CSV only, bounded;
- corrections: issue only.

## Command checks

Feature mode is rechecked on every queue/Apply/resume/download command.

No mode comes from form/file input.

## Production supplements

Separate exact supplements:

- import file/batch/plan hash;
- correction id/effect hash;
- first XLSX parser/output canary;
- first large export artifact.

## Kill switch

A downgrade:

- blocks new Apply/correction/export generation;
- permits read-only evidence;
- permits safe pause/cancel where supported;
- does not delete applied truth/artifacts/audit.

## No hidden bypass

- no admin force flag;
- no direct Oban Web action;
- no database status edit;
- no environment variable that skips exact hash.
