# CSV/XLSX Output Security

## CSV formula injection

Any text cell beginning after optional whitespace with:

```text
= + - @
```

must be neutralized according to a versioned export policy.

Preferred: prefix with apostrophe and record `csv_formula_escape_v1`.

Do not alter numeric/date typed values unnecessarily.

## CSV encoding

- UTF-8;
- RFC4180;
- line endings documented;
- stable column order;
- explicit schema/version row or manifest;
- no unescaped newline/quote;
- no raw control characters.

## XLSX output

- typed numbers, decimals and datetimes;
- text cells never formulas;
- no external links;
- no macros;
- no hidden data sheets unless documented;
- bounded styles/shared strings;
- manifest sheet visible;
- sheet/row/cell limits enforced.

## Filename/content disposition

- no user-controlled path;
- safe ASCII/UTF-8 filename policy;
- export id and generated date;
- no customer/event secret in filename.

## Content sniffing

Set exact content type and `X-Content-Type-Options: nosniff` where delivered by app.

## Verification

Open generated artifacts in at least LibreOffice and Excel-compatible parser tests where available, but never use spreadsheet rendering as correctness authority.
