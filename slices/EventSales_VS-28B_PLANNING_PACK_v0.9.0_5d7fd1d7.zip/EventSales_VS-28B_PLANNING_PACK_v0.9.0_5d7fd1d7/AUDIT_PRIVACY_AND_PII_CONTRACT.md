# Audit, Privacy and PII Contract

## Audit event families

Planning additions:

- import_file_uploaded;
- import_dry_run_requested;
- import_plan_ready;
- import_apply_requested;
- import_apply_completed;
- export_requested;
- export_generated;
- export_downloaded;
- data_issue_transitioned;
- correction_proposed;
- correction_approved;
- correction_apply_requested;
- correction_applied;
- correction_reversed.

Final event-type names must fit the closed AuditLog allowlist.

## Transactionality

Mutation audit commits with the accepted state/job/effect.

A failed audit cannot leave an untracked Apply or correction.

## Metadata allowlist

Allowed:

- batch/export/case/correction ids;
- source/event ids;
- schema/policy versions;
- file SHA;
- plan/effect hash;
- counts;
- reason code/reason;
- prior/new state;
- artifact size/row count;
- PII policy;
- authorization reference.

Forbidden:

- raw file rows;
- customer data;
- payment/transaction fields;
- credentials;
- object-store signed URL;
- raw exception/source response;
- arbitrary metadata map.

## PII modes

- `no_pii` — default and required for decision/reconciliation exports;
- `approved_operational_pii` — disabled in v1 unless separately approved;
- `safe_ids_only` — source/order ids with no customer fields.

## Import PII

Current legacy schema accepts customer/payment fields. VS-28B default schema removes them.

Legacy files containing those columns:

- may be rejected;
- or accepted but redacted/ignored under a versioned migration adapter;
- never copy them into row evidence by default.

## Logs/telemetry/PubSub

Only low-cardinality state, format, disposition and counts.

No event/order/file ids as telemetry labels where cardinality is unsafe.

## Evidence

Production evidence uses redacted ids and hashes. Never attach source data files to GitHub/Linear/packs.
