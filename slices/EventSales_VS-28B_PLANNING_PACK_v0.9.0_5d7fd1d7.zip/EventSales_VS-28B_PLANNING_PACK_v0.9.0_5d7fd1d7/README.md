# EventSales VS-28B Planning Pack

## Identity

- Slice: `VS-28B`
- Name: Controlled CSV/XLSX Import, Filtered Exports, Reconciliation and Audited Corrections
- Pack: `0015_VS-28B`
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#131`
- Linear milestone: `M6 — Historical Completeness and Data Operations`
- Linear document: `VS-28B — Pack 15 Gate Ledger and Planning Record`
- Created: `2026-07-18T05:14:27Z`

## Authority

This ZIP authorises independent pack review and repository implementation planning only.

It does not authorise code, dependency, migration or configuration changes; production file upload, dry-run, Apply, export or correction; source/Railway mutation; merge; deployment; or production data change.

Implementation remains blocked until Pack 15 and its plan are independently approved, VS-28A.1/A.2 are certified and closed, final VS-26G and VS-27B.1/B.2 interfaces are known, and an activation supplement returns `APPROVE`.

Every production import Apply and production correction Apply requires a separate exact-hash supplement.

## Outcome

```text
bounded CSV/XLSX upload
→ durable file identity
→ asynchronous canonical validation
→ immutable dry-run plan and exact hash
→ safe create/no-op allowlist
→ exact-hash Apply through certified writers
→ issue/correction proposals for conflicts
→ analytics and completeness convergence
```

```text
bounded export definition
→ captured as_of and contract versions
→ certified B.2 or bounded operational reader
→ durable CSV/XLSX artifact
→ audited download and expiry
```

```text
reconciliation finding
→ immutable disposition history
→ correction proposal
→ exact before/after and metric-effect preview
→ exact-hash Apply
→ superseding reversal
```
