# Planning Agent Prompt — VS-28B

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-28B_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, dependencies, migrations or config. Do not upload/parse/apply production files, generate production exports, alter findings, apply corrections, call sources, commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified VS-28A.1/A.2, VS-26G, VS-27B.1/B.2 and VS-27D interfaces. Do not assume planning names survived.

## Required decisions

1. exact current-code gap verification;
2. staged child-slice/PR sequence;
3. canonical import kinds/schema/version;
4. CSV and XLSX adapter equivalence;
5. XLSX dependency/security/licence;
6. durable upload/artifact store;
7. file bounds/retention/encryption;
8. async parse state/resources/workers;
9. canonical row/group evidence and PII minimization;
10. batch existing-identity/source-version lookup;
11. disposition matrix;
12. plan snapshot/hash/expiry;
13. exact Apply command/transaction;
14. writer/G integration;
15. progress/generation/retry/pause/cancel;
16. partial Apply representation;
17. B.2/completeness convergence;
18. export kinds/filters/bounds/as_of;
19. B.2 versus operational reader authority;
20. keyset/snapshot consistency;
21. artifact generation/storage/download;
22. CSV formula injection/XLSX output;
23. generic issue/case model;
24. immutable disposition history/cutover;
25. correction resource/type/risk matrix;
26. before/after/effect preview/hash;
27. Tier 1 Apply and reversal;
28. source update conflicts;
29. audit event types/metadata/transactionality;
30. feature modes and production supplements;
31. migrations/index/lock/storage costs;
32. tests-first sequence;
33. exact files create/modify/generated/forbidden;
34. verification/security/load commands;
35. rollout/kill switch/rollback;
36. Linear gate mapping;
37. risks/stop conditions.

## Output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with exactly one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
