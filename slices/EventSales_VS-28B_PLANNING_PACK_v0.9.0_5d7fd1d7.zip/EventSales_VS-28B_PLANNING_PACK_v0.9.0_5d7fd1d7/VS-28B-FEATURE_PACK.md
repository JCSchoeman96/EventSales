# VS-28B — Controlled CSV/XLSX Import, Filtered Exports, Reconciliation and Audited Corrections

## 1. Goal

Deliver bounded and auditable data operations without creating a spreadsheet-controlled parallel source of truth.

## 2. Core doctrine

```text
Source history is preserved.
Imports create safe missing facts or exact no-ops.
Conflicts become issues.
Corrections are explicit, previewed, approved and reversed by supersession.
Exports identify scope, versions, completeness and truncation.
```

## 3. Required delivery stages

1. Common import schema and durable asynchronous dry-run.
2. Exact-hash safe Apply with bounded progress.
3. Versioned filtered export definitions and artifacts.
4. Generic issue/case and immutable finding-disposition history.
5. Type-specific correction proposal, Apply and reversal.
6. Production canaries and independent evidence certification.

No single implementation PR should contain all stages.

## 4. Import authority

A file may provide source-shaped records, but it is not automatically authoritative.

V1 safe Apply is limited to deterministic allowlisted dispositions:

- create an entirely absent source order when every required identity/header/line fact is complete and certified;
- create an absent line under a certified existing-order merge contract;
- exact identical no-op;
- skip stale local/source-newer evidence.

Any differing existing record, ambiguous semantic state, incomplete order representation or unsupported field becomes a finding/correction proposal.

## 5. Common format contract

CSV and XLSX normalize to the same canonical row and produce the same plan hash when semantically equivalent.

The format declares:

- import kind;
- schema version;
- source system;
- scope;
- timezone;
- currency;
- generated/exported timestamp where applicable;
- row identity;
- source timestamps;
- semantic-policy version;
- optional evidence reference.

## 6. Dry-run

Dry-run is asynchronous and durable.

It records:

- file SHA-256;
- file size/type;
- parser/schema/policy versions;
- actor/source/scope;
- canonical row fingerprints;
- row/group dispositions;
- expected creates/no-ops/conflicts;
- metric and completeness effects;
- immutable plan snapshot;
- exact plan hash;
- expiry.

It performs no Sales mutation.

## 7. Apply

Apply requires:

- exact current plan hash;
- allowed feature mode;
- unexpired plan;
- unchanged file/schema/policy/source/event/mapping/semantic versions;
- exact operator confirmation and reason;
- no blockers;
- atomic claim + real job/outbox + audit.

Apply is chunked, restartable and idempotent. It uses certified writer services rather than direct Sales inserts.

## 8. Exports

Exports are definitions and artifacts, not ad hoc hidden SQL.

A definition includes:

- export kind/version;
- source/event/ticket scope;
- half-open time window and timestamp axis;
- `as_of`;
- business timezone;
- status/semantic/mapping filters;
- currency;
- PII policy;
- metric/semantic versions;
- completeness/freshness evidence;
- row/byte limits;
- format.

Decision metrics read B.2. Operational rows use bounded keyset readers.

## 9. Reconciliation cases

Existing Tickera/Woo findings remain detection records.

A generic issue/case layer links source/event/order/item, one or more findings, import batch/row, backfill evidence and correction proposal. Resolving or ignoring an issue never mutates Sales by itself.

## 10. Corrections

A correction contains:

- exact target identity and source version;
- correction type/version;
- immutable before snapshot;
- proposed patch or overlay;
- after preview;
- metric/ticket/revenue/tax/refund delta;
- affected B.2 keys;
- completeness/target impact;
- reason/evidence;
- exact approval hash;
- actor/timestamps;
- Apply result;
- supersedes/reversal links.

No generic arbitrary field editor.

## 11. Risk tiers

- Tier 0: issue disposition only; no Sales mutation.
- Tier 1: one order/line attribution or semantic correction through an allowlisted service.
- Tier 2: bounded batch correction with separate reviewer/approver and stronger preview.
- Tier 3: destructive or broad source-history rewrite; out of scope.

V1 should implement Tier 0 and a narrow Tier 1 set first.

## 12. Completeness and targets

An applied import/correction may dirty contribution/bucket keys, set event completeness pending, supersede an affected certificate and block VS-27D target claims until rebuilt and re-certified.

## 13. Privacy

No PII in pack, evidence, logs, telemetry or PubSub.

Production files may contain approved operational PII only under a documented encrypted storage and retention policy. V1 schemas should exclude customer and payment fields unless independently justified.

## 14. Non-goals

- no arbitrary SQL/data editor;
- no spreadsheet overwrite of Woo truth;
- no anonymous/customer import;
- no event-scoped portal access;
- no unbounded file/export;
- no coupon/UTM dimensions unless already certified;
- no webhook changes;
- no direct Woo call from web;
- no production execution from pack approval.

## 15. Exit gate

Equivalent CSV/XLSX fixtures generate the same plan. Safe missing data applies once; stale/duplicate/conflicting data cannot overwrite truth. Exports are bounded and self-describing. Finding history is immutable. One allowlisted correction previews, applies, rebuilds analytics and reverses through a superseding correction with complete audit evidence.
