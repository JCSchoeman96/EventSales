# Current Code Data Operations Map

| Current area | Current behaviour | VS-28B implication |
|---|---|---|
| ImportsLive | CSV only, one event, 10 MB, synchronous dry-run | move parse/validation off web and add XLSX |
| Event selector | first 50 events | bounded searchable/paginated facade |
| CsvImports | batch create then synchronous validator | durable file + async lifecycle |
| DryRunValidator | stream parser but accumulates all rows | durable chunk processing |
| Duplicate checks | per-row Order and OrderItem reads | batch/keyset lookup, no N+1 |
| Raw rows | raw and normalized maps persisted publicly | PII-minimised evidence and retention |
| Datetime parsing | timezone-less values treated as UTC | strict versioned timestamp policy |
| CsvImportBatch | no file/schema/policy/plan hash | immutable file/plan identity |
| queue_apply | job inserted, audit later | atomic claim + job/outbox + audit |
| ApplyImport | all rows grouped in one worker | bounded cursor/chunk progress |
| Apply semantics | forces ticket/mapped | consume final G policy |
| stale_noop | permanent error | deterministic no-op disposition |
| partial Apply | orders can commit before row/final state | restart-safe effects ledger |
| XLSX | no dependency | reviewed parser/storage/security |
| Event summary export | legacy raw Sales SQL | decision exports use B.2 |
| Order export | offset pagination, 10k cap | keyset/snapshot-labelled artifact |
| Finding export | full CSV assembled in memory | streaming/artifact path |
| Finding disposition | current status/reason overwritten | immutable disposition events |
| Finding actions | no explicit operational audit | transactionally audited transitions |
| Current correction | hard-coded order 113834 | precedent only; no arbitrary editor |
| AuditLog | closed event-type allowlist | reviewed data-operation events |
| CsvStream | RFC4180 only | formula-injection protection |
