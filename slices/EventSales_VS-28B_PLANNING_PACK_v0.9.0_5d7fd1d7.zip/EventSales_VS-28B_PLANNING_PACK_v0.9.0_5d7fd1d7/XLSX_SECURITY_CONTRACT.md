# XLSX Security Contract

## Dependency

Current repository has no XLSX dependency.

The planning agent must evaluate a maintained reader against official documentation and source code. Activation records exact version, transitive dependencies, licence and security posture.

## Accepted container

- Office Open XML `.xlsx`;
- ZIP signature and required OOXML parts;
- no legacy `.xls`;
- no `.xlsm`;
- no macros;
- no embedded executables/objects;
- no encrypted/password-protected workbook in v1.

## ZIP safety

Before XML parse:

- bounded compressed size;
- bounded total uncompressed size;
- bounded entry count;
- bounded per-entry size;
- compression-ratio limit;
- ZipSlip/path traversal rejection;
- duplicate path handling;
- symlink/special-file rejection where applicable.

Planning defaults:

- total uncompressed maximum: 100 MB;
- maximum entries: 2,000;
- maximum compression ratio: 100:1;
- maximum sheets: 10.

## XML safety

- external entity resolution disabled;
- DTD prohibited;
- external links rejected;
- remote relationships rejected;
- shared-string count/size bounded;
- XML depth/node count bounded;
- no formula evaluation;
- no cached formula result accepted as authoritative without policy;
- no hidden sheet/row data silently imported.

## Cells

- canonical typed conversion;
- date-system detection including 1900/1904;
- formulas rejected in required data cells;
- errors and rich text normalized safely;
- merged data cells rejected;
- empty/blank distinction versioned.

## Sheet contract

Only allowlisted sheet names are read.

Unknown data-bearing sheets cause a finding or failure; they are not ignored silently.

## Testing

Include malicious fixtures for:

- ZIP bomb;
- traversal;
- external link;
- XXE/DTD;
- formula;
- hidden rows/sheets;
- macro-enabled package;
- excessive shared strings;
- malformed relationships;
- duplicate workbook entries.
