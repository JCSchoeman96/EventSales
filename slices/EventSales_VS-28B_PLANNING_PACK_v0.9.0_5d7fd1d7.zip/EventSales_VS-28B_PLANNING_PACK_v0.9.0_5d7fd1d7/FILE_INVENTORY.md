# Mandatory File Inventory — VS-28B

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Predecessor artifacts
- final VS-28A.1 and VS-28A.2 packs/plans/implementations/reviews/evidence;
- final VS-26G;
- final VS-27B.1 and VS-27B.2;
- final VS-27D completeness/target interfaces.

## Current import web/facade
- `lib/event_sales_web/live/admin/imports_live.ex`
- import LiveView tests;
- `lib/event_sales/ingestion/csv_imports.ex`
- CsvImports tests;
- upload and admin session/rate-limit helpers.

## CSV parser/validator/apply
- `lib/event_sales/ingestion/csv/parser.ex`
- `lib/event_sales/ingestion/csv/dry_run_validator.ex`
- `lib/event_sales/ingestion/csv/apply_import.ex`
- `lib/event_sales/ingestion/workers/process_csv_import_worker.ex`
- parser/validator/apply/large-import/worker tests.

## Import resources
- `lib/event_sales/ingestion/resources/csv_import_batch.ex`
- `lib/event_sales/ingestion/resources/csv_import_row.ex`
- migrations/resource snapshots/state-machine docs;
- `lib/event_sales/ingestion.ex`.

## Sales writer and semantics
- `lib/event_sales/sales/order_upserter.ex`
- parser/source-version guard;
- Order/OrderItem/Coupon resources/actions/indexes;
- final G semantic/correction services;
- writer tests.

## Exports
- `lib/event_sales/exports/csv_stream.ex`
- `lib/event_sales/exports/event_sales_csv.ex`
- `lib/event_sales_web/controllers/admin/event_export_controller.ex`
- `lib/event_sales/ingestion/findings_csv_export.ex`
- `lib/event_sales_web/controllers/admin/reconciliation_export_controller.ex`
- export tests/routes/rate limits.

## B.1/B.2 readers
- final metric/window contract;
- final contribution/bucket/read facades;
- completeness/freshness DTOs;
- export-compatible query/index tests.

## Reconciliation
- `lib/event_sales_web/live/admin/reconciliation_live.ex`
- `lib/event_sales/ingestion/admin_reconciliation_dashboard.ex`
- `lib/event_sales/ingestion/tickera_reconciliation_findings.ex`
- `lib/event_sales/ingestion/resources/tickera_reconciliation_finding.ex`
- reconciliation run/worker/resources;
- tests/exports.

## Current correction
- `lib/event_sales/sales/order_attribution_correction.ex`
- its LiveView integration/tests;
- OrderItem `correct_event_attribution`;
- DashboardCache/analytics notifier integration.

## Audit/privacy
- `lib/event_sales/audit/logger.ex`
- `lib/event_sales/audit/resources/audit_log.ex`
- `lib/event_sales/audit/metadata_sanitizer.ex`
- audit tests;
- PII/domain-boundary/static checks.

## Dependencies/storage/config
- `mix.exs`
- `mix.lock`
- `config/config.exs`
- `config/runtime.exs`
- `config/test.exs`
- `railway.toml`
- current storage/cloud dependencies;
- release/migration helpers;
- Oban queues/plugins.

## Security/load support
- archive/ZIP helpers;
- XML parsers;
- upload tests;
- source file fixtures;
- architecture manifests;
- CI scripts.
