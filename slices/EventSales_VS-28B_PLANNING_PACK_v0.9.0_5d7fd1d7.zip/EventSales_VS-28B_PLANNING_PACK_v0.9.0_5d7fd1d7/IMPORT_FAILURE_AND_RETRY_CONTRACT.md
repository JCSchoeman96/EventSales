# Import Failure and Retry Contract

## Failure identity

Candidate fields:

- batch id;
- phase;
- file/sheet/row/group reference;
- safe reason code;
- retryability;
- attempt count;
- first/last seen;
- resolved/superseded at;
- safe evidence hash.

No raw row, PII, payment data, source credentials or stack trace.

## Retryable

- durable storage timeout;
- transient database error;
- worker crash;
- temporary analytics enqueue failure;
- temporary object-store read failure;
- lock contention.

## Non-retryable/blocking

- unsupported schema;
- invalid file signature;
- malicious XLSX feature;
- file hash mismatch;
- duplicate conflicting identity;
- source-history conflict;
- unknown semantics;
- incomplete order;
- plan hash/version drift;
- row/byte/sheet limit exceeded.

## Parser failure

A parser failure must not leave a batch in `validating` indefinitely.

The batch records a bounded safe reason and retains/purges the source file according to policy.

## Apply failure

Progress advances only after the exact group effect is durable.

A permanent group conflict creates an issue and blocks the plan unless the plan explicitly classified it as non-Apply.

## Attempts

Planning defaults:

- parse/storage transient attempts: 10;
- Apply group transient attempts: 10;
- hash/drift/malicious file: no blind retry;
- analytics convergence: separate bounded retry.

## Manual retry

Manual retry is a new audited command over a safe retryable state. It never edits an Oban job directly.
