# Implementation Agent Prompt Template — VS-27D

**Do not use until an explicit activation supplement returns APPROVE.**

Activation fills:

- exact main SHA;
- certified B.1/B.2/B.3/C/F.2 interfaces;
- 28A completeness state;
- final target/version/evaluation resources;
- final pacing/gate/rule contracts;
- final queues/Cron;
- final recipient/access/inbox design;
- final email disabled/adapter decision;
- final staged scope/files/tests;
- rollout/kill switches;
- mapped implementation gate.

Write tests first. Implement only the activated stage. Open a PR and stop before merge, deployment, target creation, notification delivery or post-backfill enablement.
