# VS-27D Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified B.1/B.2/B.3/C/F.2 interfaces
## 4. VS-28A completeness state
## 5. Current target/channel/audit/Oban truth
## 6. Staged delivery recommendation
## 7. Decisions domain/resource split
## 8. Target stable identity/versioning
## 9. Lifecycle and arming
## 10. Decimal pacing formula/precision
## 11. States and hysteresis
## 12. Final-period/correction semantics
## 13. Completeness/freshness gate
## 14. Scheduler/due-target query
## 15. Evaluation transaction/idempotency/sequence
## 16. Current-state and evidence retention
## 17. Rule kinds/revisions/cooldowns
## 18. Occurrence/delivery identity
## 19. Recipient/subscription/access checks
## 20. In-app inbox
## 21. Acknowledgement/escalation
## 22. Email adapter or disabled decision
## 23. Audit/privacy/telemetry
## 24. Queues/Cron composition
## 25. Admin/B.3/C UI integration
## 26. Migrations/indexes/lock strategy
## 27. Tests-first sequence
## 28. Exact files create/modify/generated/forbidden
## 29. Verification/load/security commands
## 30. Framework rollout/kill switches
## 31. Framework production evidence
## 32. Post-28A enablement supplement
## 33. Linear gate ledger mapping
## 34. Risks/stop conditions
## 35. Prohibited-actions statement
