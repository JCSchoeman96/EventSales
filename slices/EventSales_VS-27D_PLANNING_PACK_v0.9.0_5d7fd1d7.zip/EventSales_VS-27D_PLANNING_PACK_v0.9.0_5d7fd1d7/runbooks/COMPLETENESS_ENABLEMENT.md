# Completeness and Post-Backfill Enablement Runbook

## Framework observation before backfill

1. Create no production armed target.
2. Optionally create draft target.
3. Run evaluator in observation.
4. Verify `blocked_incomplete`.
5. Verify no performance occurrence/delivery.
6. Verify optional admin data-blocked occurrence follows persistence/cooldown.

## After VS-28A

1. Select one event/target.
2. Load 28A certification.
3. Confirm target start >= certified boundary.
4. Confirm B.2 buckets rebuilt/ready.
5. Confirm F.2 source fresh.
6. Confirm contract versions/currency.
7. Confirm recipients and channel.
8. Complete post-backfill supplement.
9. Arm target transactionally.
10. Observe first evaluation.
11. Exercise one safe threshold fixture/canary.
12. Verify occurrence and in-app delivery.
13. Expand incrementally.

## Regression

When completeness is revoked/gap discovered:

- block target;
- stop performance occurrences;
- suppress pending performance deliveries;
- preserve old evidence;
- notify authorised admins under blocked rule;
- require new certification before rearm.
