# Migration and Queue Preflight

## Repository/topology

- exact main/deployed SHA;
- Postgres version;
- direct/session migration URL;
- PgBouncer mode;
- Oban version/schema;
- current plugins and Cron entries;
- current queues/concurrency;
- current B/C/F worker load;
- database/table sizes;
- disk headroom.

## Migration review

- additive tables/resources;
- unique target revision/occurrence/delivery constraints;
- foreign keys/delete behaviour;
- Decimal precision;
- time constraints;
- indexes for due targets, current state, inbox, retries;
- no data evaluation/delivery in migration;
- generated snapshots reviewed.

## Queue review

- `decisions` and `notifications` isolated;
- concurrency conservative;
- scheduler entries merged with existing Cron;
- evaluation runtime/timeout;
- delivery timeout;
- repair drainer cadence;
- queue kill switches;
- backlog thresholds/runbook.

## Stop

Unknown topology, Cron replacement, unsafe populated index, missing unique dedupe constraint, queue starvation or email enabled without preflight.
