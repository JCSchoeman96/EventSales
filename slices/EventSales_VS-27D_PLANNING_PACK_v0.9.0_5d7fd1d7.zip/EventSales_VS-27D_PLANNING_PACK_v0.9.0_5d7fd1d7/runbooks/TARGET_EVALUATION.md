# Target Evaluation Runbook

## Due-target enumeration

1. Scheduler obtains leader execution.
2. Query armed/active versions where `next_evaluate_at <= now`.
3. Order by next time and stable id.
4. Limit page/runtime.
5. Enqueue one evaluation-slot job.
6. Advance/schedule only through reviewed workflow.
7. Continue while budget remains.

## Evaluation

1. Load target/current active version.
2. Reject stale job version.
3. Capture one `as_of`.
4. Build exact B.1 period.
5. Read B.2 once.
6. Read F.2 freshness and completeness evidence.
7. Apply eligibility gate.
8. Calculate Decimal state when eligible.
9. Allocate evaluation sequence.
10. Insert append-only evaluation.
11. Conditionally update current state.
12. Detect transition.
13. Insert unique occurrences.
14. Commit.
15. Enqueue occurrence expansion and broadcast.

## Boundary fixtures

Evaluate:

- before start;
- exactly start;
- every hysteresis threshold;
- actual exactly target;
- actual above target;
- one microsecond before due;
- exactly due;
- due but incomplete;
- due complete;
- correction after final;
- stale source;
- mixed currency;
- missing bucket;
- version drift.

## Negative proof

No raw Sales query, Woo call, float arithmetic or performance occurrence while blocked.
