# Acknowledgement and Escalation Runbook

## Acknowledge

1. Authenticate current user.
2. Load delivery/occurrence.
3. Reauthorize event/metric visibility.
4. Confirm acknowledgement is required/allowed.
5. Insert or set idempotent acknowledgement.
6. Write audit transactionally.
7. Broadcast inbox/target invalidation.

## Escalation scan

1. Enumerate occurrences with `escalation_due_at <= now`.
2. Exclude acknowledged/recovered/disabled cases.
3. Reevaluate condition using latest eligible state.
4. Resolve escalation recipients.
5. Recheck access.
6. Insert unique escalation occurrence.
7. Queue deliveries.

## Recovery before escalation

Cancel pending escalation work and create recovery only when configured.

## Tests

- read but not acknowledged;
- email delivered but not acknowledged;
- one of several recipients acknowledges;
- access lost after original delivery;
- condition recovers;
- duplicate escalation worker;
- escalation recipient lacks revenue;
- stale data blocks persistence check.
