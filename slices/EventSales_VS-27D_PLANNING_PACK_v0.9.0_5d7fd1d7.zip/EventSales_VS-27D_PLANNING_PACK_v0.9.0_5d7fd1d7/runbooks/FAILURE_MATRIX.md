# Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| history incomplete | blocked evaluation | 28A certification |
| source stale | blocked evaluation | F.2 catches up |
| bucket missing/dirty | blocked evaluation | B.2 repair |
| metric/version drift | blocked | activation/revise target |
| duplicate scheduler/job | one evaluation/transition | DB uniqueness |
| stale evaluation finishes late | current state unchanged | newer sequence wins |
| evaluation transaction fails | no occurrence | retry |
| occurrence enqueue fails | durable occurrence remains | drainer |
| duplicate expansion | one delivery | unique key |
| recipient access lost | suppressed | no send |
| revenue hidden | suppressed/redacted | permission change |
| in-app PubSub missed | durable inbox on reload | reconnect |
| email disabled | channel unavailable | enable only after preflight |
| email retryable failure | retry with backoff | worker |
| email ambiguous timeout | unknown outcome | provider reconciliation/admin |
| acknowledgement duplicate | one acknowledgement | idempotent |
| condition recovers | cancel escalation/recovery | evaluator |
| Cron overwritten | predecessor jobs missing | rollout stop/restore |
| queue backlog | delivery delayed, truth unchanged | throttle/pause email |
| completeness regression | target blocked | recertify |
