# Optional Email Channel Preflight

Email remains disabled unless every item passes.

## Dependency and adapter

- exact library/adapter and locked version;
- licence/security review;
- supported OTP/Elixir versions;
- no runtime dynamic dependency fetch;
- test adapter.

## Provider/sender

- provider account;
- sender domain/address;
- DNS/SPF/DKIM/DMARC status where applicable;
- API/SMTP credentials stored in Railway secrets;
- region/residency considerations;
- sending limits;
- sandbox/production mode.

## Delivery semantics

- provider idempotency;
- timeout/ambiguous acceptance behaviour;
- message id;
- rejection/bounce reporting;
- rate limits;
- retry-after;
- payload size;
- unsubscribe/transactional classification.

## Application config

- global kill switch;
- adapter module;
- sender;
- timeout;
- max attempts/backoff;
- test recipient allowlist for canary;
- no secret in compiled config.

## Canary

1. One authorised admin recipient.
2. One non-revenue ticket target.
3. One occurrence.
4. Verify exactly one message.
5. Verify provider id and app delivery evidence.
6. Simulate retryable and ambiguous failure.
7. Disable channel and prove no send.

## Verdict

- ENABLED FOR CANARY;
- DISABLED;
- BLOCKED.

No preflight means disabled.
