# Rollout and Stop Conditions

## Framework rollout

1. Deploy domain/schema with scheduler/delivery disabled.
2. Verify migrations/indexes/Cron composition.
3. Run deterministic evaluator fixtures.
4. Enable observation on production draft targets.
5. Verify every real target is blocked before 28A.
6. Enable in-app occurrence pipeline for certified test scope.
7. Verify access/revenue suppression.
8. Enable admin target UI under feature flag.
9. Add B.3/C read-only cards/inbox.
10. Certify framework.
11. Keep production performance enablement off.

## Optional email rollout

Separate preflight and canary.

## Post-28A rollout

Per-event/target supplements only.

## Kill switches

- scheduler;
- evaluator;
- occurrence creation;
- occurrence expansion;
- in-app delivery;
- email;
- escalation;
- admin UI;
- dashboard cards;
- portal inbox;
- target enablement.

## Stop immediately

- performance claim from blocked data;
- admin override bypass;
- mismatch with B.1/B.2;
- stale worker overwrite;
- duplicate notifications;
- hidden revenue leak;
- send after access loss;
- email false success/unsafe retry;
- PII/order content;
- predecessor Cron/queues damaged;
- critical ingestion degradation;
- target cards compute client-side;
- production target armed before 28A.
