# Notification Delivery Runbook

## Occurrence expansion

1. Claim unexpanded occurrence.
2. Resolve active subscriptions/rule recipients.
3. Recheck user/event/metric access.
4. Insert one unique delivery per recipient/channel.
5. Mark occurrence expanded.
6. Queue pending channel deliveries.

## In-app

1. Recheck access.
2. Mark durable delivery available/delivered.
3. Broadcast user inbox invalidation.
4. Inbox reloads durable rows.
5. Hidden revenue is projected out at read time as well as creation time.

## Email

Only when enabled/certified:

1. Recheck access and channel config.
2. Render reviewed text/HTML.
3. Create attempt evidence.
4. Call adapter with delivery idempotency key.
5. Persist result.
6. Retry only retryable outcomes.
7. Treat ambiguous outcome under provider policy.
8. Never log body/recipient email/token/provider payload.

## Suppression reasons

- user inactive;
- event access lost;
- revenue hidden;
- subscription inactive;
- channel disabled;
- target/rule disabled;
- occurrence superseded for escalation;
- invalid recipient;
- unknown.

Suppression is durable and auditable; it is not failure.

## Repair

A periodic bounded drainer finds:

- unexpanded occurrences;
- pending/available deliveries without jobs;
- retryable deliveries due;
- stuck sending rows beyond timeout.

Oban uniqueness is not the repair authority.
