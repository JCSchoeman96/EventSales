# Independent Reviewer Prompt — VS-27D

Block any design that:

- redefines B.1 metrics/windows/completeness;
- reads raw Sales/contribution/source data;
- evaluates incomplete, stale or mixed-currency data as performance;
- allows admin completeness override;
- presents linear pace as prediction;
- uses floats for target/revenue arithmetic;
- mutates historical target versions/evaluations;
- lets stale jobs overwrite newer state;
- emits every evaluation rather than transitions;
- lacks database occurrence/delivery dedupe;
- lets cooldown suppress legitimate recovery/final revision;
- sends to arbitrary external recipients;
- sends revenue to users lacking current C capability;
- fails to recheck access at dispatch/render;
- treats email unavailable/timeout as success;
- stores provider payload, customer/order PII or plaintext secrets;
- overwrites existing Oban Cron plugins;
- puts notifications on source-critical queues;
- makes PubSub the durable authority;
- exposes target editing to management/marketing in v1;
- activates real alerts before 28A completeness;
- introduces predictive ML, campaigns, SMS/WhatsApp/Slack/webhooks or automatic operational actions.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only. Activation controls implementation.
