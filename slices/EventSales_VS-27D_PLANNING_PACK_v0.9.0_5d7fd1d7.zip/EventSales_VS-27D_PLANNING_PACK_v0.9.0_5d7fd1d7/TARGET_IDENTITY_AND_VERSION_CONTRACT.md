# Target Identity and Version Contract

## Stable target identity

A target has one stable identity for user navigation and audit.

Recommended split:

### SalesTarget

- id;
- source_system_id;
- event_id;
- optional ticket_type_id;
- name;
- lifecycle state;
- active_version_id;
- created_by_user_id;
- inserted/updated timestamps.

### SalesTargetVersion

Immutable configuration:

- target_id;
- revision;
- metric;
- currency when revenue;
- target_value;
- starts_at;
- due_at;
- business_timezone;
- metric_contract_version;
- semantic_policy_version;
- pacing threshold set;
- minimum projection fraction;
- created_by_user_id;
- reason;
- configuration_hash;
- inserted_at.

The implementation plan may choose another equivalent immutable model, but in-place historical reinterpretation is forbidden.

## Identity constraints

- event belongs to source;
- ticket type belongs to event;
- metric is B.1 allowlisted;
- revenue requires exact currency;
- ticket target cannot carry currency-dependent semantics;
- target value is positive;
- due time is after start;
- business timezone matches the certified event/business policy;
- contract versions are non-null;
- revision unique per target;
- active version belongs to target.

## Lifecycle

### Draft

May exist without completeness.

No evaluation or notification delivery.

### Armed

Completeness and configuration preflight passed.

Scheduler may evaluate at or after start.

### Active

Current time is within period and evaluation is eligible or temporarily blocked.

### Completed

Due period has a certified final evaluation.

### Disabled

No future evaluation or occurrence creation.

Historical rows remain.

## Revision rules

Changing any of these creates a new version:

- metric;
- target value;
- period;
- scope;
- currency;
- thresholds;
- notification rule semantics;
- contract versions.

A revision:

1. validates current access and reason;
2. creates immutable version;
3. atomically switches active version;
4. schedules reevaluation;
5. preserves old evaluations/occurrences;
6. emits audit.

Do not mutate old evaluations to match the new target.

## Scope deletion

Event/ticket deletion must be restrictive or historical-safe. Target history may not cascade silently.
