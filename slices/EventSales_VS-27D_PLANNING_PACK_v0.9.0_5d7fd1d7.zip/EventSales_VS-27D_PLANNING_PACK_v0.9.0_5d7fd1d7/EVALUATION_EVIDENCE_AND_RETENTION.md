# Evaluation Evidence and Retention Contract

## Evaluation record

Candidate fields:

- target_id/version_id/revision;
- evaluation sequence/slot;
- evaluated_at and `as_of`;
- period start/end;
- actual/target/expected;
- target and schedule progress;
- pace delta;
- projection;
- previous/new state;
- eligibility and blocked reason;
- currency;
- metric/semantic contract versions;
- B.2 bucket/read revision;
- F.2 source watermark/freshness state;
- completeness boundary/state;
- deterministic evidence hash;
- inserted_at.

## Privacy

No customer/order data, arbitrary payload, email body or invitation/access reason.

Revenue evaluations are commercially sensitive and access-controlled even though they are not customer PII.

## Immutability

Evaluation rows are append-only.

Corrections create new rows.

No update action except narrowly reviewed metadata repair unrelated to meaning.

## Retention

Planning default:

- target versions: indefinite;
- transition/final evaluations: indefinite;
- periodic non-transition evaluations: 180 days;
- notification occurrences/deliveries/audits: indefinite or policy-reviewed;
- delivery attempt provider payloads: never stored raw; bounded sanitized evidence.

A purge worker may be planned only with:

- durable cursor;
- bounded batch;
- exclusion of referenced transition/final evidence;
- audit/telemetry;
- no loss of active cooldown/dedupe state.

Implementation plan may keep all evaluations initially if measured volume is small. It may not introduce silent unbounded growth without a decision.
