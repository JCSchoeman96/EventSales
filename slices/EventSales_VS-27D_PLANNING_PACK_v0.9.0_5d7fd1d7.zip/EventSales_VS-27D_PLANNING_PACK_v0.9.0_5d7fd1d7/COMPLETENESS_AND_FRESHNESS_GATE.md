# Completeness and Freshness Gate

## Performance eligibility

A target evaluation may produce a performance state only when all are true:

1. target version is armed/active;
2. B.1 metric and semantic versions match;
3. target start is not before certified completeness;
4. the requested `[starts_at, min(as_of, due_at))` period is complete;
5. currency is exact;
6. B.2 data is ready through the requested end;
7. F.2 source freshness is within the approved threshold;
8. no semantic/source gap blocks the metric;
9. event/ticket scope still exists and is eligible.

## Blocked reasons

Low-cardinality reasons:

- `history_not_certified`;
- `window_incomplete`;
- `source_stale`;
- `bucket_pending`;
- `bucket_failed`;
- `semantic_version_mismatch`;
- `metric_version_mismatch`;
- `mixed_currency`;
- `scope_ineligible`;
- `source_gap`;
- `unknown`.

Blocked evaluation records:

- reason;
- requested period;
- certified boundary;
- source watermark;
- bucket revision/status;
- contract versions;
- `as_of`.

No target actual, expected, delta or projected performance value is exposed when the predecessor contract forbids it.

## Operational blocked notification

A separate rule may notify global admins that target evaluation is blocked.

It must:

- say data/evaluation is blocked;
- never say sales are behind/ahead;
- use a long cooldown;
- recover when eligibility returns;
- avoid hidden revenue values;
- not auto-trigger F.2 catch-up.

Planning default:

- notify after blocked condition persists 30 minutes;
- cooldown 6 hours;
- recovery once.

Activation may tighten.

## Target arming

Before 28A completeness, production targets remain draft/blocked.

Arming requires an explicit reviewed workflow and audit.

No `force=true` or admin override bypasses completeness.
