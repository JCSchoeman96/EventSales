# TOON Prompts — VS-27D

## Planning agent
Task: Design completeness-gated target evaluation and durable notifications from current code.
Output: Complete implementation plan.
Boundary: No code or delivery.

## Metric reviewer
Task: Attack target identity, B.1/B.2 parity, periods and Decimal pacing.
Output: Truth-table findings.
Boundary: No alternative sales truth.

## Completeness reviewer
Task: Attack backfill boundary, freshness, blocked/final states and overrides.
Output: Gate verdict.
Boundary: Partial history never becomes performance.

## Concurrency reviewer
Task: Attack scheduler, stale jobs, transition dedupe, cooldown and delivery races.
Output: Race matrix.
Boundary: Database uniqueness is authority.

## Access/privacy reviewer
Task: Attack C capabilities, revenue masking, recipients, content and revocation.
Output: Leakage verdict.
Boundary: Recheck at dispatch/render.

## Channel reviewer
Task: Attack in-app durability and optional email ambiguity/retry.
Output: Delivery verdict.
Boundary: Unavailable is not success.

## Activation reviewer
Task: Refresh exact B/C/F/28A/current code interfaces and topology.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
