# Evaluation Pipeline Contract

## Scheduler

One recurring leader tick enumerates due target versions.

Requirements:

- one leader across nodes;
- bounded page size;
- stable `next_evaluate_at, id` ordering;
- hard runtime budget;
- requeue/continue cursor;
- feature/config kill switch;
- no B.2 read in the scheduler itself.

Planning default tick: every minute.

## Evaluation job identity

Candidate unique identity:

```text
target_version_id
+ evaluation_slot_start
+ metric_contract_version
+ semantic_policy_version
```

Slot length derives from the target evaluation interval.

Duplicate enqueue/runs converge to one durable evaluation.

## Evaluation transaction

1. Cast and lock target/current state.
2. Reject stale/inactive version.
3. Capture one `as_of`.
4. Resolve C access-independent target scope and B contract versions.
5. Read B.2 once for exact target period.
6. Evaluate completeness/freshness.
7. Calculate deterministic state.
8. Persist append-only evaluation.
9. Update current state conditionally by evaluation sequence/version.
10. Detect transition/crossing.
11. Create unique notification occurrence(s).
12. Commit.
13. Enqueue deliveries and publish invalidation after commit.

## Sequence/revision authority

Use a monotonic database sequence or exact evaluation ordering authority.

A late older evaluation cannot overwrite current state or generate obsolete transitions.

## Accelerated evaluation

B.2 bucket/event invalidation may enqueue an immediate evaluation for affected targets.

It is an acceleration hint. Periodic due evaluation remains convergence authority.

Coalesce by target/version/slot.

## Bounded source reads

- B.2 facade only;
- no raw Sales/contribution query;
- no Woo/F.2 source action;
- no per-recipient metric read;
- one event/ticket target query per evaluation;
- bulk optimisation may be introduced only with exact parity proof.

## Failure

- B.2 error: job retries; no partial occurrence;
- transaction error: no evaluation/occurrence;
- enqueue delivery failure: occurrence remains durable and drainer repairs;
- contract mismatch: blocked evaluation, not exception storm;
- unknown state: fail closed.
