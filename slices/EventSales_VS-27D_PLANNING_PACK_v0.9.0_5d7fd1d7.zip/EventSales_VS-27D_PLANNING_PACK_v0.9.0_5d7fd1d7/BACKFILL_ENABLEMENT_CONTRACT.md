# Post-Backfill Enablement Contract

## Why this is separate

VS-27D may deploy before VS-28A.

Framework correctness does not prove production history completeness.

Therefore target delivery has a second enablement gate.

## Before VS-28A

Allowed:

- create draft target definitions;
- configure rules/subscriptions;
- evaluate certified fixtures/test environments;
- persist `blocked_incomplete` production evaluations;
- use admin UI to inspect the gate;
- test in-app delivery with synthetic/certified test scope.

Forbidden:

- arm real performance targets;
- emit under/over/met/missed production claims;
- use current Railway rows as implicit lifetime truth;
- override completeness.

## Enablement supplement

After VS-28A certification, record:

- backfill/certification id;
- source/event ids;
- certified-from boundary;
- target start/due;
- B.1 metric and semantic versions;
- B.2 rebuild/bucket readiness;
- F.2 freshness;
- currency;
- target/rule versions;
- recipients/access;
- channel readiness;
- rollout mode;
- rollback/stop conditions.

Verdict:

- `APPROVE EVENT/TARGET ENABLEMENT`;
- `REFRESH REQUIRED`;
- `BLOCKED`.

## Arming transaction

For approved targets:

1. lock target/current version;
2. recheck completeness/freshness;
3. set armed state;
4. initialize next evaluation;
5. audit with certification id;
6. commit;
7. enqueue first evaluation.

## Incremental enablement

Enable per event/target.

Do not use a global one-click enable for all events before evidence.

## Backfill regression

If later a completeness gap is discovered:

- target becomes blocked;
- performance notifications stop;
- data-blocked occurrence may notify admins;
- prior occurrences remain evidence;
- re-enable only after new certification.
