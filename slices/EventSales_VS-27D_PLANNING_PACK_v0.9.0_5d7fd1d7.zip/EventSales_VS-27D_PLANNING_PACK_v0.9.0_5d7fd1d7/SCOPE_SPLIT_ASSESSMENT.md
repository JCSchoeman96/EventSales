# Scope Split Assessment

A staged implementation is strongly recommended.

## Stage A — Target law and evaluator

- Decisions domain;
- target/version/evaluation/current-state;
- completeness/freshness gate;
- scheduler/evaluation workers;
- audit;
- deterministic tests.

No user notification delivery.

## Stage B — Occurrence and in-app channel

- rules/subscriptions;
- occurrence/delivery/attempt;
- in-app inbox;
- acknowledgement/escalation;
- access rechecks;
- PubSub.

Email remains disabled.

## Stage C — Admin/B.3/C UI integration

- target management;
- dashboard cards;
- portal inbox/cards;
- browser/accessibility/load;
- framework rollout.

## Stage D — Optional email adapter

Separate PR/review only when adapter and provider contract are ready.

## Stage E — Post-28A enablement supplement

Configuration/evidence gate, not a code shortcut.

A split is mandatory if:

- B.1/B.2/C interfaces are not final;
- target/evaluator and delivery are too broad for one exact-head review;
- email adapter introduces external-provider uncertainty;
- migration/queue changes cannot be isolated;
- UI would activate production claims before completeness.

All stages remain under one VS-27D authority.
