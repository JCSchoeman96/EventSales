# UI and Read Facade Contract

## Read authority

Add a Decisions read facade layered over:

- target/current-state resources;
- B.3 query/filter contract;
- C event scope and revenue projection;
- notification inbox deliveries.

Web code must not query target/evaluation/delivery tables directly.

## Admin surfaces

Planning routes:

```text
/admin/targets
/admin/targets/:id
/admin/notifications
```

Functions:

- list/filter targets by lifecycle/event/metric;
- create/revise/disable target;
- configure bounded rules/recipients;
- view current state and evaluation evidence;
- view delivery failures;
- acknowledge/retry/cancel under policy;
- show completeness gate and post-28A eligibility.

No raw provider payload.

## Dashboard integration

B.3 all-event/event pages may show:

- target value;
- actual;
- expected;
- pace state;
- target/schedule progress;
- run-rate projection where defined;
- blocked reason;
- next evaluation;
- notification state.

Values come from one Decisions DTO.

Do not compute pacing in HEEx/JavaScript.

## Portal integration

C portal may show read-only target cards and inbox.

Management/marketing:

- cannot create/revise/disable targets;
- can self-subscribe where allowed;
- can read/acknowledge own notifications;
- receive server-side revenue masking.

No operations/source controls.

## Inbox

Planning routes:

```text
/admin/notifications
/portal/notifications
```

Features:

- unread/read;
- severity/kind;
- event/target link;
- acknowledged/unacknowledged;
- bounded pagination;
- filter by state/event/kind;
- durable mark-read/ack;
- generic suppressed/expired state where access changed.

## URL/filter state

Reuse B.3 typed URL conventions.

Target admin filters must be bounded and canonical.

No email address, provider id or target secret in URLs.

## Accessibility

- state not conveyed by colour alone;
- exact “linear plan pace” wording;
- blocked evaluation explains data state;
- projection labelled non-predictive;
- acknowledgement confirmation;
- keyboard forms/tables;
- live inbox changes announced politely;
- mobile layout.

## Empty/blocked states

- no targets: setup guidance for admin, neutral state for portal;
- incomplete: “Target evaluation unavailable until sales history is certified”;
- stale: “Target evaluation paused while source data is stale”;
- email unavailable: channel shown disabled, never delivered;
- missing bucket: no zero target actual.
