# Planning Agent Prompt — VS-27D

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-27D_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, create targets, deliver notifications, configure email, run migrations, commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect final certified B.1/B.2/B.3/C/F.2 artifacts and the current 28A plan/certification state.

Do not assume planning names survived implementation.

## Required decisions

1. actual B.1 metric/completeness interfaces;
2. actual B.2 target-period reader/revisions/topics;
3. actual B.3 extension points;
4. actual C capabilities/revenue/portal/invalidation interfaces;
5. actual F.2 freshness interface;
6. Decisions domain/resource split;
7. stable target/version identity;
8. lifecycle and arming;
9. exact Decimal pacing formulas/precision;
10. state precedence/hysteresis;
11. final-period and correction revision semantics;
12. completeness/freshness gate;
13. scheduler cadence and due-target query;
14. evaluation idempotency/sequence/stale-job guard;
15. occurrence/delivery dedupe;
16. rule kinds/cooldowns/recovery;
17. recipient expansion/access checks;
18. in-app inbox/read/ack;
19. escalation semantics;
20. email adapter decision or explicit disabled status;
21. audit event additions/metadata;
22. queues/Cron composition;
23. retention/purge;
24. admin/B.3/C UI integration;
25. staged PRs;
26. tests-first sequence;
27. exact files create/modify/generated/forbidden;
28. verification/load/security commands;
29. rollout/kill switches;
30. framework certification;
31. post-28A enablement supplement;
32. risks/stop conditions;
33. Linear gate ledger mapping.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`; or
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
