# Notification Rule, Hysteresis and Cooldown Contract

## Rule identity

A target version may have one or more immutable rule versions.

Candidate fields:

- target version;
- kind;
- enabled;
- severity;
- channel set;
- acknowledgement required;
- cooldown seconds;
- escalation after seconds;
- recovery enabled;
- threshold/hysteresis band reference;
- created_by/reason;
- revision/configuration hash.

## Initial kinds

### Performance

- `pace_behind`;
- `pace_ahead`;
- `recovered_on_track`;
- `target_met`;
- `target_exceeded`;
- `target_missed`;
- `final_revised`.

### Data/operational

- `evaluation_blocked`;
- `evaluation_recovered`.

No arbitrary expression builder in v1.

## Transition rules

An occurrence is created only when:

- entering a configured state/band;
- crossing an explicit target threshold;
- recovering from a notified state;
- a configured persistent condition reaches its repeat cooldown;
- a final certified state is established or revised.

No occurrence for every scheduled evaluation.

## Cooldown

Planning defaults:

- behind/ahead persistent reminder: 6 hours;
- data blocked reminder: 6 hours after 30-minute persistence;
- recovery: once per preceding occurrence;
- target met/exceeded/missed final: once per target version/final revision.

Configurable cooldown is bounded:

- minimum 30 minutes for persistent pace/data reminders;
- maximum 7 days;
- final crossing rules cannot be changed into high-frequency spam.

## Hysteresis

Pacing notifications use the same enter/exit threshold contract as state evaluation.

A behind recovery does not occur until the exit boundary is crossed.

## Rule revisions

Changing channel, cooldown, escalation, threshold or acknowledgement creates a new rule version.

Existing occurrences retain old rule/version evidence.

## Disable

Disabling a rule stops new occurrences.

Pending deliveries may be cancelled under an explicit reviewed policy; already delivered occurrences remain.

## Unknown states

Unknown state/rule/version fails closed and creates no performance notification.
