# VS-27D — Completeness-Gated Targets, Pacing and Notifications

## 1. Identity

- Pack: `0012_VS-27D`
- Version: `0.9.0`
- Baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub: #128
- Milestone: M5 — Scoped Access and Proactive Decisions
- Predecessor: VS-27C
- Completeness enabler: VS-28A
- Execution authority: none

## 2. Goal

Allow global admins to configure event or ticket-type ticket/revenue targets and allow authorised users to view pacing and receive durable notifications—without changing sales truth, sending alerts from incomplete data, exposing hidden revenue or creating a generic notification platform.

## 3. Current repository truth

Current `main` has:

- no target, target version, evaluation, rule, subscription, notification occurrence, delivery attempt or inbox resource;
- no mailer dependency or runtime sender configuration;
- user email fields but no notification verification/preferences;
- Oban and production Cron support;
- a maintenance failed-job worker that only logs and emits telemetry;
- a closed AuditLog event-type allowlist;
- no implemented B.1/B.2 completeness watermark interface yet;
- no target UI or target capability.

## 4. Predecessor law

- B.1 owns metric, period, timestamp, currency and completeness meaning.
- B.2 owns exact durable reads.
- B.3 owns display/query components and state presentation.
- C owns event scope, revenue masking and current recipient access.
- F.2 owns source freshness.
- 28A owns the completeness watermark that activates real alerts.

D may add decision state. It may not reinterpret any predecessor field.

## 5. Domain boundary

Prefer a narrow new Ash domain such as `EventSales.Decisions`.

Candidate resources:

- `SalesTarget`;
- immutable `SalesTargetVersion`;
- `TargetEvaluation`;
- optional `TargetCurrentState`;
- `TargetNotificationRule`;
- `TargetSubscription`;
- `NotificationOccurrence`;
- `NotificationDelivery`;
- `NotificationDeliveryAttempt`.

Do not generalise into marketing campaigns or arbitrary application messaging.

## 6. Target scope

V1 target dimensions:

- source system;
- event;
- optional ticket type;
- metric: B.1 `tickets_sold` or `revenue`;
- currency for revenue;
- target period start;
- due time;
- target value;
- business timezone;
- B.1 metric version;
- semantic-policy version.

No coupon, campaign, UTM, status, order or customer dimensions.

## 7. Target lifecycle

Planning states:

- draft;
- armed;
- active;
- blocked;
- completed;
- disabled.

A target may be configured before completeness exists, but cannot become `armed` or emit performance notifications until the completeness gate passes.

Edits create a new immutable target version. Previous evaluations and occurrences continue to reference their original version.

## 8. Pacing

V1 pacing is an explicitly labelled linear plan baseline, not a forecast model.

For one captured `as_of`:

```text
target_progress = actual / target_value
schedule_progress = elapsed / target_duration
pace_delta = target_progress - schedule_progress
expected_value = target_value × schedule_progress
```

All arithmetic uses Decimal.

States include:

- not_started;
- blocked_incomplete;
- blocked_stale;
- blocked_semantics;
- behind;
- on_track;
- ahead;
- met_early;
- exceeded_early;
- final_met;
- final_exceeded;
- final_missed;
- disabled.

Optional run-rate projection is shown only after an activation-approved minimum elapsed fraction and is labelled as projection, not prediction.

## 9. Hysteresis

A target version stores or references reviewed pacing thresholds.

Planning defaults:

- behind enter: pace delta <= -10 percentage points;
- behind exit: pace delta >= -5 points;
- ahead enter: pace delta >= +10 points;
- ahead exit: pace delta <= +5 points.

Exact thresholds are configurable only within reviewed bounds.

## 10. Completeness/freshness gate

Performance evaluation is eligible only when:

- target start is covered by certified history;
- selected period is complete;
- B.1/B.2 versions match the target version;
- currency is exact;
- buckets are ready through `as_of`;
- source freshness is within the approved threshold;
- no blocking semantic/source gap exists.

Blocked evaluation persists evidence but creates no under/over-target occurrence.

## 11. Final-period rule

After due time, `final_*` state is permitted only when:

- source watermark covers due time;
- bucket/read model is complete through due time;
- required correction/backfill state is certified.

Later corrections may create a reviewed `final_revised` transition. Notifications always say “as of” and retain old evidence.

## 12. Evaluation architecture

```text
recurring leader tick
→ bounded due-target enumeration
→ per-target/version/evaluation-slot job
→ B.2 read with one as_of
→ deterministic evaluator
→ current state + append-only evaluation
→ transition occurrence transaction
→ delivery outbox
```

B.2 invalidation may accelerate an evaluation, but the periodic path is the durable convergence authority.

## 13. Cadence

Planning defaults:

- scheduler tick: every minute;
- target evaluation interval: 5 minutes;
- minimum configurable interval: 5 minutes;
- maximum active interval: 60 minutes;
- bounded page and runtime;
- one unique job per target version/evaluation slot.

Activation locks final cadence against the actual B.2/F.2 queues.

## 14. Occurrences and delivery

A notification occurrence records one business transition.

A delivery records one recipient/channel projection.

Unique keys prevent duplicate occurrences and deliveries.

Evaluation commit and occurrence creation are atomic. Channel sending is asynchronous and cannot roll back the evaluation.

## 15. Recipients

V1 recipients are existing active EventSales users only.

- Admin manages target recipients.
- Users may self-subscribe only to accessible assigned events.
- Revenue notifications require current revenue capability at both subscription and dispatch.
- Revoked, expired, inactive or access-lost users are suppressed before dispatch.
- No arbitrary email address list.

## 16. Channels

### In-app

Required:

- durable inbox;
- unread/read state;
- acknowledgement where required;
- portal/admin links;
- PubSub hint and durable reload.

### Email

Optional and disabled by default.

Activation must certify:

- adapter/library;
- sender identity/domain;
- secret handling;
- idempotency key;
- provider timeout ambiguity;
- retry/backoff;
- delivery evidence;
- production canary.

No configured adapter means `channel_unavailable`, not success.

## 17. Rules

Initial rule kinds:

- behind pace;
- ahead pace;
- recovered on track;
- target met;
- target exceeded;
- target missed;
- evaluation blocked by stale/incomplete data;
- evaluation recovered.

No order/customer or marketing-campaign rules.

## 18. Cooldown/deduplication

- transition/crossing based;
- same persistent state does not notify every evaluation;
- one occurrence per target version, rule and crossing band;
- configurable bounded cooldown;
- recovery is separately deduplicated;
- final met/exceeded/missed is normally once per version;
- revised final state creates explicit revision occurrence.

## 19. Acknowledgement/escalation

- acknowledgement is user-specific and idempotent;
- default acknowledgement policy: any authorised required recipient;
- escalation only while condition persists and acknowledgement is absent;
- escalation recipients reauthorize independently;
- delivery failure is not acknowledgement;
- escalation never broadens revenue or event visibility.

## 20. UI and access

- global-admin target management;
- B.3 all-event/event target cards through a Decisions read facade;
- C portal read-only target cards and in-app inbox;
- v1 management/marketing cannot configure target values;
- C capabilities extended for viewing, subscribing and acknowledging;
- no operations/source/admin links added to portal.

## 21. Audit

Audit:

- target create/revise/disable;
- rule create/revise/disable;
- subscription change;
- acknowledgement;
- manual delivery retry/cancel if supported;
- post-28A target enablement.

Audit references target/version ids and reasons. Sensitive revenue values need not be copied into audit metadata.

## 22. Backfill sequencing

D has two production gates:

### Framework certification

Can close before 28A after proving:

- evaluator correctness with certified fixtures;
- blocked-incomplete behaviour;
- occurrence/delivery safety;
- access/revenue masking;
- in-app inbox.

### Target enablement

After 28A certification:

- verify event completeness covers target start;
- verify source/bucket freshness;
- arm selected targets;
- enable delivery per event/source;
- record explicit enablement audit.

No global override bypasses this.

## 23. Non-goals

No predictive ML, arbitrary formulas, automatic pricing/marketing actions, source calls, backfill execution, customer/order notifications, external recipient lists, WhatsApp/SMS/Slack/webhooks, broad notification platform, target editing by non-admins or access expansion.

## 24. Acceptance

Certified fixtures produce exact deterministic state. Duplicate/stale/out-of-order jobs converge. Incomplete or stale data never emits a performance claim. Hidden revenue never reaches unauthorised content. Revoked recipients are suppressed. In-app delivery, acknowledgement, cooldown, recovery and escalation are durable and auditable. Email remains disabled until separately certified. Production target delivery cannot arm before 28A completeness covers the full target period.
