# Acknowledgement and Escalation Contract

## Acknowledgement

A delivery/occurrence may require acknowledgement.

V1 default policy:

```text
any authorised required recipient acknowledges
```

Candidate evidence:

- occurrence id;
- acknowledging user id;
- acknowledged_at;
- source surface;
- audit id.

Acknowledgement is idempotent.

A user may acknowledge only while authorised to view the occurrence.

Global admin may acknowledge on behalf of operations only through an audited explicit action.

## Read versus acknowledge

- read means opened/seen in-app;
- acknowledge means responsibility accepted;
- email delivery is neither read nor acknowledge.

## Escalation eligibility

Escalate only when:

- rule requires acknowledgement;
- condition still persists under a fresh eligible evaluation;
- no valid acknowledgement;
- escalation delay elapsed;
- recipient remains authorised;
- escalation occurrence not already created.

## Escalation recipients

- configured existing users;
- independently authorised for event/metric;
- optional global admin operational recipient;
- no arbitrary external address.

## Escalation content

Must not expose more information than the escalation recipient may access.

A generic admin escalation may say evaluation requires attention without hidden commercial values.

## Recovery

When condition recovers before escalation:

- cancel pending escalation;
- optionally create recovery occurrence;
- keep original evidence.

## Access loss

Acknowledgement from a user who later loses access remains historical evidence.

That user receives no future escalation or updates.
