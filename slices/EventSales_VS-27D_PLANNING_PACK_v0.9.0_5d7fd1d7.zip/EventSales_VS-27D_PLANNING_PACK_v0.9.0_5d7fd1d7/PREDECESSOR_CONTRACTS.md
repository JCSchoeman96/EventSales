# Predecessor Contracts — VS-27D

## VS-27B.1

B.1 owns:

- `tickets_sold`;
- `revenue`;
- Decimal/currency;
- sale time and half-open periods;
- completeness states;
- semantic/metric versions.

D stores references and evaluates targets. It does not calculate alternative sales totals.

## VS-27B.2

B.2 owns:

- exact event/ticket-type reads;
- bucket readiness/freshness;
- edge periods;
- bounded query limits;
- invalidation hints.

D uses the B.2 facade only. No Sales or contribution-table reads.

## VS-27B.3

B.3 owns:

- decision page query/filter state;
- charts and metric presentation;
- source/bucket/completeness UI;
- LiveView reload patterns.

D adds target cards/inbox through explicit extension points.

## VS-27C

C owns:

- event scope;
- management/marketing capability profiles;
- revenue masking;
- portal sessions;
- revocation;
- assigned users.

D reauthorizes recipients and viewers through C at render, subscription and dispatch.

## VS-26F.2

F.2 owns source freshness and catch-up state.

D may notify that evaluation is blocked by stale data, but may not request source catch-up automatically.

## VS-28A

28A owns historical backfill and certified completeness watermark.

D performance alerts remain disabled until 28A covers the target period.
