# Recipient Subscription and Access Contract

## Recipient class

V1 recipients are existing EventSales users only.

No arbitrary email addresses or external contact lists.

## Management authority

### Global admin

May:

- assign/remove recipients;
- choose allowed channels;
- designate escalation recipients;
- view delivery state;
- retry/cancel failed deliveries;
- configure targets/rules.

### Management/Marketing user

May:

- view target progress for assigned events;
- self-subscribe/unsubscribe to allowed in-app/email channels;
- acknowledge own notifications;
- never edit target values/rules in v1.

## Capability additions to VS-27C

Planning capability names:

- `view_event_targets`;
- `subscribe_event_target_notifications`;
- `acknowledge_event_target_notifications`.

Revenue target viewing/subscription additionally requires `view_assigned_event_revenue`.

## Subscription identity

Candidate fields:

- target or event scope;
- user id;
- rule/kind;
- channel;
- active;
- created_by;
- inserted/updated timestamps.

One active subscription per exact scope/user/rule/channel.

## Access checks

At subscription creation:

- user active;
- current event assignment;
- target visible;
- metric visible;
- channel available.

At occurrence expansion and delivery:

- repeat all material checks.

At inbox render:

- repeat current event/metric access;
- hidden revenue delivery is not displayed after access loss;
- historical occurrence evidence remains admin-accessible.

## Revenue

A user without current revenue capability cannot:

- see revenue target actual/value;
- subscribe to revenue target rules;
- receive revenue message content;
- infer revenue from percentage/progress if that would reveal the hidden value under the reviewed UI contract.

The plan must decide whether a percentage-only revenue pace card is safe. Default: hide the revenue target card entirely.

## Revocation/deactivation

C access invalidation triggers delivery suppression/inbox reload.

A pending email is suppressed if access is lost before send.

Already delivered external email cannot be recalled; audit records the access state at dispatch.

## Escalation

Escalation recipients must independently pass access checks.

Global admin may receive a generic operational failure escalation without commercial values.
