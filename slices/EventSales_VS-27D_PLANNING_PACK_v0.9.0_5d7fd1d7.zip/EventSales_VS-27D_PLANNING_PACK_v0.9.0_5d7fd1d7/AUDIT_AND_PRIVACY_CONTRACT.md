# Audit and Privacy Contract

## Audit event families

Planning names:

- `sales_target_created`;
- `sales_target_revised`;
- `sales_target_armed`;
- `sales_target_disabled`;
- `target_rule_created`;
- `target_rule_revised`;
- `target_subscription_changed`;
- `target_notification_acknowledged`;
- `target_delivery_retried`;
- `target_delivery_cancelled`;
- `target_enablement_after_backfill`.

AuditLog currently has a closed allowlist, so final event types require migration/resource review.

## Audit metadata

Allowlisted examples:

- target id/version/revision;
- event/ticket type id;
- metric;
- rule id/kind;
- recipient user id;
- channel;
- prior/new lifecycle;
- reason;
- evaluation/occurrence/delivery id;
- source=`admin|portal|worker|system`.

Avoid duplicating:

- revenue target values;
- actual revenue values;
- email body;
- user email;
- provider payload;
- customer/order data;
- arbitrary config maps.

Resource/version tables retain exact target values under access control.

## Mutation transactionality

Target/rule/subscription/acknowledgement admin mutations and audit must commit together.

Evaluation occurrence evidence is system/worker evidence and may use dedicated immutable rows plus operational audit for exceptional/manual actions.

## PII

No customer PII exists in target/evaluation/notification data.

User account identity is operational personal data and should be referenced by id in durable records.

## Commercial sensitivity

Revenue targets/evaluations/notifications are access-sensitive.

Redaction and authorization apply to:

- DTOs;
- LiveView assigns;
- inbox;
- email;
- exports;
- audit UI;
- telemetry/logs.

## Logging/telemetry

Use low-cardinality:

- rule kind;
- channel;
- result;
- blocked reason;
- queue;
- state;
- counts/durations.

Do not tag target/event/user ids as telemetry dimensions.
