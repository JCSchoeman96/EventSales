# Mandatory File Inventory — VS-27D

## Governance and roadmap
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`
- final VS-27B.1/B.2/B.3 artifacts;
- final VS-27C artifacts;
- final VS-26F.2 artifacts;
- current VS-28A pack/plan/certification state.

## Current analytics/decision inputs
- certified B.1 metric/completeness modules;
- certified B.2 reader/resources/topics;
- certified B.3 decision facades/DTOs/components/LiveViews;
- certified C capability/scope/revenue/inbox/session files;
- certified F.2 freshness/read files.

## Accounts/access
- `lib/event_sales/accounts/resources/user.ex`
- `lib/event_sales/accounts/policies.ex`
- `lib/event_sales/accounts/pii_policy.ex`
- final C capability and grant files/tests.

## Current infrastructure
- `mix.exs`
- `mix.lock`
- `config/config.exs`
- `config/runtime.exs`
- `config/test.exs`
- `lib/event_sales/application.ex`
- `lib/event_sales/repo.ex`
- `railway.toml`
- `docs/architecture/oban-pgbouncer.md`
- `docs/runbooks/oban-queue-backlog.md`

## Existing worker patterns
- `lib/event_sales/maintenance/failed_job_alert_worker.ex`
- `lib/event_sales/maintenance/oban_queue_snapshot_worker.ex`
- worker tests;
- B.2/F.2/C scheduler/worker implementations.

## Audit
- `lib/event_sales/audit/logger.ex`
- `lib/event_sales/audit/metadata_sanitizer.ex`
- `lib/event_sales/audit/resources/audit_log.ex`
- audit migrations/resource snapshots/tests.

## Web/UI
- certified B.3 admin dashboard/event pages;
- certified C portal shell/routes/inbox;
- `lib/event_sales_web/router.ex`
- `assets/js/app.js`
- `assets/css/app.css`
- admin/portal navigation components.

## Static/security boundaries
- `scripts/check_no_web_woocommerce_refs.sh`
- PII/domain boundary tests;
- project index/module manifest files;
- CI quality aliases.

## Migrations
- all current Analytics/Accounts/Audit migrations;
- final B/C/F/28A migrations;
- Oban schema/version as deployed.

## External channel state
- dependency/config search for mailer/provider;
- Railway sender-related environment evidence;
- sender-domain/provider operational documentation if email is proposed.
