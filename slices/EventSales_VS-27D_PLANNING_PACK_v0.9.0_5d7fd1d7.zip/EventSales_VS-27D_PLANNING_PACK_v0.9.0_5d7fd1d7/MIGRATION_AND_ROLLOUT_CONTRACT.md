# Migration and Rollout Contract

## Expected additive changes

Potential additions:

- `EventSales.Decisions` Ash domain;
- target and immutable version resources;
- evaluation/current-state resources;
- rule/subscription resources;
- occurrence/delivery/attempt resources;
- audit event-type additions;
- Oban `decisions`/`notifications` queues;
- scheduler Cron composition;
- admin/portal routes/components;
- channel adapter configuration;
- feature/enablement flags.

No B.1/B.2 schema reinterpretation.

## Queue direction

Planning queues:

- `decisions`: target enumeration/evaluation;
- `notifications`: occurrence expansion and delivery.

Initial concurrency is activation-controlled.

Do not put email delivery on webhook/source-critical queues.

## Cron composition

Current production runtime replaces Oban plugins with a Cron list.

Future B/F packs may add Cron entries.

Activation must merge the final current plugin configuration rather than overwrite it.

## Migrations

- additive and disabled first;
- no target creation or evaluation inside migration;
- no delivery inside migration;
- generated Ash migrations reviewed;
- unique dedupe/index constraints explicit;
- populated-table indexes assessed;
- direct/session-capable migration route verified;
- rollback does not delete audit/evidence after use.

## Rollout phases

### Stage A — Domain/evaluator

1. Deploy resources and queues disabled.
2. Verify migrations/indexes.
3. Enable fixture/staging evaluator.
4. Verify deterministic parity and blocked states.
5. Enable production observation with delivery disabled.
6. Confirm all real events remain blocked until completeness.

### Stage B — In-app notifications

1. Enable occurrence and in-app delivery for certified test scope.
2. Verify dedupe/cooldown/recovery.
3. Verify C revenue/access suppression.
4. Verify acknowledgement/escalation.
5. Keep production performance enablement off.

### Stage C — UI

1. Enable admin target UI.
2. Add B.3 cards under feature flag.
3. Add C portal inbox/cards after C certification.
4. Verify privacy/accessibility/load.

### Stage D — Optional email

Only after channel certification.

### Stage E — Post-28A target enablement

Per `BACKFILL_ENABLEMENT_CONTRACT.md`.

## Kill switches

- target scheduler;
- target evaluation;
- occurrence creation;
- in-app delivery;
- email delivery;
- escalation;
- dashboard cards;
- portal inbox;
- per-source/event target enablement.

## Stop conditions

- B/C predecessor interface unresolved;
- performance alert from incomplete/stale data;
- raw Sales/source call;
- duplicate occurrence/delivery;
- hidden revenue leak;
- access loss not suppressing send;
- fake email success;
- Cron overwrite removes predecessor schedules;
- queue impacts critical ingestion;
- no clean disable/rollback.
