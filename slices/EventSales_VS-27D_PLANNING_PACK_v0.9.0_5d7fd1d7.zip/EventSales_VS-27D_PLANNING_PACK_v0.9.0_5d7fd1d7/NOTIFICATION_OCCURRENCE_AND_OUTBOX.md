# Notification Occurrence and Outbox Contract

## Business occurrence

A `NotificationOccurrence` is an immutable business fact that a reviewed rule crossed.

Candidate fields:

- id;
- target_id/version_id;
- evaluation_id;
- rule_id/version;
- event_id;
- optional ticket_type_id;
- occurrence kind;
- severity;
- transition from/to;
- dedupe key;
- occurred_at;
- condition_active;
- recovery_of_occurrence_id;
- requires_acknowledgement;
- escalation_due_at;
- content-template version;
- commercial-visibility class;
- evidence hash.

## Dedupe identity

The exact key is locked by plan, but must include enough to prevent duplicates without suppressing legitimate recovery/revision:

```text
target version
+ rule version
+ occurrence kind/crossing band
+ transition sequence/evaluation evidence
```

Database uniqueness is authority.

Oban uniqueness is optimisation only.

## Delivery outbox

`NotificationDelivery` is one occurrence projected to one recipient/channel.

Candidate fields:

- occurrence_id;
- recipient_user_id;
- channel;
- status;
- available_at;
- delivered_at;
- read_at;
- acknowledged_at;
- acknowledged_by_user_id;
- suppressed_reason;
- attempt_count;
- last_attempt_at;
- provider_message_id/hash where allowed;
- inserted/updated timestamps.

Unique:

```text
occurrence_id + recipient_user_id + channel
```

## Delivery states

- pending;
- sending;
- delivered;
- failed_retryable;
- failed_terminal;
- suppressed;
- cancelled;
- unknown_provider_outcome.

## Transaction boundary

Evaluation and occurrence commit together.

Recipient expansion/delivery rows may:

1. be created in the same transaction when bounded; or
2. be durably expanded by a separate occurrence-drainer.

Either way, occurrence existence is the durable source.

## Access recheck

Before creating/sending/displaying delivery:

- user active;
- event access current;
- profile capability current;
- revenue visibility current for revenue content;
- subscription/rule current;
- occurrence still relevant for escalation where required.

Loss of access suppresses delivery. It does not delete occurrence evidence.

## Content

Content is rendered from:

- occurrence/evaluation evidence;
- authorised visibility projection;
- reviewed template version.

Do not persist arbitrary rendered HTML or provider payload as authority.

## Manual retry

Global admin may retry a terminal/unknown delivery only through an audited workflow after reviewing the failure.

Retry does not create a duplicate occurrence.
