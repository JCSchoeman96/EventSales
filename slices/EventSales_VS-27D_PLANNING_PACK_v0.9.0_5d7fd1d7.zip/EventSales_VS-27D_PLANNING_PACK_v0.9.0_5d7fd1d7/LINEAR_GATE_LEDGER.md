# Linear Gate Ledger — VS-27D

The Linear workspace free issue limit prevents creation of the normal child-issue chain.

The following gates remain mandatory and must be mapped to issue cards when capacity becomes available:

1. PACK — create immutable ZIP.
2. PACK REVIEW — independent pack review.
3. PLAN — agent current-code implementation plan.
4. PLAN REVIEW — independent plan review.
5. ACTIVATE — exact baseline/interfaces/topology refresh.
6. IMPLEMENT — tests-first staged implementation.
7. PR REVIEW — exact-head independent review.
8. MERGE/DEPLOY — separate authorisation.
9. VALIDATE FRAMEWORK — production observation/in-app certification.
10. CLOSE FRAMEWORK — record certification; alerts still completeness-gated.
11. POST-28A ENABLEMENT — per-event/target reviewed activation.
12. ENABLEMENT VALIDATION — prove real target delivery.
13. FINAL CLOSE — record enabled scope.

No document/comment state can replace explicit approval verdicts.
