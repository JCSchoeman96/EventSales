# Current Code Target and Notification Map

| Current area | Existing behaviour | VS-27D implication |
|---|---|---|
| Targets | none | new narrow Decisions domain |
| Completeness | planning docs only on current main | activation consumes final B/28A interface |
| User contact | account email field | not yet a certified delivery preference |
| Email sender | no dependency/config | email optional and disabled |
| In-app inbox | none | required durable v1 channel |
| Oban | available; prod Cron exists | reuse one leader tick and bounded workers |
| Base Oban plugins | empty | runtime composition must preserve predecessor cron |
| FailedJobAlertWorker | logs/telemetry only | not a delivery framework |
| AuditLog | closed event-type list | add reviewed target/notification events |
| PubSub | infrastructure exists | hint only, durable inbox is truth |
| Roles/access | admin/event grants on current main | activation consumes final C capabilities |
| Dashboard | current legacy implementation | activation consumes final B.3 extension points |
