# Pacing and State Contract

## Inputs

For one target version and captured `as_of`:

- actual B.2 metric value;
- target value;
- target start/due;
- previous persisted state;
- completeness/freshness eligibility;
- threshold/hysteresis configuration.

## Decimal formula

Let:

```text
elapsed = clamp(as_of - starts_at, 0, due_at - starts_at)
duration = due_at - starts_at
schedule_progress = elapsed / duration
target_progress = actual / target_value
pace_delta = target_progress - schedule_progress
expected_value = target_value × schedule_progress
```

All divisions and multiplications use Decimal with an explicitly reviewed precision policy.

No float authority.

## Run-rate projection

```text
projected_at_due = actual / schedule_progress
```

Only when:

- target started;
- schedule progress >= configured minimum;
- actual is eligible;
- duration non-zero;
- data complete/fresh;
- result within numeric bounds.

Label: `Run-rate projection`, not forecast.

## State precedence

1. disabled;
2. not_started;
3. blocked_*;
4. final state after due and final eligibility;
5. met/exceeded early;
6. behind/ahead/on_track.

## Early threshold state

- actual == target -> `met_early`;
- actual > target -> `exceeded_early`.

Because refunds/corrections can reduce net values, these states may later recover/reverse.

## Hysteresis

Planning defaults:

- enter behind at <= -0.10;
- remain behind until >= -0.05;
- enter ahead at >= +0.10;
- remain ahead until <= +0.05.

When previous state is neither behind nor ahead, values between thresholds are `on_track`.

Threshold ordering is validated.

## Final state

After due time and final eligibility:

- actual < target -> `final_missed`;
- actual == target -> `final_met`;
- actual > target -> `final_exceeded`.

If later certified corrections alter actual, create a new evaluation and explicit `final_revised` occurrence. Do not delete prior evidence.

## Zero/invalid values

Target value must be positive.

Unknown/mixed currency, missing metric, invalid period or contract drift blocks evaluation.

## Presentation

Every result includes:

- actual;
- target;
- expected;
- target progress;
- schedule progress;
- pace delta;
- state;
- as_of;
- projection when defined;
- eligibility;
- completeness/freshness;
- contract versions.
