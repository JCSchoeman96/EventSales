# Channel and Delivery Contract

## Required channel: in-app

In-app is a durable delivery row rendered through admin/portal inbox facades.

Requirements:

- unread/read;
- acknowledgement where required;
- event/target link;
- severity and occurrence time;
- current access projection;
- PubSub invalidation hint;
- durable reload on mount/reconnect;
- bounded pagination;
- no customer/order PII.

A delivery may be considered `delivered` when durably available in the inbox, not when viewed.

## Optional channel: email

Email is disabled unless activation certifies all of:

- selected adapter/library and version;
- sender domain/address;
- credentials/secrets;
- transport timeout;
- provider idempotency support or safe ambiguity policy;
- retry/backoff;
- production test recipient;
- bounce/rejection visibility;
- content/security review;
- runtime kill switch.

Current repo has no email dependency or sender configuration. Planning agents must not assume one.

## Email adapter boundary

Recommended behaviour:

```elixir
deliver(delivery, rendered_message, idempotency_key)
```

Return:

- delivered with provider id;
- retryable failure;
- terminal failure;
- ambiguous/unknown outcome;
- channel unavailable.

No provider-specific type leaks into domain state.

## Retry

Planning defaults:

- maximum 5 attempts;
- exponential backoff with jitter;
- hard timeout;
- one Oban job per delivery id;
- database delivery status is authority.

## Ambiguous timeout

If provider may have accepted the message but response is unknown:

- record `unknown_provider_outcome`;
- do not blindly resend unless provider idempotency guarantees safety;
- surface for admin review/reconciliation.

## Privacy/content

Email contains only event/target aggregate data recipient may currently view.

No customer/order data.

Revenue content is rendered only after dispatch-time capability check.

## Excluded channels

- SMS;
- WhatsApp;
- Slack;
- arbitrary webhook;
- push notification.

These require separate provider, identity, consent, retry and privacy contracts.
