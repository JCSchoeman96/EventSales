# VS-27D Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- B.1/B.2/B.3/C/F.2 versions:
- 28A certification:
- Framework/target enablement mode:
- Target/event/user ids redacted:

## Target/version
- scope/metric/currency:
- period:
- target/revision/config hash:
- lifecycle:
- audit:

## Evaluation truth
| Case/as_of | Actual | Expected | Pace delta | State | Eligible | Result |
|---|---:|---:|---:|---|---|---|

- Decimal precision:
- hysteresis:
- projection minimum:
- final/revision:
- B.2 evidence:
- completeness/freshness:

## Concurrency
- duplicate scheduler:
- duplicate job:
- stale older job:
- transaction rollback:
- occurrence dedupe:
- delivery dedupe:
- repair drainer:

## Notification
- rule/cooldown:
- transition/recovery:
- recipients:
- access recheck:
- revenue masking:
- in-app read/ack:
- escalation:
- email status:
- ambiguous outcome:

## Queues/Cron
- existing entries preserved:
- decisions queue:
- notifications queue:
- backlog/runtime:
- kill switches:

## Privacy
- no customer/order PII:
- no hidden revenue:
- no arbitrary external recipient:
- no provider payload/secrets:
- telemetry low-cardinality:

## Backfill gate
- before 28A blocked:
- performance occurrence count: 0
- enablement supplement:
- per-target canary:
- regression block:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
