# VS-27D Acceptance Checklist

## Planning and activation
- [ ] Exact current main recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-27B.1/B.2/B.3 certified.
- [ ] VS-27C certified.
- [ ] VS-26F.2 interface refreshed.
- [ ] VS-28A completeness state explicit.
- [ ] Linear gate ledger mapped.
- [ ] Activation verdict APPROVE.

## Target law
- [ ] Stable target identity.
- [ ] Immutable target versions.
- [ ] Event/source/ticket scope validated.
- [ ] Metric allowlist.
- [ ] Currency exact for revenue.
- [ ] Positive target value.
- [ ] Valid half-open period.
- [ ] Contract versions stored.
- [ ] No historical reinterpretation.

## Pacing
- [ ] Decimal-only formula.
- [ ] Linear-plan wording.
- [ ] Schedule/target progress.
- [ ] Expected value and pace delta.
- [ ] Projection minimum elapsed bound.
- [ ] State precedence.
- [ ] Hysteresis enter/exit.
- [ ] Early and final states.
- [ ] Correction/final revision handling.

## Completeness/freshness
- [ ] Certified boundary covers target start.
- [ ] Requested period complete.
- [ ] B.2 ready through as_of.
- [ ] F.2 source fresh.
- [ ] Versions/currency match.
- [ ] Blocked reasons explicit.
- [ ] No performance occurrence while blocked.
- [ ] No admin override.
- [ ] Post-28A arming audit.

## Evaluation
- [ ] One captured as_of.
- [ ] Bounded scheduler.
- [ ] Stable due-target ordering.
- [ ] Per-version/slot idempotency.
- [ ] Monotonic current-state update.
- [ ] Stale-job rejection.
- [ ] Append-only evidence.
- [ ] Evaluation + occurrence atomic.
- [ ] B.2-only read.
- [ ] PubSub acceleration only.

## Rules and occurrences
- [ ] Initial rule kinds bounded.
- [ ] Transition/crossing based.
- [ ] Durable dedupe key.
- [ ] Cooldown bounds.
- [ ] Recovery occurrence.
- [ ] Final once/revision.
- [ ] Rule revisions immutable.
- [ ] Disable semantics.

## Recipients/access
- [ ] Existing active users only.
- [ ] Admin manages target/rules.
- [ ] Management/marketing read-only.
- [ ] Self-subscribe only assigned events.
- [ ] Revenue capability at subscribe/dispatch/render.
- [ ] Revoked/inactive recipient suppressed.
- [ ] No arbitrary addresses.
- [ ] No hidden percentage inference.

## In-app
- [ ] Durable inbox.
- [ ] Bounded pagination.
- [ ] Read/unread.
- [ ] Acknowledgement.
- [ ] PubSub hint + durable reload.
- [ ] Admin and portal projections.
- [ ] No PII/orders.

## Email
- [ ] Disabled by default.
- [ ] Adapter/sender/secrets certified if enabled.
- [ ] Provider idempotency/ambiguity policy.
- [ ] Retry/backoff.
- [ ] Delivery canary.
- [ ] Channel unavailable not success.
- [ ] No provider raw payload.

## Escalation
- [ ] Requires persistent condition.
- [ ] Requires missing acknowledgement.
- [ ] Independent recipient authorization.
- [ ] Unique escalation.
- [ ] Recovery cancels pending.
- [ ] Delivery failure not acknowledgement.

## Audit/privacy
- [ ] Closed AuditLog allowlist updated.
- [ ] Mutation + audit atomic.
- [ ] Metadata allowlisted.
- [ ] Revenue values not duplicated unnecessarily.
- [ ] No customer/order PII.
- [ ] No target/event/user telemetry cardinality leak.
- [ ] Token/provider secrets absent.

## Queues/Cron
- [ ] Separate decisions/notifications queues.
- [ ] Existing Cron entries preserved.
- [ ] Kill switches.
- [ ] Source-critical queues unaffected.
- [ ] Backlog/latency telemetry.
- [ ] Failed delivery repair.

## UI
- [ ] Admin target management.
- [ ] B.3 target cards.
- [ ] C portal read-only cards/inbox.
- [ ] No pacing calculation in web/client.
- [ ] Blocked state clear.
- [ ] Projection labelled.
- [ ] Accessibility/mobile.
- [ ] No non-admin target editing.

## Tests
- [ ] Ticket and revenue fixtures.
- [ ] Every pacing boundary.
- [ ] Hysteresis/flapping.
- [ ] Incomplete/stale/mixed currency.
- [ ] Duplicate/stale/out-of-order jobs.
- [ ] Correction/final revision.
- [ ] Dedupe/cooldown/recovery.
- [ ] Access revocation before delivery.
- [ ] Hidden revenue.
- [ ] Acknowledgement/escalation.
- [ ] Email unavailable/ambiguous.
- [ ] Cron composition.
- [ ] Fifty-viewer/load/backlog.
- [ ] Full CI.

## Production
- [ ] Framework observation.
- [ ] All real targets blocked before 28A.
- [ ] In-app certified test scope.
- [ ] Email remains disabled unless certified.
- [ ] Post-28A per-event enablement supplement.
- [ ] Rollback tested.
