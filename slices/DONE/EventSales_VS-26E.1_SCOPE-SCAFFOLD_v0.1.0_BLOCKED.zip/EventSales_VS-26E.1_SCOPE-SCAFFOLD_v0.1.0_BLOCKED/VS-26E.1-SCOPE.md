# VS-26E.1 — Targeted WordPress Catalog Change Trigger

## Outcome

A relevant production WordPress/Tickera event, WooCommerce ticket product, or variation change emits a compact authenticated PII-free signal to EventSales.

EventSales durably deduplicates and coalesces the signal and queues one bounded targeted Catalog Sync dry-run through the existing lifecycle.

This slice does not auto-apply catalog changes.

## Authority

WordPress signal
→ authenticated EventSales intake
→ durable idempotency/coalescing/defer state
→ Oban
→ existing TickeraCatalogSync dry-run lifecycle

No parallel Event, TicketType, or ProductMapping writer may be introduced.

## Required behaviour

- Select correct hooks for events, products, variations, statuses, and relevant metadata.
- Suppress autosaves, revisions, and irrelevant duplicate hooks.
- Emit one versioned bounded event/product/variation target.
- Use a reviewed signature, source identity, timestamp, and replay contract.
- Keep customer, order, and payment data out of the signal.
- Return quickly so editing is not coupled to EventSales completion.
- Durably deduplicate retries and coalesce bursts.
- Defer safely while another Catalog Sync run is active.
- Reuse the existing feed adapter, planner, findings, dry-run, and Apply authority.
- Show accepted, queued, deferred, resulting-run, and failure status safely.
- Target normal visibility in less than five minutes.

## Non-goals

- No auto-apply; that belongs to VS-26E.2.
- No periodic sweep; that belongs to VS-26E.3.
- No order catch-up/backfill.
- No OrderUpserter, payment, refund, scanner, delivery, import, or dashboard redesign.
- No WordPress write-back.
- No full-feed request for every save.
