# Questions the Final Pack Must Resolve

## WordPress
- Which hooks represent logical event/product/variation changes?
- Which hooks duplicate during normal edits?
- How are autosaves, revisions, bulk edits, and imports handled?
- How are private, draft, trash, and deletion transitions represented?

## Contract
- What exact versioned fields are required?
- What bytes are signed?
- What algorithm, key rotation, timestamp skew, and replay window apply?
- What deterministic idempotency key distinguishes retries from later edits?

## Durable intake
- Is a new Ash resource/table required?
- What transaction guarantees accepted receipt plus queued work?
- How is enqueue failure recovered?
- How are bursts coalesced and retained?

## Active run
- How is a signal durably deferred while a sync is active?
- How is deferred work replayed after completion or failure?

## Targeted discovery
- Does the existing feed support event/product/variation filters?
- What related variations are included?
- How is full-feed fallback prevented?

## Rollout
- Which side deploys first?
- What compatibility window and feature flag are required?
- What production edit is safe for validation?
