# Final Pack Requirements

When JC-114 activates, the baseline-locked pack should contain:

- README.md
- VS-26E.1-FEATURE_PACK.md
- CODING_AGENT_PROMPT.md
- REVIEWER_PROMPT.md
- TOON_PROMPTS.md
- ACCEPTANCE_CHECKLIST.md
- FILE_INVENTORY.md
- REPO_BASELINE.json
- pack.json
- checksums.sha256
- implementation/review/Linear report templates
- deployment, migration, WordPress rollout, validation, rollback, and failure runbooks
- redacted evidence template

The ZIP must be generated mechanically from reviewed canonical GitHub source and locked to the exact certified `main` SHA.
