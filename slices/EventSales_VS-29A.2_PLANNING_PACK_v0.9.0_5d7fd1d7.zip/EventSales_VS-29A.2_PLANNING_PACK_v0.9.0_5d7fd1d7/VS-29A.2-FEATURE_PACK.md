# VS-29A.2 — Bounded Acquisition Projection and Aggregates

## 1. Goal

Create a durable, versioned and bounded acquisition aggregate layer that labels certified ticket and revenue contributions with certified order-level acquisition evidence.

## 2. Authority chain

```text
B.1 metric and time law
→ B.2 certified contribution projection
                                                           → A.2 acquisition projection
                             /
A.1 acquisition snapshot and coverage
→ dimension policy and classification versions
→ durable acquisition dirty keys
→ exact hour/day recomputation
→ bounded acquisition reader
```

A.2 never recalculates ticket quantity, revenue, refund, tax or fee values from `Order`, `OrderItem` or raw payloads.

## 3. Current repository truth

Current `main` has:

- only `EventAggregateSnapshot` and `DailySalesAggregateSnapshot` in the Analytics domain;
- no durable contribution projection;
- no hour bucket;
- no acquisition resource;
- no acquisition dimension registry;
- no acquisition dirty-key authority;
- no acquisition bucket reader;
- event-wide `SnapshotRefresh` reads;
- in-memory daily filtering;
- current `MetricRules` calculated directly from `Order` and `OrderItem`;
- best-effort notifier-driven hot-state invalidation.

Pack 18 therefore defines a future integration seam and must be refreshed against final B.2/A.1 code before implementation.

## 4. Core parity

For every supported source, event scope, ticket-type scope, currency, time window and version tuple:

```text
covered acquisition totals
+ uncovered acquisition totals
= certified B.2 base totals
```

For each enabled full-partition dimension:

```text
sum(all dimension members including sentinels)
= covered acquisition totals
```

A parity mismatch is a blocking data-quality state, not a dashboard warning to ignore.

## 5. Initial measures

Additive v1 measures:

- gross ticket quantity;
- reversal ticket quantity;
- net ticket quantity;
- gross recognised ticket revenue;
- refund/reversal ticket revenue;
- net recognised ticket revenue;
- covered and uncovered equivalents;
- internal contribution-row count for diagnostics only.

Not included:

- conversion rate;
- sessions;
- visitors;
- customers;
- first-touch or multi-touch credit;
- ad cost;
- CPA;
- ROAS;
- inferred distinct order count.

## 6. Distinct-order boundary

Distinct order counts are non-additive across event, ticket type, time and dimension partitions.

A.2 v1 must return `unsupported` for distinct order count unless activation approves dedicated exact order/order-event facts with their own metric law.

It may never sum event bucket order counts to produce an all-event count.

## 7. Coverage classes

Every base contribution receives exactly one acquisition coverage class:

- `covered_classified`;
- `covered_unclassified`;
- `uncovered`.

Observed but unknown source evidence remains covered/unclassified.

Pre-enablement, feature-disabled, unsupported, missing, malformed, over-bound and conflict evidence remain uncovered.

No contribution disappears because acquisition evidence is absent.

## 8. Fixed aggregate dimensions

Planning v1 candidates:

- coverage class;
- origin class;
- source;
- source + medium;
- campaign;
- optional device class.

Disabled by default pending cardinality evidence:

- content;
- term;
- referrer host;
- source platform;
- creative format;
- marketing tactic.

No arbitrary caller-supplied dimension list.

## 9. Sentinels

Every enabled dimension uses exact sentinel members such as:

- `not_provided`;
- `not_applicable`;
- `unknown`;
- `unclassified`;
- `overflow`.

`uncovered` remains a coverage partition, not a fake campaign/source member.

## 10. Projection

One acquisition projection row derives from:

- one final B.2 contribution identity/revision;
- one A.1 acquisition snapshot fingerprint/revision;
- one aggregation policy version;
- one classification version.

Projection mutation and every old/new dirty key commit together.

## 11. Buckets

Planning tables:

- event hour acquisition bucket;
- event day acquisition bucket;
- ticket-type hour acquisition bucket;
- ticket-type day acquisition bucket;
- durable acquisition dirty bucket;
- projection/repair watermark resources.

Postgres is authority. Oban uniqueness and PubSub are optimisations/signals only.

## 12. Reader

A non-web `AcquisitionBucketReader` provides:

- bounded event/ticket-type scope;
- B.1 windows/resolution/as-of;
- one enabled dimension kind;
- optional selected dimension members;
- exact totals and ordered series;
- top-N plus exact `other`;
- coverage ratios;
- base parity state;
- sales completeness;
- acquisition coverage;
- source, projection and bucket freshness;
- all contract versions;
- explicit missing, rebuilding, partial and unsupported states.

No raw Sales fallback.

## 13. Correction and rebuild

These changes dirty old and new keys:

- B.2 contribution revision;
- refund/reversal;
- event or ticket-type remap;
- sale timestamp change;
- currency change;
- A.1 evidence/source-version change;
- acquisition correction;
- normalisation/classification policy change;
- dimension policy change.

## 14. Non-goals

- no dashboard or route;
- no acquisition export;
- no source tracking changes;
- no compact v2 changes;
- no alias-management UI;
- no coupon allocation;
- no raw-order reader;
- no approximate distinct counts;
- no retention purge;
- no direct B.2 bucket mutation.

## 15. Exit gate

A sale, refund, remap, acquisition evidence change and reviewed correction each converge idempotently to exact old/new acquisition buckets. Reader totals reconcile to certified B.2 values, dimension partitions reconcile to covered totals, and no raw Sales scan or PII is used.
