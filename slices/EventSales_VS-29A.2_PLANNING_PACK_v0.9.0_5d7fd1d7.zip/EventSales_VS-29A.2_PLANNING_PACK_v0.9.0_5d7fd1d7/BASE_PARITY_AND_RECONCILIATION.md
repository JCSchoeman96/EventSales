# Base Parity and Reconciliation Contract

## Primary invariant

For an identical base bucket key/version:

```text
A.2 coverage_class=covered_classified
+ A.2 coverage_class=covered_unclassified
+ A.2 coverage_class=uncovered
= B.2 base bucket
```

Compare every additive measure exactly with Decimal/integer arithmetic.

## Dimension invariant

For any dimension kind declared `full_partition` by policy:

```text
sum(all member buckets including sentinels and overflow)
= covered_classified + covered_unclassified
```

No top-N limit participates in parity.

## Parity states

- `pending`;
- `verified`;
- `mismatch`;
- `base_missing`;
- `acquisition_missing`;
- `version_mismatch`;
- `unsupported`.

## Mismatch evidence

Record safe:

- bucket key hash;
- scope/time/version ids;
- expected and observed numeric differences;
- revisions;
- detected at;
- attempts;
- finding/case id.

Do not record raw campaign/source values.

## Reader behaviour

- `verified` → normal;
- `pending` → updating;
- mismatch/base missing/version mismatch → incomplete/error;
- no fallback to raw Sales;
- never hide mismatch by replacing with base totals.

## Repair

Parity repair may:

- rebuild A.2 projection;
- rebuild A.2 bucket;
- request final B.2 rebuild through its public interface;
- reopen a Pack 15 issue/case.

It may not directly edit B.2 or A.2 bucket numeric fields.

## Canary

Initial canary requires zero mismatches across:

- sale;
- status change;
- full refund;
- partial refund;
- event remap;
- ticket-type remap;
- A.1 evidence update;
- correction/reversal;
- duplicate and stale replay.
