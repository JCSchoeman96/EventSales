# Test Matrix

## Projection

- base contribution with classified A.1 evidence;
- covered unclassified evidence;
- each uncovered state;
- missing A.1 snapshot;
- duplicate/equal revision;
- stale base revision;
- stale A.1 revision;
- equal vector/different projection conflict;
- contribution inactivation;
- transaction rollback;
- old/new dirty keys.

## Dimensions

- every fixed dimension kind;
- sentinels;
- source+medium tuple identity;
- Unicode/case/display independence;
- cap admission;
- overflow;
- hash collision defence;
- policy version change;
- disabled dimension;
- no aliases.

## Measures

- gross sale;
- partial/full refund;
- net zero;
- negative net edge if B.1 permits;
- event remap;
- ticket-type remap;
- timestamp move;
- currency move;
- semantic correction;
- acquisition correction.

## Parity

- covered + uncovered equals base;
- origin partition equals covered;
- source partition includes not-provided;
- campaign partition includes not-provided/overflow;
- missing base bucket;
- version mismatch;
- delayed B.2 bucket;
- mismatch repair;
- Decimal exactness.

## Buckets

- event hour/day;
- ticket-type hour/day;
- built zero;
- missing not zero;
- stale worker fencing;
- duplicate dirty rows;
- worker crash/retry;
- repair cursor;
- PubSub after commit.

## Reader

- bounded range/events;
- one dimension only;
- top N and exact other;
- keyset page;
- all-event complete event set;
- no UI pagination totals;
- edge windows;
- comparison;
- mixed currency rejection;
- missing/rebuilding/mismatch;
- all versions/freshness/coverage.

## Distinct orders

- reader reports unsupported;
- no contribution count presented as orders;
- no event-sum all-event order count.

## Privacy/static

- no raw source/campaign telemetry labels;
- no PII fields in projection/bucket/PubSub/error;
- no web/source calls;
- no Sales/MetricRules references in A.2 evaluator;
- no dashboard/export route.

## Load

- 25k contributions;
- maximum dimension fan-out;
- 100 events;
- 50 concurrent reader simulations;
- correction storm;
- rebuild restart;
- query plans.
