# VS-29A.2 Implementation Plan

## 1. Baseline and drift proof
## 2. Files/predecessors inspected
## 3. Current-code gap verification
## 4. Final B.2 contribution interface
## 5. Final B.2 invalidation/repair/reader interface
## 6. Final A.1 snapshot/coverage interface
## 7. Quantitative-copy boundary
## 8. Projection identity/revision vector
## 9. Coverage partition
## 10. Aggregation policy/version
## 11. Dimension kinds/sentinels
## 12. Member identity/cardinality/overflow
## 13. Projection transaction/old-new keys
## 14. Durable outbox/repair
## 15. Event hour/day resources
## 16. Ticket-type hour/day resources
## 17. Dirty-bucket resource
## 18. Exact recompute/revision fencing
## 19. Base/dimension parity
## 20. Edge-window reads
## 21. Reader inputs/outputs/bounds
## 22. Top-N/exact other/keyset
## 23. All-event scope
## 24. Distinct-order decision
## 25. Completeness/coverage/freshness
## 26. Correction/reclassification
## 27. Versioning/retention
## 28. Migrations/indexes/query plans
## 29. Queue/concurrency/retries
## 30. Tests-first sequence
## 31. Exact files/dependencies/config/generated files
## 32. Static/privacy boundaries
## 33. Child PR sequence
## 34. Rollout/shadow/canary
## 35. Rollback/stop conditions
## 36. Production evidence
## 37. Linear M8 gates
## 38. VS-29A.3 handoff
## 39. Prohibited actions
## 40. Verdict
