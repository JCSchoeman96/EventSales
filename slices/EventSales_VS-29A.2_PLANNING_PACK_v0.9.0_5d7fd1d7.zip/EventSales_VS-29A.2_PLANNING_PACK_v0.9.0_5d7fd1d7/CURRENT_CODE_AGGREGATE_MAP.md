# Current Code Aggregate Map

| Current area | Current behaviour | Pack 18 implication |
|---|---|---|
| Analytics domain | registers event and daily snapshots only | additive future resources; activation refresh required |
| Event snapshot | one mutable row/event with total/today/status | not acquisition authority |
| Daily snapshot | one row/event/day with repeated total/today fields | not suitable for dimensions |
| SnapshotRefresh | loads all event OrderItems and relationships | no acquisition extension here |
| Daily refresh | filters loaded rows in memory by completed date | final B.2 hour/day engine required |
| MetricRules | completed-only quantity/revenue from raw Order/OrderItem | A.2 must not call it directly |
| OrderProcessedNotifier | best-effort cache/hot-state signal | cannot be durable projection authority |
| AggregateEvent | event recompute signal, rejects deltas | keep signal-only doctrine |
| Hot state | whole-event recompute/read-model | not durable acquisition truth |
| AdminDashboard | page-bounded events and 1,000 ticket rows | no acquisition dashboard in A.2 |
| EventSalesCsv | legacy raw SQL/offset export | no acquisition export in A.2 |
| Sales resources | no acquisition snapshot on current main | A.1 implementation prerequisite |
| B.2 resources | absent on current main | exact interfaces must be activated later |
