# VS-29A.2 Redacted Evidence

- Pack/plan/activation:
- Child stage:
- PR/head/deployed SHA:
- Final A.1/B.2 versions:
- Aggregation policy/hash:
- Version tuple:
- Approved scope:

## Projection
- base contribution rows:
- A.2 projection rows:
- classified:
- unclassified:
- uncovered:
- missing/conflict:
- dimension members:
- overflow:
- dirty keys:
- duplicate/restart/repair:
- numeric copy proof:

## Buckets
- event hour/day:
- ticket-type hour/day:
- built zero:
- stale fencing:
- dirty satisfied:
- base parity:
- dimension parity:
- pending/mismatch:
- corrections/refunds/remaps:

## Reader
- queries/scopes:
- top-N/other:
- edge windows:
- all-event:
- mixed currency:
- completeness/coverage/freshness:
- versions:
- distinct-order unsupported:
- p50/p95/load/query plans:

## Privacy/static
- PII seed:
- URL/query/click id:
- source/campaign telemetry labels:
- raw Sales references:
- source/web calls:
- web/routes/exports:
- verdict:

## Negative proof
- no second metric engine:
- no omitted uncovered contributions:
- no dynamic cross-products:
- no silent truncation:
- no direct bucket edits:
- no production work beyond supplement:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED LIMIT / REJECTED
