# Correction and Reclassification Matrix

| Change | Projection effect | Dirty keys |
|---|---|---|
| base contribution quantity/revenue | copy new values | current scope/dimensions |
| sale timestamp | move | old/new hour/day |
| event remap | move | old/new event and ticket-type |
| ticket-type remap | move | old/new ticket-type |
| currency change | move | old/new currency |
| refund/reversal | add/update contribution | original sale/activity keys per B.1 |
| A.1 evidence create | uncovered → covered/other | old/new dimensions |
| A.1 evidence update | reclassify | old/new dimensions |
| A.1 malformed/conflict | covered → uncovered | old/new dimensions |
| acquisition correction | exact A.1 revision | old/new dimensions |
| normalisation version | new projection version | full affected scope |
| aggregation policy | new enabled members/kinds | full affected scope |
| classification/alias version | new dimension ids | full affected scope |
| base contribution inactive | projection inactive | old keys |
| duplicate/stale update | no-op | none |

## Source evidence preservation

A classification change never edits A.1 source evidence.

## Versioned coexistence

Old projection/bucket versions remain until rollout/retention policy retires them.

Readers select one exact version tuple.

## Correction completion

A Pack 15 correction affecting A.1 or B.2 remains `analytics_pending` until:

- A.2 projection current;
- all dirty buckets satisfied;
- parity verified;
- completeness/target/reporting downstream state resolved where applicable.
