# Predecessor Contracts

## VS-29A.1

A.1 owns:

- source model and exact evidence version;
- canonical acquisition DTO;
- field presence;
- normalisation;
- privacy and URL handling;
- source-version guard;
- order acquisition snapshot;
- coverage/absence state;
- source coverage window.

A.2 must not reinterpret source evidence or classify missing evidence as direct.

## VS-27B.1

B.1 owns:

- ticket and recognised-revenue contribution semantics;
- gross, reversal and net values;
- sale and activity timestamps;
- business timezone;
- windows and comparisons;
- currency law;
- completeness semantics;
- metric contract version.

A.2 reuses these values exactly.

## VS-27B.2

B.2 owns:

- durable contribution identity;
- projection revision;
- old/new key invalidation;
- hour/day base buckets;
- rebuild and repair;
- bounded edge-window reads;
- source/bucket freshness;
- base reader contract.

A.2 should consume final B.2 projections and invalidation seams, not implement a second B.1 evaluator.

## VS-26G

G owns semantic policy version and the meaning of ticket, refund, fee, tax, add-on and unknown contributions.

A.2 initially aggregates only ticket quantity and ticket revenue contribution kinds approved by B.1/G.

## VS-28A and VS-28B

Historical completeness, source backfill and corrections remain external authorities.

A correction may change acquisition evidence or base contribution; A.2 reprojects and rebuilds but never applies the correction itself.

## VS-27A

Transport and compact-contract compatibility remain unchanged.

A.2 operates only on durable A.1/B.2 state and never calls WordPress/WooCommerce.
