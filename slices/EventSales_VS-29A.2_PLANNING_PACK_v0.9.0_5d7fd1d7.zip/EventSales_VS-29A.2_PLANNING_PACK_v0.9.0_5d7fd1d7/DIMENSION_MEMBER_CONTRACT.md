# Acquisition Dimension Member Contract

## Candidate resource

```text
AcquisitionDimensionMember
```

## Candidate identity

```text
source_system_id
source_model
acquisition_evidence_version
normalisation_version
aggregation_policy_version
dimension_kind
canonical_key_hash
```

## Candidate fields

- dimension kind;
- canonical key hash;
- safe display label;
- normalized component values;
- sentinel kind or nil;
- member state;
- first/last observed;
- occurrence count metadata if bounded;
- inserted/updated timestamps.

## Fixed sentinels

Per dimension kind as applicable:

- `not_provided`;
- `not_applicable`;
- `unknown`;
- `unclassified`;
- `overflow`.

Sentinel identities are deterministic and created with the policy.

## Examples

### origin_class

```text
direct
organic
referral
utm
web_admin
api_or_other
unknown
```

### source

```text
newsletter
google
facebook
not_provided
unknown
unclassified
overflow
```

### source_medium

Canonical key is an ordered tuple, not string concatenation:

```json
{"source":"newsletter","medium":"email"}
```

### campaign

One normalized campaign evidence value or a sentinel.

## Safe display

Display is sanitized and bounded by A.1.

Do not derive identity from display casing.

## No aliases

`facebook`, `fb` and `facebook.com` remain separate evidence members until a later classification overlay is reviewed.

## Deletion

Members remain while referenced by projections/buckets.

Retirement does not rewrite source evidence.
