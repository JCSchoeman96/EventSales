# Partial-Hour and Edge-Window Contract

## Principle

Reuse final B.2 window semantics.

A.2 must not create a different notion of `today`, rolling seven days or custom boundaries.

## Interior

Use exact A.2 hour/day buckets for fully covered intervals.

## Partial-hour edges

At most two bounded edge queries may read `AcquisitionContributionProjection` directly for partial hours.

They may not read raw Sales or A.1 source payloads.

## Very short ranges

If final B.2 allows direct projection reads for windows at or below 60 minutes, A.2 may use the equivalent bounded acquisition projection read.

Bounds and point limits remain identical.

## Edge parity

For each edge:

- base B.2 edge contribution total;
- A.2 covered/uncovered edge partition;
- dimension partition;
- parity state.

A mismatch blocks certification.

## Time changes

A sale timestamp correction dirties:

- old/new hour;
- old/new business day;
- every enabled dimension;
- coverage;
- event/ticket-type scopes.

## Timezone

Business timezone and bucket start rules are inherited from B.1/B.2 and included in every key/version.
