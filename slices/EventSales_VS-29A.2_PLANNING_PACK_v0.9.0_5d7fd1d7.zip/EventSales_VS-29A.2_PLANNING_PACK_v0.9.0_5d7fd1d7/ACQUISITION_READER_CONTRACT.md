# Acquisition Bucket Reader Contract

## Boundary

Provide a non-web facade such as:

```text
EventSales.Analytics.AcquisitionBucketReader
```

A.2 exposes no route, LiveView or controller.

## Inputs

- source system;
- event scope;
- optional ticket-type scope;
- B.1 window/custom range;
- resolution;
- one metric: tickets or revenue;
- one enabled dimension kind;
- optional exact dimension member ids;
- currency;
- one `as_of`;
- metric/semantic/acquisition/normalisation/policy/classification versions;
- pagination/top-N bounds.

## Outputs

- exact period metadata;
- total base measure;
- covered classified;
- covered unclassified;
- uncovered;
- gross coverage ratio;
- ordered dimension totals;
- ordered time series;
- comparison values/state where B.1 permits;
- exact top-N and computed `other`;
- currency;
- sales completeness;
- A.1 acquisition coverage;
- source freshness;
- base bucket freshness;
- A.2 projection/bucket freshness;
- parity state;
- all contract versions;
- explicit missing/rebuilding/partial/truncated/unsupported states.

## Top-N and other

Top-N never defines totals.

Reader:

1. obtains exact covered total;
2. retrieves top N dimension members;
3. sums top N;
4. returns exact `other = covered total - top N`;
5. marks whether a full keyset list is available.

No silent truncation.

## All-event

Additive ticket/revenue values may sum complete event acquisition buckets across every event in the selected reportable scope.

Do not use UI page rows.

Distinct order count remains unsupported unless dedicated source-level facts are activated.

## No raw fallback

Missing or mismatched buckets return explicit states.

No query of Sales rows.

## Query bounds

Planning defaults:

- maximum selected events inherited from B.1/B.3, no more than 100;
- maximum one dimension kind;
- top N default 20, maximum 100;
- full dimension page 50;
- maximum custom range 366 days;
- points inherited from B.1/B.2;
- stable ordering by measure, canonical key and member id;
- one query or small reviewed bounded query set;
- no N+1.

## Access

Internal domain use only in A.2.

VS-29A.3 owns actor-aware policy and web DTOs.
