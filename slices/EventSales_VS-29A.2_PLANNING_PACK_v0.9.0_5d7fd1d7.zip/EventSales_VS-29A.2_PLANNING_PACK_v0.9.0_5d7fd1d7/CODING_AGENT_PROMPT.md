# Planning Agent Prompt — VS-29A.2

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-29A.2_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
GitHub: `#133`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, dependencies, migrations, configuration, source contracts, acquisition evidence, contribution projections, buckets or production data. Do not commit, open a PR, merge, deploy or rebuild.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`, every Pack 18 file, final certified VS-29A.1 and final VS-27B.1/B.2 artifacts.

Do not assume planning resource/module names survived implementation.

## Required decisions

1. exact current-code gap verification;
2. exact final B.2 contribution identity/fields/revision;
3. exact final B.2 dirty/outbox/repair/read interfaces;
4. exact final A.1 snapshot identity/fingerprint/source-version/coverage;
5. numeric-copy boundary proving no raw Sales metric evaluation;
6. acquisition projection identity/revision vector;
7. complete covered/uncovered partition;
8. aggregation policy resource/version/hash;
9. enabled dimensions and sentinels;
10. cardinality caps/overflow;
11. dimension member identity/collision handling;
12. old/new dirty-key fan-out;
13. projection transaction;
14. durable repair cursor/outbox;
15. event hour/day resources;
16. ticket-type hour/day resources;
17. exact recompute and stale-worker fencing;
18. base and dimension parity;
19. missing/base-lag states;
20. edge-window implementation;
21. bounded reader contract;
22. top-N and exact other;
23. all-event additive scope;
24. distinct-order unsupported or dedicated-fact decision;
25. completeness/coverage/freshness DTO;
26. correction/reclassification lifecycle;
27. version coexistence/retention;
28. queue/concurrency/retry;
29. migrations/indexes/query plans;
30. tests-first sequence;
31. exact files/dependencies/config/generated files;
32. static/privacy boundaries;
33. staged PR sequence;
34. rollout/shadow/canary/rollback;
35. production evidence;
36. M8 gate mapping;
37. VS-29A.3 handoff;
38. risks/stop conditions.

## Output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with exactly one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
