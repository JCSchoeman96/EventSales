# Completeness, Coverage and Freshness Contract

## Independent dimensions

Every reader response distinguishes:

### Sales completeness

Owned by VS-28A/B.1/B.2.

### Acquisition source coverage

Owned by VS-29A.1.

### Source freshness

Owned by VS-26F/source state.

### Base bucket freshness

Owned by B.2.

### Acquisition projection freshness

Whether A.2 has projected through current B.2/A.1 revisions.

### Acquisition bucket freshness

Whether all required dirty keys are satisfied.

### Parity

Whether A.2 partitions reconcile to B.2.

## No overloaded state

Examples:

- sales complete + acquisition partially covered;
- source fresh + A.2 updating;
- B.2 current + A.2 mismatch;
- A.2 current + source coverage unavailable before enablement.

These must remain distinct.

## Candidate watermark

Per source/version:

```text
base_projection_revision_observed
acquisition_snapshot_revision_observed
acquisition_projection_revision_through
dirty_bucket_count
failed_bucket_count
last_projected_at
last_bucketed_at
last_parity_verified_at
```

## Reader eligibility

Decision-grade acquisition response requires:

- requested sales completeness state disclosed;
- A.1 coverage window disclosed;
- projection and buckets current through required revisions;
- parity verified;
- no incompatible versions.

Otherwise return an explicit limited/updating/error state.

## Targets

Existing VS-27D sales targets remain based on base metrics.

A.2 does not create campaign targets or notifications.
