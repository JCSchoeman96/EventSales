# Performance and Bounds

## Fan-out

Planning maximum enabled dimension kinds: 6.

One changed contribution may dirty:

```text
event hour/day
+ ticket-type hour/day when present
× enabled dimension kinds
× old/new keys
```

Activation must calculate the exact worst-case fan-out and confirm it is acceptable.

No dynamic dimension kind multiplies fan-out.

## Planning defaults

- projection job scope: one order or bounded contribution batch;
- projection batch: 100 contributions;
- dirty claim batch: 50 keys;
- acquisition queue concurrency: 2;
- dimension member page: 50;
- top N default 20, maximum 100;
- selected events maximum inherited from B.1/B.3, capped at 100;
- custom range maximum 366 days;
- no automatic bucket retention purge;
- repair keyset batch: 500 projections.

Activation may tighten.

## Index principles

Projection composite indexes should support:

- base contribution identity;
- order/revision repair;
- event/hour/currency/version;
- ticket-type/hour/currency/version;
- dimension member/key;
- active/current state.

Bucket indexes follow reader filters and stable ordering.

Do not add every possible high-cardinality text index.

## Query plans

Require `EXPLAIN (ANALYZE, BUFFERS)` on representative data for:

- exact bucket recompute;
- all-event dimension total;
- event time series;
- ticket-type breakdown;
- top N plus exact other;
- repair cursor;
- parity comparison.

## Load evidence

At minimum:

- 10,000 ticket-sale contribution period;
- 25,000 base contribution rows including refunds;
- source cardinality at policy caps;
- 100 selected events;
- 50 later concurrent reader clients;
- repeated correction/reclassification storm;
- queue restart and backlog drain.

## Web boundary

A.2 has no web route.

Later A.3 must use the bounded reader only.

## Memory

No full event/order/contribution history loaded into one process.

Use keyset/bounded pages and database aggregation.
