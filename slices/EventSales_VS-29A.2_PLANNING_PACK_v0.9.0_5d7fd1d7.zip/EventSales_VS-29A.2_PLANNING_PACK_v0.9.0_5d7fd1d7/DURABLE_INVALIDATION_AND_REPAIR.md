# Durable Invalidation and Repair

## Authority

`AcquisitionDirtyBucket` is durable work authority.

Oban uniqueness and PubSub are not authority.

## Dirty causes

- base B.2 contribution create/update/inactivation;
- contribution time, event, ticket type or currency change;
- refund/reversal;
- A.1 acquisition snapshot create/update/conflict correction;
- coverage state change;
- normalisation/classification/policy version change;
- dimension member overflow/reclassification;
- manual reviewed rebuild.

## Old/new keys

Every mutation records all old and new keys for:

- event hour/day;
- ticket-type hour/day;
- every enabled dimension kind;
- coverage partition.

## Revision fencing

Each dirty row carries the maximum required projection revision.

Worker:

1. claims bounded dirty rows;
2. reads current projections for the exact key;
3. computes exact aggregate;
4. verifies input revision;
5. writes only when not stale;
6. marks dirty row satisfied through revision.

A stale worker cannot overwrite a newer bucket.

## Upstream seams

Preferred:

- final B.2 durable projection-change outbox;
- A.1 snapshot-change outbox;
- shared post-commit enqueue.

If final predecessors provide no durable outbox, A.2 requires:

- fast hint;
- changed-revision repair cursor;
- periodic projection reconciliation.

Best-effort `OrderProcessedNotifier` alone is insufficient.

## Repair

A source-scoped repair cursor compares:

- B.2 base projection revisions;
- A.1 snapshot revisions/fingerprints;
- A.2 projection vectors.

It queues/reprojects stale or missing rows in bounded keyset batches.

## No raw Sales repair

Repair reads B.2 projections and A.1 snapshots, not `OrderItem`/raw payloads.

## PubSub

Broadcast only after bucket commit.

Topic payload contains safe scope/version/revision data, not campaign strings or PII.
