# Retention and Versioning

## Initial retention

No automatic purge of A.2 projections, dimension members or buckets in v1.

Correctness, rollback and rebuild evidence take priority.

## Version tuple

Every projection/bucket/read includes:

- metric contract version;
- semantic policy version;
- acquisition evidence version;
- normalisation version;
- aggregation policy version;
- classification version;
- source model.

## Active version

One reviewed active version tuple per source for normal reads.

Historical versions may coexist during shadow/cutover.

## Retirement

A version may retire only after:

- no active reader uses it;
- no correction/rebuild requires it;
- replacement parity certified;
- retention/audit requirements reviewed;
- bounded purge plan approved.

## Dimension members

Do not delete members still referenced by any projection/bucket.

A retired member may remain read-only.

## Rebuild

A version change creates a new projection/bucket generation.

Do not rewrite old bucket rows in place under a new semantic meaning.
