# Acquisition Bucket Data Model

## Planning resources

- `AcquisitionEventHourBucket`;
- `AcquisitionEventDayBucket`;
- `AcquisitionTicketTypeHourBucket`;
- `AcquisitionTicketTypeDayBucket`;
- `AcquisitionDirtyBucket`;
- `AcquisitionProjectionWatermark`;
- optional `AcquisitionRebuildRun`.

## Event bucket key

```text
source_system_id
event_id
bucket_start/business_date
business_timezone
currency
metric_contract_version
semantic_policy_version
acquisition_evidence_version
normalisation_version
aggregation_policy_version
classification_version
dimension_kind
dimension_member_id
```

## Ticket-type bucket key

Same key plus:

```text
ticket_type_id
```

Ticket-type bucket exists only when the contribution has a certified ticket type and the dimension policy enables that scope.

## Measures

- gross ticket quantity;
- reversal ticket quantity;
- net ticket quantity;
- gross ticket revenue;
- refund/reversal ticket revenue;
- net ticket revenue;
- internal contribution count;
- source row/projection count;
- bucket revision;
- base projection revision through;
- acquisition projection revision through;
- refreshed at;
- parity status.

## Separate hour/day tables

Follow final B.2 physical-granularity direction.

Do not put arbitrary resolution strings into one unbounded table if B.2 uses split resources.

## Empty buckets

Prefer durable built-zero rows for known dirty keys after exact recomputation.

Missing row means not built/unsupported, not automatically zero.

## Currency

Currency is part of the key.

Never sum mixed currencies.

## No dimension maps

Dimension identity is explicit columns/FK/hash, not a JSON map in the bucket key.
