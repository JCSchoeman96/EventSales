# Scope Split Assessment

VS-29A.2 must be delivered as staged child slices.

## VS-29A.2A — Projection and Dimension Policy

- final B.2/A.1 seam;
- aggregation policy;
- dimension members/sentinels;
- acquisition contribution projection;
- revision vector;
- durable dirty keys;
- repair cursor;
- no buckets/read facade.

## VS-29A.2B — Acquisition Buckets

- event hour/day buckets;
- ticket-type hour/day buckets;
- exact recompute workers;
- revision fencing;
- parity states;
- rebuild workflow;
- no web UI.

## VS-29A.2C — Reader, Parity and Canary

- bounded reader;
- edge windows;
- top N plus exact other;
- completeness/freshness DTO;
- parity validation;
- load/query plans;
- production shadow/canary;
- A.3 handoff.

## Mandatory blockers

- A.1 not certified;
- final B.2 projection identity unavailable;
- agent proposes raw Sales evaluator;
- acquisition-only money semantics;
- missing complete uncovered partition;
- dynamic dimension cross-product;
- order count inferred from line buckets;
- parity hidden or approximate;
- projection/dirty writes non-atomic;
- notifier/PubSub as sole authority;
- source/compact changes included;
- dashboard/export included.
