# Coverage Partition Contract

## Coverage classes

A.2 collapses A.1 evidence states into one deterministic aggregate partition:

### covered_classified

The evidence is observed and has a valid primary origin/dimension classification.

Examples:

- explicit UTM;
- explicit direct;
- organic;
- referral;
- web admin;
- other certified source type.

### covered_unclassified

The evidence is observed and valid but the primary source/origin cannot yet be classified.

Examples:

- explicit unknown;
- valid new source type;
- valid fields whose alias/channel taxonomy is not defined.

### uncovered

The contribution lacks usable acquisition evidence.

Examples:

- unavailable before enablement;
- source feature disabled;
- adapter unsupported;
- not observed;
- malformed;
- over-bound;
- conflict.

## Partition invariant

For every base bucket:

```text
covered_classified
+ covered_unclassified
+ uncovered
= base ticket/revenue measures
```

No contribution is omitted.

## Ratios

Coverage ratios use gross completed measures, not net values:

```text
gross covered ticket quantity / gross base ticket quantity
gross covered ticket revenue / gross base ticket revenue
```

Reasons:

- refunds may make net denominators zero or negative;
- coverage describes evidence availability at sale capture;
- net covered/uncovered values remain separately available.

If denominator is zero, ratio is `unavailable`, not 0%.

## Covered unknown

`covered_unclassified` is still covered evidence.

Later UI may show it as “Observed but unclassified”.

It must not be merged with uncovered.

## Corrections

An A.1 correction may move contributions among the three classes and dirties old/new coverage keys.
