# Implementation Agent Prompt Template — VS-29A.2

**Do not use until activation returns APPROVE.**

Activation fills:

- exact current main/deployed SHA;
- exact child stage;
- certified B.2 contribution/outbox/dirty/reader interfaces;
- certified A.1 snapshot/coverage interfaces;
- exact policy/dimension/version contract;
- exact resources/actions/workers/readers;
- exact files/dependencies/config/migrations/tests;
- query/load/security commands;
- rollout/stop conditions;
- M8 gate.

Write tests first.

Implement only the activated child stage.

Open a PR and stop before merge, deployment, rebuild, production projection/bucket work or reporting integration.
