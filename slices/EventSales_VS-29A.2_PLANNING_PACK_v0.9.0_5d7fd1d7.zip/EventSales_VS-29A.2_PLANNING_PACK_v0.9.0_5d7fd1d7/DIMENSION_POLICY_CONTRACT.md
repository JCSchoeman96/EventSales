# Acquisition Dimension Policy Contract

## Purpose

Prevent arbitrary cardinality and cross-product growth while making aggregate semantics reproducible.

## Candidate resource

```text
AcquisitionAggregationPolicy
```

Candidate fields:

- version;
- policy hash;
- source model;
- acquisition evidence version;
- normalisation version;
- enabled dimension kinds;
- maximum admitted members per kind/source;
- sentinel registry;
- overflow behaviour;
- effective at;
- status: draft/active/retired;
- approved by/evidence.

## Initial dimension kinds

1. `coverage_class`;
2. `origin_class`;
3. `source`;
4. `source_medium`;
5. `campaign`;
6. optional `device_class`.

Not enabled initially:

- content;
- term;
- referrer host;
- source platform;
- creative format;
- marketing tactic;
- coupon;
- arbitrary combinations.

## One dimension at a time

Buckets are partitioned by `dimension_kind`.

The reader selects one kind per query.

No caller can request arbitrary:

```text
source × medium × campaign × device × event × ticket type
```

The only initial approved combination is the predeclared `source_medium` key.

## Policy immutability

An active policy version is immutable.

Changing enabled kinds, sentinels, normalisation or caps creates a new version and triggers reviewed reprojection/rebuild.

## Admission

New dimension members are admitted only if:

- source evidence passed A.1 bounds/privacy;
- dimension kind is enabled;
- canonical key is deterministic;
- source/kind cardinality remains within policy.

If the cap is exceeded:

- source evidence remains in A.1;
- A.2 uses the exact `overflow` member for that dimension;
- a safe finding/metric is emitted;
- coverage remains covered;
- no silent value truncation or hash collision merge.

## Policy activation

No admin UI in A.2.

Activation is code/config/data-operation gated and audited.
