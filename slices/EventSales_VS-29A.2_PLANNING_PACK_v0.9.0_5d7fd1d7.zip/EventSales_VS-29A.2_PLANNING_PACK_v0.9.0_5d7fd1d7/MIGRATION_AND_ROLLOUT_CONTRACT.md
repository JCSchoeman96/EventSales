# Migration and Rollout Contract

## Candidate additive migrations

- acquisition aggregation policy;
- acquisition dimension member;
- acquisition contribution projection;
- acquisition dirty bucket;
- event hour/day buckets;
- ticket-type hour/day buckets;
- projection watermark;
- optional rebuild run;
- indexes and constraints;
- Analytics domain resource registration;
- Oban queue/config.

## Migration rules

- additive;
- no raw Sales scan;
- no bucket build in migration;
- no A.1/B.2 full projection in migration;
- no destructive legacy snapshot change;
- no source call;
- no speculative high-cardinality index;
- direct/session-capable migration route;
- Ash snapshots deterministic;
- lock/index strategy reviewed.

## Rollout modes

Candidate server mode:

- `disabled`;
- `projection_shadow`;
- `bucket_shadow`;
- `reader_canary`;
- `enabled`.

Default after deploy: `disabled`.

## Stage 1 — Projection shadow

- project one selected event/range/version;
- no web reads;
- verify complete base contribution coverage;
- verify fixed dimension fan-out;
- verify repair/restart.

## Stage 2 — Bucket shadow

- build selected keys;
- verify coverage parity and dimension partition;
- test refunds/remaps/evidence corrections;
- no dashboard.

## Stage 3 — Reader canary

- query approved event/windows;
- compare with independent bounded evidence;
- verify exact other/truncation;
- load/query plans.

## Stage 4 — Enabled for A.3

Only after certification may VS-29A.3 consume the facade.

## Rollback

Disable new projection/bucket work and reader exposure.

Keep durable derived rows for evidence/restart.

Do not alter A.1 snapshots, B.2 contributions or Sales truth.

## Stop conditions

- raw Sales read;
- quantity/money recomputation;
- parity mismatch;
- missing base contribution projection;
- uncovered row omitted;
- dimension fan-out outside policy;
- cardinality overflow hidden;
- stale worker overwrites newer revision;
- PII/raw acquisition value leakage;
- migration lock/index failure.
