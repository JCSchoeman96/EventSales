# EventSales VS-29A.2 Planning Pack

## Identity

- Slice: `VS-29A.2`
- Name: Bounded Acquisition Projection and Aggregates
- Pack: `0018_VS-29A.2`
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub issue: `#133`
- Linear milestone: `M8 — Acquisition Evidence and Reporting`
- Linear document: `VS-29A.2 — Pack 18 Gate Ledger and Planning Record`
- Created: `2026-07-18T14:34:58Z`

## Authority

This ZIP authorises independent pack review and repository implementation planning only.

It does not authorise:

- code, dependency, migration, configuration or source-contract changes;
- acquisition projection or bucket rebuilds;
- production data reads or writes;
- dashboard, export or route changes;
- merge, deployment or production canary.

Implementation remains blocked until:

1. Pack 18 is independently approved;
2. the implementation plan is independently approved;
3. VS-29A.1 is certified and closed;
4. final VS-27B.1 and VS-27B.2 contribution/bucket interfaces are refreshed;
5. final VS-28B correction and completeness interfaces are refreshed;
6. an activation supplement returns `APPROVE`.

## Outcome

```text
certified B.2 contribution projection
+ certified A.1 order acquisition snapshot
→ acquisition contribution projection
→ fixed versioned dimension partitions
→ durable old/new dirty-bucket authority
→ exact event and ticket-type hour/day aggregates
→ bounded acquisition read facade
→ parity and coverage evidence
→ later VS-29A.3 reporting
```

## Critical doctrine

```text
B.2 owns quantity and money.
A.1 owns acquisition evidence and coverage.
A.2 only joins and aggregates those truths.
Covered + uncovered must equal base totals.
Missing evidence is never direct.
Distinct orders are not inferred from additive line buckets.
No raw Sales scan from web or reporting paths.
No arbitrary dimension cross-products.
```
