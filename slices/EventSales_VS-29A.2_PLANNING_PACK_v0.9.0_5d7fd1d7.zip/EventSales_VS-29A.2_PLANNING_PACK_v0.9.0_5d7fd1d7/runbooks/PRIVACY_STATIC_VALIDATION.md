# Privacy and Static Validation

## Seeded values

Use synthetic markers for:

- customer PII;
- IP/user-agent;
- full URL/query/click id;
- payment/provider/ticket token;
- raw campaign/source values;
- arbitrary metadata.

## Inspect

- A.2 projection;
- dimension member;
- dirty bucket;
- aggregate buckets;
- watermark/run;
- errors;
- Oban args;
- PubSub;
- telemetry;
- logs;
- reader DTO;
- evidence.

## Rules

Allowed dimension display comes only from A.1 sanitized bounded fields.

Telemetry labels may include only low-cardinality:

- dimension kind;
- coverage class;
- version;
- result/error;
- scope/resolution.

No source/campaign/member id/hash as telemetry label unless reviewed as a measurement or trace field with cardinality protection.

## Static boundaries

A.2 code may not reference:

- WooCommerceClient;
- webhook payload parser;
- raw Sales Order/OrderItem query for metric computation;
- current MetricRules numeric methods;
- web controllers/LiveViews;
- export controller;
- source plugins.

A.2 may reference final B.2 projections/read contracts and A.1 snapshots only.

## Evidence

Use safe ids, version ids, counts and hashes.
