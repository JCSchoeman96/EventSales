# Operational Failure Matrix

| Failure | Safe state | Recovery |
|---|---|---|
| A.1 snapshot missing | uncovered projection | later A.1 revision |
| B.2 contribution missing | projection gap/block | B.2 repair |
| stale base revision | no-op | none |
| stale A.1 revision | no-op | none |
| equal vector/different projection | conflict | case/rebuild |
| dimension cap exceeded | overflow member | policy review |
| member hash collision | block | stronger key/manual review |
| projection transaction fails | no projection/dirty partial | retry |
| enqueue fails after commit | durable dirty/repair | queue repair |
| worker stale | no bucket overwrite | retry current |
| base bucket lag | parity pending | wait/request B.2 rebuild |
| parity mismatch | mismatch/block | projection/bucket repair |
| dimension partition mismatch | mismatch/block | policy/projection repair |
| bucket missing | explicit not built | build |
| reader over-bound | reject | narrow |
| mixed currency | reject/group separately | select currency |
| top-N truncation | exact other + flag | paginate |
| repair interrupted | durable cursor | resume |
| policy version change | new generation | bounded rebuild |
| correction pending | analytics pending | converge |
| PII/raw value leak | security incident | stop/purge/remediate |
