# Migration Preflight

## Topology

Record:

- exact main/deployed SHA;
- PostgreSQL version/size;
- pooler/direct migration route;
- B.2/A.1 row counts/index sizes;
- Oban queue health;
- replication/deployment topology;
- current analytics snapshot sizes.

## Candidate migrations

- aggregation policy;
- dimension members;
- contribution projections;
- dirty buckets;
- event hour/day;
- ticket-type hour/day;
- watermarks/runs;
- indexes/checks/FKs;
- Analytics domain snapshots;
- queue config.

## Rules

- additive;
- no projection or bucket build in migration;
- no raw Sales scan;
- no high-cardinality data backfill;
- no destructive legacy snapshot change;
- concurrent/lock-safe index strategy;
- FK delete/restrict semantics preserve evidence;
- no broad JSON keys;
- generated snapshots deterministic.

## Estimate

- projection rows = base contribution rows × version generations;
- dirty fan-out;
- bucket rows by scope/dimension/time;
- index/storage growth;
- write amplification under flash sale;
- rebuild duration.

## Stop

- long table rewrite/lock;
- missing direct route;
- unbounded fan-out;
- index invalid;
- base/A.1 identity not enforceable;
- migration requires simultaneous production rebuild.
