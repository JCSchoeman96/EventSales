# Final Predecessor Refresh Runbook

## Purpose

Refresh Pack 18 against actual implemented A.1/B.2 interfaces before activation.

## Record

- exact current main/deployed SHA;
- final B.1 metric/time versions;
- final B.2 contribution resource identity and fields;
- projection revision type/sequence;
- base dirty/outbox/repair seams;
- base hour/day bucket keys;
- base reader/edge-window APIs;
- final A.1 snapshot resource/actions;
- A.1 fingerprint/source-version/coverage statuses;
- correction/audit/completeness hooks;
- queue/topology/migration route.

## Compare to Pack

For every planned module/resource field classify:

- exact match;
- renamed equivalent;
- absent;
- incompatible;
- newly required.

## Hard blockers

- no durable B.2 contribution source;
- B.2 contribution lacks order id/event/time/currency/measure versions;
- no safe changed-revision repair seam;
- A.1 snapshot lacks explicit absent/coverage state;
- no source-version/fingerprint;
- final A.1/B.2 values cannot reconcile deterministically;
- migration route unknown.

## Output

Complete activation supplement.

Do not code during refresh.
