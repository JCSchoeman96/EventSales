# Projection Shadow Runbook

## Preconditions

- VS-29A.2A deployed disabled;
- exact production rebuild supplement approves shadow scope;
- final A.1/B.2 versions match;
- no bucket/UI reads enabled.

## Scope

Start with:

- one source;
- one current public event;
- bounded 7-day or smaller range;
- one currency;
- exact version tuple.

## Execute

1. create immutable active aggregation policy;
2. create sentinel dimension members;
3. project bounded B.2 contributions;
4. persist uncovered rows for missing A.1 evidence;
5. persist dirty keys;
6. do not build buckets unless separately approved.

## Verify

- projection row count equals active base contribution count for scope;
- numeric fields equal B.2 projection exactly;
- A.1 fingerprint/version matches;
- coverage partition counts;
- dimension fan-out;
- cardinality/overflow;
- old/new dirty keys;
- duplicate run idempotency;
- interruption/restart;
- repair cursor.

## Negative proof

- no raw Sales query;
- no `MetricRules` numeric calculation;
- no source/Woo call;
- no PII/raw URLs;
- no bucket or dashboard change.

## Verdict

- PROJECTION SHADOW CERTIFIED;
- EXTEND;
- REJECTED.
