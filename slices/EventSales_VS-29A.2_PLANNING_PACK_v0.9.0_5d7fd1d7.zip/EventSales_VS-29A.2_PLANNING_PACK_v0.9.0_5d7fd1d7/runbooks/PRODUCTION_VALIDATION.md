# VS-29A.2 Production Validation

## Projection stage

- exact deployed SHA/version tuple;
- approved event/range;
- row parity with base projections;
- coverage partitions;
- dimension admission/overflow;
- old/new dirty keys;
- duplicate/restart/repair;
- privacy/static proof.

## Bucket stage

- event/ticket hour/day;
- zero/missing;
- stale fencing;
- dirty satisfaction;
- base parity;
- dimension parity;
- refunds/remaps/evidence corrections;
- queue/load/storage.

## Reader stage

- bounded windows/events/dimensions;
- top-N/exact other;
- all-event full scope;
- edge windows;
- mixed currency;
- completeness/coverage/freshness;
- versions/parity;
- 50-client load.

## Negative proof

- no raw Sales metric query;
- no source call;
- no dashboard/export;
- no distinct order inference;
- no PII/raw URL/click id;
- no direct bucket edit;
- no automatic production rebuild.

## Final verdict

- `CERTIFIED — VS-29A.3 MAY START`;
- `CERTIFIED WITH ACCEPTED LIMIT`;
- `REJECTED / BLOCKED`.
