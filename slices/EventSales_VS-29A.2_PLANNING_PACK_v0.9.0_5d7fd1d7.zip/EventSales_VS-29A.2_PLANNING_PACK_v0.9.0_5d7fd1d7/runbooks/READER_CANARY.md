# Acquisition Reader Canary

## Preconditions

- projection and bucket shadows certified;
- VS-29A.2C deployed;
- reader remains non-web;
- exact canary supplement approved.

## Queries

Run bounded approved cases:

- event today;
- event rolling 7 days;
- previous-period comparison;
- all-event origin;
- event source;
- source+medium;
- campaign top 20 plus other;
- ticket-type dimension;
- partial-hour edge;
- uncovered-only;
- mixed-currency rejection;
- missing/rebuilding/mismatch.

## Verify

- exact base total;
- coverage partitions;
- gross coverage ratios;
- dimension totals;
- exact top-N other;
- series order and point bounds;
- all versions;
- sales completeness;
- A.1 coverage;
- source/base/A.2 freshness;
- parity state;
- no raw fallback;
- stable keyset.

## Load

Simulate 50 clients over representative queries.

Record p50/p95, rows, buffers and database load.

No promise is certified without evidence.

## Distinct order

Confirm unsupported state is explicit.

## Verdict

- READER CERTIFIED — A.3 MAY PLAN;
- CERTIFIED WITH ACCEPTED LIMIT;
- REJECTED.
