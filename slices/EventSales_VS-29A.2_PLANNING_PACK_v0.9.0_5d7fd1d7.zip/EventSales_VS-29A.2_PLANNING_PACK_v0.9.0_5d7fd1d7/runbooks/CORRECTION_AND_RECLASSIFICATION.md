# Correction and Reclassification Runbook

## Source correction

A Pack 15 correction changes A.1 evidence under its own approval.

After commit:

1. A.1 emits durable revision/outbox;
2. A.2 reprojects every active B.2 contribution for the order;
3. old/new dimension and coverage keys dirty;
4. buckets rebuild;
5. parity verifies;
6. correction may leave analytics-pending.

## Base correction

A B.2 contribution correction follows the same flow from base revision.

## Classification version

A later reviewed classification/alias version:

- does not edit A.1 evidence;
- creates a new A.2 version tuple;
- projects/rebuilds bounded scope;
- compares parity;
- switches readers only after certification.

## Reversal

Correction reversal reprojects from current A.1/B.2 state.

No manual bucket edit.

## Evidence

Record safe ids/hashes/revisions/counts only.

## Stop

- direct dimension/bucket data patch;
- old version overwritten with new meaning;
- correction completed before parity;
- source evidence changed by aliasing;
- raw campaign/source in audit metadata.
