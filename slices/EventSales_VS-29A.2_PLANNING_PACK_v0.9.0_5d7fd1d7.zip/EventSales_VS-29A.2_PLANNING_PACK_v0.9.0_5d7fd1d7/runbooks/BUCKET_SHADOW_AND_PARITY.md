# Bucket Shadow and Parity Runbook

## Preconditions

- projection shadow certified;
- VS-29A.2B deployed;
- exact bucket scope supplement approved;
- base B.2 buckets available for same revisions.

## Build

For approved dirty keys:

- event hour/day;
- ticket-type hour/day;
- coverage class;
- enabled dimension kinds.

## Verify exact recompute

- worker reads A.2 projections only;
- built-zero rows;
- revision fencing;
- dirty rows satisfied through revision;
- duplicate worker no-op;
- crash/retry;
- PubSub after commit.

## Base parity

For every bucket:

```text
classified + unclassified + uncovered = base
```

Compare all quantity/revenue fields exactly.

## Dimension parity

For each full-partition kind:

```text
all members including sentinels/overflow = covered
```

## Mutation cases

- new sale;
- refund;
- remap;
- timestamp move;
- currency move;
- A.1 evidence create/update/conflict;
- correction/reversal.

Verify old and new buckets.

## Stop

Any mismatch, missing base contribution, hidden overflow, stale overwrite, raw Sales read or privacy leak.

## Verdict

- BUCKET SHADOW CERTIFIED;
- EXTEND;
- REJECTED.
