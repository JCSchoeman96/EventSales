# Mandatory File Inventory

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- feature-pack standard;
- live-sales roadmap/product decisions;
- GitHub #133;
- final Pack 17/VS-29A.1;
- final VS-27B.1 and VS-27B.2.

## Current Analytics
- `lib/event_sales/analytics.ex`
- `aggregate_event.ex`
- `aggregate_event_idempotency.ex`
- `aggregators/event_aggregator.ex`
- `metric_rules.ex`
- `order_processed_notifier.ex`
- `snapshot_refresh.ex`
- `snapshot_queries.ex`
- `snapshot_reader.ex`
- `hot_state_aggregator.ex`
- current snapshot resources/workers/cache/PubSub;
- tests/migrations/indexes.

## Final B.2 implementation
Inspect exact:
- contribution projection resource/service;
- dirty-bucket resource/service;
- event/ticket hour/day resources;
- projector/outbox/repair;
- bucket workers;
- bucket reader;
- edge-window reader;
- revisions/watermarks;
- queue/config/indexes;
- parity/rebuild tests.

## Final A.1 implementation
Inspect exact:
- `OrderAcquisitionSnapshot`;
- canonical DTO/adapter;
- source-version/fingerprint;
- coverage window;
- normalisation/privacy;
- compact v1/v2 support;
- correction/audit hooks;
- tests/migrations/indexes.

## Sales and correction
- Order/OrderItem/refund/semantic resources;
- final G/B.1 contribution evaluator;
- source-version guard;
- Pack 15 corrections/cases;
- backfill/completeness services;
- final notifier/outbox seams.

## Reporting/access
- final B.3 read DTOs;
- final C policies;
- final D completeness/targets;
- current admin dashboard/event detail;
- current exports;
- static no-raw-Sales checks.

## Config/CI
- `mix.exs`, `mix.lock`;
- config/runtime/test;
- Oban queues/plugins;
- Railway/release/migration route;
- Ash snapshots/migrations;
- architecture manifests/index;
- telemetry/privacy scripts;
- local CI/load/query-plan tooling.
