# VS-29A.2 Acceptance Checklist

## Governance
- [ ] Exact current main.
- [ ] Pack review approved.
- [ ] Plan review approved.
- [ ] VS-29A.1 certified.
- [ ] VS-27B.1/B.2 certified.
- [ ] Activation APPROVE.

## Authority
- [ ] B.2 quantitative authority.
- [ ] A.1 acquisition/coverage authority.
- [ ] No raw Sales metric calculation.
- [ ] No second writer.
- [ ] Every base contribution has one current A.2 projection.

## Projection
- [ ] Stable identity.
- [ ] Revision vector.
- [ ] Numeric values copied exactly.
- [ ] Covered classified/unclassified/uncovered.
- [ ] Missing A.1 creates uncovered row.
- [ ] Old/new keys.
- [ ] Projection + dirty transaction.
- [ ] Durable repair.

## Dimensions
- [ ] Immutable aggregation policy.
- [ ] Fixed enabled kinds.
- [ ] Deterministic members.
- [ ] Sentinels.
- [ ] Cardinality caps.
- [ ] Explicit overflow.
- [ ] No aliases.
- [ ] No arbitrary cross-products.
- [ ] High-cardinality fields disabled.

## Buckets
- [ ] Event hour/day.
- [ ] Ticket-type hour/day.
- [ ] Currency/version in key.
- [ ] Exact recompute.
- [ ] Durable dirty authority.
- [ ] Stale worker fencing.
- [ ] Built zero.
- [ ] Missing not zero.
- [ ] Repair/restart.
- [ ] PubSub after commit.

## Parity
- [ ] Coverage partition equals base.
- [ ] Full dimensions equal covered.
- [ ] Decimal exactness.
- [ ] Pending/base lag explicit.
- [ ] Mismatch durable.
- [ ] No raw fallback.
- [ ] Corrections/refunds/remaps tested.

## Reader
- [ ] Bounded scopes/windows.
- [ ] One dimension/query.
- [ ] Top-N plus exact other.
- [ ] Stable keyset.
- [ ] All-event uses full scope.
- [ ] Edge-window bounds.
- [ ] Completeness/coverage/freshness separated.
- [ ] Versions explicit.
- [ ] Mixed currency rejected.
- [ ] Distinct orders unsupported unless exact facts.

## Privacy
- [ ] No PII.
- [ ] No full URLs/query/click ids.
- [ ] No raw source values in telemetry labels.
- [ ] Safe errors/PubSub/evidence.
- [ ] No web/source calls.

## Performance
- [ ] Fan-out measured.
- [ ] 25k contribution load.
- [ ] 100 event query.
- [ ] 50 reader clients.
- [ ] Query plans.
- [ ] No N+1/full-memory scans.
- [ ] Queue/backlog/restart.

## Non-goals
- [ ] No dashboard.
- [ ] No export.
- [ ] No source/compact change.
- [ ] No coupon allocation.
- [ ] No ROAS/conversion.
