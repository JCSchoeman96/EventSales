# VS-29A.2 Production Rebuild Supplement

- Certified implementation PR/head/deployed SHA:
- Source system:
- Event/ticket-type scope:
- Time range:
- Version tuple:
- Aggregation policy/hash:
- Base B.2 revision/watermark:
- A.1 revision/coverage:
- Expected projection rows:
- Expected dirty fan-out:
- Queue/database health:
- Batch/concurrency:
- Query-plan/load evidence:
- Parity expectations:
- Authorization:
- Operator:
- Start/end:
- Pause/kill switch:
- Rollback:
- Evidence destination:
- Stop conditions:

Verdict:

- APPROVE SHADOW PROJECTION
- APPROVE SHADOW BUCKET BUILD
- APPROVE READER CANARY
- APPROVE BOUNDED REBUILD
- REFRESH
- BLOCKED

Approval applies only to the exact scope and version tuple.
