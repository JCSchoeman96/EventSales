# Distinct Order Count Boundary

## Problem

Line contributions are additive. Distinct orders are not.

One order may:

- contain multiple lines;
- contain multiple ticket types;
- contain multiple events;
- span several dimension rows only if policy is broken;
- receive partial/full refunds;
- be represented in multiple time buckets through activity.

Summing event or ticket-type order counts produces incorrect all-event totals.

## V1 decision

A.2 v1 does not expose a distinct order count measure.

Reader returns:

```text
order_count: unsupported
reason: dedicated_exact_order_fact_required
```

## Future exact option

A later reviewed extension may add:

- one `AcquisitionOrderFact` per order/source-model/version;
- one `AcquisitionOrderEventFact` per order/event;
- optionally one order/ticket-type fact;
- exact sale-time and status/refund law;
- separate source-level and event-level buckets;
- non-additivity metadata.

It must define whether full refund removes an order from net-active counts and how mixed-event orders behave.

## Forbidden

- `COUNT(*)` of contribution rows as order count;
- sum of event order counts for all events;
- approximate HLL count presented as exact;
- customer count inferred from order count;
- conversion rate without a certified denominator.
