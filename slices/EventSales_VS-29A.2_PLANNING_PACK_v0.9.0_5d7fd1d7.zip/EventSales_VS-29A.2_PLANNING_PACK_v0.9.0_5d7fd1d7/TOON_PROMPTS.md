# TOON Prompts

## Pack reviewer
Task: Attack current-code accuracy, A.1/B.2 authority and scope.
Output: APPROVE / REQUEST CHANGES / BLOCKED.

## Projection reviewer
Task: Attack identity, revision vector, absence partition, old/new keys and repair.
Output: projection verdict.

## Dimension reviewer
Task: Attack policy versions, sentinels, cardinality, overflow and aliases.
Output: dimension verdict.

## Metric reviewer
Task: Prove all numbers are copied from B.2 and reconcile exactly.
Output: parity verdict.

## Bucket reviewer
Task: Attack exact recompute, stale fencing, zero/missing semantics and queue durability.
Output: bucket verdict.

## Reader reviewer
Task: Attack bounds, top-N/other, all-event sums, edge windows and distinct counts.
Output: reader verdict.

## Privacy reviewer
Task: Attack projections, dimension members, telemetry, PubSub, errors and evidence.
Output: leakage verdict.

## Activation reviewer
Task: Refresh exact final A.1/B.2 interfaces and current main/deployment.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
