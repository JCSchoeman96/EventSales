# Acquisition Contribution Projection Contract

## Purpose

The projection joins certified quantitative contributions to certified order acquisition evidence without rereading raw Sales rows.

## Candidate identity

Prefer:

```text
base_contribution_id
+ metric_contract_version
+ semantic_policy_version
+ acquisition_evidence_version
+ normalisation_version
+ aggregation_policy_version
+ classification_version
```

If final B.2 contribution identity already includes metric/semantic versions, reuse it rather than duplicating identity semantics.

## Candidate fields

- source_system_id;
- order_id;
- base_contribution_id;
- base_projection_revision;
- event_id;
- ticket_type_id;
- contribution_kind;
- currency;
- occurred_at;
- time_axis;
- business timezone/date;
- hour_start_utc;
- gross/reversal/net ticket quantity;
- gross/refund/net ticket revenue;
- A.1 snapshot id;
- A.1 canonical fingerprint;
- A.1 source version;
- coverage class;
- fixed dimension member ids/hashes;
- acquisition evidence version;
- normalisation version;
- aggregation policy version;
- classification version;
- projection revision;
- active/superseded state;
- inserted/updated timestamps.

No PII, raw URL, query string, click id, customer data, arbitrary metadata or raw payload.

## Complete partition

Every active base contribution must have exactly one active A.2 projection for the current version tuple.

No acquisition evidence produces an uncovered projection, not no row.

## Projection transaction

For one base contribution/order revision:

1. Load final B.2 contribution state.
2. Load exact A.1 order acquisition snapshot or explicit absence state.
3. Apply the immutable aggregation policy.
4. Resolve fixed dimension members/sentinels.
5. Load prior acquisition projection.
6. Compute old and new event/ticket-type hour/day keys for every enabled dimension.
7. Allocate a monotonic projection revision.
8. Upsert/supersede projection.
9. Persist old and new dirty keys with the revision.
10. Commit.
11. Queue work after commit.

Projection mutation and dirty-key persistence share one transaction.

## Quantitative authority

The projection copies certified B.2 numeric values and may validate them.

It does not call `MetricRules`, aggregate `OrderItem`, parse refunds or recalculate money.

## Missing base contribution

A projection absent from the new authoritative B.2 set becomes inactive/superseded and its old keys are dirtied.

Do not remove because an upstream payload was partial or because A.1 evidence is missing.

## Source-version vectors

A projection is current only for the vector:

```text
base contribution revision
A.1 acquisition fingerprint/source version
aggregation policy version
classification version
```

Any changed component requires reprojection.
