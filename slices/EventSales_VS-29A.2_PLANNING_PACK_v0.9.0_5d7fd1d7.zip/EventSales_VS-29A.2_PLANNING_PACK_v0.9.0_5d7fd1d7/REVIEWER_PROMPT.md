# Independent Reviewer Prompt — VS-29A.2

Review adversarially against exact current repository code and final A.1/B.1/B.2 contracts.

Block any design that:

- calculates ticket/revenue from raw Order/OrderItem;
- calls current `MetricRules` as A.2 numeric authority;
- creates a second contribution writer;
- omits a base contribution when acquisition evidence is absent;
- classifies missing/pre-enable evidence as direct;
- lacks covered + uncovered = base parity;
- calculates coverage ratio from unstable net denominators;
- lets dimensions be caller-defined cross-products;
- enables content/term/referrer-host without cardinality evidence;
- truncates or hashes over-cap values into false identities;
- silently aliases source values;
- stores raw URLs/query/click ids/PII;
- puts campaign/source strings in telemetry labels;
- uses notifier/PubSub/Oban uniqueness as durable authority;
- separates projection mutation from dirty-key persistence;
- trusts deltas instead of exact recompute;
- permits stale workers to overwrite newer buckets;
- treats missing bucket as zero;
- falls back to raw Sales when buckets are missing;
- derives all-event totals from UI pagination;
- sums event/ticket-type order counts;
- approximates distinct orders as exact;
- hides top-N truncation without exact `other`;
- directly edits B.2 buckets;
- includes dashboard/export/source-contract work;
- enables production rebuilds by deployment.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only.
