# Bucket Build and Revision Contract

## Exact recomputation

A bucket worker never applies trusted numeric deltas.

For one exact bucket key it:

1. loads all active A.2 projections matching the key;
2. sums certified copied B.2 measures;
3. calculates projection count;
4. records maximum base/A.2 revisions;
5. compares the corresponding base B.2 bucket where required;
6. writes a new bucket revision;
7. clears/satisfies durable dirty state;
8. broadcasts after commit.

## Projection query

Queries are indexed by:

- source;
- event;
- ticket type where applicable;
- hour/day occurrence key;
- currency;
- version tuple;
- dimension member.

No raw Sales join.

## Coalescing

Many contribution changes may coalesce into one dirty key.

Recomputation remains exact from current projections.

## Revision fields

Candidate vector:

```text
bucket_revision
base_projection_revision_through
acquisition_projection_revision_through
aggregation_policy_version
classification_version
```

`bucket_revision` is monotonic database authority.

## Parity timing

A bucket may be built before its base B.2 bucket reaches the same upstream revision.

In that case:

- store the A.2 values;
- mark parity `pending`;
- do not claim certified parity;
- queue/retry parity after B.2 catches up.

## Failure

A permanent bucket failure remains durable with:

- safe error code;
- attempts;
- first/last failed;
- required revision;
- next retry/manual review state.

No raw dimension value or exception body.

## Queue

Planning default:

- dedicated `analytics_acquisition` queue;
- concurrency 2;
- dirty claim batch 50;
- one exact bucket recompute per bounded transaction;
- bounded attempts/backoff;
- no one transaction across an entire rebuild.
