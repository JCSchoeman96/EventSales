# Scope Split Assessment

VS-29A is a programme, not one implementation PR.

## VS-29A.1 — Acquisition Evidence Contract and Coverage Certification

- exact source certification;
- canonical DTO;
- privacy/cardinality/normalization;
- durable current snapshot;
- adapter parity;
- coverage window;
- no aggregates/UI.

## VS-29A.2 — Acquisition Projection and Aggregates

- dimension identities;
- contribution joins;
- hourly/daily aggregates;
- coverage measures;
- dirty/rebuild/reclassification;
- bounded query facade.

## VS-29A.3 — Acquisition Reporting

- decision surfaces;
- source/medium/campaign;
- coverage UX;
- access/revenue permissions;
- bounded export;
- no ad cost/ROAS unless separately added.

## Mandatory blockers

Split or block when:

- VS-27A final contract unknown;
- source feature/version/field registry unknown;
- core evidence unavailable/insufficient;
- source enablement requires consent/WAF change;
- REST/webhook/backfill parity unresolved;
- arbitrary meta proposed;
- full URL/click IDs proposed;
- sales and acquisition completeness conflated;
- coupon allocation invented;
- aggregate/UI included in A.1;
- high-cardinality indexes/reporting unproven.
