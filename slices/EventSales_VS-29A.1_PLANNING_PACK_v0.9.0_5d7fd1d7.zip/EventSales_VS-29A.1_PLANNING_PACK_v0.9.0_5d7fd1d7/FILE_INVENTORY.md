# Mandatory File Inventory

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`
- GitHub #132.
- final Pack 16/VS-27A contract and activation artefacts.

## Current order and children
- `lib/event_sales/sales/resources/order.ex`
- `lib/event_sales/sales/resources/order_item.ex`
- `lib/event_sales/sales/resources/coupon_snapshot.ex`
- final fee/refund/semantic resources from G;
- migrations/indexes/resource snapshots.

## Parsers/writer
- `lib/event_sales/ingestion/parsers/woocommerce_order_parser.ex`
- final VS-27A router/legacy/v1/v2 parsers;
- `lib/event_sales/sales/order_upserter.ex`
- source-version guards;
- tests/fixtures.

## Webhook/intake
- webhook controller/raw body/HMAC/intake/replay/processor;
- `WebhookEvent` resource/debug/purger;
- Pack 16 contract metadata and body bounds.

## Catch-up/backfill/import
- final VS-26F Woo REST adapter;
- final VS-28A backfill adapter;
- final VS-28B import/correction interfaces;
- canonical order DTO/presence contract.

## Analytics/reporting
- final B.1 contribution/time law;
- final B.2 projection/buckets;
- final B.3 query facade/dashboard;
- final C/D permissions/completeness;
- current `AdminDashboard`, `EventDetail`, exports and tests.

## WordPress integration
- catalog feed plugin and README;
- final Pack 16 order webhook bridge;
- exact source plugin tests/docs/config.

## Production source evidence
Inspect exact installed:
- WordPress;
- WooCommerce;
- HPOS state;
- Woo Order Attribution classes/traits/templates;
- field registry/prefix filters;
- consent plugins/WP Consent API;
- WAF/CDN/cookie exceptions;
- Tickera/Bridge;
- UTM/analytics/CRM/custom snippets;
- webhook API/version;
- REST order response;
- order-meta storage.

## Official exact-version Woo source
- `src/Internal/Orders/OrderAttributionController.php`
- `src/Internal/Traits/OrderAttributionMeta.php`
- relevant checkout/store API integration;
- REST orders controller;
- feature configuration and tests.

## Config/CI
- `mix.exs`, `mix.lock`;
- config/runtime/test;
- Ash snapshots/migrations;
- Oban/Redis;
- CI/security/static boundary scripts;
- Railway release/migration configuration.
