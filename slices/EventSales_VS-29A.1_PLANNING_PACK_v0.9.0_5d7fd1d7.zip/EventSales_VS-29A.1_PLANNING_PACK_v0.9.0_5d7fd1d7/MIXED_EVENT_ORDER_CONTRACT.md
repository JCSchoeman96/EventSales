# Mixed-Event Order Contract

## Current truth

`OrderItem` is the event/ticket reporting unit because one Woo order may contain lines for multiple EventSales events.

Acquisition evidence is order-level.

## Later metric join

```text
OrderAcquisitionSnapshot
join Order
join certified line ContributionProjection
→ event/ticket acquisition contribution
```

The line contribution amount/quantity remains defined by B/G.

## Rules

- one order acquisition snapshot may label multiple event line contributions;
- do not copy mutable acquisition strings into source `OrderItem` rows;
- contribution projection may snapshot normalized acquisition dimension ids later;
- order-level order counts are distinct and not additive across event rows;
- mixed-currency rules remain unchanged;
- refunded/reversed line contributions follow B/G, not acquisition logic.

## Coverage

If an order has no acquisition evidence, all its line contributions are `uncovered` for acquisition reporting but remain valid sales contributions.

## Current slice

No event-level acquisition aggregate or UI is built in VS-29A.1.
