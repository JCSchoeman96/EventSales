# Cardinality and Query Budget

## Source sample requirements

Before schema/index decisions, measure bounded cardinality for:

- origin class;
- source type;
- source;
- medium;
- campaign;
- content;
- term;
- campaign id;
- source platform;
- creative format;
- marketing tactic;
- referrer host;
- device class.

Use counts and hashes only in evidence.

## Planning bounds

| Dimension | Max value length | Expected report cardinality cap |
|---|---:|---:|
| origin class | enum | 20 |
| source type | 100 | 100 |
| source | 200 | 500 |
| medium | 100 | 200 |
| campaign | 250 | 1,000 |
| content | 250 | 1,000 |
| term | 250 | 1,000 |
| campaign id | 200 | 1,000 |
| referrer host | 253 | 1,000 |
| device | enum | 10 |

These are planning ceilings, not permission to render all values.

## Storage

A current order snapshot may store bounded strings.

Later aggregates should use durable normalized dimension identities where evidence justifies them.

## Query rules

- no raw `ILIKE '%term%'` across unbounded orders;
- no arbitrary dimension cross-product;
- no high-cardinality telemetry labels;
- bounded top-N plus explicit other/unclassified;
- keyset pagination for long dimension lists;
- selected events/ranges follow B.1/B.2 limits;
- query plans and load evidence required.

## Term/content

`utm_term` and `utm_content` can be high-cardinality.

They should remain evidence-only until production cardinality proves bounded reporting is useful.

## Referrer

Host-only reduces privacy and cardinality risk.

No path/query grouping in v1.
