# Official WooCommerce Order Attribution Evidence

Retrieved: 18 July 2026.

## Sources

- WooCommerce Order Attribution Tracking documentation:
  `https://woocommerce.com/document/order-attribution-tracking/`
- WooCommerce attribution details template/code reference:
  `https://woocommerce.github.io/code-reference/files/woocommerce-templates-order-attribution-details.html`
- WooCommerce hooks reference:
  `https://woocommerce.github.io/code-reference/hooks/hooks`
- WooCommerce REST Orders controller reference:
  `https://woocommerce.github.io/code-reference/classes/WC-REST-Orders-Controller.html`

## Stable planning facts

Official WooCommerce documentation describes the core feature as:

- order-level attribution evidence;
- a last-click/current-session model;
- written only when an order is placed;
- session-scoped rather than cross-session customer tracking;
- configurable under WooCommerce advanced features;
- integrated with WP Consent API;
- dependent on attribution cookies that may interact with WAF rules.

The current official UI/code reference exposes candidate fields including:

- origin/source type;
- UTM source, medium, campaign, content, term and id;
- source platform;
- creative format;
- marketing tactic;
- device type;
- session page count.

The exact installed field registry may be filtered through WooCommerce hooks. Therefore Pack 17 treats all fields as candidates until exact-version source certification.

## Privacy implication

Woo documentation states that source evidence may initially include a full referrer and session/customer-agent context in source cookies/meta.

EventSales must not ingest the full referrer URL, user-agent, IP or cookie contents. Only a validated normalized referrer host may be retained.

## Coverage implication

WooCommerce documentation states attribution exists only for orders placed while the feature is enabled.

Pre-enablement orders must remain acquisition-unavailable rather than being classified as direct.

## WAF implication

Official documentation describes an optional base64-cookie mode for WAF compatibility in recent WooCommerce versions.

Any use of that filter is a source change requiring a separate supplement; it is not part of Pack 17 planning authority.

## Exact-version warning

These sources describe current WooCommerce, not necessarily the production site's installed build.

Activation must inspect the exact installed tag/commit and final filter results.
