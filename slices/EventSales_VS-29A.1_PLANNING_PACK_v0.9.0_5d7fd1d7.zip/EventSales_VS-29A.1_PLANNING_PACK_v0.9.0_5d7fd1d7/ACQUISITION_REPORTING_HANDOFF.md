# Acquisition Reporting Handoff

## Successor slices

### VS-29A.2 — Bounded Acquisition Projection and Aggregates

Owns:

- joining certified line contributions to order acquisition snapshots;
- versioned acquisition dimension ids;
- hourly/daily acquisition buckets;
- coverage numerator/denominator;
- correction/reclassification dirtying;
- query facade;
- bounded dimension combinations;
- additive versus non-additive measures.

### VS-29A.3 — Acquisition Decision Reporting

Owns:

- all-event/event acquisition surfaces;
- source/medium/campaign/origin/device views;
- coverage and unknown states;
- bounded filters/comparisons;
- role/revenue permissions;
- acquisition exports;
- responsive accessible UI.

## Metrics not defined by A.1

VS-29A.1 does not define:

- campaign-attributed revenue;
- coupon-attributed revenue;
- conversion rate;
- ROAS;
- cost per acquisition;
- customer count;
- unique visitors;
- sessions;
- first-touch/multi-touch credit.

## Later required measure law

At minimum:

- tickets and net recognised revenue use certified line contributions;
- one selected source model per report;
- uncovered contributions remain explicit;
- order count distinctness is explicit;
- multi-coupon measures are non-additive unless allocated;
- mixed currencies never sum;
- comparison/coverage windows follow B.1 time law;
- reclassification versions are visible.
