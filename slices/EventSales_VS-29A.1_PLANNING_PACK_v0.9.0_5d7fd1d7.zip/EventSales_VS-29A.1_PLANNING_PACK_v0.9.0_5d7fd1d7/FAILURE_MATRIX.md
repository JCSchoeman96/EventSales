# Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| core feature disabled | explicit source status; no invented evidence | product/source decision |
| enablement date unknown | coverage uncertified | source evidence review |
| hidden meta not in REST | adapter unsupported | safe REST field/endpoint or no support |
| compact v1 has no section | v1 acquisition unsupported | compact v2 |
| unknown compact version | permanent contract failure | source/backend sequencing |
| arbitrary meta present | ignored/rejected | exact allowlist |
| full referrer URL | host extraction only or malformed | source adapter fix |
| click id present | excluded | separate future contract |
| overlong UTM | field finding / over-bound | source cleanup |
| control/HTML characters | reject field, safe finding | source cleanup |
| invalid URI host | no referrer host, malformed | source cleanup |
| absent fields pre-enable | unavailable-before-enablement | coverage boundary |
| absent fields after enable | not-observed | investigate |
| source says direct | explicit direct | normal |
| admin/API order | explicit admin/other where proven | normal |
| equal source version different evidence | conflict | case/catch-up |
| stale acquisition payload | stale no-op | none |
| newer order update omits section | fail closed or explicit unsupported | adapter fix |
| duplicate webhook/catch-up | idempotent fingerprint no-op | none |
| mixed-event order | one order snapshot joined later | no line copy |
| multiple coupons | non-additive promotion state | later allocation law |
| import conflicts with source | case; source wins by policy | Pack 15 review |
| consent/WAF blocks capture | coverage gap; no guess | separate source change |
| source change causes drop | stop rollout | rollback/config review |
| cardinality explosion | no dimension reporting | taxonomy/bounds review |
| PII in logs/evidence | security incident | stop/purge/remediate |
