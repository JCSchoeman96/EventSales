# Correction, Import and Audit Handoff

## Source evidence corrections

A manual correction may be justified when source evidence is malformed or demonstrably wrong.

It must:

- preserve original source evidence;
- record before/after;
- record reason/actor/time;
- use Pack 15 conflict/correction law;
- invalidate if source version changes;
- remain distinct from channel aliasing.

## Import authority

Imported acquisition fields carry:

```text
provenance = import
authority = reviewed_import
```

They cannot silently overwrite `woocommerce_core` source evidence.

## Alias/classification changes

Changing `facebook` to a canonical alias is not a source correction.

It is a versioned classification overlay.

## Conflicts

Examples:

- legacy adapter and catch-up produce different evidence at equal source version;
- compact v2 says observed while REST says unavailable;
- source field exceeds bound;
- multiple competing UTM plugins provide different values.

Create a safe finding/case; do not guess.

## Audit

Reuse final shared audit resources where available.

Do not create raw acquisition-payload logs.
