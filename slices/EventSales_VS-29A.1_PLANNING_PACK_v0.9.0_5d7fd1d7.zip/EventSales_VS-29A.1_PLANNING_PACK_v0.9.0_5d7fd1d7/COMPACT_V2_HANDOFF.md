# Compact Order v2 Handoff

## Why v2 is the default

Pack 16 states:

- v1 has an exact allowlist;
- unknown keys fail;
- new required meaning requires a new identifier;
- no arbitrary `extensions`.

A required acquisition coverage envelope changes the semantic contract.

Therefore planning default:

```text
eventsales.order.v2
```

## v2 relation to v1

```text
v2 order/header/child semantics = certified v1 semantics
v2 adds required acquisition envelope
v2 may not change money/time/identity/completeness law
```

## Candidate envelope

```json
{
  "contract": "eventsales.order.v2",
  "snapshot_kind": "full_order",
  "acquisition": {
    "contract": "eventsales.acquisition.v1",
    "source_model": "woocommerce_core_session_last_click",
    "coverage_status": "observed",
    "origin_class": "utm",
    "source_type": "utm",
    "source": "newsletter",
    "medium": "email",
    "campaign": "winter_launch",
    "content": null,
    "term": null,
    "campaign_id": null,
    "source_platform": null,
    "creative_format": null,
    "marketing_tactic": null,
    "referrer_host": null,
    "device_class": "mobile",
    "session_page_count": 4,
    "field_presence": {}
  }
}
```

This is illustrative, not implementation authority.

## Required status even when absent

The acquisition object remains present and carries an explicit coverage state.

It does not disappear ambiguously.

## Sequencing

```text
backend v2 parser
→ legacy/v1/v2 coexistence
→ source v2 shadow
→ parity and privacy
→ v2 canary
→ v2 preferred
→ v1 parse-only only after evidence
```

## Body limits

The acquisition envelope must remain within final Pack 16 body/cardinality/Redis bounds.

No raw source meta or URL is added.
