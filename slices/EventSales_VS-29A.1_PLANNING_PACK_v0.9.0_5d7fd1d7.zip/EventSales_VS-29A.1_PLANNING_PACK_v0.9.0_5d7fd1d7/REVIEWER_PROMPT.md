# Independent Reviewer Prompt — VS-29A.1

Review adversarially against exact current repository code, Pack 16 and official exact-version WooCommerce behaviour.

Block any design that:

- treats Woo core last-click evidence as multi-touch/causal truth;
- builds custom tracking before certifying core evidence;
- silently changes `eventsales.order.v1`;
- ingests arbitrary order meta;
- stores full URLs/query strings, click IDs, IP, user-agent or customer identity;
- labels missing evidence as direct;
- conflates acquisition coverage with sales completeness;
- changes ticket/revenue/refund semantics;
- creates a second order writer;
- lacks stale/equal/new source-version law;
- cannot reconcile legacy/compact/catch-up/backfill adapters;
- assumes hidden meta is REST/webhook-visible without proof;
- uses production DB meta as a runtime shortcut;
- copies acquisition values into mutable OrderItem source truth;
- treats coupon as acquisition;
- double-counts multi-coupon orders;
- invents coupon/revenue allocation;
- adds campaign aggregates/UI/export to A.1;
- aliases source/channel values silently;
- indexes every high-cardinality field speculatively;
- logs raw acquisition strings or uses them as telemetry labels;
- enables Woo tracking or changes consent/WAF without exact approval;
- lacks explicit pre-enablement/unknown/malformed states;
- lacks rollback and coverage evidence.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only.
