# Test Matrix

## Source evidence fixtures

- direct;
- UTM source/medium/campaign;
- organic;
- referral with full URL reduced to host;
- web admin;
- API/other;
- unknown;
- pre-enablement missing;
- post-enablement missing;
- consent/tracking unavailable only where source proves it;
- malformed URL;
- over-bound values;
- control/HTML input;
- competing plugin fields;
- click IDs present but excluded.

## Normalization

- Unicode NFKC;
- whitespace;
- casefold identity;
- display preservation;
- empty after normalization;
- max-length rejection;
- IDNA host;
- invalid/private/local host;
- no query/path/userinfo retention;
- stable fingerprint.

## Adapter parity

- legacy webhook exact meta allowlist;
- compact v1 supported/unsupported branch;
- compact v2 acquisition object;
- catch-up REST;
- backfill REST;
- explicit import authority;
- equal fingerprints for equal evidence;
- unsupported adapter coverage state.

## Source version/idempotency

- create;
- duplicate equal version/fingerprint;
- equal version/different fingerprint conflict;
- stale no-op;
- newer update;
- source omission;
- order update with unchanged evidence;
- replay.

## Persistence

- one snapshot/order;
- order/source relationship;
- validations/checks;
- no arbitrary JSON;
- migration/index plans;
- deletion/restrict behaviour.

## Privacy

Seed:

- customer PII;
- IP/user-agent;
- full URLs;
- query strings;
- click ids;
- order key;
- provider/ticket tokens;
- arbitrary meta.

Prove absence from DTO, DB, logs, telemetry, PubSub, UI/evidence.

## Coverage

- source observed/certified window;
- pre-enable not direct;
- covered/uncovered denominator;
- sales completeness independent;
- backfill cannot manufacture evidence.

## Coupon boundary

- single coupon;
- multiple coupons;
- case variants;
- omitted/revoked coupon;
- no automatic source/campaign mapping;
- no duplicated ticket/revenue measure in A.1.

## Performance

- maximum accepted fields;
- 10,000-order local rebuild;
- source sample/cardinality;
- query plans;
- no N+1;
- no unbounded meta parsing.
