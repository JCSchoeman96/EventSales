# Source Certification Contract

## Objective

Determine what acquisition evidence exists in the exact production/staging WooCommerce source before freezing schema or code.

## Read-only facts

Record exact:

- WordPress version;
- WooCommerce version and source tag;
- HPOS authoritative/compatibility state;
- Order Attribution feature state;
- Order Attribution field registry after filters;
- tracking meta prefix after filters;
- REST/webhook API version;
- source plugin/custom-code inventory affecting attribution;
- consent plugin/WP Consent API state;
- WAF/cache/CDN behaviour affecting attribution cookies;
- feature enablement date or earliest observed order;
- source order storage tables and indexes;
- Pack 16 bridge version/config when available.

## Safe source probes

Use synthetic/staging orders where possible:

- direct;
- UTM email;
- UTM paid social;
- organic search;
- referral;
- web admin;
- Store API/checkout block;
- classic checkout;
- consent denied/granted where supported;
- WAF/base64-cookie mode;
- HPOS and compatibility tables.

## Exposure tests

Verify exact safe evidence available through:

- native full Woo webhook;
- Woo REST order catch-up response;
- backfill response;
- Pack 16 compact builder;
- order object APIs;
- database read only as evidence, not runtime adapter.

## Distribution evidence

For bounded production samples, record only:

- counts;
- null/absence states;
- length/cardinality histograms;
- normalised value hashes;
- origin/source-type categories;
- earliest/latest observed timestamps;
- malformed/over-bound counts;
- coverage percentage by order date/status.

Do not copy raw campaign/referrer/query values into pack/GitHub/Linear.

## Verdict

- `CORE SOURCE CERTIFIED`;
- `CORE SOURCE CERTIFIED WITH GAPS`;
- `CORE SOURCE INSUFFICIENT — PRODUCT DECISION REQUIRED`;
- `BLOCKED`.

Only the first two permit implementation planning to freeze exact fields.
