# Coupon and Promotion Boundary

## Current resource

`CouponSnapshot` stores:

- order;
- code;
- discount amount;
- discount tax.

It has no normalization, source-set completeness, event allocation or campaign identity.

## Source promotion evidence

Coupon code is a promotion identifier associated with an order.

It is not automatically:

- UTM campaign;
- marketing source;
- channel;
- affiliate;
- acquisition touch.

## Authoritative set

Coupon reporting is blocked until the final order child-set contract proves:

- complete coupon collection;
- removal/revocation behaviour;
- stale/equal-version handling;
- duplicate-code normalization.

## Normalization

Candidate later rules:

- trim;
- preserve safe display;
- case-insensitive identity if Woo coupon semantics are case-insensitive in the certified source;
- reject control/over-bound values;
- no aliasing to campaign without reviewed mapping.

## Multi-coupon orders

For an order using two coupons:

- distinct order count per coupon is non-additive across coupons;
- ticket quantity/revenue repeated under each coupon would double count;
- discount amount may be source-specific per coupon but still requires reconciliation.

Later reporting must choose one:

- coupon-set composite dimension;
- explicit allocation;
- non-additive per-coupon usage report;
- mutually exclusive primary promotion rule.

VS-29A.1 chooses none.

## Cross-dimension limits

Coupon × source × medium × campaign × event × ticket type can explode cardinality.

Later slices require bounded dimension combinations and query budgets.
