# Compact v2 Acquisition Cutover Supplement

- Certified backend SHA:
- Certified source bridge SHA/version:
- Exact source versions:
- EventSales webhook id/topic/API version:
- v1 schema hash:
- v2 schema hash:
- acquisition schema hash:
- source field registry:
- coverage-state behaviour:
- exact order allowlist:
- basis points:
- HMAC/native delivery proof:
- legacy/v1/v2 parity:
- catch-up/backfill parity:
- privacy scan:
- body/Redis bounds:
- source fallback:
- rollback to v1/legacy:
- operator/authorization:
- stop conditions:

Verdict:

- APPROVE SHADOW
- APPROVE EXACT V2 CANARY
- APPROVE V2 BROADENING
- APPROVE V2 PREFERRED
- REFRESH
- BLOCKED
