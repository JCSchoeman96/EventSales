# VS-29A.1 Acceptance Checklist

## Governance
- [ ] Exact current main.
- [ ] Pack review approved.
- [ ] Plan review approved.
- [ ] VS-27A certified.
- [ ] Source-certification supplement approved.
- [ ] Exact source evidence recorded safely.
- [ ] Activation APPROVE.

## Source certification
- [ ] WordPress/Woo/HPOS versions.
- [ ] Core feature state.
- [ ] Field registry after filters.
- [ ] Meta prefix after filters.
- [ ] REST/webhook/backfill exposure.
- [ ] Enablement/coverage boundary.
- [ ] Consent/WAF behaviour.
- [ ] Competing plugins/custom code.
- [ ] Cardinality/length/null histograms.
- [ ] No raw production values copied.

## Contract
- [ ] Correct last-click/session label.
- [ ] Exact canonical DTO.
- [ ] Presence semantics.
- [ ] Coverage/absence enum.
- [ ] Normalization version.
- [ ] Stable fingerprint.
- [ ] Referrer host only.
- [ ] Click IDs excluded.
- [ ] Value/cardinality bounds.
- [ ] Unknown values preserved safely.

## Persistence
- [ ] One snapshot/order.
- [ ] Source-version guard.
- [ ] Equal-version conflict.
- [ ] Stale no-op.
- [ ] Ash actions/domain service.
- [ ] No arbitrary JSON/meta.
- [ ] Migration additive.
- [ ] Query-plan-driven indexes.
- [ ] Audit/correction handoff.

## Adapter parity
- [ ] Legacy exact allowlist.
- [ ] Compact v1 decision.
- [ ] Compact v2 where required.
- [ ] Catch-up.
- [ ] Backfill.
- [ ] Import authority.
- [ ] Equal canonical fingerprint.
- [ ] Unsupported adapter explicit.

## Coverage
- [ ] Sales completeness independent.
- [ ] Pre-enable not direct.
- [ ] Covered/uncovered denominator.
- [ ] Source coverage window.
- [ ] Malformed/over-bound/conflict.
- [ ] Backfill does not manufacture evidence.

## Coupons/mixed events
- [ ] Coupon remains promotion.
- [ ] Complete coupon-set dependency.
- [ ] Multi-coupon non-additivity explicit.
- [ ] No revenue allocation in A.1.
- [ ] Order evidence joined later to line contributions.
- [ ] No acquisition copied into OrderItem.

## Privacy/security
- [ ] No PII/IP/user-agent.
- [ ] No full URLs/query strings.
- [ ] No click ids.
- [ ] No arbitrary cookies/meta.
- [ ] Safe logs/telemetry/debug/evidence.
- [ ] Seeded secret scans.
- [ ] Exact role/access boundaries.

## Non-goals
- [ ] No dashboard.
- [ ] No aggregate table.
- [ ] No ROAS/ad cost.
- [ ] No custom tracker.
- [ ] No source feature change.
- [ ] No sales semantic change.
- [ ] No #100/#101 promotion without evidence.
