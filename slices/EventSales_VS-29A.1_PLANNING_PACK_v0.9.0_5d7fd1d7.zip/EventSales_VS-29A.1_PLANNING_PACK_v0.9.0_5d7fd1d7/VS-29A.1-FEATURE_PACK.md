# VS-29A.1 — Acquisition Evidence Contract and Coverage Certification

## 1. Goal

Establish a PII-safe, versioned and coverage-aware acquisition evidence contract before any campaign/source dashboard, aggregate or export is implemented.

## 2. Preferred source

Prefer the exact installed WooCommerce core Order Attribution feature.

The source model is explicitly:

```text
WooCommerce core
session-scoped
last-click / current-session attribution
stored on order creation
```

Do not describe this as multi-touch, first-touch, cross-session or customer-journey truth.

Do not build a competing tracker unless source certification proves core evidence unavailable or insufficient and a separate reviewed product decision approves an alternative.

## 3. Authority chain

```text
WooCommerce order attribution evidence
→ exact allowlisted source adapter
→ canonical acquisition DTO
→ source-version guarded durable snapshot
→ explicit coverage/completeness state
→ later acquisition projection/aggregates/reporting
```

Sales totals, ticket entitlement, refunds, tax, fees, corrections and sales completeness remain owned by predecessor contracts.

## 4. Programme position

```text
VS-27A compact/legacy order transport
→ VS-29A.1 acquisition evidence and coverage
→ VS-29A.2 bounded acquisition contribution projection/aggregates
→ VS-29A.3 bounded acquisition reporting
```

VS-29A.1 does not implement the later slices.

## 5. Current repository gap

Current code has:

- no acquisition resource or relationship on `Sales.Order`;
- no parser for order-level attribution metadata;
- no acquisition writer in `OrderUpserter`;
- no acquisition coverage boundary;
- only a basic `CouponSnapshot`;
- no campaign/source dimensions in current dashboard or exports;
- a catalog-only WordPress integration;
- a planned VS-27A compact bridge whose v1 contract rejects unknown arbitrary fields.

## 6. Transport handoff from Pack 16

Pack 16 `eventsales.order.v1` cannot be silently reinterpreted.

Default planning direction:

```text
legacy full Woo payload          → legacy acquisition adapter
eventsales.order.v1             → no acquisition section unless final v1 explicitly registered it
eventsales.order.v2             → v1 semantics plus required acquisition envelope
catch-up/backfill full REST      → exact source acquisition adapter
```

A compatible v1 extension is allowed only if final VS-27A explicitly reserved and registered the exact optional section. Otherwise use a new exact contract identifier.

## 7. Order-level evidence

Acquisition evidence belongs to the order.

Mixed-event orders later join one order acquisition snapshot to certified line contributions. It is not copied into mutable order lines as source truth.

## 8. Coupon boundary

Coupon data is a separate promotion dimension.

Existing `CouponSnapshot` may be reused only after authoritative coupon-set reconciliation is certified.

Do not:

- treat coupon code as UTM source;
- duplicate an order's ticket/revenue contribution once per coupon;
- claim coupon revenue is additive across multi-coupon orders without an allocation contract.

## 9. Privacy

Default excluded data:

- full referrer URL;
- landing URL query string;
- path fragments containing identifiers;
- IP address;
- user-agent;
- customer/user/session/client IDs;
- order key;
- email/phone/address;
- `gclid`, `fbclid`, `msclkid` and other raw click IDs;
- arbitrary cookies;
- arbitrary order meta;
- free-form notes.

Allowed fields are exact, bounded and normalised.

## 10. Coverage

Acquisition reporting has its own coverage law.

Sales totals may be complete while acquisition evidence is partially unavailable.

Historical orders before source enablement are `unavailable_before_enablement`, not `direct`.

Missing source evidence is never silently coerced to a marketing channel.

## 11. Source certification first

Before implementation, read-only evidence must establish:

- exact source versions;
- whether core Order Attribution is enabled;
- exact field registry and meta prefix;
- HPOS/CPT storage;
- REST and webhook exposure;
- source enablement boundary;
- consent and WAF behaviour;
- competing plugins/custom code;
- real null/value/cardinality distribution;
- source data quality and malformed cases.

## 12. Non-goals

- no campaign dashboard;
- no acquisition buckets;
- no ad cost or ROAS;
- no cross-session tracking;
- no customer journey;
- no custom first-touch tracker;
- no source enablement;
- no production reads;
- no arbitrary metadata;
- no changes to sales contribution or completeness;
- no promotion of #100/#101 without production evidence.

## 13. Exit gate

A certified fixture from every supported order adapter produces the same bounded canonical acquisition DTO, persists idempotently beside the order, exposes an explicit coverage/absence state, contains no forbidden data, and can be carried by the final VS-27A transport without changing Sales effects.
