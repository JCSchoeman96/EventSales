# WooCommerce Attribution Source-Change Supplement

Required for enabling/disabling/changing WooCommerce Order Attribution, cookie encoding, consent or WAF configuration.

- Exact source environment:
- WordPress/Woo/HPOS versions:
- Current feature state:
- Proposed change:
- Exact option/filter/config:
- Consent review:
- Cookie disclosure/legal owner:
- WAF/CDN review:
- Checkout classic/block coverage:
- Staging evidence:
- Existing order impact:
- Expected coverage start:
- Rollback:
- Monitoring:
- Operator/authorization:
- Start/end:
- Stop conditions:

Verdict:

- APPROVE STAGING ONLY
- APPROVE PRODUCTION SOURCE CHANGE
- REFRESH
- BLOCKED

This does not authorise EventSales code deployment or compact contract change.
