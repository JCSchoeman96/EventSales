# Feature Flags and Rollout

## Backend candidate flags

- acquisition adapter parsing enabled;
- acquisition snapshot writes enabled;
- acquisition snapshot reads enabled;
- compact v2 parser enabled;
- coverage projection enabled;
- safe debug fields enabled.

Defaults are disabled until the activated stage.

## Source candidate controls

Source controls remain owned by exact Woo/Pack 16 configuration:

- core Order Attribution enabled;
- safe REST field enabled;
- compact v2 shadow/canary/preferred;
- exact webhook ids;
- deterministic basis points;
- fallback to v1/legacy.

## Sequencing

```text
source certification
→ backend legacy/REST acquisition adapters
→ durable snapshot validation
→ compact v2 backend support
→ source shadow
→ exact canary
→ broadening
→ coverage certification
```

Source tracking enablement is independent from compact v2 rollout.

## Kill switches

An incident must be able to:

- stop acquisition snapshot writes while order ingestion continues;
- stop safe source field exposure;
- return compact source to v1/legacy;
- disable core source tracking only under source-owner approval;
- keep existing acquisition evidence intact.

## No automatic progression

No flag change or deployment broadens source tracking or compact v2 without an exact reviewed supplement.
