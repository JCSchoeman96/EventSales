# VS-29A.1 Redacted Evidence

- Pack/plan/activation:
- GitHub #132:
- M8/document:
- PR/head/deployed SHA:
- Source versions/HPOS:
- VS-27A contract support:
- Acquisition schema/hash:
- Coverage window:

## Source certification
- feature state:
- exact field registry/prefix:
- official code tag/files:
- REST/webhook/compact exposure:
- consent/WAF:
- competing plugins:
- safe distributions:
- raw production values attached: no

## Backend
- migration/index:
- resource/actions:
- source-version tests:
- legacy/v1 regression:
- v2 parser:
- catch-up/backfill parity:
- import authority:
- query/load:

## Privacy
- seeded PII:
- URL/query/click ids:
- DB:
- logs:
- telemetry:
- PubSub:
- debug:
- evidence:

## Coverage
- eligible:
- covered:
- uncovered:
- explicit origins:
- malformed/conflict:
- certified dates:
- sales completeness separate:

## Boundaries
- coupon promotion only:
- no multi-coupon allocation:
- mixed-event join later:
- no dashboard/aggregates:
- no custom tracker:
- no source change without supplement:
- no Sales semantic change:

## Optional source/v2 operations
- supplement:
- exact scope:
- shadow/canary:
- HMAC/body:
- parity:
- rollback:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED COVERAGE LIMIT / REJECTED
