# Privacy, URL and Click-ID Contract

## Forbidden

- customer id/name/email/phone/address;
- IP;
- user-agent;
- cookie/session/client identifiers;
- full referrer URL;
- landing URL query string;
- URL userinfo;
- order key;
- payment/provider identifiers;
- ticket/access/download identifiers;
- raw `gclid`, `gbraid`, `wbraid`, `fbclid`, `msclkid`, `ttclid` or equivalent;
- arbitrary order meta;
- raw consent strings.

## URL handling

For referral evidence:

1. parse with a strict URI parser;
2. require `http` or `https`;
3. discard userinfo, port, path, query and fragment;
4. normalize host through IDNA rules;
5. lower-case;
6. reject local/private/invalid hosts;
7. store host only.

Do not store the original URL alongside the host.

## Campaign IDs

`utm_id` or another marketer-assigned campaign id may be allowed after source certification because it identifies a campaign, not a click.

It remains bounded and opaque.

## Click-ID future work

Ad-platform conversion matching requires a separate consent, retention, access, security and destination contract.

Presence booleans are also out of scope unless a business need is reviewed.

## Logs/evidence

Use only:

- field-presence flags;
- lengths/cardinality;
- safe hashes;
- normalized category counts;
- coverage statuses;
- schema/version ids.

No raw acquisition strings in telemetry labels.
