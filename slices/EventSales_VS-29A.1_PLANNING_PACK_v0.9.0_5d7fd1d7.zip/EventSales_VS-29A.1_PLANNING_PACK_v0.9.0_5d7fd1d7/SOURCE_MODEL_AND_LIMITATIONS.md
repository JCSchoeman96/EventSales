# Source Model and Limitations

## Preferred model

`woocommerce_core_session_last_click`

Meaning:

- evidence is collected during the current browser session;
- a non-direct recognised source may be retained under WooCommerce source precedence;
- evidence is written only when an order is placed;
- it does not identify a person across sessions;
- it does not allocate fractional credit;
- it does not prove causal marketing impact.

## Required label

Every durable snapshot includes:

```text
source_model = woocommerce_core_session_last_click
source_model_version = exact certified Woo implementation version
```

## Not equivalent to

- first-touch attribution;
- multi-touch attribution;
- data-driven attribution;
- ad-platform conversion matching;
- customer lifetime journey;
- incrementality;
- ROAS;
- campaign cost;
- offline attribution.

## Source data gaps

Orders may lack evidence because:

- feature was not enabled yet;
- tracking was disabled;
- consent/cookie restrictions prevented capture;
- checkout was created by admin/API;
- source fields were not exposed by the adapter;
- source data was malformed or removed;
- the order predates the feature/version;
- another plugin changed the registry.

The adapter records evidence, not speculative reason, unless the source proves the reason explicitly.
