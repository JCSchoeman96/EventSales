# TOON Prompts

## Pack reviewer
Task: Attack Pack 17 current-code accuracy and predecessor law.
Output: APPROVE / REQUEST CHANGES / BLOCKED.

## Source-certification planner
Task: Determine exact installed Woo Order Attribution fields, exposure and coverage safely.
Output: read-only plan, no production execution.

## Data-contract reviewer
Task: Attack DTO identity, presence, source-version, absence and fingerprint semantics.
Output: contract verdict.

## Privacy reviewer
Task: Attack URLs, click IDs, cookies, logs, telemetry, evidence and debug paths.
Output: leakage verdict.

## Marketing-semantics reviewer
Task: Distinguish source evidence, origin, channel aliases, campaigns and coupons.
Output: semantic verdict.

## Adapter reviewer
Task: Compare legacy, compact v1/v2, catch-up, backfill and import representations.
Output: parity verdict.

## Performance reviewer
Task: Attack cardinality, indexes, rebuilds, joins and future dimension cross-products.
Output: boundedness verdict.

## Activation reviewer
Task: Refresh exact main/deployed/source versions and certified coverage.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
