# Classification and Alias Overlay

## Source evidence versus business taxonomy

Source fields are evidence:

```text
source=facebook
medium=paid_social
campaign=winter_launch
```

Business classifications are derived:

```text
channel_group=paid_social
campaign_family=winter_2026
owner=marketing_team
```

Do not merge them.

## Future resource candidates

```text
AcquisitionAliasRule
AcquisitionChannelRule
CampaignDefinition
```

These require separate versioning, effective dates, preview/apply, audit and rebuild rules.

## Reclassification

A new alias/channel rule changes reporting classification, not the stored source evidence.

Later aggregate rebuilds must be versioned.

## Unknown values

Unknown source/medium/campaign values remain visible as unclassified coverage, not discarded.

## Current slice

VS-29A.1 records the boundary and required versions only.

No marketing taxonomy management UI or rule engine.
