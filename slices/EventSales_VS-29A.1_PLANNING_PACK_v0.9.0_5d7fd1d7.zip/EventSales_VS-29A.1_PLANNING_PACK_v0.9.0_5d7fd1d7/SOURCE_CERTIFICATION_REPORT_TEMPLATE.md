# VS-29A.1 Source Certification Report

- Supplement/authorization:
- Date/time/operator:
- Environment:
- WordPress:
- WooCommerce tag/commit:
- PHP/database:
- HPOS:
- Order Attribution option:
- Field registry:
- Meta prefix:
- Checkout paths:
- Consent/WAF/CDN:
- Competing plugins/custom code:
- Pack 16 bridge:

## Official code evidence
- controller:
- meta trait:
- checkout stamping:
- REST exposure:
- cookie/session:
- filters:

## Safe fixture results
- direct:
- UTM:
- organic:
- referral:
- web admin:
- unknown:
- consent:
- classic/blocks:
- webhook:
- REST:
- compact shadow:

## Safe production distribution
- eligible count:
- evidence-present:
- origin counts:
- field presence:
- max lengths:
- distinct counts:
- malformed/over-bound:
- earliest/latest:
- gaps:
- values represented only by hashes/counts:

## Exposure matrix
| Field | WC_Order | Webhook | REST | Compact | Allowed |
|---|---|---|---|---|---|

## Coverage
- observed_from:
- certified_from:
- certified_through:
- ratio:
- gaps:
- blockers:

## Privacy
- full URL:
- query/click IDs:
- IP/user-agent:
- customer identity:
- logs/evidence:

Verdict: CORE SOURCE CERTIFIED / CERTIFIED WITH GAPS / INSUFFICIENT / BLOCKED
