# Current Code Acquisition Map

| Current area | Current behaviour | VS-29A.1 implication |
|---|---|---|
| `Sales.Order` | source/order/status/time/money plus customer/payment fields; no acquisition | add separate relationship/resource, not more free-form fields |
| `CouponSnapshot` | order, code, discount amount/tax; identity order+code | promotion evidence only; no campaign semantics |
| `WoocommerceOrderParser` | parses header, lines, coupons; ignores order meta attribution | add exact acquisition adapter, not arbitrary meta pass-through |
| `OrderUpserter` | parser directly then order/items/coupons | route acquisition DTO to one source-version-guarded child writer |
| child reconciliation | incoming coupons upserted; omitted rows not removed | coupon reporting waits for certified complete-set law |
| `OrderItem` | event/ticket reporting unit for mixed-event orders | later acquisition metrics join through order relationship |
| dashboard | bounded but no source/campaign dimension | no UI work in A.1 |
| export | event-scoped PII-free order/ticket rows; no acquisition | later export contract only |
| webhook intake | stores payload and size; Pack 16 adds family/version | acquisition metadata must obey Pack 16 body/privacy/retention |
| current WordPress plugin | catalog feed only | do not overload it; Pack 16 bridge/source adapter boundary applies |
| roadmap | UTM/coupon/campaign explicitly deferred | A.1 supplies missing identity/privacy/cardinality/coverage law |
