# Index and Migration Contract

## Candidate table

```text
sales_order_acquisition_snapshots
```

## Candidate constraints

- primary UUID;
- unique `order_id`;
- foreign keys to order and source system;
- source-version timestamp not null where evidence adapter is source-authoritative;
- enum/check constraints for coverage/origin/device;
- bounded string validations in Ash and database where practical;
- fingerprint length/format check.

## Candidate indexes

Only after query evidence:

- `(source_system_id, source_updated_at, id)`;
- `(coverage_status, source_updated_at)`;
- `(origin_class, source_updated_at)`;
- normalized source/medium/campaign indexes for future rebuild/read paths.

Do not index every high-cardinality text field speculatively.

## Migration

- additive;
- no parsing existing payloads inside migration;
- no production source call;
- no full-table backfill;
- no rewrite of `sales_orders`;
- generated Ash snapshots deterministic;
- direct/session-capable migration path required.

## Existing orders

A bounded restartable local projection job may derive acquisition snapshots from already stored safe payloads only if:

- payload retention still contains evidence;
- extraction is exact and PII-safe;
- no raw payload is logged;
- source version is preserved;
- work is bounded and resumable.

Otherwise use certified Woo backfill/catch-up source adapters.

## Rollback

Disable acquisition snapshot writes/reads.

Do not delete source evidence or alter Sales truth during rollback.
