# Implementation Agent Prompt Template — VS-29A.1

**Do not use until activation returns APPROVE.**

Activation must fill:

- exact current main/deployed SHA;
- certified VS-27A contract/version support;
- exact source versions/HPOS;
- certified Order Attribution field registry/prefix;
- exact source exposure path;
- exact coverage boundary;
- exact canonical DTO/schema;
- exact privacy/normalization/cardinality rules;
- exact resource/action/source-version law;
- exact files/dependencies/config/migrations/tests;
- exact rollout/stop conditions;
- mapped M8 gate.

Write tests first.

Implement only the activated child stage.

Open a PR and stop before merge, deployment, source settings, production reads, source enablement, cookie/consent/WAF changes or compact v2 emission.
