# Durable Resource Contract

## Recommended resource

```text
EventSales.Sales.Resources.OrderAcquisitionSnapshot
```

## Candidate attributes

```text
id
order_id
source_system_id
source_model
source_model_version
evidence_version
coverage_status
absence_reason
origin_class
source_type_display
source_type_normalized
source_name_display
source_name_normalized
medium_display
medium_normalized
campaign_display
campaign_normalized
content_display
content_normalized
term_display
term_normalized
campaign_id
source_platform
creative_format
marketing_tactic
referrer_host
device_class
session_page_count
field_presence
normalization_version
canonical_fingerprint
source_updated_at
first_observed_at
last_observed_at
inserted_at
updated_at
```

Exact columns may be reduced after source evidence.

## Identity

- unique `order_id`;
- optional supporting unique/index on `(source_system_id, source_updated_at, id)`;
- no global uniqueness on campaign/source strings.

## Actions

- `create_from_source`;
- `sync_from_source`;
- `mark_conflict`;
- read actions through a focused facade.

All mutations use Ash actions/domain services.

## Source version

Use the same canonical order source version guard.

Rules:

- older source version → stale no-op;
- equal version + equal fingerprint → idempotent no-op;
- equal version + different fingerprint → conflict/finding;
- newer version → update after complete validation.

## History

The current snapshot is source truth for the latest order version.

If Pack 15 correction/audit interfaces require immutable revision history, use the certified shared audit mechanism rather than inventing a parallel history table.

## Relationship

Add `has_one :acquisition_snapshot` on `Sales.Order`.

Do not add acquisition columns directly to every `OrderItem`.

## No arbitrary JSON

`field_presence` may be a small exact map/bitset.

Do not store the original source meta array or an open-ended `metadata` map.
