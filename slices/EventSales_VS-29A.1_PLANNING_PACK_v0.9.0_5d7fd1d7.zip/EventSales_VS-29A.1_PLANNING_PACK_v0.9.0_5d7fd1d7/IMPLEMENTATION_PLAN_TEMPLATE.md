# VS-29A.1 Implementation Plan

## 1. Baseline/drift proof
## 2. Files and predecessor artefacts inspected
## 3. Current-code gap verification
## 4. Exact source-version inventory
## 5. Official Woo source evidence
## 6. Feature/field-registry/meta-prefix state
## 7. HPOS/CPT/REST/webhook exposure
## 8. Consent/WAF/cookie behaviour
## 9. Competing plugins/custom code
## 10. Safe source sampling and coverage boundary
## 11. Source model and limitations
## 12. Canonical acquisition DTO
## 13. Field presence/absence semantics
## 14. Coverage state/window
## 15. Origin/normalization rules
## 16. URL/referrer handling
## 17. Privacy/click-id exclusion
## 18. Cardinality/value/body bounds
## 19. Durable resource/actions/identity
## 20. Source-version/idempotency/conflicts
## 21. Migration/index/query plans
## 22. Legacy adapter
## 23. Compact v1 compatibility
## 24. Compact v2 design/rollout
## 25. Catch-up/backfill exposure remedy
## 26. Import/correction authority
## 27. Coupon/promotion boundary
## 28. Mixed-event join
## 29. Classification/alias boundary
## 30. Telemetry/debug/retention
## 31. Tests-first sequence
## 32. Exact files/dependencies/config/migrations
## 33. Static/security/load commands
## 34. Staged PR/deployment sequence
## 35. Source-change supplements
## 36. Rollback/stop conditions
## 37. M8 gate mapping
## 38. A.2/A.3 successor handoff
## 39. Prohibited actions
## 40. Verdict
