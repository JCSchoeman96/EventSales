# EventSales VS-29A.1 Planning Pack

## Identity

- Slice: `VS-29A.1`
- Name: Acquisition Evidence Contract and Coverage Certification
- Pack: `0017_VS-29A.1`
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub issue: `#132`
- Linear milestone: `M8 — Acquisition Evidence and Reporting`
- Linear document: `VS-29A.1 — Pack 17 Gate Ledger and Planning Record`
- Created: `2026-07-18T11:08:34Z`

## Authority

This ZIP authorises independent pack review and repository/source reconnaissance planning only.

It does not authorise:

- code, dependency, migration, schema or configuration changes;
- enabling or disabling WooCommerce Order Attribution;
- consent, cookie, WAF or source-plugin changes;
- production WordPress/WooCommerce reads;
- changing the VS-27A compact contract;
- merge, deployment, backfill, import, correction or production validation.

Implementation remains blocked until:

1. Pack 17 is independently approved;
2. the implementation plan is independently approved;
3. VS-27A is certified and closed;
4. exact final legacy/compact/catch-up/backfill/import adapters are refreshed;
5. read-only source certification proves the exact attribution field registry, exposure and coverage boundary;
6. an activation supplement returns `APPROVE`.

Any production source enablement or cookie/WAF change requires a separate exact source-change supplement.

## Outcome

```text
certified WooCommerce acquisition evidence
→ bounded canonical acquisition DTO
→ one durable order acquisition snapshot
→ explicit acquisition coverage state
→ adapter parity across legacy/compact/catch-up/backfill
→ later bounded acquisition aggregates
→ later acquisition reporting
```

## Critical doctrine

```text
Acquisition evidence is not sales truth.
Last click is not multi-touch truth.
Missing evidence is not direct traffic.
Coupon is promotion, not automatically acquisition.
No arbitrary order meta.
No raw URL query strings, click IDs, IP, user-agent or customer identity.
Pack 16 transport law remains authoritative.
```
