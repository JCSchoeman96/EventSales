# Origin and Normalization Contract

## Source versus canonical fields

Keep source-reported values separate from derived canonical categories.

```text
source_type/source/medium/campaign
→ deterministic normalizer
→ origin_class
→ later channel_group classification
```

## Candidate origin classes

- `direct`;
- `organic`;
- `referral`;
- `utm`;
- `web_admin`;
- `api_or_other`;
- `unknown`.

Exact mapping comes from certified source values.

## Normalization

- Unicode NFKC;
- trim leading/trailing whitespace;
- reject control characters;
- collapse internal whitespace only where semantic-safe;
- casefold identity for source/medium/platform/tactic;
- preserve bounded safe display separately where needed;
- empty after normalization is absent;
- no HTML rendering;
- no percent-decoding loops;
- no URL query parsing except source adapter's exact field extraction.

## Aliasing

Do not silently merge:

- `facebook`, `facebook.com`, `fb`;
- `newsletter`, `email`;
- campaign spelling variants.

Marketing aliases/channel classification are versioned reviewed overlays in a later slice.

## Unknown values

A valid but unrecognised source value remains evidence with canonical `unknown`/`other`.

It is not rejected solely because it is new.

## Cardinality protection

Over-bound values are excluded from canonical dimension identity and produce `over_bound` evidence status or field finding.

Never truncate two values into the same identity.
