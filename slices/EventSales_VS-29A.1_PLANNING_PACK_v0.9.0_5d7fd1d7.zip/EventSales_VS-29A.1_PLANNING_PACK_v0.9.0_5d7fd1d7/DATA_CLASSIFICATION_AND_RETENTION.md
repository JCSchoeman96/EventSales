# Data Classification and Retention

## Classification

Acquisition evidence is business analytics data, not Sales authority.

Some marketer-provided strings may contain accidental personal or sensitive data. Therefore all values remain untrusted input and are sanitized/bounded.

## Retention

Planning default:

- current durable acquisition snapshot follows order/source retention;
- no raw cookie/referrer/query payload retained;
- WebhookEvent payload retention remains Pack 16 authority;
- classification/coverage evidence retains versions and safe hashes;
- no new indefinite raw evidence store.

## Deletion/anonymisation

Because the snapshot excludes customer identity, normal customer anonymisation should not require deleting campaign/source evidence unless legal policy says otherwise.

A privacy review must confirm this before production.

## Access

- source evidence writes: ingestion services only;
- raw source certification: tightly approved operators;
- safe admin debug: global admin;
- later event-scoped aggregate views: VS-27C policy;
- no order/customer linkage exported to marketing by default.

## Incident

If a UTM/campaign field contains PII:

- stop display/export;
- retain safe finding/hash;
- use reviewed correction/redaction;
- do not silently truncate and keep reporting it.
