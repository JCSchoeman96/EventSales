# Telemetry and Debug Contract

## Low-cardinality metadata

Allowed labels:

- adapter family;
- compact contract version;
- acquisition evidence version;
- coverage status;
- origin class;
- result/error code;
- source model;
- operation.

Not allowed as labels:

- source;
- medium;
- campaign;
- content;
- term;
- referrer host;
- order/event/customer ids;
- fingerprint;
- raw value hash.

## Measurements

- processed count;
- evidence-present count;
- missing/malformed/over-bound/conflict count;
- parse duration;
- persistence duration;
- body bytes;
- field count;
- source-to-visible lag;
- local rebuild progress.

## Debug UI

Admin-only safe view may show:

- source model/version;
- coverage and origin class;
- bounded sanitized marketing display values only if final access policy allows;
- field-presence state;
- source updated time;
- fingerprint prefix only if useful;
- safe error code.

It must not show raw referrer, click ids, cookies, arbitrary meta, IP/user-agent or customer identity.

Event-scoped marketing users require final VS-27C permissions and later reporting contracts.
