# Source Exposure Matrix

Activation must complete this exact-version matrix.

| Candidate field | WC_Order API | Legacy webhook | Woo REST catch-up | Woo REST backfill | Compact v1 | Compact v2 | Allowed |
|---|---|---|---|---|---|---|---|
| source type | ? | ? | ? | ? | decision | required/explicit | candidate |
| UTM source | ? | ? | ? | ? | decision | candidate | candidate |
| UTM medium | ? | ? | ? | ? | decision | candidate | candidate |
| UTM campaign | ? | ? | ? | ? | decision | candidate | candidate |
| UTM content | ? | ? | ? | ? | decision | candidate | evidence-only default |
| UTM term | ? | ? | ? | ? | decision | candidate | evidence-only default |
| UTM id | ? | ? | ? | ? | decision | candidate | certify not click id |
| source platform | ? | ? | ? | ? | decision | candidate | candidate |
| creative format | ? | ? | ? | ? | decision | candidate | candidate |
| marketing tactic | ? | ? | ? | ? | decision | candidate | candidate |
| referrer | ? | ? | ? | ? | no raw | host only | host only |
| device type | ? | ? | ? | ? | decision | candidate | optional |
| session pages | ? | ? | ? | ? | decision | candidate | optional |
| user-agent | ? | ? | ? | ? | forbidden | forbidden | no |
| IP | ? | ? | ? | ? | forbidden | forbidden | no |
| click ids | ? | ? | ? | ? | forbidden | forbidden | no |

## Rules

- `?` is not implementation permission.
- A field unsupported in one adapter must produce explicit adapter/coverage state.
- Do not scrape admin UI labels as source data.
- Database evidence may certify storage but does not automatically become runtime adapter authority.
