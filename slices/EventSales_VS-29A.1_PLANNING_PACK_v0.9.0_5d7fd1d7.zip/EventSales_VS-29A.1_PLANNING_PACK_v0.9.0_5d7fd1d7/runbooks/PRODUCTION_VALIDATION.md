# VS-29A.1 Production Validation

## Backend-only

- exact deployed SHA;
- migration/indexes;
- source unchanged;
- legacy/v1 Sales regression;
- acquisition snapshot fixtures;
- stale/equal/new source version;
- privacy/debug/telemetry;
- catch-up/backfill parity;
- query/load evidence.

## Source certification

- exact source versions/state;
- field registry/prefix;
- HPOS/REST/webhook exposure;
- coverage boundary;
- consent/WAF;
- competing plugins;
- safe cardinality.

## Optional source enablement

Only under exact supplement:

- pre/post state;
- checkout/WAF/consent;
- synthetic sources;
- coverage start;
- rollback.

## Optional compact v2

Only under exact supplement:

- shadow;
- exact canary;
- broadening;
- native HMAC;
- parity;
- privacy/body bounds;
- rollback.

## Coverage certification

Record:

- eligible orders;
- covered/uncovered;
- explicit origin classes;
- malformed/conflict;
- certified-from/through;
- gaps;
- sales completeness independently.

## Final verdict

- `CERTIFIED — VS-29A.2 MAY START`;
- `CERTIFIED WITH ACCEPTED COVERAGE LIMIT`;
- `REJECTED / BLOCKED`.

No acquisition aggregate or dashboard is implicitly authorised.
