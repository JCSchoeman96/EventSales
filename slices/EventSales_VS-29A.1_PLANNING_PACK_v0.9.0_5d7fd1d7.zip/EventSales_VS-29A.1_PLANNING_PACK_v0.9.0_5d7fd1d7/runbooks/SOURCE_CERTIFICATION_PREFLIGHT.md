# Source Certification Preflight

## Preconditions

- Pack and planning review approved;
- exact read-only source supplement approved;
- no source settings changed;
- no raw production values exported.

## Inventory

Record exact:

- WordPress/WooCommerce/PHP/database versions;
- HPOS state;
- Order Attribution feature option;
- field-registry and prefix filters;
- checkout block/classic paths;
- consent plugins;
- WAF/CDN/cookie rules;
- attribution/UTM/CRM plugins and snippets;
- Pack 16 bridge;
- Woo webhooks/REST API versions.

## Official code verification

From the exact installed WooCommerce tag/commit inspect:

- Order Attribution controller;
- field registry/default fields;
- tracking prefix;
- checkout stamping;
- REST exposure;
- feature option;
- cookie/session settings;
- consent integration;
- base64-cookie filter.

Record file/line/hash evidence.

## Safe probes

Create synthetic/staging orders for direct, UTM, organic, referral, web-admin and unknown.

Inspect through:

- `WC_Order` APIs;
- native webhook fixture;
- REST catch-up fixture;
- compact bridge shadow fixture;
- HPOS/CPT evidence.

## Production sample

Use bounded aggregate queries returning:

- counts by field presence;
- lengths;
- distinct counts;
- earliest/latest observed;
- category counts;
- malformed counts.

Hash values locally where needed.

Do not return raw values.

## Output

Complete `SOURCE_CERTIFICATION_REPORT_TEMPLATE.md`.

Verdict only; no feature change.
