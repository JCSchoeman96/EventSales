# Migration and Local Backfill Preflight

## Topology

Record exact:

- main/deployed SHA;
- PostgreSQL version/size;
- pooler/direct migration route;
- `sales_orders` count;
- WebhookEvent retained payload count;
- backfill/catch-up state;
- source health.

## Migration

Candidate changes are additive:

- acquisition snapshot table/resource;
- order relationship;
- coverage window resource if approved;
- minimal indexes;
- Ash snapshots.

No payload parsing or source calls in migration.

## Existing data options

Priority:

1. certified source backfill/catch-up adapter;
2. bounded extraction from retained WebhookEvent payloads;
3. explicit unavailable/unsupported state.

Do not scan all raw payloads inside migration.

## Restartability

Any local projection job:

- bounded batches;
- deterministic keyset;
- source-version guard;
- safe progress;
- no raw errors;
- idempotent;
- pause/stop;
- coverage outcome.

## Stop

- table rewrite/long lock;
- hidden meta cannot be extracted safely;
- source coverage unknown;
- raw PII would enter logs/evidence;
- acquisition write can partially desynchronise order writer without repair.
