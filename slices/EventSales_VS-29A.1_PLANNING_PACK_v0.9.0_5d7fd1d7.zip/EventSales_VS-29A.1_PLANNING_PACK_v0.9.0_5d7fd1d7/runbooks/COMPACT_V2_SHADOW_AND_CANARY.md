# Compact v2 Shadow and Canary

## Preconditions

- backend v2 parser deployed/certified;
- source acquisition evidence certified;
- exact v2 schema/hash approved;
- Pack 16 bridge exact version;
- no source field uncertainty;
- cutover supplement approved.

## Shadow

Build v2 candidate but return the currently preferred legacy/v1 payload.

Record only safe:

- schema validation;
- coverage status;
- field-presence counts;
- body bytes;
- canonical acquisition fingerprint;
- legacy/REST parity;
- privacy verdict.

No dual HTTP delivery.

## Exact canary

Use exact approved order ids with deterministic source selection.

Verify:

- native Woo headers/delivery/HMAC;
- v2 contract classification;
- acquisition DTO;
- order/acquisition snapshot transaction outcome;
- unchanged Sales effects;
- catch-up/backfill parity;
- duplicate/stale/replay;
- body/Redis bounds;
- privacy.

## Broadening

Use reviewed basis points only after exact canary.

No automatic progression.

## Rollback

Return source to v1/legacy while backend keeps v2 support for queued/stored events.

## Stop

- unknown/missing required acquisition section;
- canonical mismatch;
- source-version conflict;
- privacy finding;
- increased failure/lag;
- body/buffer bound;
- source fallback unavailable.
