# Acquisition Coverage Certification

## Purpose

Establish when and how much acquisition evidence can support later reports.

## Eligible order denominator

Define before querying:

- source system;
- order creation range;
- relevant order types;
- statuses;
- exclusions for tests/admin/API only when source categories remain visible;
- duplicate/stale source rules.

## Read-only measures

By day/week:

- eligible order count;
- orders with any certified attribution section;
- explicit direct/organic/referral/UTM/admin/unknown;
- no evidence;
- malformed/over-bound;
- adapter unsupported;
- field presence;
- source version distribution.

## Boundary

Record:

- earliest observed order;
- earliest sustained evidence date;
- source feature enablement evidence if available;
- certified-from date;
- gaps/outages;
- current coverage percentage.

Do not infer the option enablement time only from the first order.

## Sales independence

Do not modify sales completeness watermarks.

Acquisition reports later display both:

- sales completeness;
- acquisition coverage.

## Verdict

- coverage certified from exact date;
- partial/gapped coverage;
- insufficient for reporting;
- blocked.
