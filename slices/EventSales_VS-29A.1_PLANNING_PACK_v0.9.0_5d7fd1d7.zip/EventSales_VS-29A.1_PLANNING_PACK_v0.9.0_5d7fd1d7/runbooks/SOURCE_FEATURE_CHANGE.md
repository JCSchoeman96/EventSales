# WooCommerce Source Feature Change

## Scope

Only use after `SOURCE_CHANGE_SUPPLEMENT_TEMPLATE.md` returns an exact approval.

## Preconditions

- exact installed versions unchanged;
- consent/legal owner approved;
- WAF/CDN/cookie behaviour tested;
- classic and Store API checkout tested;
- backend acquisition support deployed;
- source safe field exposure certified;
- rollback command tested.

## Enablement

Use the exact approved WooCommerce option/filter only.

Do not add a second custom tracker.

## Verify

- feature state;
- no checkout/WAF errors;
- consent denied/granted behaviour;
- source cookies bounded and session-scoped;
- synthetic direct/UTM/referral/organic/admin orders;
- evidence stored on order;
- REST/webhook/compact exposure;
- no PII/click-id leakage;
- EventSales coverage begins as expected.

## Monitoring

- checkout error rate;
- 403/WAF rate;
- attribution presence;
- malformed/over-bound values;
- source-to-EventSales lag;
- legacy/v1/v2 parse failures;
- privacy findings.

## Rollback

Restore the previous feature/filter state.

Record the resulting coverage gap explicitly.

Do not relabel orders during the disabled period.

## Stop

Any consent, WAF, checkout, privacy, signature, parity or order-ingestion regression.
