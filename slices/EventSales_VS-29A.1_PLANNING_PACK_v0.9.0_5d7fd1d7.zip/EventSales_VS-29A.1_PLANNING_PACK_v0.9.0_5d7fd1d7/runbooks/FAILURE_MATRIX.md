# Operational Failure Matrix

| Stage | Failure | Safe response | Operator action |
|---|---|---|---|
| source audit | exact version/field registry unknown | block | refresh source evidence |
| source audit | competing plugin values | conflict | product/source decision |
| source audit | hidden meta absent from REST | unsupported | safe exposure design |
| backend deploy | legacy/v1 Sales regression | disable/rollback app | fix exact diff |
| backend deploy | migration lock/index issue | stop | topology/index review |
| adapter | arbitrary meta appears | ignore/reject | allowlist review |
| adapter | full URL/click id | exclude/fail field | privacy remediation |
| writer | stale version | no-op | none |
| writer | equal version/different fingerprint | conflict | case/catch-up |
| writer | newer evidence invalid | preserve old + finding | source fix |
| coverage | pre-enable missing | unavailable | normal |
| coverage | post-enable evidence drops | gap/alert | source/WAF/consent review |
| source enable | checkout/WAF regression | rollback source | incident |
| source enable | consent behaviour invalid | rollback/block | legal/consent review |
| compact v2 | HMAC/parse failure | rollback v1/legacy | source/backend fix |
| compact v2 | body/buffer over bound | rollback | reduce schema |
| compact v2 | acquisition parity mismatch | rollback/block | adapter fix |
| privacy | raw value in logs/evidence | security incident | stop/purge/remediate |
| reporting handoff | cardinality excessive | keep evidence-only | taxonomy/bounds |
| coupons | multi-coupon double count proposed | block | later metric law |
