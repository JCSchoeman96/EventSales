# Order Attribution Field Discovery

## Goal

Resolve the exact installed source field registry without assuming documentation examples equal production code.

## Discover

- invoke/inspect the final `wc_order_attribution_tracking_fields` result in a safe diagnostic;
- resolve `wc_order_attribution_tracking_field_prefix`;
- list field descriptions/types from exact source code;
- verify which fields are written on classic and Store API checkout;
- verify hidden/public meta status;
- verify REST/webhook response names;
- verify filter/plugin modifications.

## Expected candidates only

- source type;
- referrer;
- UTM source/medium/campaign/content/term/id;
- source platform;
- creative format;
- marketing tactic;
- device type;
- session page count;
- possible session metadata.

Do not treat candidates as certified.

## Safe diagnostic output

```text
source_version
field_name
meta_key_hash
field_type
present_count
nonempty_count
max_length
distinct_count
rest_exposed
webhook_exposed
compact_exposed
```

Do not output raw values or the full meta prefix if it is considered operationally sensitive; normally the field name/prefix is not a secret, but evidence should stay minimal.

## Unsupported/custom fields

Classify:

- core default;
- core optional;
- registered by plugin/filter;
- unknown;
- forbidden.

Unknown custom fields are not ingested automatically.

## Exit

Produce the exact allowlist and exposure matrix for activation.
