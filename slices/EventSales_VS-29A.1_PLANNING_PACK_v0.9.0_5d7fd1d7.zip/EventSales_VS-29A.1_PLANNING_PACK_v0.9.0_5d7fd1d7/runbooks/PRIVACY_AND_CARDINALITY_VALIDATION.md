# Privacy and Cardinality Validation

## Seeded values

Use synthetic distinct markers for:

- customer PII;
- IP/user-agent;
- full referrer/landing URL;
- URL query/fragment/userinfo;
- click ids;
- cookies/session ids;
- order key;
- payment/provider ids;
- ticket/download tokens;
- script/control characters;
- overlong UTM values.

## Prove absence

Inspect:

- source safe REST field;
- compact v2 body;
- legacy adapter DTO;
- persisted snapshot;
- logs;
- telemetry;
- PubSub;
- debug UI;
- evidence;
- exports.

## URL tests

- valid external host;
- international domain;
- uppercase;
- port/path/query/fragment;
- userinfo;
- localhost/private IP;
- malformed percent encoding;
- javascript/data schemes.

Store only valid normalized host.

## Cardinality

Measure safe histograms and hashes.

Block reporting fields whose cardinality or value quality exceeds approved bounds.

`term` and `content` default to evidence-only.

## Telemetry

No raw source/campaign/referrer value as a label.

Use low-cardinality status/version/count metrics.
