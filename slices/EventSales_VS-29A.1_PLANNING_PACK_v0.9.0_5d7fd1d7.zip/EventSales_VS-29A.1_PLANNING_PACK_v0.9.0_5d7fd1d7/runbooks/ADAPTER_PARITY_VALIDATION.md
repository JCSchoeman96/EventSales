# Adapter Parity Validation

## Fixtures

For the same synthetic source order obtain:

- native legacy webhook payload;
- compact v1 output/unsupported status;
- compact v2 candidate;
- catch-up REST payload;
- backfill REST payload.

No production raw payload is committed.

## Extract

Each adapter returns:

```text
canonical acquisition DTO
field presence
coverage status
source version
fingerprint
```

## Compare

- exact canonical fingerprint where supported;
- explicit unsupported coverage where not;
- no arbitrary meta leakage;
- no full URL/query/click id;
- same normalization;
- same malformed/over-bound result;
- same source version.

## Hidden meta failure

If REST/backfill lacks attribution:

1. prove exact cause;
2. evaluate a safe explicit REST field in the source bridge;
3. evaluate a bounded signed endpoint only if necessary;
4. retain unsupported state if no safe remedy is approved.

Never add direct production database reads as the runtime adapter by convenience.

## Result

Any mismatch blocks compact v2/source rollout.
