# Backend Implementation and Deployment

## Preconditions

- Pack/plan/source certification approved;
- VS-27A certified;
- exact canonical DTO/schema frozen;
- source remains unchanged.

## Implement

Deploy only the activated backend stage:

- acquisition adapter interface;
- exact legacy/full adapter;
- compact v1 supported/unsupported handling;
- compact v2 parser support where activated;
- `OrderAcquisitionSnapshot`;
- source-version/idempotency/conflict logic;
- coverage state;
- telemetry/debug privacy;
- migrations/indexes;
- tests/docs.

Do not enable source tracking or compact v2 emission.

## Deployment validation

- migration/index validity;
- legacy order processing unchanged;
- compact v1 order processing unchanged;
- no Sales contribution changes;
- acquisition snapshot idempotency;
- stale/equal/new source versions;
- privacy scan;
- catch-up/backfill adapter fixture parity;
- payload purger/debug behaviour;
- queue/load/query plans.

## Rollback

Disable acquisition snapshot writes/reads with feature configuration.

Keep order ingestion operational.

Do not drop tables or revert source data during incident response.

## Exit

`CERTIFIED — SOURCE OR COMPACT V2 CHANGE MAY BE REVIEWED`
or a documented blocker.
