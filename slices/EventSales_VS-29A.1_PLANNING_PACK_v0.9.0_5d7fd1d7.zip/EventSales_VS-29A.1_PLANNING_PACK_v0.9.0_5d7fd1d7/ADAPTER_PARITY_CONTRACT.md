# Acquisition Adapter Parity Contract

## Adapters

```text
legacy native Woo webhook
eventsales.order.v1 where supported
eventsales.order.v2 acquisition envelope
VS-26F catch-up REST
VS-28A backfill REST
VS-28B import only when explicit
→ canonical acquisition DTO
→ one durable snapshot writer
```

## Legacy/full Woo adapter

Read only exact certified attribution meta keys or explicit REST fields.

Do not pass all `meta_data` into the canonical DTO.

## Compact v1

Two allowed outcomes:

1. final v1 registered an exact optional acquisition section before certification; or
2. v1 has no acquisition and returns `adapter_not_supported`.

Do not reinterpret an already certified v1 payload.

## Compact v2

Planning default:

```text
contract = eventsales.order.v2
acquisition = {
  contract: eventsales.acquisition.v1,
  coverage_status: ...,
  fields: ...
}
```

v2 otherwise preserves final v1 order/child semantics.

## Catch-up/backfill

Use the exact same source extraction and normalization.

If Woo REST does not expose hidden core attribution meta, source certification must choose one reviewed remedy:

- safe explicit REST field added by the Pack 16/17 source bridge;
- bounded signed source endpoint consumed by approved ingestion workers;
- no support with explicit coverage state.

No database-specific production adapter becomes runtime authority merely because meta is hidden.

## Import

Imported acquisition evidence has a separate authority class and provenance.

It may not overwrite newer certified source evidence without Pack 15 conflict/correction law.

## Parity proof

Equivalent source order state produces equal canonical fingerprint across every supported adapter.
