# Coverage and Absence Contract

## Principle

Sales completeness and acquisition coverage are independent.

A sales result may be certified while only part of the orders have usable acquisition evidence.

## Order-level coverage states

Candidate enum:

- `observed`;
- `explicit_direct`;
- `explicit_organic`;
- `explicit_referral`;
- `explicit_utm`;
- `explicit_web_admin`;
- `explicit_unknown`;
- `unavailable_before_enablement`;
- `source_feature_disabled`;
- `adapter_not_supported`;
- `not_observed`;
- `malformed`;
- `over_bound`;
- `conflict`.

The final mapping is source-evidence driven.

## Source-level coverage record

Candidate `AcquisitionCoverageWindow`:

```text
source_system_id
source_model
observed_from
certified_from
certified_through
feature_enabled_at
adapter_supported_from
coverage_ratio
sample_size
status
blocked_reason
evidence_hash
```

## Rules

- earliest order with metadata is not automatically the feature enablement timestamp;
- pre-enablement orders are not direct;
- absent UTM with a valid direct/referral/organic source is still observed;
- missing all fields is not direct;
- manually created orders may be explicit web-admin if source says so;
- coverage ratio includes eligible orders and clearly defines denominator;
- campaign reports expose covered/uncovered counts and percentage.

## Backfill

Backfill may ingest available historical evidence, but cannot manufacture evidence absent in source.

Acquisition coverage certification is a separate gate from sales backfill certification.
