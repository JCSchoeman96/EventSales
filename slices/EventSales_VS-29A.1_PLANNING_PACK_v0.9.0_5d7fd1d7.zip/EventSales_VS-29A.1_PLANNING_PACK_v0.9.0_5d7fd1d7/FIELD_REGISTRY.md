# Acquisition Field Registry

This registry is provisional until source certification.

## Core identity and coverage

| Field | Type | Bound | Notes |
|---|---|---:|---|
| `source_model` | enum | 64 | expected `woocommerce_core_session_last_click` |
| `source_model_version` | string | 64 | exact certified implementation/version |
| `evidence_version` | string | 64 | EventSales field registry |
| `coverage_status` | enum | — | explicit evidence state |
| `absence_reason` | enum/null | — | only when evidenced |
| `origin_class` | enum | — | canonical origin category |
| `source_type` | normalised string/null | 100 | source-reported type |
| `normalization_version` | string | 64 | deterministic rules |
| `canonical_fingerprint` | SHA-256 | 64 | no raw values |

## Marketing fields

| Field | Normalization | Max |
|---|---|---:|
| `source_name` | trim, Unicode normalize, casefold identity, display preserved safely | 200 |
| `medium` | trim, lower/casefold identity | 100 |
| `campaign` | trim, safe display + normalized identity | 250 |
| `content` | trim, safe display + normalized identity | 250 |
| `term` | trim, safe display + normalized identity | 250 |
| `campaign_id` | bounded opaque marketing id, not click id | 200 |
| `source_platform` | lower/casefold identity | 100 |
| `creative_format` | lower/casefold identity | 100 |
| `marketing_tactic` | lower/casefold identity | 100 |

## Context fields

| Field | Rule |
|---|---|
| `referrer_host` | lowercased IDNA-safe host only; no path/query/userinfo |
| `device_class` | allowlist: desktop/mobile/tablet/other/unknown |
| `session_page_count` | integer 0–10,000; values above bound reject/cap only by reviewed rule |

## Excluded by default

- full referrer;
- session entry URL/path;
- session start timestamp unless reporting need is proven;
- session count unless exact meaning is certified;
- user-agent;
- IP;
- source cookie contents;
- arbitrary fields returned by filters;
- click IDs.
