# Linear Gate Ledger

The Linear issue creation call was blocked, so M8 and the Pack 17 document hold the gate record.

Required sequence:

1. PACK
2. PACK REVIEW
3. PLAN
4. PLAN REVIEW
5. SOURCE CERTIFICATION PLAN
6. SOURCE CERTIFICATION APPROVAL
7. READ-ONLY SOURCE CERTIFICATION
8. SOURCE EVIDENCE REVIEW
9. ACTIVATE IMPLEMENTATION
10. IMPLEMENT
11. PR REVIEW
12. MERGE/DEPLOY
13. BACKEND VALIDATION
14. SOURCE/COMPACT CHANGE REVIEW IF REQUIRED
15. PRODUCTION VALIDATION
16. CLOSE
17. UNLOCK VS-29A.2

Tracking authority:

- GitHub #132;
- immutable Pack 17 ZIP/SHA;
- Linear M8;
- Linear document `VS-29A.1 — Pack 17 Gate Ledger and Planning Record`.

No earlier approval authorises a later source or deployment gate.
