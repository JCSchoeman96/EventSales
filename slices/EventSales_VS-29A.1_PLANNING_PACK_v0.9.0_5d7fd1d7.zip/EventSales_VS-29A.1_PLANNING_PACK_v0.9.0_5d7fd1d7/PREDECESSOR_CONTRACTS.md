# Predecessor Contracts

## VS-27A — Compact source contract

VS-27A owns:

- contract identifiers;
- exact allowlists;
- raw-body HMAC;
- native Woo delivery;
- dual-read sequencing;
- child-set completeness;
- source privacy and body bounds;
- legacy support/retirement.

VS-29A.1 may define an acquisition envelope only through the final VS-27A compatibility process.

It does not mutate `eventsales.order.v1` by implication.

## VS-26F — Catch-up

Catch-up remains recovery authority for missed order updates.

If source acquisition fields are exposed in the certified REST representation, catch-up must parse the same evidence and call the same acquisition snapshot writer.

No source callback occurs during webhook processing.

## VS-26G and VS-27B

Product semantics and metric contracts remain authoritative for ticket/revenue/refund/tax/fee effects.

Acquisition evidence does not change contribution amounts.

Later acquisition reporting joins certified line contributions to the order acquisition snapshot.

## VS-28A — Backfill

Backfill remains historical sales completeness authority.

Acquisition evidence coverage is separate and may begin later than the selected event's sales history.

Backfill must not label pre-enablement orders as direct.

## VS-28B — Import/correction

Imports do not masquerade as source acquisition evidence.

An import may carry acquisition evidence only under an explicit schema and lower authority class.

Manual marketing classification or campaign aliasing is a reviewed overlay/correction, never a silent rewrite of source evidence.

## Pack 16 privacy

No arbitrary order metadata, click IDs, customer identity, IP, user-agent, URLs with query strings, provider payloads or tokens may enter compact bodies, logs, packs or evidence.
