# Planning Agent Prompt — VS-29A.1

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-29A.1_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
GitHub: `#132`

## Authorised phase

Repository and source reconnaissance planning only.

Do not modify files, dependencies, migrations, schemas, source plugins, Woo settings, cookies, consent, WAF, compact contracts or production data. Do not call production WordPress/WooCommerce without an exact source-certification supplement. Do not commit, open a PR, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every repository path in `FILE_INVENTORY.md`, every Pack 17 file and the final certified Pack 16/VS-27A artefacts.

Use official WooCommerce source/docs for the exact installed version. Record tag/commit/file evidence.

## Required decisions

1. current-code gap verification;
2. exact installed WordPress/Woo/HPOS/Tickera/bridge/consent/WAF inventory;
3. core Order Attribution enabled/disabled state;
4. exact field registry and meta prefix after filters;
5. source model/limitations;
6. earliest/certified coverage boundary;
7. REST/webhook/backfill exposure;
8. competing plugin/custom UTM fields;
9. safe source sampling method;
10. exact canonical acquisition DTO;
11. field presence/absence semantics;
12. origin mapping and normalization;
13. URL/referrer host handling;
14. click-ID exclusion;
15. cardinality/value/body bounds;
16. durable `OrderAcquisitionSnapshot` design;
17. source-version/idempotency/conflict law;
18. migration/index strategy;
19. `OrderUpserter` child-writer integration;
20. adapter parity;
21. compact v1 compatibility decision;
22. compact v2 schema/rollout if required;
23. catch-up/backfill remedy if hidden meta is not exposed;
24. import/correction authority;
25. acquisition coverage window;
26. sales completeness separation;
27. coupon/promotion boundary;
28. mixed-event order join;
29. classification/alias overlay boundary;
30. telemetry/debug/privacy;
31. tests-first sequence;
32. exact files/dependencies/config/migrations;
33. load/query-plan evidence;
34. staged PR/deployment plan;
35. source change supplements;
36. rollback/stop conditions;
37. M8 gate mapping;
38. successor A.2/A.3 handoff.

## Output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with exactly one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
