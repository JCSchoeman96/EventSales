# Retention and Completeness Contract

## V1 retention

Planning default:

- contribution projections retained while underlying normalized history is retained;
- hourly buckets retained without automatic purge in v1;
- daily buckets retained without automatic purge;
- current version-one snapshot rows retained until B.3 cutover and later deprecation review.

This avoids losing historical hourly resolution before real storage measurements exist.

Any future retention policy requires:

- measured table/index size;
- daily/hourly parity proof;
- explicit supported-resolution change;
- reviewed purge cursor and recovery;
- no impact on certified completeness claims.

## Completeness

Bucket rows record build metadata, not historical completeness authority.

BucketReader combines:

- bucket build/read-model state;
- B.1 metric/semantic versions;
- F.2 source freshness;
- approved backfill/completeness watermark.

States must distinguish:

- source fresh but historical partial;
- bucket built but source stale;
- contribution projection behind;
- dirty bucket pending;
- bucket missing;
- complete for requested window.

## Backfill boundary

B.2 may build buckets from already-normalized EventSales facts.

It may not fetch historical WooCommerce orders.

VS-28A populates Sales truth; B.2 projection/repair then builds buckets through the same pipeline.

## Existing Railway data

No migration may automatically bless current Railway history as complete. Production validation uses a bounded canary until backfill certification exists.
