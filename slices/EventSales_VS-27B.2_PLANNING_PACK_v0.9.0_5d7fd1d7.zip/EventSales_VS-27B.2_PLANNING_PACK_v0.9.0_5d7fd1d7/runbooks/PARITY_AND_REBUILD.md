# Parity and Rebuild Runbook

## Canary parity

For one event and exact hour/day:

1. Evaluate certified B.1 contributions directly.
2. Sum contribution projection.
3. Read event bucket.
4. Read ticket-type buckets and sum.
5. Compare every Decimal and quantity exactly.
6. Compare contract versions, currency and period bounds.
7. Record contribution count/revision.

All layers must match.

## Bounded rebuild

1. Select explicit event/date/version scope.
2. Preview bucket count and contribution count.
3. Require operator approval for production rebuild.
4. Mark exact keys dirty in bounded batches.
5. Drain and record progress.
6. Compare parity sample/full scope.
7. Do not fetch WooCommerce.

## Repair scenarios

- delete/disable one queued projector hint and verify cursor repair;
- enqueue duplicate projection;
- run older bucket worker after newer revision;
- remap one line;
- apply one refund correction;
- move one timestamp across hour/day boundary.
