# Migration Preflight

## Read-only checks

- exact production SHA;
- Postgres version;
- direct/session-capable migration URL;
- PgBouncer mode if present;
- current Sales/Analytics row counts;
- existing index definitions;
- active Oban jobs;
- disk headroom;
- migration lock route;
- B.1/G/F.2 migrations applied.

## Plan checks

- additive tables only;
- no migration-time projection/rebuild;
- generated migration reviewed;
- revision sequence ownership;
- foreign-key delete behaviour;
- populated-table indexes assessed for blocking;
- rollback limits explicit;
- queue disabled on deploy.

## Stop

- topology unknown;
- migration route transaction-pooled only where session features required;
- lock estimate unsafe;
- duplicate table/index names;
- incompatible Postgres feature assumption;
- active rollout uses the same tables unexpectedly.
