# Projection and Repair Runbook

## Fast path

1. Receive a post-commit order/correction hint.
2. Queue one projection job for the stable source/order identity.
3. Projector reads complete durable Sales/semantic truth.
4. Evaluate certified B.1 contributions.
5. Compare prior projections.
6. Allocate one revision.
7. Upsert contributions and old/new dirty keys transactionally.
8. Queue bounded dirty draining.
9. Record low-cardinality telemetry.

## Repair path

1. Load analytics projection cursor for source.
2. Scan a bounded page of locally changed relevant facts.
3. Use stable timestamp plus id tie-break and reviewed overlap.
4. Project each order/scope.
5. Advance cursor only after durable success.
6. Requeue while work remains.
7. Never call WooCommerce.

## Failure handling

- projection failure: cursor does not pass record;
- enqueue failure: dirty state remains or next repair discovers change;
- partial upstream state: classify incomplete and retry after later update;
- missing semantic version: block projection;
- PII detected: stop and reject field set.
