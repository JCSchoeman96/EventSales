# Failure Matrix

| Failure | Durable result | Recovery |
|---|---|---|
| notifier missed | no fast job | repair cursor projects |
| projector duplicate | same projection/revision-safe | idempotent |
| projector fails | cursor held | retry |
| dirty enqueue fails | dirty DB row remains | drainer/periodic repair |
| two drainers | one row claim/key | DB locks |
| stale bucket worker | conditional write rejected | newer revision remains |
| correction changes key | old/new dirty | both rebuilt |
| all contributions removed | built-zero row | reader returns zero-built |
| PubSub fails | bucket correct | reload/poll |
| contribution query timeout | dirty retryable | bounded retry |
| mixed currency request | grouped/error | narrow scope |
| missing bucket | explicit missing/rebuilding | repair |
| B.1 version mismatch | projection blocked | activation/rebuild |
| migration succeeds, workers fail | empty/additive tables | keep old dashboard |
| repair cursor gap | parity mismatch | overlap/full bounded repair |
| PII field included | release blocked | remove/migrate safely |
