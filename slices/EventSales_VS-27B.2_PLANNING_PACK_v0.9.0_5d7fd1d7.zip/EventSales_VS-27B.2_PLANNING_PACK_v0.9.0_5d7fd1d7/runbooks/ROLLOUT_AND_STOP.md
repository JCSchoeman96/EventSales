# Rollout and Stop Conditions

## Rollout

1. Deploy additive schema with all B.2 workers disabled.
2. Verify migrations and indexes.
3. Enable contribution observation for one event.
4. Verify no PII and exact B.1 parity.
5. Enable durable dirty writes.
6. Enable event bucket builds for one hour/day.
7. Enable ticket-type buckets.
8. Simulate missed hint and verify repair.
9. Simulate stale worker and verify revision guard.
10. Simulate remap/refund correction.
11. Enable periodic repair.
12. Expand current-event scope.
13. Record query plans/load evidence.
14. Keep current dashboard/snapshots authoritative.
15. Certify at JC-199 before B.3.

## Kill switches

- projector;
- dirty drainer;
- periodic repair;
- event buckets;
- ticket-type buckets;
- PubSub;
- production rebuild.

## Stop immediately

- B.1 meaning changes inside B.2;
- dirty state can be lost;
- stale overwrite succeeds;
- old key remains wrong after correction;
- contribution projection stores PII;
- unbounded Sales/event scan;
- mixed currency sum;
- migration builds data;
- B.3 switches readers;
- source/Woo call occurs;
- parity mismatch cannot be explained.
