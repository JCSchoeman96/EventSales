# Dirty Bucket Drain Runbook

1. Start one bounded drainer.
2. Claim up to configured rows using row locks / `SKIP LOCKED`.
3. For each key:
   - re-read requested revision;
   - query exact contribution period/scope;
   - reduce using B.1;
   - conditionally upsert bucket;
   - mark built only if request has not advanced.
4. Commit before PubSub.
5. Broadcast small event/source invalidation.
6. Release/retry failed rows with bounded error.
7. Stop at batch/time budget.
8. Requeue if pending work remains.

## Duplicate drainer

Multiple drainers are safe because DB row claims and unique bucket keys are authoritative.

## Empty result

Write a built-zero bucket with revision evidence; do not confuse absent with zero.
