# Bucket Read Contract

## Read facade

Provide a bounded non-web facade such as `Analytics.BucketReader`.

Inputs:

- event scope;
- ticket-type scope when allowed;
- current window and optional comparison;
- resolution;
- currency;
- metric contract version;
- semantic policy version;
- one `as_of`.

Outputs:

- exact period metadata;
- metric values;
- ordered series;
- comparison values/state;
- currency;
- completeness;
- source freshness;
- bucket/read-model freshness;
- contract versions;
- explicit partial/truncated/error states.

## No raw Sales scans

LiveView/controllers/components may not query Sales rows or contribution tables directly.

All reads pass through the facade.

## All-event sums

Ticket and revenue fields are additive across complete event buckets.

`All events` must use every event in the selected scope, not UI pagination.

Distinct-order status metrics are not additive across event buckets and require their separately certified current-state/activity read model.

## Missing buckets

The reader must not silently query all Sales rows as fallback.

Return:

- missing/not built;
- partial;
- rebuilding;
- unsupported resolution;
- narrower range required.

A bounded contribution edge query is allowed only under the edge-window contract.

## Query bounds

- inherit B.1 event/range/point limits;
- one query or small bounded query set per series;
- no N+1 event reads;
- stable ordering;
- explicit maximum ticket-type cardinality;
- representative query plans required.
