# TOON Prompts — VS-27B.2

## Planning agent
Task: Design durable versioned contribution-to-bucket convergence from current code.
Output: Complete implementation plan.
Boundary: No code, migrations or production actions.

## Concurrency reviewer
Task: Attack dirty claims, revisions, stale workers and duplicates.
Output: Race matrix and verdict.
Boundary: Durable DB state is authority.

## Data-model reviewer
Task: Attack contribution/bucket identities, currency, versions and constraints.
Output: Schema findings.
Boundary: No polymorphic ambiguity.

## Query reviewer
Task: Attack edge reads, all-event queries, N+1 and indexes.
Output: Query-plan requirements.
Boundary: No raw Sales reads from web.

## Migration reviewer
Task: Attack locks, backfill, rollback and compatibility.
Output: Rollout verdict.
Boundary: Additive and disabled first.

## Activation reviewer
Task: Refresh B.1/G/F.2/current main/topology.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
