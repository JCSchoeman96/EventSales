# VS-27B.2 Implementation Plan

## 1. Baseline proof and drift
## 2. Files inspected
## 3. Certified B.1 contribution/window interface
## 4. Certified G/F.2 interfaces
## 5. Current snapshots/notifier/upserter truth
## 6. Recommended staged delivery
## 7. Contribution persistence decision
## 8. Contribution identity/fields/versioning
## 9. Monotonic revision authority
## 10. Projection transaction and partial upstream writes
## 11. Projection repair cursor
## 12. Dirty-bucket resource and claim state machine
## 13. Event bucket resource
## 14. Ticket-type bucket resource
## 15. Hour/day alignment and keys
## 16. Metric fields/sign/zero constraints
## 17. Old/new correction matrix
## 18. Stale-worker protection
## 19. Oban queues/workers/uniqueness
## 20. Activity-bucket support decision
## 21. BucketReader interface
## 22. Edge-window contribution queries
## 23. All-event/range query plan
## 24. Currency/completeness/freshness
## 25. Existing snapshot compatibility
## 26. Retention
## 27. Migrations/indexes/lock strategy
## 28. Tests-first sequence
## 29. Exact files create/modify/generated/forbidden
## 30. Verification commands
## 31. Rollout/kill switches
## 32. Production canary/parity evidence
## 33. JC-195 activation inputs
## 34. Risks/stop conditions
## 35. Prohibited-actions statement
