# Mandatory File Inventory — VS-27B.2

## Governance and roadmap
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Certified predecessor artifacts
- final VS-27B.1 pack, plan, activation, PR review and production certification;
- certified VS-26G semantic resources/policy/tests;
- certified VS-26F.2 recovery/freshness resources and tests.

## Current Analytics domain
- `lib/event_sales/analytics.ex`
- `lib/event_sales/analytics/metric_rules.ex`
- certified B.1 contract/contribution modules;
- `lib/event_sales/analytics/aggregators/event_aggregator.ex`
- `lib/event_sales/analytics/aggregate_event.ex`
- `lib/event_sales/analytics/aggregate_event_idempotency.ex`
- `lib/event_sales/analytics/order_processed_notifier.ex`
- `lib/event_sales/analytics/hot_state_aggregator.ex`
- `lib/event_sales/analytics/dashboard_pub_sub.ex`
- `lib/event_sales/analytics/dashboard_cache.ex`

## Existing snapshots
- `lib/event_sales/analytics/snapshot_refresh.ex`
- `lib/event_sales/analytics/snapshot_reader.ex`
- `lib/event_sales/analytics/snapshot_queries.ex`
- `lib/event_sales/analytics/resources/event_aggregate_snapshot.ex`
- `lib/event_sales/analytics/resources/daily_sales_aggregate_snapshot.ex`
- `lib/event_sales/analytics/workers/refresh_snapshot_worker.ex`
- `lib/event_sales/analytics/workers/rebuild_hot_state_worker.ex`
- `docs/architecture/historical-reporting-snapshots.md`

## Sales/ingestion mutation paths
- `lib/event_sales/sales/order_upserter.ex`
- `lib/event_sales/sales/order_item_mapper.ex`
- `lib/event_sales/sales/order_attribution_correction.ex`
- certified VS-26G historical correction/apply files;
- `lib/event_sales/ingestion/webhook_processor.ex`
- certified VS-26F.1 catch-up worker/facade;
- certified VS-26F.2 completion/recovery hooks.

## Current readers
- `lib/event_sales/analytics/admin_dashboard.ex`
- `lib/event_sales/analytics/event_detail.ex`
- `lib/event_sales_web/live/admin/dashboard_live.ex`
- `lib/event_sales_web/live/admin/event_detail_live.ex`

## Configuration/deployment
- `config/config.exs`
- `config/runtime.exs`
- `lib/event_sales/application.ex`
- `mix.exs`
- `mix.lock`
- `railway.toml`
- `docs/architecture/oban-pgbouncer.md`
- `docs/runbooks/oban-queue-backlog.md`

## Migrations
- `priv/repo/migrations/20260515124923_slice_4_sales.exs`
- `priv/repo/migrations/20260518062734_slice_9_7_historical_reporting_snapshots.exs`
- all later B.1/G/F.2 Sales/Analytics migrations.

## Tests
- `test/event_sales/analytics/metric_rules_test.exs`
- certified B.1 contract/boundary tests;
- `test/event_sales/analytics/event_aggregator_test.exs`
- `test/event_sales/analytics/historical_reporting_snapshots_test.exs`
- `test/event_sales/analytics/snapshot_boundaries_test.exs`
- `test/event_sales/analytics/refresh_snapshot_worker_test.exs`
- `test/event_sales/analytics/hot_state_aggregator_test.exs`
- `test/event_sales/analytics/order_processed_notifier_test.exs`
- `test/event_sales/analytics/admin_dashboard_test.exs`
- `test/event_sales/analytics/event_detail_test.exs`
- certified G/F.2 tests.
