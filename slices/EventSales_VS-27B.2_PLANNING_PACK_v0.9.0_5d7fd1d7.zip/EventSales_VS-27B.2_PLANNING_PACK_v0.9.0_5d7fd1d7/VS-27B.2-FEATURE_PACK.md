# VS-27B.2 — Durable Hourly and Daily Event Sales Buckets

## 1. Identity and status

- Pack: `0009_VS-27B.2`
- Version: `0.9.0`
- Status: planning review ready
- Baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub issue: #125
- Linear: JC-190 through JC-200
- Predecessor: VS-27B.1
- Successor: VS-27B.3
- Execution authority: none

## 2. Executive summary

VS-27B.1 defines what each metric and time window means. VS-27B.2 creates durable derived data that can answer those definitions without unbounded event-wide Sales scans.

The pipeline must remain correct when webhooks are duplicated or missed, catch-up replays an order, statuses change, lines move event/ticket type, timestamps change, old sales are refunded, semantics are corrected, workers run late, or PubSub fails.

## 3. Current repository truth

Current code has one mutable event snapshot, one event/business-day snapshot, no hourly bucket, event-wide reads before aggregation, daily in-memory filtering, a snapshot worker with no discovered production enqueue path, best-effort notifier calls, swallowed notifier failures, whole-event hot-state recomputation, in-memory dedupe, a single-concurrency analytics rebuild queue, no transactional order-plus-children writer, no analytics repair cursor, and no contribution-time composite indexes.

Notifier-only incremental deltas are therefore unsafe.

## 4. Product decisions implemented

This slice implements bounded durable reporting read models, B.1 metric semantics, hourly/daily event and ticket-type aggregates, complete all-event summation, freshness/completeness propagation, Postgres authority and PubSub notification-only behaviour.

## 5. Goal

A certified B.1 contribution is projected durably, marks every old and new affected bucket, and converges into exact hourly/daily rows. Replays, stale jobs and missed notifier calls produce no permanent drift.

## 6. Dependencies

Required:

- VS-27B.1 certified contribution/window contract;
- VS-26G semantic fields and corrections;
- VS-26F.2 freshness and recovery hooks;
- Railway/Postgres/Oban topology;
- direct/session-capable migration route.

Blocks VS-27B.3 and dependable pacing/reporting paths.

## 7. In scope

- canonical contribution projection when B.1 does not persist it;
- monotonic projection revision;
- durable coalesced dirty-bucket rows;
- event and ticket-type hour/day resources;
- exact recomputation;
- old/new invalidation;
- repair cursor;
- workers/read facade;
- partial-hour edge reads from contributions;
- source/event PubSub hints;
- additive migrations/indexes;
- tests, telemetry and canary.

## 8. Non-goals

No dashboard redesign, targets, roles, Woo REST, Woo historical backfill, new semantics, payment/ticket/scanner authority, acquisition dimensions, PII exports, deletion of current snapshots or migration-time full rebuild.

## 9. Architectural boundary

```text
Sales / certified semantic truth
        ↓
B.1 pure contribution contract
        ↓
durable contribution projection
        ↓
old/new bucket-key diff
        ↓
durable dirty-bucket authority
        ↓
bounded exact recompute
        ↓
versioned Postgres hour/day buckets
        ↓
BucketReader
        ↓
future VS-27B.3
```

## 10. Durable invariants

1. No customer PII.
2. Bucket key includes metric and semantic versions.
3. Full recomputation, never trusted deltas.
4. Dirty state is durable; Oban uniqueness is not authority.
5. Stale workers cannot overwrite newer revisions.
6. Corrections dirty old and new keys.
7. PubSub after commit only.
8. Repair cursor fixes missed triggers.
9. No silent truncation.
10. Existing dashboard remains compatible until B.3.

## 11. Performance boundary

Planning defaults:

- one order projection per job;
- dirty claim batch 50;
- one bucket per recompute transaction;
- separate `analytics_buckets` queue, initial concurrency 2;
- no automatic v1 bucket purge;
- no N+1 all-event reads;
- no Sales scan on LiveView mount.

## 12. Final response contract

Report baseline/head, resources, migrations, indexes, queues, tests, query plans, rollout, parity, risks, prohibited actions and next gate.
