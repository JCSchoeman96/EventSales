# Correction and Remap Matrix

| Change | Projection action | Dirty keys |
|---|---|---|
| quantity/amount changes | update contribution | current event/ticket hour/day |
| completed becomes non-completed | zero/inactivate sale contribution | original event/ticket hour/day |
| non-completed becomes completed | activate contribution | new event/ticket hour/day |
| paid/completed timestamp changes | update occurred_at | old and new hour/day |
| event remap | update event | old and new event buckets; old/new ticket buckets |
| ticket-type remap | update ticket type | event bucket if value changed; old/new ticket buckets |
| currency correction | update currency | old and new currency keys |
| semantic becomes unknown/non-ticket | inactivate ticket metrics | old keys |
| unknown becomes certified ticket | activate ticket metrics | new keys |
| full refund/revocation | update original contribution | original sale keys; activity keys if enabled |
| partial monetary refund | update net revenue only | original sale keys; activity keys if enabled |
| explicit quantity refund | update net quantity | original sale keys; activity keys if enabled |
| contribution removed | inactive/superseded | old keys |
| metric contract version changes | new version projection | new version keys; old version retained/deprecated |
| semantic policy version changes | reviewed re-projection | versioned old/new keys |
| historical bulk correction | bounded exact scope | every previewed old/new key |

## Historical apply

Historical G/B.1 correction workflows must emit exact affected contribution scopes or be discoverable through the B.2 repair cursor.

B.2 does not authorise semantic corrections. It only converges derived analytics after approved changes.
