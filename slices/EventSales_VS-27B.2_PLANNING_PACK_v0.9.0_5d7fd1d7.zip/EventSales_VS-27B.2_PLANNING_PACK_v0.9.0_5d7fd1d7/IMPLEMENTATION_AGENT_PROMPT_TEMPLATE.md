# Implementation Agent Prompt Template — VS-27B.2

**Do not use until JC-195 returns APPROVE.**

Activation must fill:

- exact current main SHA;
- certified B.1 contribution/version contract;
- certified G/F.2 interfaces;
- final projection and revision design;
- final bucket resources/identities;
- final queues/workers/cursors;
- final reader/edge contract;
- exact migrations/indexes;
- exact tests/staged PR scope;
- rollout/kill switches/stop conditions.

Write tests first. Implement only the activated stage. Open a PR and stop before merge, deployment, production rebuild or dashboard cutover.
