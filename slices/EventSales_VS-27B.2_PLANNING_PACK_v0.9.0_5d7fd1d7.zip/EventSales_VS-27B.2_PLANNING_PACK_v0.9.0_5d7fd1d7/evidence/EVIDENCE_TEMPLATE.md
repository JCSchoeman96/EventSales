# VS-27B.2 Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- B.1/G/F.2 versions:
- Projection version:
- Bucket schema version:
- Source/event ids redacted:

## Migration
- Postgres/topology:
- direct migration route:
- row counts:
- migration result:
- indexes:
- workers enabled: no/yes by stage

## Contribution parity
| Fixture/scope | B.1 | Projection | Event bucket | Ticket sum | Result |
|---|---:|---:|---:|---:|---|

## Convergence
- duplicate projection:
- missed notifier:
- repair cursor:
- stale revision race:
- dirty coalescing:
- empty built-zero:
- remap old/new:
- refund old/activity:
- timestamp boundary move:

## Read/query
- hour series:
- day series:
- edge 15/30/60:
- all-event >50:
- facts >1,000:
- mixed currency:
- missing bucket state:
- completeness/freshness:
- EXPLAIN evidence:
- load evidence:

## Negative proof
- no Woo call:
- no raw Sales read from web:
- no PII:
- no dashboard cutover:
- no migration-time rebuild:
- old snapshots preserved:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
