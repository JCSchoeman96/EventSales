# Planning Agent Prompt — VS-27B.2

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-27B.2_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, commit, open a PR, run migrations, build production buckets, call WooCommerce, redesign dashboards, merge or deploy.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect the final certified VS-27B.1 pack, plan, activation, PR and certification. Do not assume planning names survived implementation.

Inspect certified VS-26G and VS-26F.2 interfaces.

## Required plan decisions

1. actual B.1 contribution interface and versions;
2. whether B.1 already persists contributions;
3. contribution resource/identity/fields;
4. monotonic revision source;
5. projection transaction and upstream partial-write handling;
6. repair cursor source and tie-break;
7. dirty-bucket resource/state/claim protocol;
8. event/ticket bucket schemas and exact identities;
9. hour/day alignment;
10. exact metrics and sign constraints;
11. old/new key matrix;
12. stale-worker conditional-write strategy;
13. zero-bucket policy;
14. activity-bucket support or explicit unsupported result;
15. Oban queues/concurrency/uniqueness;
16. BucketReader API;
17. partial-edge contribution reads;
18. all-event query plan;
19. currency/completeness/freshness propagation;
20. existing snapshot compatibility;
21. retention;
22. migrations/indexes/lock strategy;
23. tests-first sequence;
24. staged PR recommendation;
25. exact files create/modify/generated/forbidden;
26. verification commands;
27. rollout/kill switches;
28. production canary/parity evidence;
29. JC-195 activation inputs;
30. risks/stop conditions.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with `PACK VALID`, `PACK REFRESH RECOMMENDED`, or `PACK BLOCKED`.

Confirm no prohibited action occurred.
