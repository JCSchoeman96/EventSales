# Scope Split Assessment

The implementation plan must assess staged PRs.

A recommended sequence:

## Stage A — Projection foundation

- B.1 contribution adapter;
- durable projection resource;
- monotonic revision;
- dirty-key transaction;
- repair cursor;
- focused tests.

## Stage B — Buckets and workers

- event/ticket bucket resources;
- drainer/recompute workers;
- revision guards;
- PubSub/telemetry;
- parity tests.

## Stage C — Read facade and production canary

- BucketReader;
- exact edge-window reads;
- all-event/range queries;
- query plans/load evidence;
- rollout/runbooks.

A split is mandatory if one PR would mix:

- uncertain B.1 interfaces with irreversible migrations;
- contribution durability and dashboard cutover;
- large populated-table indexes without independent review;
- production rebuild with implementation;
- more files/behaviour than an exact-head reviewer can validate confidently.

All stages remain one VS-27B.2 authority and final certification.
