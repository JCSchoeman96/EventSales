# Current Code Bucket Map

| Area | Current behaviour | B.2 implication |
|---|---|---|
| Event snapshot | one mutable row per event | keep compatibility |
| Daily snapshot | one row per event/date/timezone | v1 compatibility only |
| SnapshotRefresh | loads all event items | exact contribution-period query required |
| Daily refresh | filters in memory | DB-bound period query required |
| RefreshSnapshotWorker | event/daily, unique 300s | no durable dirty authority |
| SnapshotReader | one event or one day | no range/series/all-event facade |
| OrderProcessedNotifier | post-write best effort | hint only |
| WebhookProcessor | catches notifier failure | analytics update may be missed |
| OrderUpserter | separate order/child actions | no atomic trigger assumption |
| HotStateAggregator | whole-event recompute | not bucket authority |
| Hot-state dedupe | GenServer memory | not durable |
| Oban | `analytics_rebuilds: 1` | separate reviewed bucket queue |
| Sales indexes | status/completed/event/mapping | add contribution/bucket indexes |
| Snapshot version | integer `1` | bucket identity needs contract versions |
