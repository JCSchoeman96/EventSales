# Predecessor Contracts — VS-27B.2

## VS-27B.1

B.1 is the sole authority for metric version, semantic-policy input, contribution fields, timestamp axes, half-open periods, timezone, currency, completeness, public names and comparisons.

B.2 may choose storage and processing topology. It may not alter metric meaning.

## VS-26G

G remains authoritative for ticket entitlement, refund quantity/amount allocation, tax/net/gross, fee/add-on treatment, semantic correction and unknown fail-closed state.

## VS-26F.2

F.2 remains authoritative for source catch-up freshness and source recovery. B.2 may consume its hooks but still requires its own durable analytics repair cursor.

## VS-27B.3

B.3 may consume only the certified bucket/read facade. It may not fallback to raw Sales scans or redefine metrics.
