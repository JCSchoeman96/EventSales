# Independent Reviewer Prompt — VS-27B.2

Review adversarially.

Block any design that:

- changes B.1 metric meaning;
- trusts notifier/PubSub as durable authority;
- applies caller-supplied deltas;
- lacks a durable repair path;
- uses timestamps instead of a safe monotonic revision where stale overwrite is possible;
- cannot dirty both old and new keys;
- lets stale workers overwrite newer buckets;
- scans all event Sales rows for one hourly/daily build;
- queries Sales rows from LiveView;
- silently falls back when buckets are missing;
- sums mixed currencies;
- omits contract versions from identity;
- treats absent bucket as zero without built evidence;
- performs unbounded migration-time backfill;
- drops or reinterprets v1 snapshots;
- introduces dashboard/targets/access/Woo-backfill scope;
- stores PII/raw payloads;
- lacks query-plan and missed-notification tests.

Classify blocker, major and minor.

Verdict: APPROVE / REQUEST CHANGES / BLOCKED.

Approval authorises planning only. JC-195 controls implementation.
