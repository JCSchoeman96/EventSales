# Bucket Data Model Contract

## Recommended physical split

Prefer two resources/tables:

1. event sales buckets;
2. ticket-type sales buckets.

Each table supports `hour` and `day` granularity.

This avoids nullable polymorphic uniqueness and keeps event/ticket-type query plans explicit.

## Event bucket key

- source_system_id;
- event_id;
- granularity;
- period_start_utc;
- business timezone;
- currency;
- metric contract version;
- semantic policy version.

## Ticket-type bucket key

- source_system_id;
- event_id;
- ticket_type_id;
- granularity;
- period_start_utc;
- business timezone;
- currency;
- metric contract version;
- semantic policy version.

## Common period fields

- `period_start_utc`;
- `period_end_utc`;
- optional `business_date`;
- half-open invariant;
- hour rows aligned to UTC hour;
- day rows aligned to local business midnight translated to UTC.

## Common metric fields

Exact names come from certified B.1:

- gross ticket entitlement;
- reversed ticket entitlement;
- net tickets sold;
- gross ticket revenue;
- allocated ticket refunds;
- net ticket revenue;
- ancillary revenue;
- fee amount;
- tax amount;
- contribution count;
- anomaly count if bucketable.

## Build metadata

- built_through_revision;
- input/source watermark;
- metric contract version;
- semantic policy version;
- refreshed_at;
- input hash or deterministic evidence hash where approved;
- build status/diagnostic reason if needed.

## Constraints

- exact unique index per bucket key;
- `period_end_utc > period_start_utc`;
- gross/reversal fields follow B.1 sign constraints;
- currency non-null;
- no mixed currencies;
- event/ticket references use reviewed delete behaviour;
- contract versions non-null;
- no customer PII.

## Activity buckets

If certified B.1 exposes durable status/refund activity facts, the implementation plan must either:

- define a separate activity bucket family; or
- return `unsupported` for activity series.

Do not mix sale-time and activity-time facts under one ambiguous timestamp.
