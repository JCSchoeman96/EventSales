# Linear Update — VS-27B.2

- Gate/status:
- Pack/plan/schema version:
- Baseline/head:
- ZIP SHA:
- PR:
- B.1/G/F.2 versions:
- Delivery stage:
- Verdict/findings:
- Production rebuild authorised:
- Dashboard cutover authorised: no
- Next gate/blockers:
