# EventSales VS-27B.2 Planning Pack

## Identity

- Slice: `VS-27B.2`
- Name: Durable Hourly and Daily Event Sales Buckets
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub scope: `#125`
- Linear parent: `JC-190`
- Pack: `JC-191`
- Pack review: `JC-192`
- Agent plan: `JC-193`
- Plan review: `JC-194`
- Activation: `JC-195`
- Implementation: `JC-196`

## Authority

This ZIP authorises repository reconnaissance and implementation planning only.

It does not authorise code changes, migrations, source calls, bucket rebuilds, dashboard cutover, merge or deployment.

Implementation requires independent pack and plan approval, VS-27B.1 certification and `JC-189` closeout, exact-current-main activation through `JC-195`, and verdict `APPROVE`.

## Outcome

Create durable, versioned Postgres read models that materialise the certified B.1 contribution contract into:

```text
event hourly buckets
event daily buckets
ticket-type hourly buckets
ticket-type daily buckets
bounded exact edge-window reads
```

Duplicate, stale, missed and out-of-order triggers must converge from durable truth.

## Core rule

Buckets are rebuilt from durable metric contributions. They never accept caller-supplied metric deltas as truth.

## Existing compatibility

The current `EventAggregateSnapshot` and `DailySalesAggregateSnapshot` remain version-one compatibility read models until VS-27B.3 performs a reviewed cutover.
