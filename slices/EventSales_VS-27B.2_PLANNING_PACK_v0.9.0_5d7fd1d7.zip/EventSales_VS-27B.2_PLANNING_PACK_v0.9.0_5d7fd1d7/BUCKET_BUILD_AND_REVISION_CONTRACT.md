# Bucket Build and Revision Contract

## Exact recompute

A bucket worker must:

1. validate/cast the complete bucket key;
2. load the dirty row and requested revision;
3. query only contribution projections within the exact period/key;
4. reduce through the certified B.1 metric reducer;
5. calculate deterministic metrics;
6. upsert the bucket in one transaction;
7. update only when incoming revision is not older;
8. mark dirty complete only if requested revision did not advance;
9. broadcast after commit.

Never apply incoming deltas directly.

## Old/new key matrix

Changes that dirty both prior and current keys include:

- sale timestamp/hour/day;
- event;
- ticket type;
- currency;
- semantic kind/eligibility;
- metric contract version;
- semantic policy version;
- contribution activation/removal.

Amount-only changes dirty the existing keys.

A refund may dirty:

- the original sale hour/day;
- the refund activity hour/day when activity facts are enabled.

## Stale-worker protection

Scenario:

1. revision 10 worker starts;
2. revision 11 contribution commits;
3. revision 11 worker writes;
4. revision 10 worker finishes.

Revision 10 must not overwrite revision 11.

Use conditional upsert or row lock/recheck with `built_through_revision`.

## Empty buckets

When all contributions leave a key:

- persist an explicit zero bucket or delete under one reviewed rule;
- the reader must distinguish absent/not-built from built-zero;
- preferred v1 rule: retain a built-zero row with revision metadata.

## Failure after bucket commit

If PubSub or cache invalidation fails, durable bucket remains correct.

If dirty completion fails after bucket write, retry is idempotent.

## Contract-version rebuild

A new metric/semantic contract version creates versioned bucket rows or an explicit reviewed replacement strategy.

Do not silently reinterpret a version-one bucket in place.
