# Durable Invalidation and Repair Contract

## Dirty-bucket authority

Use a durable resource such as `AnalyticsDirtyBucket`.

Candidate key:

- bucket family;
- source_system_id;
- event_id;
- ticket_type_id when applicable;
- granularity;
- period_start_utc;
- business timezone;
- currency;
- metric contract version;
- semantic policy version.

Candidate state:

- requested_revision;
- claimed_revision;
- built_revision;
- status;
- attempt count;
- last error code;
- next retry time;
- inserted/updated timestamps.

One unique row per exact bucket key coalesces repeated requests.

## Monotonic revision

Use a database-backed monotonic bigint revision/sequence.

Rules:

- each projection transaction receives one revision;
- dirty row keeps `max(requested_revision)`;
- bucket records `built_through_revision`;
- worker may not overwrite a bucket with a lower revision;
- if requested revision advances during build, dirty row remains pending;
- timestamps alone are not sufficient revision authority.

## Fast trigger

After an order/correction commit, enqueue a bounded projection job when possible.

The trigger is acceleration only. It is not the durability boundary.

## Projection repair cursor

Maintain a separate analytics cursor per source.

It scans bounded changed durable facts using a certified local-change key, for example:

```text
updated_at
+ stable id tie-break
```

It must cover:

- order changes;
- child contribution changes;
- semantic/historical corrections;
- refund/fee changes;
- remapping.

Use bounded overlap so equal timestamps and transaction boundaries cannot create gaps.

The cursor advances only after durable projection success.

## Bucket drainer

A unique drainer job:

1. claims a bounded dirty batch using row locks / `SKIP LOCKED`;
2. runs one exact bucket build at a time or under a bounded concurrency;
3. records safe low-cardinality failure;
4. retries without losing dirty state;
5. stops at configured batch/time limits;
6. requeues itself when work remains.

Oban job uniqueness is optimisation only.

## Periodic repair

A conservative periodic analytics repair may enqueue projection scans and dirty draining.

It may not call WooCommerce or duplicate F.2 order catch-up.

Final cadence/plugin topology is locked at activation after F.2.
