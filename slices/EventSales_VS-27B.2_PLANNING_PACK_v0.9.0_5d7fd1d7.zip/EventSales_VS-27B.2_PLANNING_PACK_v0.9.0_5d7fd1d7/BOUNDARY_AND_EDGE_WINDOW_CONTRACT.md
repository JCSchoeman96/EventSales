# Boundary and Edge-Window Contract

## Hour buckets

Aligned to UTC:

```text
HH:00:00.000000Z
through next hour, end exclusive
```

## Day buckets

Aligned to B.1 business timezone:

```text
local 00:00
through next local 00:00
translated to UTC
```

Store both UTC bounds and business date/timezone.

## Why hourly buckets alone are insufficient

Last 15/30/60-minute and arbitrary partial-hour windows cannot be answered exactly from whole-hour rows alone.

## Exact edge strategy

Use the durable contribution projection, never raw Sales rows.

For a requested window:

1. identify complete interior hour/day buckets;
2. identify left/right partial edges;
3. query contributions only for bounded edge periods;
4. sum interior buckets plus exact edges;
5. prove no overlap or gap.

For windows of 60 minutes or less, a direct bounded contribution-projection query is allowed.

## Bounds

- edge contribution query maximum span: 2 hours;
- indexed by contract version, event/ticket scope, currency and occurred_at;
- hard row/time limit;
- no source call;
- return explicit failure if bound exceeded.

## Boundary tests

Test facts:

- one microsecond before start;
- exactly start;
- one microsecond before end;
- exactly end;
- Johannesburg midnight;
- UTC hour change;
- comparison-window boundary.

Each contribution belongs to exactly one hour and one business day per time axis.
