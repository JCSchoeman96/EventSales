# Contribution Projection Contract

## Purpose

B.1 defines a pure contribution contract. B.2 requires a durable projection of those contributions unless B.1 already persists an equivalent source.

The projection exists to:

- rebuild exact buckets without rereading arbitrary raw payloads;
- compare old and new bucket keys;
- repair missed notifier calls;
- support bounded partial-hour reads;
- isolate analytics from customer PII.

## Candidate identity

Prefer one stable contribution identity supplied by B.1:

```text
source_system_id
+ contribution_id
+ contribution_kind
+ metric_contract_version
+ semantic_policy_version
```

Contribution kinds may include:

- ticket sale line;
- ticket refund/reversal;
- ancillary/add-on;
- fee;
- tax;
- status/refund activity when certified.

Do not derive durable identity from labels.

## Candidate fields

- source_system_id;
- order_id;
- order item/refund/fee source identity;
- event_id;
- ticket_type_id;
- contribution_kind;
- currency;
- sale or activity occurred_at;
- time_axis;
- business timezone/date;
- hour_start_utc;
- metric contract version;
- semantic policy version;
- gross/reversal/net ticket quantity;
- gross/refund/net ticket revenue;
- ancillary revenue;
- fee and tax;
- anomaly flags;
- source/local version;
- projection_revision;
- active/current flag;
- inserted/updated timestamps.

No customer names, emails, addresses, payment tokens or raw payloads.

## Projection transaction

For one source order or correction scope:

1. Read the complete certified durable state.
2. Evaluate B.1 contributions.
3. Load prior contribution projections.
4. Compute inserts, updates and removals/inactivation.
5. Allocate one monotonic revision.
6. Upsert projections.
7. Persist every old and new dirty bucket key with the revision.
8. Commit.
9. Queue/drain work after durable state exists.

Contribution mutation and dirty-key persistence must share one transaction.

## Upstream non-atomicity

Current OrderUpserter does not wrap order and child actions in one transaction. Therefore:

- an immediate notifier is only a fast hint;
- projector must read the complete durable state after the upstream write;
- periodic repair must re-project changed orders;
- a partial upstream write must not be certified as complete;
- activation must inspect whether F.1/G have changed this boundary.

## Removal and omission

A contribution absent from the new authoritative projection becomes inactive or is superseded with audit/version evidence. Its old keys are dirtied.

Do not remove a projection because a known partial source payload omitted a child.
