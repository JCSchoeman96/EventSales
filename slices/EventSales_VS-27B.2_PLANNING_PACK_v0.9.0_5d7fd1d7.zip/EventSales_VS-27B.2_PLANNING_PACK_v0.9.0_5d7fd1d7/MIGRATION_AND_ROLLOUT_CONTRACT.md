# Migration and Rollout Contract

## Additive schema

Expected additions may include:

- metric contribution projection;
- projection cursor;
- dirty bucket resource;
- event sales bucket;
- ticket-type sales bucket;
- monotonic revision sequence;
- supporting indexes;
- `analytics_buckets` Oban queue configuration.

Do not rewrite or drop current snapshot tables.

## Migration rules

- no data scan/rebuild inside migration;
- verify direct/session-capable migration connection;
- new empty-table indexes may be ordinary;
- indexes on populated Sales tables require row-count/lock review and possibly concurrent creation;
- generated Ash migrations require review;
- rollback must not drop data after B.3 cutover without explicit decision.

## Initial rollout

1. Deploy schema/resources with projector and bucket workers disabled.
2. Verify migrations/indexes and queue configuration.
3. Enable projection observation for one source/event.
4. Compare projected contributions with B.1 evaluator.
5. Enable dirty-bucket writes.
6. Build one hour/day canary.
7. Verify duplicate/stale/missed-trigger convergence.
8. Verify remap/refund old/new corrections.
9. Enable bounded repair cursor.
10. Expand to selected current events.
11. Keep B.3 dashboard cutover disabled.
12. Certify parity/performance at JC-199.

## Kill switches

- contribution projector disabled;
- dirty-bucket draining disabled;
- periodic repair disabled;
- event/ticket bucket families independently disabled;
- PubSub broadcast disabled;
- existing snapshot/dashboard path remains active.

## Stop conditions

- B.1 contract is not certified;
- contribution identity is unstable;
- customer PII enters analytics;
- dirty state can be lost;
- stale worker can overwrite newer build;
- old bucket key is not corrected;
- migration performs unbounded build;
- source calls occur;
- all-event result can truncate silently;
- B.3 cutover occurs in this slice.
