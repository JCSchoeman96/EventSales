# VS-27B.2 Acceptance Checklist

## Planning and activation
- [ ] Exact current baseline.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-27B.1 certified and closed.
- [ ] VS-26G/F.2 actual interfaces refreshed.
- [ ] Railway/Postgres/Oban topology verified.
- [ ] JC-195 verdict APPROVE.

## Contribution projection
- [ ] Stable contribution identity.
- [ ] Metric and semantic versions.
- [ ] No PII/raw payload.
- [ ] One monotonic revision.
- [ ] Projection + old/new dirty keys in one transaction.
- [ ] Partial upstream write handling.
- [ ] Removal/inactivation semantics.
- [ ] Bounded repair cursor.

## Dirty-bucket authority
- [ ] Exact unique bucket key.
- [ ] Requested revision coalesces by max.
- [ ] Bounded claim/locking.
- [ ] Durable retry state.
- [ ] Oban uniqueness is not authority.
- [ ] Missed notifier recovery.
- [ ] Safe failure codes.

## Buckets
- [ ] Event hour/day resources.
- [ ] Ticket-type hour/day resources.
- [ ] Half-open UTC bounds.
- [ ] Business day alignment.
- [ ] Currency in identity.
- [ ] Metric/semantic versions in identity.
- [ ] Built-through revision.
- [ ] Zero-bucket rule.
- [ ] No trusted deltas.
- [ ] Old/new correction matrix.
- [ ] Stale worker cannot overwrite.

## Reads
- [ ] BucketReader facade.
- [ ] No Sales reads from web.
- [ ] No N+1 all-event path.
- [ ] Exact bounded edge-window reads.
- [ ] Missing/rebuilding/partial states.
- [ ] Mixed currencies rejected/grouped.
- [ ] Completeness and F.2 freshness propagated.
- [ ] No silent truncation.

## Compatibility
- [ ] V1 event snapshot preserved.
- [ ] V1 daily snapshot preserved.
- [ ] Existing dashboard path unchanged.
- [ ] No B.3 cutover.
- [ ] Activity series explicitly supported or unsupported.

## Migrations and queues
- [ ] Additive migrations only.
- [ ] No migration-time rebuild.
- [ ] Direct migration connection verified.
- [ ] Populated-table index lock strategy.
- [ ] Separate reviewed bucket queue.
- [ ] Worker bounds/timeouts.
- [ ] Kill switches.

## Tests
- [ ] Raw contribution/bucket parity.
- [ ] Hour/day boundaries.
- [ ] Duplicate/stale/out-of-order jobs.
- [ ] Revision race.
- [ ] Missed notifier repair.
- [ ] Remap old/new keys.
- [ ] Refund original/activity keys.
- [ ] Currency/version isolation.
- [ ] Empty built-zero bucket.
- [ ] >50 events and >1,000 facts.
- [ ] Edge windows.
- [ ] Query plans/load evidence.
- [ ] Privacy/static boundaries.
- [ ] Full CI.

## Production certification
- [ ] One-event contribution canary.
- [ ] Hour/day parity.
- [ ] Missed-trigger canary.
- [ ] Duplicate/stale canary.
- [ ] Remap/refund canary.
- [ ] Repair cursor catches up.
- [ ] Queue/backlog healthy.
- [ ] Dashboard cutover remains disabled.
- [ ] JC-199 certification recorded.
