# Auto-Apply Policy Matrix — Initial V1

## Event actions

| Action | V1 result | Notes |
|---|---|---|
| `reuse` | allow | Exact published identity. |
| `create` | allow | Published, bounded, simple-product plan. |
| `update_metadata` | conditional | Source remains published; exact field allowlist; no identity movement. |
| `adopt_existing` | manual | Changes external identity of existing domain record. |
| unknown | reject | Fail closed. |

## TicketType actions

| Action | V1 result | Notes |
|---|---|---|
| `reuse` | allow | Exact event membership and identity. |
| `create` | allow | Published simple product; required source risk absent. |
| `adopt_existing` | manual | Existing-domain adoption requires review. |
| unknown | reject | Fail closed. |

## ProductMapping actions

| Action | V1 result | Notes |
|---|---|---|
| `create` | allow | New product-level mapping with no conflict/history warning. |
| move/update/deactivate/delete | manual/reject | Not safe in initial v1. |
| unknown | reject | Fail closed. |

## Findings

| Finding | V1 result |
|---|---|
| any blocking | reject |
| any warning | reject |
| unknown severity/code | reject |
| `duplicate_meta_collapsed` info | candidate allowlist |
| `existing_mapping_adopted` info | manual |
| private/draft skipped | manual |
| special-case info | manual |

## Source risks

| Risk | V1 result |
|---|---|
| private/draft/trash/deleted | manual |
| subscription/payment plan | manual/reject |
| missing template | manual |
| any variation | manual |
| ambiguous/duplicate name | reject |
| mapping conflict/event movement | reject |
| unknown product type | reject |

## Historical impact

| Condition | V1 result |
|---|---|
| bounded eligible pending lines only | may allow |
| deferred lines > 0 | manual |
| conflicting lines > 0 | reject |
| already mapped lines > 0 | manual |
| warning/unresolved destination | reject/manual |
| threshold exceeded | manual |
