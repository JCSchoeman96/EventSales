# VS-26E.2 — Conservative Catalog Auto-Apply

## Current repository truth

### Existing Apply authority

`EventSales.Catalog.TickeraCatalog.Applier`:

- requires a `dry_run_ready` run;
- validates the exact dry-run hash;
- rejects persisted blocking findings;
- claims the run before mutation;
- applies Event, TicketType and ProductMapping changes transactionally;
- marks the run applied;
- performs cache/PubSub/recovery work after commit.

This remains the only catalogue writer.

### Existing planner actions

Events:

- `create`
- `reuse`
- `update_metadata`
- `adopt_existing`

Ticket types:

- `create`
- `reuse`
- `adopt_existing`

Product mappings:

- `create`

The planner also persists a deterministic snapshot/hash, touched identities, findings and historical-impact forecast.

### Existing findings

Current findings include:

- `duplicate_meta_collapsed` — info
- `variation_mapping_required` — warning
- `ambiguous_variation_ticket_type_name` — blocking
- `duplicate_ticket_type_name` — blocking
- `private_event_skipped` / `draft_event_skipped` — info
- `published_event_without_ticket_products` — warning
- `existing_mapping_conflict` — blocking
- `existing_mapping_adopted` — info

### Critical gaps before automation

- Human Apply allows warnings; automation requires stricter policy.
- WordPress `requires_review` reasons are not all propagated to persisted findings.
- Variations currently always produce a warning.
- Private/draft source rows are skipped rather than represented as reviewable state-change plans.
- Run origin is not explicit enough.
- Durable policy decision/audit state does not exist.

## Goal

Introduce a pure, versioned, fail-closed policy that evaluates persisted dry-run truth and queues the existing exact-hash Apply worker only when eligibility is proven.

## Initial v1 posture

Auto-apply only when all are true:

- global and source-level modes permit it;
- run origin is explicitly eligible;
- run is ready with a supported snapshot and exact hash;
- scope is bounded;
- source entities are published;
- no private/draft/trash/deleted risk;
- no subscription/payment-plan/missing-template risk;
- no blocking or warning finding;
- info findings are in an exact allowlist;
- actions are in an exact allowlist;
- no variation in initial v1;
- no adoption of existing domain records in initial v1;
- no event movement/mapping conflict/name ambiguity;
- historical forecast has no conflicts, deferred rows, warnings, unresolved destination or existing mapped history;
- thresholds are within approved bounds;
- Apply can still claim the exact run/hash.

Unknown data fails closed.

## Product decisions

- Public/live events are the normal automation target.
- Private/draft transitions must be visible and reviewed.
- Variations exist, but are not automatically safe.
- Human Apply remains available.
- Performance, audit and kill switches are mandatory.

## Explicit run origin

The plan must define durable origin values, for example:

- `admin`
- `targeted_trigger`
- `reconciliation`
- `manual_rows`
- `system_recovery`

Never infer automation eligibility from a missing user id.

Initial v1 normally permits only `targeted_trigger`.

## Source-risk propagation

Persist reviewable risk from feed to Normalizer, Planner, Finding and snapshot:

- private/draft/trash/deleted event
- private/draft/trash/deleted product
- private/draft variation
- subscription
- payment plan
- missing ticket template
- variation mapping
- ambiguous variation name
- duplicate ticket name
- mapping conflict
- product moved between events
- unsupported product type

The policy evaluates persisted truth, not raw source responses.

## Policy interface

Recommended pure output:

```text
eligible + bounded decision
ineligible + bounded decision
error + bounded decision
```

Decision includes:

- policy version
- run id and hash
- evaluated timestamp
- result and reason codes
- finding codes
- action summary
- historical-impact summary
- origin and configuration mode

## Durable audit

The plan must justify extending the run or creating a dedicated decision resource.

Required invariants:

- idempotent evaluation for run/hash/policy version
- no duplicate Apply job
- durable reason codes
- Apply job linkage
- indexed pending/error state
- no raw payload, PII or secrets

## Findings policy

Initial default:

- any blocking: ineligible
- any warning: ineligible
- unknown severity/code: ineligible
- info requires allowlist

Possible v1 allowlist candidate:

- `duplicate_meta_collapsed`

Manual-only candidates:

- `existing_mapping_adopted`
- special-case findings
- private/draft skipped findings

## Historical-impact policy

Initial requirements:

- conflicting lines = 0
- deferred lines = 0
- already mapped lines = 0
- no historical warnings
- all destinations resolved
- affected pending lines within reviewed threshold
- only eligible pending lines, if present

## Flow

1. Dry-run becomes ready.
2. Evaluator is scheduled after commit or by a recoverable sweep.
3. Evaluator reloads persisted run/snapshot/findings.
4. Pure policy produces a decision.
5. Decision is persisted idempotently.
6. Observation mode stops without Apply.
7. Eligible enabled decision queues the existing Apply worker once with exact hash.
8. Existing Apply claim/hash remains authoritative.
9. Ineligible run remains ready for human review.

Do not Apply inside discovery transaction.

## Human review compatibility

- Admin/manual runs stay manual by default.
- Ineligible runs remain reviewable.
- UI shows bounded policy reason codes.
- Human Apply semantics remain unchanged.
- Auto policy does not weaken existing blocking-finding checks.

## Safety controls

- global `disabled | observe | enabled`
- source-level mode
- policy-version pin
- scope/change/history thresholds
- kill switch
- source rollout allowlist
- no direct WordPress calls in evaluator/UI
- Postgres as truth
- safe low-cardinality telemetry

## Failure modes

Cover:

- evaluator scheduling gap
- duplicate evaluator
- changed/stale hash
- manual cancel/apply race
- unsupported snapshot
- policy exception
- audit write failure
- Apply enqueue failure
- duplicate Apply insert
- source disabled after evaluation
- config/policy drift
- post-commit PubSub/cache failure
- observation discrepancy

## Tests-first sequence

1. risk propagation
2. pure policy matrix
3. unknown/fail-closed behaviour
4. historical-impact classification
5. origin/configuration
6. durable audit
7. evaluator idempotency
8. Apply enqueue uniqueness
9. race/cancellation
10. admin explanation
11. observation mode
12. rollout evidence

## Non-goals

- no periodic reconciliation
- no order catch-up
- no parallel catalogue writer
- no auto-apply for manual runs
- no variations in initial posture
- no private/draft/deletion auto-apply
- no subscription/payment-plan auto-apply
- no unrelated reporting/import/payment work

## Acceptance

- eligible run queues one existing Apply job
- evaluator retries remain idempotent
- exact hash remains required
- unknown/risky inputs fail closed
- ineligible runs remain human-reviewable
- source risk is persisted
- observation mode never Applies
- kill switch works
- manual Apply remains unchanged
- production canaries certify both eligible and rejected cases
