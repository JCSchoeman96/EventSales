# TOON Prompts — VS-26E.2

## Planning agent
Task: Design a fail-closed auto-apply policy using existing dry-run/Apply authority.
Output: Complete implementation plan only.
Boundary: No code or production action.

## Policy reviewer
Task: Attack every allowlist and unknown-input path.
Output: Findings and verdict.
Boundary: Default unsafe when uncertain.

## Concurrency reviewer
Task: Prove evaluator retries/races cannot queue duplicate Apply.
Output: Findings and required tests.
Boundary: Existing hash/claim remains authoritative.

## Activation reviewer
Task: Refresh current main and VS-26E.1 production evidence.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
Boundary: No implementation.

## Exact-head reviewer
Task: Compare PR head with pack, plan and activation.
Output: PR verdict.
Boundary: Approval is not merge approval.
