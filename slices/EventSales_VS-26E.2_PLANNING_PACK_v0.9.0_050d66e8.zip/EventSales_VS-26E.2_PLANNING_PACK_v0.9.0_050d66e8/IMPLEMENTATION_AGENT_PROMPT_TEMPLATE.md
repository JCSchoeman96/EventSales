# Implementation Agent Prompt Template — VS-26E.2

**Do not use until `JC-129` returns APPROVE.**

Fill from the reviewed plan and activation supplement:

- exact current main SHA
- policy/snapshot versions
- allowed action/finding matrices
- historical thresholds
- exact files/migrations/indexes
- configuration modes
- exact tests
- exclusions and stop conditions

Write tests first, implement only activated scope, open a PR and stop before merge/deployment.
