# Planning Agent Prompt — VS-26E.2

Repository: `JCSchoeman96/EventSales`

Pack: `EventSales_VS-26E.2_PLANNING_PACK_v0.9.0_050d66e8.zip`

Planning baseline: `050d66e88d55270655833cd9c9b51476a4bfefeb`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, commit, open/merge a PR, deploy, migrate, change configuration, queue Catalog Sync/Apply or alter production.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

Assess drift and report it.

## Required plan

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md` and lock:

1. current Normalizer/Planner/Applier truth
2. source-risk propagation
3. explicit run origin
4. pure policy/versioning
5. action/finding/history matrix
6. durable decision/audit
7. evaluator scheduling/recovery
8. evaluator and Apply-job idempotency
9. observation/global/source modes
10. admin explanation/PubSub
11. migrations/indexes/query shapes
12. tests-first sequence
13. rollout/kill switches
14. production evidence
15. `JC-129` activation inputs
16. exact files and stop conditions

Do not merely check “no blocking findings.” Prove every allowed input safe.

Finish with `PACK VALID`, `PACK REFRESH RECOMMENDED` or `PACK BLOCKED`, plus confirmation that no prohibited action occurred.
