# Mandatory File Inventory — VS-26E.2

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Core
- `lib/event_sales/catalog/tickera_catalog/normalizer.ex`
- `lib/event_sales/catalog/tickera_catalog/planner.ex`
- `lib/event_sales/catalog/tickera_catalog/applier.ex`
- `lib/event_sales/catalog/tickera_catalog/finding.ex`
- `lib/event_sales/catalog/tickera_catalog/plan.ex`
- `lib/event_sales/ingestion/tickera_catalog_sync.ex`
- `lib/event_sales/ingestion/tickera_catalog_historical_impact.ex`
- `lib/event_sales/ingestion/resources/tickera_catalog_sync_run.ex`
- `lib/event_sales/ingestion/resources/tickera_catalog_sync_finding.ex`
- `lib/event_sales/ingestion/workers/discover_tickera_catalog_worker.ex`
- `lib/event_sales/ingestion/workers/apply_tickera_catalog_worker.ex`
- `lib/event_sales/ingestion/workers/missing_catalog_resolution_worker.ex`
- `lib/event_sales_web/live/admin/catalog_sync_live.ex`

## Source risk
- `integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`
- `docs/ops/tickera_catalog_feed_contract.md`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_discovery_source.ex`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_client.ex`

## Runtime
- `config/config.exs`
- `config/runtime.exs`
- `railway.toml`
- `lib/event_sales/release.ex`

## Tests
- `test/event_sales/catalog/tickera_catalog/normalizer_test.exs`
- `test/event_sales/catalog/tickera_catalog/planner_applier_test.exs`
- `test/event_sales/ingestion/tickera_catalog_sync_test.exs`
- `test/event_sales/ingestion/tickera_catalog_sync_concurrency_test.exs`
- `test/event_sales/ingestion/tickera_catalog_historical_impact_test.exs`
- `test/event_sales/ingestion/workers/discover_tickera_catalog_worker_test.exs`
- `test/event_sales/ingestion/workers/apply_tickera_catalog_worker_test.exs`
- `test/event_sales_web/live/admin/catalog_sync_live_test.exs`

## Predecessor
- final VS-26E.1 pack, plan, activation, PR and production certification evidence
