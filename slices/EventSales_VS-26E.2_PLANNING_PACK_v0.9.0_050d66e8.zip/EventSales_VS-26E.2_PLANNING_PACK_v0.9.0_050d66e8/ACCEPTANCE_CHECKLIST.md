# VS-26E.2 Acceptance Checklist

## Planning
- [ ] Pack reviewed.
- [ ] Plan reviewed.
- [ ] VS-26E.1 certified.
- [ ] Activation approved.

## Policy
- [ ] Explicit origin.
- [ ] Global/source/observe modes.
- [ ] Supported versions.
- [ ] Exact action/finding allowlists.
- [ ] Unknown fails closed.
- [ ] Variations manual by default.
- [ ] Source risks persisted.
- [ ] Historical rules and thresholds.

## Durability
- [ ] Decision/audit persisted.
- [ ] Evaluation idempotent.
- [ ] Apply queued once.
- [ ] Exact hash required.
- [ ] Ineligible run stays reviewable.
- [ ] Human Apply unchanged.

## Safety
- [ ] No parallel writer.
- [ ] No PII/secrets/raw payload.
- [ ] Kill switches.
- [ ] Safe reason codes/telemetry.
- [ ] Observation mode first.

## Tests
- [ ] allowed create/reuse
- [ ] conditional metadata
- [ ] adoption manual
- [ ] all severities/unknown codes
- [ ] every source risk
- [ ] variation
- [ ] historical states
- [ ] origin/config
- [ ] duplicate evaluator/job
- [ ] stale hash/race/cancel
- [ ] observation/admin explanation
- [ ] full CI

## Production
- [ ] eligible canary applies once
- [ ] risky canary stays manual
- [ ] kill switch verified
- [ ] no unrelated mutation
- [ ] certification recorded
