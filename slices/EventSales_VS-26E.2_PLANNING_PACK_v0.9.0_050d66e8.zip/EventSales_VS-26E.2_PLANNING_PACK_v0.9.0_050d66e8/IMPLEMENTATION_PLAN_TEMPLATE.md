# VS-26E.2 Implementation Plan

## Baseline and files inspected
## Current Normalizer/Planner/Applier truth
## VS-26E.1 dependency/origin semantics
## Source-risk propagation
## Policy interface/versioning
## Full action matrix
## Full finding matrix
## Historical-impact rules/thresholds
## Durable decision/audit
## Evaluator scheduling/recovery
## Idempotency and Apply-job uniqueness
## Human Apply compatibility
## Configuration and observation mode
## Admin/PubSub/telemetry
## Migrations/indexes/query shapes
## Tests-first sequence
## Exact files and forbidden areas
## Verification commands
## Rollout/kill switches
## Production evidence
## JC-129 activation inputs
## Risks/stop conditions
## Prohibited-actions statement
