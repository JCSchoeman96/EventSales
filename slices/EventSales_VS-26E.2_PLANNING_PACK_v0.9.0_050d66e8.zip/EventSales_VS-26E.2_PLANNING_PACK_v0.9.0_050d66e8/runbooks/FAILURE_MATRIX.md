# Failure Matrix

| Failure | Behaviour | Result |
|---|---|---|
| unknown snapshot/action/finding | durable reason | ineligible |
| missing risk data | durable reason | ineligible |
| duplicate evaluator | same decision/job | no duplicate |
| decision write failure | no Apply | retry/error |
| Apply enqueue failure | recoverable | retry |
| hash/status changed | no Apply | stale |
| manual Apply wins | evaluator stops | no duplicate |
| source/global disabled | reason | ineligible |
| policy exception | safe error | no Apply |
| observation mode | record only | no Apply |
| historical conflict/warning | reason | manual/reject |
