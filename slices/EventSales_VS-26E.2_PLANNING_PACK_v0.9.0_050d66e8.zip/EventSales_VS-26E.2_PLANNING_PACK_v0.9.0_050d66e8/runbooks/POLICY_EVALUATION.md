# Policy Evaluation Runbook

1. Reload persisted run/snapshot/findings.
2. Verify status, hash, origin, configuration and versions.
3. Validate snapshot schema.
4. Inspect actions.
5. Inspect findings and propagated source risks.
6. Inspect historical totals, warnings and destinations.
7. Enforce thresholds.
8. Produce bounded reason codes.
9. Persist decision idempotently.
10. Stop in observation mode.
11. If eligible and enabled, queue existing Apply worker once.
12. Record job linkage.
13. Never mutate catalogue directly.
