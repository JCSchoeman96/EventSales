# Rollout Plan

1. Deploy decision/audit/evaluator disabled.
2. Verify migrations/indexes.
3. Enable observation for one source.
4. Compare decisions with human review.
5. Correct false positives.
6. Enable one simple product-level canary class.
7. Verify eligible run applies once.
8. Verify risky runs remain ready.
9. Verify kill switches.
10. Widen only by explicit approval.

Variations remain manual initially.
