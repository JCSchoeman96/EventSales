# Rollback and Stop Conditions

Kill switches:

- global disabled
- source disabled
- observation mode
- policy version pin/disable

Stop immediately when:

- unsafe run is eligible
- missing risk defaults safe
- duplicate Apply jobs are possible
- stale hash is bypassed
- manual run auto-applies
- variation/private/subscription unexpectedly auto-applies
- historical conflict is ignored
- parallel writer exists
- evidence leaks protected data

Disable automated queueing first and preserve durable decisions/runs.
