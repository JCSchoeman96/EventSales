# VS-26E.2 Redacted Evidence

- Pack/plan/activation:
- Policy version:
- PR/head/CI:
- Global/source mode:

## Eligible canary
- run/hash redacted:
- origin:
- actions/findings:
- historical summary:
- decision/reasons:
- Apply job/final status:
- duplicate evaluation result:

## Ineligible canaries
- warning:
- blocking:
- variation:
- subscription/payment plan:
- private/draft:
- historical conflict:
- unknown input:

## Safety
- observation:
- kill switch:
- manual Apply:
- no parallel mutation:
- no PII/secrets:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
