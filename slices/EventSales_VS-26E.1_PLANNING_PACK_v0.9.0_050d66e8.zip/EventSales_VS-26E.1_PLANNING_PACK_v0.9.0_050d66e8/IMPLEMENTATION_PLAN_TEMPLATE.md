# VS-26E.1 Implementation Plan

## 1. Baseline proof

- Worktree:
- HEAD:
- origin/main:
- Planning baseline drift:
- Pack verdict:

## 2. Files inspected

List exact paths and relevant findings.

## 3. Current behaviour confirmed

### WordPress
### EventSales feed adapter
### Catalog Sync lifecycle
### Web/security precedent
### Runtime/deployment

## 4. Proposed architecture

Include a sequence diagram.

## 5. Signal contract

- route:
- method:
- content type:
- max bytes:
- payload:
- headers:
- canonical signature base:
- replay window:
- source resolution:
- status codes:
- key rotation:

## 6. WordPress hook and async design

- hooks:
- suppression:
- signal id:
- scheduler:
- retries:
- terminal errors:
- kill switch:
- cache invalidation:

## 7. Durable resource/model

- resource/table:
- fields:
- states:
- actions:
- uniqueness:
- indexes:
- retention:
- audit:

## 8. Transaction and recovery

- intake transaction:
- Oban insertion:
- recovery if insertion fails:
- duplicate race:
- payload mismatch:

## 9. Coalescing algorithm

- coalescing key:
- quiet window:
- freshness ordering:
- threshold:
- updated-since escalation:
- backlog cap:
- fairness:
- cleanup:

## 10. Active-run defer/replay

- detection:
- durable state:
- replay trigger:
- failure behaviour:
- one-active-run proof:

## 11. Internal Catalog Sync authority

- facade/action:
- scope validation:
- system authority:
- resulting run linkage:

## 12. Admin and observability

- facade queries:
- LiveView:
- PubSub:
- telemetry:
- safe errors:

## 13. Files

### Create
### Modify
### Generated
### Forbidden

## 14. Tests-first sequence

List red/green steps and exact test files.

## 15. Migration/index plan

Include query shapes and concurrency reasoning.

## 16. Verification commands

List exact commands to run.

## 17. Rollout

- EventSales first:
- configuration:
- WordPress deployment:
- canary:
- enablement:
- rollback:
- secret rotation:

## 18. Production evidence

- safe test edit:
- expected timing:
- duplicate test:
- active-run test:
- no-auto-apply proof:
- redaction:

## 19. Inputs required

## 20. Risks and stop conditions

## 21. Activation supplement inputs

List every value JC-123 must refresh.

## 22. Prohibited-actions statement
