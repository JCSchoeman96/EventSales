# Implementation Agent Prompt Template — VS-26E.1

**DO NOT USE UNTIL JC-123 APPROVES AN ACTIVATION SUPPLEMENT.**

Inputs that must be filled from the reviewed plan and activation supplement:

- exact authorised `main` SHA;
- exact pack version and ZIP SHA-256;
- activation supplement id/hash;
- exact allowed files;
- exact migrations/indexes;
- exact HTTP contract;
- exact test sequence;
- exact rollout exclusions;
- exact stop conditions.

The implementation agent must:

1. prove exact baseline;
2. write failing focused tests first;
3. implement only approved scope;
4. run focused tests after each layer;
5. update generated architecture files only through project commands;
6. open a PR without merging;
7. report exact head and commands actually run;
8. stop before merge/deployment.

Never infer missing activation values.
