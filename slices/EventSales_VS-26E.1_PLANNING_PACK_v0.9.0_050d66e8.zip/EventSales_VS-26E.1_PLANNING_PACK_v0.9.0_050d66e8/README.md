# EventSales VS-26E.1 Planning Pack

## Identity

- Slice: `VS-26E.1`
- Name: Targeted WordPress Catalog Change Trigger
- Pack version: `0.9.0`
- Pack status: `planning_review_ready`
- Planning baseline: `050d66e88d55270655833cd9c9b51476a4bfefeb`
- GitHub scope: `JCSchoeman96/EventSales#118`
- Linear parent: `JC-113`
- Pack authoring: `JC-114`
- Pack review: `JC-115`
- Agent planning: `JC-116`
- Plan review: `JC-117`
- Activation gate: `JC-123`
- Implementation: `JC-118`

## Two-stage authority

This ZIP is a complete **planning and prompt pack**. It may be given to an agent for repository reconnaissance and an implementation plan.

It does not authorise implementation.

Before code changes begin, `JC-123` must issue an activation supplement that refreshes:

- exact current `main` SHA;
- material repository drift;
- final file inventory;
- VS-26E.0 certification evidence;
- Railway and WordPress deployment facts;
- migrations, indexes and queue state;
- exact implementation scope approved from the reviewed plan.

## First agent hand-off

Use `CODING_AGENT_PROMPT.md`.

The agent must inspect the repository and return the completed `IMPLEMENTATION_PLAN_TEMPLATE.md`. It must not change code, merge, deploy, migrate, modify WordPress, queue Catalog Sync, or alter production state.

## Durable goal

A relevant Tickera event, WooCommerce ticket product, or variation change produces one authenticated PII-free signal. EventSales durably accepts, deduplicates and coalesces it, then queues or defers a bounded targeted Catalog Sync dry-run through existing authority.

Nothing is auto-applied in this slice.
