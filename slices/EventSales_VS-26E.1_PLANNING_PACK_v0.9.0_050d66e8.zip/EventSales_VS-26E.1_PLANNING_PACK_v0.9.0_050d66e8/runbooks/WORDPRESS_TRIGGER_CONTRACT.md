# Proposed WordPress Trigger Contract

This is a planning contract, not a deployed interface.

## Payload goals

Minimal identity/freshness only.

Required concepts:

- version;
- stable signal id;
- source identifier;
- target type;
- positive target id;
- source-updated timestamp;
- bounded reason enum.

Forbidden:

- customer identity;
- billing/shipping;
- orders;
- payment data;
- full catalogue rows;
- secrets.

## Delivery

- enqueue asynchronously from WordPress hooks;
- preserve signal id across retries;
- bounded exponential backoff with jitter;
- terminal treatment for invalid 4xx responses;
- retry 5xx/timeouts;
- kill switch;
- safe local diagnostics without body/secret logging.

## Signature

Prefer a dedicated secret.

Recommended base includes version, method, path, timestamp, signal id and body hash.

Final bytes and headers require plan approval.
