# VS-26E.1 Failure Matrix

| Failure | Durable result | Retry | Operator visibility | Stop condition |
|---|---|---|---|---|
| WordPress scheduler unavailable | local pending/error | bounded | WP safe log/admin | repeated loss |
| HTTP timeout/5xx | same signal id retained | yes | attempt count | backlog cap |
| 4xx invalid contract | terminal local failure | no | safe reason | version mismatch |
| invalid signature | no accepted receipt | no | bounded rejection metric | unexpected valid source |
| duplicate signal | existing receipt | no extra work | duplicate count | payload mismatch |
| persistence failure | no false 2xx unless recoverable | retry | safe 503 | durable recovery absent |
| enqueue failure | receipt recoverable | yes | pending state | orphaned receipt |
| active sync run | deferred/coalesced | later | deferred state | second active run |
| source timeout/rate limit | existing dry-run retry lifecycle | yes | run state | retry exhaustion |
| stale signal | coalesced/ignored by freshness | no overwrite | audit | newer state lost |
| backlog threshold | consolidate/bound | defined | alert | unbounded growth |
| PubSub/cache failure | durable state remains | optional | warning | never data loss |
