# Rollback and Stop Conditions

## Kill switches

The final design must provide:

- EventSales receiver/dispatcher disable;
- WordPress sender disable;
- optional source-level enablement.

## Rollback order

1. Disable WordPress sender.
2. Stop new dispatcher work if required.
3. Preserve accepted receipts.
4. Allow or cancel existing Catalog Sync runs only through existing lifecycle.
5. Revert code/config only after data compatibility review.

## Stop immediately when

- duplicate active runs are possible;
- accepted signals can be lost after 2xx;
- stale work overwrites newer freshness;
- save hooks perform synchronous remote work;
- PII/order/payment data enters payload/logs;
- secret material appears in evidence;
- backlog is unbounded;
- auto-apply occurs;
- a parallel catalogue writer is introduced.
