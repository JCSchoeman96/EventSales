# VS-26E.1 Rollout Plan

## Before implementation

- pack reviewed;
- plan reviewed;
- VS-26E.0 certified;
- activation supplement approved.

## Compatibility rollout

1. Deploy receiver code with feature disabled.
2. Verify migrations, indexes, queue and admin read model.
3. Configure trigger path/secret without exposing values.
4. Deploy WordPress sender disabled.
5. Enable one source/test target.
6. Perform one safe event/product/variation edit.
7. Verify one accepted receipt and one queued/deferred targeted dry-run.
8. Verify no Apply.
9. Test duplicate retry and burst coalescing.
10. Expand to normal hooks.

## Stop

Disable WordPress sender first when intake correctness is uncertain. Preserve durable receipts and evidence.
