# Planning Agent Prompt — VS-26E.1

Repository: `JCSchoeman96/EventSales`

Planning pack: `EventSales_VS-26E.1_PLANNING_PACK_v0.9.0_050d66e8.zip`

Planning baseline: `050d66e88d55270655833cd9c9b51476a4bfefeb`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files. Do not commit. Do not open or merge a PR. Do not deploy, migrate, change Railway, change WordPress, enqueue Catalog Sync, call Apply or alter production state.

## Baseline proof

Run and report:

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

A planning baseline may have advanced. If so, inspect the drift and state whether it materially changes the pack. Do not silently implement around drift.

## Mandatory reading

Read every path in `FILE_INVENTORY.md`, plus any directly related files discovered during reconnaissance.

## Goal

Produce a tests-first, end-to-end implementation plan for a targeted WordPress catalogue-change signal that:

- is asynchronous on WordPress;
- is authenticated, replay-bounded and PII-free;
- is durably accepted by EventSales;
- deduplicates retries;
- coalesces hook bursts;
- defers safely behind an active Catalog Sync run;
- automatically resumes deferred work;
- queues only bounded existing targeted dry-runs;
- never auto-applies;
- never creates a parallel catalogue writer.

## Decisions your plan must make

1. Exact WordPress hooks and suppression rules.
2. Action Scheduler or alternative async mechanism and bounded retries.
3. Exact payload, headers, signature base, replay window and key rotation.
4. Route/controller/intake boundary.
5. Durable resource fields, states, actions, constraints and indexes.
6. Transaction boundary for receipt plus Oban work.
7. Idempotency and duplicate-payload mismatch behaviour.
8. Coalescing algorithm, quiet window, thresholds and backlog bounds.
9. Active-run defer/replay algorithm.
10. Narrow internal/system Catalog Sync queue authority.
11. Targeted feed scope and large-burst fallback.
12. Admin visibility and PubSub.
13. Telemetry and safe errors.
14. Tests-first sequence.
15. Exact expected files.
16. Migration and rollout order.
17. Kill switches and rollback limitations.
18. Production validation evidence.
19. Inputs still required from the owner/operator.
20. Material assumptions requiring `JC-123` refresh.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with:

- `PACK VALID`, `PACK REFRESH RECOMMENDED`, or `PACK BLOCKED`;
- exact reasons;
- explicit statement that no prohibited action was performed.

Stop after the plan.
