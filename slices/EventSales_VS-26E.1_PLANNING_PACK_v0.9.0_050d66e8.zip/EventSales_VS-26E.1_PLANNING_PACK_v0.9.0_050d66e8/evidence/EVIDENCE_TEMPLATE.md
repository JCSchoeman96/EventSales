# VS-26E.1 Redacted Evidence

## Build

- Pack/version:
- Activation supplement:
- PR/head:
- CI:

## Contract

- Version:
- Payload keys only:
- Signature scheme description:
- Replay window:
- Max bytes:
- Secrets shown: no

## WordPress

- Hook tested:
- Autosave/revision suppression:
- Async job id redacted:
- Retry evidence:
- Save latency:

## EventSales

- Receipt id redacted:
- Target type/id:
- Accepted at:
- State transitions:
- Coalescing:
- Resulting run id:
- Active-run defer/replay:

## Production timing

- Source edit at:
- Signal accepted at:
- Dry-run queued/deferred at:
- Dry-run ready at:
- Total latency:

## Negative evidence

- Duplicate delivery:
- Burst hooks:
- Invalid signature:
- No auto-apply:
- No order/payment changes:
- No PII/secret leakage:

## Verdict

CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
