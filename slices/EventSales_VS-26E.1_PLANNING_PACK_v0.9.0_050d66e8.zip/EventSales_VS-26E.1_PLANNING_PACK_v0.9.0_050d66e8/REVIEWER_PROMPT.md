# Independent Pack/Plan Reviewer Prompt — VS-26E.1

Review independently. Do not assume the author is correct.

## Pack review

Verify:

- planning baseline and current drift;
- current WordPress feed and targeted filters;
- current save-hook cache invalidation;
- current EventSales targeted scope support;
- current Catalog Sync transactional queue authority;
- one-active-run invariant;
- security/privacy boundaries;
- no-auto-apply boundary;
- completeness of failure, test and rollout coverage;
- checksums and ZIP/source parity.

## Plan review

Challenge:

- direct HTTP from save hooks;
- secret reuse across GET feed and POST trigger;
- acknowledgement before durable recovery;
- idempotency keys that change on retry;
- coalescing that loses newer freshness;
- active-run deferral with no replay;
- unbounded target arrays or full-feed storms;
- admin impersonation for system work;
- parallel catalogue writers;
- migration/index gaps;
- version-skew rollout;
- inadequate production evidence.

Classify findings:

- blocker;
- major;
- minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval of the planning pack or plan does not authorise implementation. `JC-123` must separately activate implementation.
