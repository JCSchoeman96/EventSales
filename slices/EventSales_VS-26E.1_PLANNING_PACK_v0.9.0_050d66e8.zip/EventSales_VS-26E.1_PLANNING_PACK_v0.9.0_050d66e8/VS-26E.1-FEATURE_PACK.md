# VS-26E.1 — Targeted WordPress Catalog Change Trigger

## 1. Identity and status

- Pack version: `0.9.0`
- Status: planning-review ready; implementation locked
- Planning baseline: `050d66e88d55270655833cd9c9b51476a4bfefeb`
- GitHub issue: `#118`
- Linear: `JC-113` through `JC-123`
- Predecessor: VS-26E.0
- Successor: VS-26E.2 Conservative Catalog Auto-Apply

## 2. Executive summary

The production WordPress/Tickera catalogue already exposes a signed, sanitised and targetable GET feed. EventSales already supports full, product, variation, event and updated-since discovery scopes and already builds Catalog Sync dry-runs through one durable lifecycle.

The missing capability is prompt change notification.

VS-26E.1 adds a compact authenticated signal from WordPress to EventSales. The signal carries identity and freshness only—not catalogue rows, order data or customer data. EventSales persists the signal, deduplicates retries, coalesces bursts and schedules bounded targeted discovery through the existing Catalog Sync planner and dry-run state machine.

This slice creates no parallel catalogue writer and performs no automatic Apply.

## 3. Current repository truth at planning baseline

### Existing WordPress feed

`integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`

Current facts:

- plugin version `0.1.0`;
- GET route under `eventsales/v1/tickera-catalog`;
- HMAC SHA-256 over method, path, canonical query and timestamp;
- five-minute timestamp skew;
- supported filters: `updated_since`, `product_id`, `variation_id`, `event_id`, pagination and `include_private`;
- default 100 rows, maximum 500;
- sanitised event and catalogue rows;
- cache invalidation hooks for product, product variation and `tc_events` saves;
- targeted requests may return private/draft state for review.

### Existing EventSales discovery adapter

`EventSales.Catalog.TickeraCatalog.WordPressFeedDiscoverySource`

It permits exactly one mode:

- full;
- product id;
- variation id;
- event id;
- updated since.

It delegates to `WordPressFeedClient` and returns `DiscoveryResult`.

### Existing Catalog Sync authority

`EventSales.Ingestion.TickeraCatalogSync`

- admin facade queues dry-run and Apply;
- dry-run run creation and Oban insertion occur inside one database transaction;
- one active run per source is protected by a database constraint;
- Apply requires exact dry-run hash;
- existing run list and admin preview are bounded.

`DiscoverTickeraCatalogWorker`

- queue: `tickera_sync`;
- max attempts: 3;
- uniqueness by `run_id` for 300 seconds;
- retry-aware ownership;
- transient source failures are distinguished;
- planner findings and run-ready state commit transactionally;
- cache/PubSub are post-commit side effects.

### Existing generic webhook precedent

`EventSales.Ingestion.WebhookIntake` demonstrates:

- raw-body signature verification;
- durable idempotency;
- source resolution;
- bounded safe errors;
- persist-then-enqueue orchestration;
- duplicate-race handling;
- backpressure strategy.

VS-26E.1 should reuse architectural lessons, not route catalogue signals through order webhook resources.

## 4. Product decisions implemented

- live/public events are the normal automation target;
- private/draft transitions must still be observed and represented for review;
- normal visibility target is under five minutes;
- stale threshold remains ten minutes for later dashboard behaviour;
- one WordPress source in v1;
- no customer PII by default;
- performance and boundedness are required regardless of current sales volume.

## 5. Observable outcome

A relevant WordPress catalogue edit produces an accepted signal quickly. Repeated delivery and duplicate hooks do not create duplicate durable work. When no Catalog Sync run is active, one bounded target becomes one targeted dry-run. When a run is active, work is durably deferred/coalesced and automatically reconsidered later.

Admin users can see safe signal status and resulting run linkage.

## 6. Dependencies

Available:

- targetable WordPress catalogue feed;
- EventSales targeted discovery adapter;
- Catalog Sync run lifecycle, planner, findings and Apply authority;
- Oban;
- source-system model;
- raw-body plug and webhook security precedents.

Pending before implementation:

- reviewed implementation plan;
- VS-26E.0 certification;
- current production baseline refresh;
- activation supplement from `JC-123`.

## 7. Required scope

### WordPress sender

- identify logical changes to `tc_events`, ticket products and variations;
- suppress autosaves/revisions;
- invalidate existing feed cache;
- generate a stable signal id once per logical delivery;
- enqueue asynchronous delivery;
- retry with bounded backoff;
- use a dedicated trigger secret;
- emit only minimal PII-free fields;
- never block the editor on EventSales completion.

### Signal contract

Planning target:

```json
{
  "version": "2026-07-17.v1",
  "signal_id": "<uuid>",
  "source": "wordpress_tickera",
  "target_type": "event|product|variation",
  "target_id": 123,
  "source_updated_at": "2026-07-17T07:00:00Z",
  "reason": "saved|status_changed|deleted|metadata_changed"
}
```

Final field names and deletion semantics require plan review.

Recommended signature base:

```text
version
HTTP method
request path
timestamp
signal id
hex SHA-256 of raw body
```

Use a separate secret from the feed GET secret unless the reviewed plan proves safe key separation another way.

### EventSales intake

- dedicated controller/intake boundary;
- raw body before JSON parsing;
- strict payload size and field validation;
- source lookup;
- signature and replay validation;
- one durable receipt per `signal_id`;
- duplicate-payload mismatch detection;
- accepted receipt and enqueue/defer state must not be silently separated;
- safe status codes and no secret-bearing errors.

### Durable orchestration

The plan must choose and justify a durable resource, likely a narrow catalogue-change receipt/pending-work resource.

Required invariants:

- deterministic unique signal id;
- deterministic coalescing key by source + target;
- newest source freshness cannot be overwritten by older work;
- duplicate retries are idempotent;
- active-run deferral is durable;
- deferred work is automatically replayed;
- no second active Catalog Sync run;
- no direct Event/TicketType/ProductMapping write;
- resulting Catalog Sync run id is auditable.

### Coalescing strategy

The plan must define:

- quiet/debounce window;
- same-target replacement rules;
- burst threshold;
- maximum pending targets per source;
- whether a large burst consolidates to one `updated_since` scope;
- fairness and retry ordering;
- retention and cleanup.

A full feed for every save is forbidden.

### Internal queue authority

Do not spoof an admin actor.

The plan must introduce or identify a narrowly scoped internal/system function that validates trigger scopes and queues existing Catalog Sync dry-runs through the same transactional run/job authority.

### Admin visibility

Minimum safe fields:

- target type/id;
- received/source-updated times;
- status: accepted, queued, deferred, coalesced, completed or failed;
- resulting run id/status;
- bounded safe reason/error;
- retry count.

Do not display payloads, signatures, secrets or customer data.

## 8. Explicit non-goals

- no auto-apply;
- no periodic sweep;
- no order catch-up/backfill;
- no OrderUpserter changes;
- no payment/refund/scanner/ticket issuance/delivery changes;
- no CSV/XLSX import changes;
- no marketing/reporting dimensions;
- no WordPress write-back;
- no unbounded target arrays;
- no source call from LiveView/controller/component;
- no Redis-only durable work;
- no direct catalogue mutation from signal intake.

## 9. Proposed domain model constraints

The plan must decide exact names, but durable truth should support:

- source system;
- signal id;
- target type and positive external id;
- source-updated timestamp;
- received timestamp;
- payload hash;
- coalescing key;
- state;
- attempt metadata;
- deferred reason;
- resulting run id;
- safe last error;
- inserted/updated timestamps.

Required database properties:

- unique signal id per source;
- efficient pending-by-source/state order;
- efficient coalescing-key lookup;
- no duplicate active pending owner for the same coalesced target;
- foreign key to source system and optional resulting run.

## 10. Interfaces

The implementation plan must lock:

- route and path token policy;
- content type;
- maximum body size;
- exact payload schema/version;
- signature headers/base string;
- replay window;
- status-code contract;
- WordPress retry classification;
- worker args/uniqueness;
- Ash actions;
- PubSub/admin refresh messages;
- environment variables and secret rotation;
- backwards-compatible deployment order.

## 11. Architecture boundaries

```text
WordPress save hooks
-> async WordPress job
-> signed PII-free HTTP signal
-> thin Phoenix controller
-> web-agnostic intake service
-> Postgres durable receipt/pending state
-> Oban dispatcher
-> narrow internal Catalog Sync queue authority
-> existing discovery/planner/dry-run lifecycle
```

Postgres is authority. Oban is execution. PubSub/cache are notification/read optimisation only.

## 12. Security and privacy

- dedicated secret or explicit reviewed key-separation scheme;
- raw-body signature before decoding;
- bounded timestamp skew;
- stable signal id and replay guard;
- strict enum and positive-id validation;
- maximum request bytes;
- path/source authentication;
- no raw body in logs;
- no signature/header secret in telemetry;
- no customer/order/payment fields;
- bounded low-cardinality telemetry;
- redacted evidence.

## 13. Performance

Planning targets:

- WordPress save hook overhead: local enqueue only;
- EventSales intake: no source call and no Catalog Sync execution inline;
- bounded database statements;
- one dispatcher queue with explicit concurrency;
- one active Catalog Sync run per source;
- coalescing prevents hook storms;
- target feed calls preserve existing page limits;
- admin lists are paginated/bounded.

The agent must propose measurable limits and tests.

## 14. Failure and recovery

Must cover:

- async scheduler unavailable;
- WordPress HTTP timeout/DNS/TLS failure;
- 4xx terminal vs 5xx retry;
- duplicate delivery;
- payload mismatch under same signal id;
- EventSales persistence failure;
- receipt persisted but job insertion fails;
- active run;
- dispatcher crash;
- target deleted/private/draft;
- feed unauthorised/rate limited;
- dry-run retry/failure/cancel;
- post-commit PubSub/cache failure;
- deployment version skew;
- secret rotation;
- signal backlog exceeds threshold.

## 15. Files to inspect first

See `FILE_INVENTORY.md`.

## 16. Expected file areas

Likely create:

- narrow catalogue-change intake/domain modules;
- Ash resource and migration if justified;
- Oban dispatcher/coalescing worker;
- controller and route;
- tests;
- WordPress sender helper/class;
- plugin tests or PHP test harness;
- operational docs.

Likely modify:

- existing WordPress plugin;
- Ingestion domain resource registration;
- router/raw-body configuration;
- Catalog Sync facade/internal authority;
- admin Catalog Sync LiveView/facade;
- queue configuration;
- architecture indexes/docs.

Forbidden:

- OrderUpserter and order writer authority;
- payment/refund/scanner/delivery domains;
- unrelated dashboards/exports/imports;
- production credentials;
- generated migrations not produced through project conventions.

## 17. Tests-first sequence

1. Contract/security tests.
2. Durable receipt/idempotency tests.
3. transactional enqueue/defer tests.
4. coalescing and stale-freshness tests.
5. active-run deferral/replay tests.
6. targeted Catalog Sync queue tests.
7. WordPress hook/scheduler/retry tests.
8. admin visibility tests.
9. rollout compatibility tests.
10. full focused and repository CI.

## 18. Acceptance criteria

- valid signed signal accepted;
- invalid/stale signature rejected safely;
- duplicate retry is idempotent;
- same id with different body is rejected/audited;
- save-hook duplicates coalesce;
- active run causes durable defer, not loss or second run;
- deferred work automatically resumes;
- target scope remains bounded;
- source private/draft/deletion state becomes a dry-run finding, not an automatic mutation;
- no auto-apply;
- no order/payment/customer effect;
- admin status truthful;
- under-five-minute production validation;
- exact-head CI green.

## 19. Verification commands

Planning agent must propose the exact focused commands. Expected baseline includes:

```bash
mix format --check-formatted
mix compile --warnings-as-errors
bash scripts/check_no_web_woocommerce_refs.sh
mix test <focused tests>
mix test
mix credo --strict
mix dialyzer
mix sobelow --config
mix deps.audit
mix hex.audit
mix assets.build
php -l integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php
git diff --check
```

Do not claim a command ran when it was only planned.

## 20. Rollout concept

Preferred compatibility order:

1. deploy EventSales receiver disabled or accepting no source until configured;
2. verify migration/index/queue/readiness;
3. configure separate secret and path safely;
4. deploy WordPress sender disabled;
5. enable one test target/source;
6. validate accepted signal and dry-run linkage;
7. widen to normal hooks;
8. preserve kill switches on both sides.

The agent must verify Railway and WordPress deployment realities.

## 21. Stop conditions

- planning baseline materially contradicted;
- unsafe secret reuse;
- intake can acknowledge without durable recovery;
- duplicate work can create two active runs;
- stale signal can replace newer target state;
- unbounded payload/query/target list;
- WordPress save waits on EventSales;
- signal contains PII/order/payment data;
- implementation requires a parallel catalogue writer;
- no safe rollout/disable path;
- VS-26E.0 evidence reveals incompatible lifecycle assumptions.

## 22. Final planning response

Return:

- exact baseline and worktree proof;
- mandatory files inspected;
- proposed architecture;
- exact contract;
- domain/resource/migration design;
- coalescing algorithm;
- tests-first sequence;
- expected files;
- rollout and rollback;
- production/operator inputs;
- open risks;
- pack validity;
- explicit confirmation that no code or production state changed.
