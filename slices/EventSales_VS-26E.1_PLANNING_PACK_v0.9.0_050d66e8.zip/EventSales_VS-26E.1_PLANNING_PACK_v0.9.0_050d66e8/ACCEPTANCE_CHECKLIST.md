# VS-26E.1 Acceptance Checklist

## Pack and plan

- [ ] Current repository baseline recorded.
- [ ] WordPress feed filters verified.
- [ ] Current save hooks verified.
- [ ] Catalog Sync queue authority verified.
- [ ] One-active-run invariant verified.
- [ ] Planning prompt is read-only.
- [ ] Plan independently reviewed.
- [ ] JC-123 activation supplement approved before implementation.

## Contract

- [ ] Versioned payload.
- [ ] Dedicated secret/key-separation decision.
- [ ] Raw-body HMAC.
- [ ] Stable signal id across retries.
- [ ] Replay window.
- [ ] Strict body-size and enum/id validation.
- [ ] PII/order/payment fields forbidden.
- [ ] Safe status codes.

## WordPress

- [ ] Logical hooks selected.
- [ ] Autosaves/revisions suppressed.
- [ ] Existing cache invalidation preserved.
- [ ] Async scheduler used.
- [ ] Retry/backoff bounded.
- [ ] Save path never waits on EventSales.
- [ ] Kill switch exists.

## Durable intake

- [ ] Receipt persisted.
- [ ] Duplicate retries idempotent.
- [ ] Payload mismatch audited.
- [ ] Receipt/enqueue failure recoverable.
- [ ] Coalescing key deterministic.
- [ ] Older freshness cannot replace newer.
- [ ] Pending backlog bounded.
- [ ] Cleanup/retention defined.

## Catalog Sync

- [ ] Narrow internal queue authority.
- [ ] No admin impersonation.
- [ ] Existing planner/dry-run reused.
- [ ] No parallel catalog writer.
- [ ] Active run causes durable defer.
- [ ] Deferred work automatically resumes.
- [ ] No full feed per save.
- [ ] No auto-apply.

## UI/observability

- [ ] Bounded admin list.
- [ ] Safe states and errors.
- [ ] Resulting run link.
- [ ] PubSub/update behaviour.
- [ ] Low-cardinality telemetry.
- [ ] No raw payload/signature/secret logs.

## Tests

- [ ] Valid event/product/variation signals.
- [ ] Invalid/stale signature.
- [ ] Duplicate and mismatch.
- [ ] Autosave/revision suppression.
- [ ] Burst coalescing.
- [ ] Active-run defer/replay.
- [ ] enqueue/persistence failures.
- [ ] targeted scope bounds.
- [ ] private/draft/deleted target.
- [ ] no auto-apply.
- [ ] no order/payment effects.
- [ ] rollout compatibility.

## Delivery

- [ ] Exact-head CI green.
- [ ] PR independently reviewed.
- [ ] Separate merge/deploy authorisation.
- [ ] Production evidence under five minutes.
- [ ] Duplicate/burst evidence.
- [ ] No PII leakage.
- [ ] Certification recorded before VS-26E.2.
