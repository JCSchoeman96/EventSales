# VS-26E.1 Mandatory File Inventory

## Governance

- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/EventSales_Hardened_V2_1_Folder_Structure.md`
- `docs/EventSales_Hardened_V2_1_Vertical_Slice_Roadmap.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`

## Catalog Sync authority

- `lib/event_sales/ingestion/tickera_catalog_sync.ex`
- `lib/event_sales/ingestion/resources/tickera_catalog_sync_run.ex`
- `lib/event_sales/ingestion/resources/tickera_catalog_sync_finding.ex`
- `lib/event_sales/ingestion/workers/discover_tickera_catalog_worker.ex`
- `lib/event_sales/ingestion/workers/apply_tickera_catalog_worker.ex`
- `lib/event_sales/catalog/tickera_catalog/configured_discovery_source.ex`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_discovery_source.ex`
- `lib/event_sales/catalog/tickera_catalog/wordpress_feed_client.ex`
- `lib/event_sales/catalog/tickera_catalog/planner.ex`
- `lib/event_sales/catalog/tickera_catalog/applier.ex`
- `lib/event_sales/catalog/tickera_catalog/pub_sub.ex`
- `lib/event_sales_web/live/admin/catalog_sync_live.ex`

## Web/security precedents

- `lib/event_sales_web/controllers/webhook_controller.ex`
- `lib/event_sales/ingestion/webhook_intake.ex`
- `lib/event_sales/ingestion/security/webhook_signature.ex`
- `lib/event_sales/ingestion/security/webhook_replay_guard.ex`
- `lib/event_sales_web/plugs/raw_body_reader.ex`
- `lib/event_sales_web/router.ex`
- `lib/event_sales_web/endpoint.ex`

## WordPress integration

- `integrations/wordpress/eventsales-tickera-catalog-feed/eventsales-tickera-catalog-feed.php`
- `integrations/wordpress/eventsales-tickera-catalog-feed/README.md`
- `docs/ops/tickera_catalog_feed_contract.md`
- `docs/ops/tickera_catalog_feed_eventsales_adapter.md`

## Runtime/deployment

- `config/config.exs`
- `config/runtime.exs`
- `railway.toml`
- `lib/event_sales/release.ex`
- `scripts/check_no_web_woocommerce_refs.sh`
- `scripts/local_ci.sh`

## Tests

- `test/event_sales/catalog/tickera_catalog/wordpress_feed_discovery_source_test.exs`
- `test/event_sales/ingestion/tickera_catalog_sync_test.exs`
- `test/event_sales/ingestion/tickera_catalog_sync_concurrency_test.exs`
- `test/event_sales/ingestion/workers/discover_tickera_catalog_worker_test.exs`
- `test/event_sales_web/live/admin/catalog_sync_live_test.exs`
- `test/event_sales_web/controllers/webhook_controller_test.exs`
- `test/support/catalog_sync_run_helpers.ex`

## Migrations/indexes

- `priv/repo/migrations/20260703090000_vs_26a_tickera_catalog_sync.exs`
- all later Catalog Sync migrations introduced through VS-26E.0 / PR #111
