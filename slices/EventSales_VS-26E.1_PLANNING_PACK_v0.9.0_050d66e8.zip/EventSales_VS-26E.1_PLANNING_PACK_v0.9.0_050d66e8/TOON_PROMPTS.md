# TOON Prompts — VS-26E.1

## Planning agent

| Field | Content |
|---|---|
| Task | Inspect current EventSales and WordPress code and produce the VS-26E.1 implementation plan. |
| Objective | Design a durable, authenticated, PII-free targeted catalogue-change trigger that reuses existing Catalog Sync dry-run authority. |
| Output | Completed implementation plan only. |
| Note | No code, PR, deploy, migration, WordPress change or production action. |

## Pack reviewer

| Field | Content |
|---|---|
| Task | Adversarially review planning pack v0.9.0. |
| Objective | Find repository-truth, architecture, security, concurrency, scope and rollout defects before agent hand-off. |
| Output | Findings plus APPROVE / REQUEST CHANGES / BLOCKED. |
| Note | Pack approval is planning approval only. |

## Plan reviewer

| Field | Content |
|---|---|
| Task | Review the agent implementation plan against the pack and current repository. |
| Objective | Lock exact contract, durable state, coalescing, tests, migrations and rollout. |
| Output | Findings and plan verdict. |
| Note | Do not authorise code; JC-123 still refreshes baseline. |

## Activation reviewer

| Field | Content |
|---|---|
| Task | Refresh current main and predecessor evidence after plan approval. |
| Objective | Produce the exact implementation activation supplement. |
| Output | APPROVE / REFRESH REQUIRED / BLOCKED. |
| Note | Only APPROVE unlocks implementation. |

## Implementation agent

| Field | Content |
|---|---|
| Task | Implement only the activated VS-26E.1 scope with tests first. |
| Objective | Deliver one reviewed PR without deployment. |
| Output | PR, tests and implementation report. |
| Note | No merge/deploy. No auto-apply. |

## Exact-head PR reviewer

| Field | Content |
|---|---|
| Task | Review exact implementation PR head against pack, plan and activation supplement. |
| Objective | Prove correctness, boundedness, security and scope. |
| Output | Findings and PR verdict. |
| Note | Review approval is not merge approval. |

## Production validator

| Field | Content |
|---|---|
| Task | Validate authorised production rollout with redacted evidence. |
| Objective | Prove real edit to exactly one queued/deferred targeted dry-run within SLO. |
| Output | CERTIFIED / CERTIFIED WITH RISK / REJECTED. |
| Note | Verify duplicate/burst suppression and no auto-apply. |
