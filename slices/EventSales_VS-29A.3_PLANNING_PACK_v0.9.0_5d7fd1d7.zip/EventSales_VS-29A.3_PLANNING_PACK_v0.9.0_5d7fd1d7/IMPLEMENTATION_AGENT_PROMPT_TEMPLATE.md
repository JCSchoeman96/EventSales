# Implementation Agent Prompt Template — VS-29A.3

**Do not use until activation returns APPROVE.**

Activation fills:

- exact current main/deployed SHA;
- exact child stage;
- certified B.3 route/filter/DTO/chart/topic interfaces;
- certified C capability/portal/revocation interfaces;
- certified A.2 reader/version/dimension interfaces;
- certified B15 export interface where relevant;
- exact DTO/filter/component/route design;
- exact files/dependencies/config/tests;
- load/accessibility/security commands;
- rollout/stop conditions;
- M8 gate.

Write tests first.

Implement only the activated child stage.

Open a PR and stop before merge, deployment, feature enablement, production canary, report execution or export generation.
