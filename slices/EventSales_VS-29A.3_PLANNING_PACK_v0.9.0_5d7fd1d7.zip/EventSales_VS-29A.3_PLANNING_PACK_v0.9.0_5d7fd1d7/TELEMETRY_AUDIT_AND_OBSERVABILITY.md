# Telemetry, Audit and Observability

## Telemetry events

Candidate low-cardinality events:

- report requested/completed/failed;
- report state ready/limited/updating/blocked;
- dimension selected;
- revenue metric normalized/denied;
- invalidation received/coalesced/reloaded;
- access reauthorization result;
- export requested/completed/failed;
- chart hook error;
- parity/mismatch surfaced.

## Allowed metadata

- view;
- scope kind;
- metric;
- dimension kind;
- result/state;
- source model/version;
- contract versions;
- revenue visible boolean;
- actor capability profile only if bounded and approved;
- event count, point count and row count as measurements.

## Forbidden metadata

- source/campaign labels;
- dimension member ids/hashes as telemetry labels;
- event names;
- order/customer ids;
- revenue amounts;
- URLs/query strings;
- grant/settings details;
- full filter maps.

## Audit

Viewing aggregate reports normally need not create high-volume audit rows unless final policy requires it.

Export request/download must be audited.

Access/revenue changes remain C audit authority.

## Operational diagnostics

Admin-only safe diagnostics may show:

- reader version;
- result revision;
- parity/completeness/freshness states;
- point/row counts;
- safe error code;
- cache status;
- last reload.

No raw acquisition labels beyond normal authorized report display.

## Alerts

Operational alert candidates:

- sustained reader failures;
- parity mismatch;
- stale A.2 buckets;
- high reload storm/coalescing;
- chart hook failures;
- export failures.

No marketing performance alert is created in A.3.
