# Test Matrix

## DTO and interpretation

- coverage classified/unclassified/uncovered;
- gross coverage percentage;
- zero denominator unavailable;
- source model/version disclaimer;
- no causal labels;
- distinct order unsupported;
- all version/state fields.

## Filters

- every allowed metric/dimension;
- disabled dimension;
- invalid member;
- top bounds;
- page reset on scope change;
- B.3 windows/custom/comparison;
- mixed currency;
- shareable URL within scope;
- copied URL cannot widen scope.

## Authorization

- admin;
- management assigned/unassigned/expired;
- marketing assigned/unassigned/expired;
- global staff without grant;
- user deactivated;
- event ineligible/private/draft;
- authorize before existence;
- multiple roles/preference;
- revocation within C bound.

## Revenue

- admin revenue;
- management flag off/on/expired;
- marketing flag off/on/expired;
- multi-event all visible;
- mixed visibility hides all aggregate revenue;
- revenue URL normalized without reader call;
- recursive DTO/assign/HTML/chart scan finds no quantitative revenue fields or values;
- old chart cleared on flag change.

## Views

- all-event full scope independent of event table page;
- event view;
- ticket-type breakdown;
- coverage/origin/source/source-medium/campaign/device;
- top-N plus exact Other;
- overflow distinct from Other;
- member selection;
- stable sorting/keyset;
- empty/limited/updating/mismatch.

## LiveView

- mount/reconnect durable read;
- A.2 invalidation coalesced;
- source status update;
- subscriptions added/removed;
- missed PubSub;
- access/revenue hint;
- heartbeat with PubSub suppressed;
- no socket metric math;
- no stale sensitive assigns.

## Charts/accessibility/CSP

- self-hosted asset;
- no inline/CDN;
- hook mount/update/destroy;
- bounded points;
- ticket-only payload;
- table fallback;
- keyboard/screen-reader;
- reduced motion;
- contrast/no colour-only state.

## Privacy

Seed customer/order/URL/query/click/provider values and raw unsafe campaign.

Prove absence from DTO, URLs, DOM, chart data, PubSub, logs, telemetry, audit and export.

## Export

- admin only;
- portal denied;
- exact filter hash/as-of;
- same reader values;
- aggregate only;
- metadata/versions/states;
- top-N/full bounded mode;
- formula injection;
- mismatch failure;
- expiry/download audit.

## Performance

- 100 events;
- 100 members;
- maximum points;
- 50 clients;
- invalidation storm;
- access revoke;
- bounded query count/payload;
- no N+1/raw scans.
