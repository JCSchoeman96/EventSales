# Dimension View Contract

## One active dimension

One query and chart use one A.2 dimension kind.

Allowed only when enabled by the active aggregation policy.

## Coverage view

Default view.

Rows:

- covered and classified;
- observed but unclassified;
- no usable evidence.

Shows exact base parity.

## Origin view

Canonical source categories only:

- direct;
- UTM;
- organic;
- referral;
- web admin;
- API/other;
- unknown;
- A.2 sentinels.

## Source view

A.2 safe dimension members.

No arbitrary source search across raw evidence.

## Source + medium

One predeclared tuple dimension, not a dynamic cross-product.

Display uses two separate safe labels or a deterministic accessible separator.

## Campaign

Safe A.1/A.2 campaign labels only.

No content, term or raw campaign id by default.

## Device

Only if the active A.2 policy enables it and source evidence is sufficiently certified.

## Ranking rows

Each row includes:

- safe label;
- sentinel explanation;
- selected metric gross/reversal/net;
- share of gross covered measure;
- comparison;
- optional trend action;
- no raw source values or order drill-down.

## Top-N

- default 20;
- maximum 100;
- exact `Other` is calculated by A.2 reader;
- `Other` is not the same as A.2 cardinality `overflow`;
- UI distinguishes:
  - `Other recorded sources` = members outside top N;
  - `Other values beyond reporting limit` = overflow sentinel.

## Pagination

Full dimension list uses stable keyset pagination where final A.2 supports it.

Headline totals and `Other` never derive from visible page rows.

## Member filter

Selecting a member:

- preserves scope/window/metric;
- displays its exact series/comparison;
- uses opaque member id;
- validates membership in active source/version/dimension;
- does not reveal member existence outside actor scope.

## Ticket-type breakdown

Event page may show selected dimension across ticket types only if:

- A.2 reader has exact ticket-type buckets;
- result is bounded;
- no mixed currency;
- no order count inference.

## Sorting

Stable tie-break order:

1. selected numeric measure;
2. canonical safe label;
3. deterministic member id.

No database-locale-dependent ordering.
