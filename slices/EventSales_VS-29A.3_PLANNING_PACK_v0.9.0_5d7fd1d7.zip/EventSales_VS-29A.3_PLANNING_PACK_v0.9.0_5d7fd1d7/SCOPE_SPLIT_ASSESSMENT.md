# Scope Split Assessment

VS-29A.3 must be delivered in reviewed child stages.

## VS-29A.3A — Report DTO and Reusable Components

- typed acquisition filter extension;
- actor-aware report facade;
- metric-selective reader;
- revenue masking/scrub assertions;
- interpretation/state mapping;
- reusable accessible components;
- chart hook extension;
- no route enablement.

## VS-29A.3B — Admin and Portal Integration

- existing B.3/C routes with acquisition tab;
- admin all-event/event views;
- portal assigned-event views;
- LiveView subscriptions/coalescing;
- C heartbeat/revocation;
- URL state;
- feature flags;
- no export.

## VS-29A.3C — Admin Aggregate Export and Production Canary

- B15 artifact integration;
- export audit/download;
- admin/management/marketing canaries;
- load/accessibility/security evidence;
- closeout.

Export child may be omitted/deferred if B15 interface is not ready.

## Mandatory blockers

- A.2 not certified;
- B.3/C exact interfaces absent;
- web code queries raw tables;
- hidden revenue fetched then template-hidden;
- parallel routes/dashboard shell;
- acquisition labels directly in URL;
- no explicit source-model disclaimer;
- missing coverage/parity states;
- no CSP-compliant chart;
- event-scoped export enabled;
- dashboard and operational PII mixed;
- distinct order/conversion/ROAS invented.
