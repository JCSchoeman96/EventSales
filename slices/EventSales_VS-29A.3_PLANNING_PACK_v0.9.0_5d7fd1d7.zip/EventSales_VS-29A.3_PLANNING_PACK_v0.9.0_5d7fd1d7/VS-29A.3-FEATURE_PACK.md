# VS-29A.3 — Acquisition Decision Reporting

## 1. Goal

Expose certified acquisition aggregates to global administrators and assigned event-scoped management/marketing users through the final EventSales decision experience.

## 2. Composition

```text
B.3 sales decision shell, filters, windows and charts
+ C scope, capabilities, revenue masking and revocation
+ A.2 acquisition reader, parity and coverage
+ B15 aggregate export framework where activated
→ A.3 acquisition reporting
```

A.3 does not implement acquisition evidence, projection, buckets, metric math, access administration or source tracking.

## 3. Current repository truth

Current `main` has:

- an admin-only dashboard that sums displayed event rows;
- a ticket-type dashboard read capped at recent rows;
- placeholder trend data;
- an event detail facade that performs direct Sales SQL;
- recent-order and customer operations mixed into the event detail page;
- an event-scoped aggregate facade that authorizes before existence and masks revenue but still reads legacy summaries;
- no portal routes;
- no acquisition UI, DTO or export;
- an inline-script Chart.js component incompatible with production self-only CSP.

Exact final B.3/C/A.2 interfaces do not yet exist on current `main`. Activation must refresh them.

## 4. Route direction

Do not create a parallel dashboard hierarchy.

Planning default:

```text
/admin/dashboard?view=acquisition
/admin/events/:id?view=acquisition
/portal?view=acquisition
/portal/events/:id?view=acquisition
```

The exact routes follow final B.3/C implementation.

The acquisition tab reuses the existing shell, event scope and typed window filters.

## 5. Views

### All-event/assigned-event overview

- source model and evidence-version notice;
- one `as_of`;
- selected-window base tickets/revenue;
- covered classified, covered unclassified and uncovered values;
- gross coverage percentage;
- acquisition coverage, sales completeness, source freshness, base-bucket freshness, A.2 freshness and parity;
- coverage trend;
- one bounded dimension ranking;
- event ranking where the final A.2 reader supports it without page-derived totals.

### Event page

- same coverage and dimension summary for one authorized event;
- optional certified ticket-type acquisition breakdown;
- same time window/comparison;
- no recent orders, customer data, order numbers, mappings or source operations in the decision DTO.

## 6. Dimension choices

Only A.2-active kinds:

- coverage;
- origin;
- source;
- source plus medium;
- campaign;
- optional device.

No arbitrary cross-product.

Content, term, referrer host, coupon and other high-cardinality evidence remain absent unless a later reviewed A.2 policy version enables them.

## 7. Measures

Selectable v1 metrics:

- tickets;
- revenue.

The selected measure exposes gross, reversal/refund and net values where B.1/A.2 provide them.

Distinct order count, sessions, visitors, customers, conversion rate, ad cost, CPA and ROAS remain unsupported.

## 8. Interpretation

Use exact wording:

- “Recorded acquisition source”;
- “WooCommerce session-based last-click evidence”;
- “Revenue associated with recorded source”;
- “Acquisition coverage”;
- “Observed but unclassified”;
- “No usable acquisition evidence”.

Do not use:

- “campaign generated”;
- “caused by”;
- “customer journey”;
- “multi-touch”;
- “conversion rate” without a certified denominator.

## 9. Revenue

Authorization is resolved before reader invocation.

For revenue-hidden actors:

- call A.2 with `metric=tickets`;
- do not fetch revenue;
- no revenue in DTO, assigns, charts, HTML, URLs, PubSub, telemetry, audit or exports;
- a requested revenue URL normalizes to tickets or returns a generic unsupported state.

For multi-event scopes, revenue is available only when every represented event is revenue-visible under final C law.

## 10. Live state

PubSub is an invalidation hint.

Open views:

- subscribe to final B.3/A.2/C topics;
- debounce/coalesce;
- reread durable facades;
- reconcile and remove subscriptions on scope change;
- reauthorize on C access hints and heartbeat;
- clear sensitive assigns before redirect/masking;
- survive missed messages through durable reload.

## 11. Export

Optional global-admin-only aggregate export:

- uses final VS-28B artifact workflow;
- exact A.2 reader filters and `as_of`;
- aggregate rows only;
- no orders or acquisition snapshots;
- versions, coverage, freshness, parity and truncation disclosed;
- CSV/XLSX formula-injection protection;
- fail closed on mismatch or unsupported state.

Portal roles receive no export capability in v1.

## 12. Non-goals

- no raw Sales or projection scan;
- no bucket rebuild or repair control;
- no source/Woo call;
- no compact v2 change;
- no alias/taxonomy administration;
- no coupon allocation;
- no target/notification logic;
- no public/share links;
- no order/customer operational tables;
- no direct-order or distinct-order approximation.

## 13. Exit gate

For the same URL filters, scope and `as_of`, each authorized surface renders the exact A.2 DTO with correct masking, coverage, parity, completeness, freshness and versions. Unassigned access reveals no event existence, charts are CSP-compliant and accessible, and no web path reads raw Sales/source data.
