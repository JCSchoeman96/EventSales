# Planning Agent Prompt — VS-29A.3

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-29A.3_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
GitHub: `#134`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, routes, components, dependencies, migrations, capabilities, portal access, exports, source contracts or production data. Do not commit, open a PR, merge, deploy, run production reports or generate exports.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

## Mandatory reading

Read every path in `FILE_INVENTORY.md`, every Pack 19 file and final certified VS-29A.2, VS-27B.3, VS-27C and VS-28B artifacts.

Do not assume planning module/route/capability names survived implementation.

## Required decisions

1. exact current-code gap verification;
2. final B.3 route/shell/filter/DTO/chart/topic interfaces;
3. final C capability/scope/revenue/portal/heartbeat interfaces;
4. final A.2 reader inputs/outputs/dimensions/versions/topics;
5. final B15 export artifact interfaces;
6. route/tab integration rather than parallel dashboard;
7. report facade and exact DTO;
8. authorization-before-existence flow;
9. represented event-set resolution;
10. metric-selective reader and revenue masking;
11. recursive no-revenue assertions;
12. multi-event mixed visibility;
13. acquisition filter extension and URL normalization;
14. source-model interpretation wording;
15. coverage/completeness/freshness/parity mapping;
16. dimension selector/top-N/Other/overflow;
17. all-event/event/ticket-type views;
18. unsupported distinct-order behaviour;
19. reusable components;
20. CSP-compliant chart hook reuse;
21. accessibility/table fallback;
22. empty/error/updating/mismatch states;
23. PubSub topics/coalescing/subscription reconciliation;
24. C heartbeat/revocation and clearing assigns;
25. privacy/display sanitization;
26. telemetry/audit;
27. performance/query/payload bounds;
28. feature flags;
29. optional admin aggregate export;
30. tests-first sequence;
31. exact files/dependencies/config/tests;
32. staged PR sequence;
33. admin/management/marketing canary;
34. rollback/stop conditions;
35. production evidence;
36. Linear M8 gates;
37. programme closeout/successor decision.

## Output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with exactly one:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`;
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
