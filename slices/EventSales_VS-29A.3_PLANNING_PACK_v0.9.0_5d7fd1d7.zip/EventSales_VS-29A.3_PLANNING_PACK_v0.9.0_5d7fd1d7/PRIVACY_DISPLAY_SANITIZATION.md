# Privacy and Display Sanitization

## Allowed display source

Only safe display labels emitted by final A.2 dimension members.

Web code never receives A.1 raw evidence or arbitrary metadata.

## Forbidden

- customer identity;
- order identity/number;
- IP/user-agent;
- full URL/path/query/fragment;
- click ids;
- cookies/session/client ids;
- payment/provider/ticket tokens;
- raw campaign/source meta;
- malformed rejected value;
- acquisition fingerprint;
- grant/settings details.

## Untrusted business strings

Even sanitized campaign/source labels remain untrusted.

Render as text, never raw HTML.

Apply:

- length bounds;
- control-character rejection;
- Unicode normalization inherited from A.1;
- bidi/confusable review where needed;
- no template/CSV formula execution;
- no URL autolinking.

## Display eligibility

A.2 member may expose:

- safe label;
- sentinel kind;
- display state.

If source evidence is malformed, over-bound, conflicted or privacy-flagged, A.3 displays only a sentinel/state label.

## URLs

Dimension selection uses opaque member UUID, not raw source/campaign text.

No acquisition labels in query parameters, paths or fragments.

## Telemetry

No dimension member, label, hash or event-specific campaign as a metric label.

Allowed low-cardinality metadata:

- view;
- metric;
- dimension kind;
- result/state;
- actor capability profile if approved;
- scope kind;
- version.

## Logs/errors

Do not inspect/print full DTO on error.

Use safe error codes and request correlation ids.
