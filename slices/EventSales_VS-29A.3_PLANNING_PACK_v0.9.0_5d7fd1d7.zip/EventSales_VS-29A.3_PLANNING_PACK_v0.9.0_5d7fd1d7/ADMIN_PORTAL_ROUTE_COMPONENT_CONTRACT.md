# Admin, Portal, Route and Component Contract

## Route direction

Prefer adding `view=acquisition` to final B.3/C routes instead of new parallel pages.

Candidate:

```text
/admin/dashboard?view=acquisition
/admin/events/:id?view=acquisition
/portal?view=acquisition
/portal/events/:id?view=acquisition
```

Activation follows exact final route architecture.

## Admin

- existing admin shell;
- all certified reportable events;
- acquisition tab alongside sales;
- operational links remain separate;
- optional admin aggregate export;
- source refresh status where B.3 permits;
- no raw-order acquisition drill-down.

## Portal

- separate portal shell;
- only assigned eligible events;
- same render-only decision components;
- no admin navigation;
- no import/export/reconciliation/source/access/target tools;
- no order/customer operations.

## Reusable components

Candidate:

- `AcquisitionStatusBanner`;
- `AcquisitionCoverageCards`;
- `AcquisitionDimensionSelector`;
- `AcquisitionCoverageChart`;
- `AcquisitionDimensionChart`;
- `AcquisitionTrendChart`;
- `AcquisitionDimensionTable`;
- `AcquisitionTicketTypeTable`;
- `AcquisitionInterpretationNotice`;
- `AcquisitionStatePanel`.

Components receive only sanitized DTO fragments.

They do not authorize, query or calculate metrics.

## Existing page separation

Current event detail mixes decision and operational content.

Final B.3/C must expose a PII-free decision surface independently.

A.3 must not import/reuse components that expect recent orders, customer PII or admin operations.

## Authorize before existence

Event route:

- parse UUID;
- capability check;
- eligibility/scope check;
- then fetch safe event display data.

Unassigned and nonexistent events return the same generic external result.

## Navigation

Tab availability depends on A.2 readiness and actor capability, not source metadata.

Hiding a tab is not authorization.
