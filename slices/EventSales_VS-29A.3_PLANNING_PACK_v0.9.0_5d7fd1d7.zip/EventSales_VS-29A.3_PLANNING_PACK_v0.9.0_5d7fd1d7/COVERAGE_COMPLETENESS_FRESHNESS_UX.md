# Coverage, Completeness, Freshness and Parity UX

## Separate states

The page presents independent status groups:

1. sales completeness;
2. acquisition source coverage;
3. source freshness;
4. base B.2 bucket freshness;
5. A.2 projection freshness;
6. A.2 bucket freshness;
7. base/dimension parity.

Do not collapse them into one green/red badge.

## Decision-grade states

### Ready

- requested sales completeness disclosed;
- A.1 coverage disclosed;
- A.2 current through required revisions;
- parity verified;
- version tuple compatible.

### Limited

Examples:

- acquisition coverage partial but accurately measured;
- selected period predates enablement;
- dimension contains overflow;
- sales history partial.

Values may display with explicit limitation; targets/causal claims remain absent.

### Updating

- dirty buckets;
- source catch-up running;
- projection/bucket lag;
- parity pending behind B.2.

Keep prior data only if clearly marked stale and capability remains valid. On access/revenue changes clear immediately.

### Blocked/error

- parity mismatch;
- version mismatch;
- acquisition reader unsupported;
- mixed currency;
- invalid scope;
- source coverage unknown;
- failed durable build.

Do not fall back to raw Sales.

## Coverage display

Show:

- covered classified;
- covered unclassified;
- uncovered;
- gross coverage numerator/denominator;
- exact gross coverage percentage or unavailable.

Net coverage percentages are not used.

## Period boundary

When the selected range crosses A.1 certification start:

- show exact covered/uncovered values;
- identify the acquisition coverage boundary;
- do not disable valid sales totals;
- do not label pre-boundary data direct.

## Mismatch

Parity mismatch:

- hides or blocks dimension decision charts/tables;
- displays safe support state;
- logs a low-cardinality event;
- never silently substitutes base totals.
