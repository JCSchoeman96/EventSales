# Rollout and Canary Contract

## Stage 0 — Activation

Refresh exact:

- B.3 routes/filters/DTO/components/chart hook/topics;
- C capabilities/portal/heartbeat/revenue rules;
- A.2 reader/dimensions/versions/topics;
- B15 export artifacts;
- deployed SHA and topology.

## Stage 1 — Report facade

- DTO builder;
- metric-selective reader calls;
- revenue scrub assertion;
- interpretation and state mapping;
- no route exposure.

## Stage 2 — Admin hidden tab

- global admin only;
- one event and bounded all-event canary;
- tickets then revenue;
- coverage/origin/source/campaign;
- CSP/accessibility/load;
- live invalidation.

## Stage 3 — Portal management

- assigned event only first;
- tickets only;
- access revoke;
- revenue flag off/on/off;
- multi-event mixed visibility;
- heartbeat with PubSub suppressed.

## Stage 4 — Portal marketing

Same sequence, with marketing revenue defaults/flags.

## Stage 5 — Optional admin export

- exact report filter;
- CSV/XLSX;
- parity/coverage/version metadata;
- formula injection;
- expiry/download/audit;
- no portal capability.

## Stop conditions

- raw Sales/source/projection read from web;
- unauthorized event existence leak;
- hidden revenue fetched or serialized;
- PII/order data;
- misleading causal language;
- parity mismatch displayed as ready;
- top-N without exact Other;
- mixed-currency sum;
- stale unauthorized chart remains;
- CSP violation/inline/CDN script;
- subscription accumulation;
- unbounded query/payload;
- export from portal role.

## Rollback

Disable acquisition flags.

Preserve A.1/A.2 truth and normal sales decision experience.

No data mutation required.
