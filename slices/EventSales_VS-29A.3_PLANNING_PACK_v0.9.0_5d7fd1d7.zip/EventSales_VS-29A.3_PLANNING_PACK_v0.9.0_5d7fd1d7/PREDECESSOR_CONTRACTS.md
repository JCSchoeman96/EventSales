# Predecessor Contracts

## VS-29A.2

A.2 owns:

- acquisition projection and numeric-copy boundary;
- fixed dimension policy and members;
- covered classified/unclassified/uncovered partitions;
- durable hour/day buckets;
- parity;
- bounded reader;
- top-N plus exact Other;
- edge-window behaviour;
- source/projection/bucket freshness;
- unsupported distinct-order state.

A.3 consumes the facade only.

## VS-27B.3

B.3 owns:

- all-event/event decision routes and shells;
- source/event/currency scope;
- B.1 window, custom range and comparison filters;
- one `as_of`;
- sales completeness and source/base freshness presentation;
- self-hosted CSP-compliant chart hook;
- accessible table fallback;
- LiveView durable reread and subscription reconciliation;
- admin operational separation.

A.3 adds a typed view and dimension state; it does not fork the window contract.

## VS-27C

C owns:

- portal authentication;
- assigned event scope;
- capability resolver;
- authorize-before-existence;
- management/marketing profiles;
- revenue flags;
- live revocation and heartbeat;
- separate portal shell;
- PII/order/export denial.

A.3 does not weaken AdminOnly or activate dormant PII/order settings.

## VS-28B

B15 owns:

- aggregate export artifact lifecycle;
- exact filter hash and `as_of`;
- CSV/XLSX generation;
- audit;
- expiry/download;
- formula injection protection;
- complete/truncated state.

A.3 only registers an acquisition aggregate export type when that framework is certified.

## VS-29A.1 and VS-27A

A.1 owns safe display evidence and coverage. VS-27A owns transport/privacy.

A.3 never reads raw order meta, compact payloads or source fields.
