# Mandatory File Inventory

## Governance and packs
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- feature-pack standard;
- live-sales roadmap/product decisions;
- GitHub #134;
- final VS-29A.2;
- final VS-27B.3;
- final VS-27C;
- final VS-28B export stage.

## Current reporting code
- `lib/event_sales/analytics/admin_dashboard.ex`
- `lib/event_sales/analytics/event_detail.ex`
- `lib/event_sales/analytics/event_scoped_dashboard.ex`
- current snapshot/hot-state/readers/PubSub;
- current MetricRules;
- tests.

## Current web
- `lib/event_sales_web/router.ex`
- admin dashboard/events/event detail LiveViews;
- admin session/plugs;
- admin/portal shells when final;
- dashboard components;
- chart component/assets/hooks;
- endpoint/CSP/root layout;
- tests.

## Final B.3
Inspect exact:
- routes and `view` state;
- typed filter/window parser;
- all-event/event decision DTO;
- chart hook/components;
- completeness/freshness source;
- PubSub topics;
- refresh actions;
- feature flags;
- operational separation.

## Final C
Inspect exact:
- portal routes/session/shell;
- capability resolver;
- assigned event scope;
- reportable lifecycle;
- revenue policy;
- heartbeat/access PubSub;
- grant/user/settings invalidation;
- PII/export denials;
- tests.

## Final A.2
Inspect exact:
- AcquisitionBucketReader;
- input/output DTO;
- dimensions/policy;
- top-N/Other;
- edge windows/comparison;
- parity/completeness/freshness;
- PubSub topics;
- metric-selective reads;
- performance/query limits.

## Final B15
Inspect exact:
- export artifact resource/actions/workers;
- filter/as-of hash;
- CSV/XLSX writers;
- formula-injection guard;
- audit;
- expiry/download authorization;
- PII/truncation contract.

## Access/privacy
- `accounts/policies.ex`
- `accounts/pii_policy.ex`
- capability modules from C;
- `catalog/resources/event_dashboard_setting.ex`
- access grants/user state;
- audit sanitizer/logger.

## Config/CI
- `mix.exs`, `mix.lock`;
- asset/package config and lock;
- CSP/security headers;
- runtime/test feature flags;
- telemetry;
- architecture manifests/index;
- static no-raw-Sales/web/source checks;
- accessibility/browser/load tooling;
- Railway/release configuration.
