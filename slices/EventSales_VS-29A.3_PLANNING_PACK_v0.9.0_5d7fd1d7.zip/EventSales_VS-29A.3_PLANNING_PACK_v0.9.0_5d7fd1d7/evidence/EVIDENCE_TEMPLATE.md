# VS-29A.3 Redacted Evidence

- Pack/plan/activation:
- Child stage:
- PR/head/deployed SHA:
- Final A.2/B.3/C/B15 versions:
- Feature flags:
- Actor profile/scope:
- Report URL/filter hash:
- `as_of`:

## DTO
- scope/window/currency:
- metric/dimension:
- base/coverage partitions:
- coverage ratio:
- top-N/Other:
- series/ticket types:
- completeness/coverage/freshness/parity:
- versions:
- interpretation:

## Access/revenue
- assigned/reportable events:
- revenue expected:
- reader calls:
- recursive no-revenue scan:
- mixed-visibility:
- access/revenue revoke:
- heartbeat without PubSub:
- unauthorized/nonexistent equivalence:

## Live/browser
- topics/subscription reconciliation:
- coalescing:
- missed messages:
- chart hook lifecycle:
- CSP:
- accessibility:
- browsers:
- payload/query count:
- p50/p95:

## Privacy
- seeded PII/order/URL/click ids:
- DTO/DOM/chart/URL:
- PubSub/logs/telemetry/audit:
- unsafe dimension label:
- export:
- verdict:

## Export
- admin capability:
- filter/as-of/version:
- artifact id/hash/size/rows:
- top/full/truncated:
- formula protection:
- expiry/download/audit:
- portal denial:

## Negative proof
- no raw Sales/A.1/A.2 table/source read:
- no bucket writes:
- no second dashboard:
- no causal claims:
- no distinct order/conversion/ROAS:
- no inline/CDN:
- no production operation outside supplement:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED LIMIT / REJECTED
