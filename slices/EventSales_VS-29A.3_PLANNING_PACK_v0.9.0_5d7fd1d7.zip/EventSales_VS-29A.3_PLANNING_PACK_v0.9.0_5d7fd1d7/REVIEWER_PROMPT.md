# Independent Reviewer Prompt — VS-29A.3

Review adversarially against exact current repository code and final A.2/B.3/C/B15 contracts.

Block any design that:

- creates a second dashboard or duplicate filter/window contract;
- queries raw Sales, A.1 snapshots, A.2 projections/buckets or Woo from web code;
- fetches hidden revenue then hides it only in templates;
- exposes revenue in DTO, assigns, chart payload, URL, PubSub, telemetry, audit or export;
- sums visible-event pages for all-event totals;
- widens assigned-event scope from URL ids;
- checks event existence before authorization;
- activates dormant PII/order settings;
- exposes order/customer/URL/query/click-id data;
- uses raw source/campaign strings in URLs or telemetry labels;
- presents last-click evidence as causal, first-touch or multi-touch;
- labels missing evidence direct;
- merges covered unclassified with uncovered;
- hides parity mismatch or falls back to raw Sales;
- omits sales completeness/acquisition coverage/freshness/version metadata;
- offers arbitrary dimension cross-products;
- omits exact Other for top-N;
- confuses A.2 overflow with UI Other;
- infers distinct orders, conversion, sessions, customers, CPA or ROAS;
- uses inline/CDN chart scripts or chart-only information;
- fails to clear stale sensitive assigns after revocation;
- accumulates subscriptions;
- lets event-scoped users export;
- bypasses B15 artifact/audit/formula protection;
- enables flags/canaries by deployment.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only.
