# Current Code Reporting Map

| Current area | Current behaviour | Pack 19 implication |
|---|---|---|
| AdminDashboard | totals from displayed event rows, event limit 50 | final B.3/A.2 full-scope DTO only |
| ticket types | up to 1,000 raw OrderItems | no reuse for acquisition |
| trend | placeholder empty `daily_buckets` | use certified B.3/A.2 series |
| EventDetail | raw Sales SQL for totals/status/ticket types | acquisition tab cannot call it |
| Event detail UI | decision metrics plus recent orders/PII/admin tools | reusable decision components must be separate |
| EventScopedDashboard | authorize-before-existence, PII-free, revenue masking | preserve doctrine; replace legacy reader at final seam |
| Policies | Postgres roles/grants/settings | final C capability resolver authoritative |
| PiiPolicy | aggregate/export PII `none` | acquisition DTO/export remains PII-free |
| EventDashboardSetting | owner/staff revenue flags; dormant order/PII flags | revenue only; dormant flags stay dormant |
| Router | `/admin/*` AdminOnly; no portal | exact B.3/C routes required |
| Chart | inline script/Chart global | replace through final B.3 self-hosted hook |
| Exports | synchronous admin event CSV | use final B15 artifacts, not current controller |
| PubSub | hot-state event topics | final A.2/B.3 topics and durable reread |
