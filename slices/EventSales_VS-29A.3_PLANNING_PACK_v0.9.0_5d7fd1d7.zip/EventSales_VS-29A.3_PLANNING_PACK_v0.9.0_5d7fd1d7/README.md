# EventSales VS-29A.3 Planning Pack

## Identity

- Slice: `VS-29A.3`
- Name: Acquisition Decision Reporting
- Pack: `0019_VS-29A.3`
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- GitHub issue: `#134`
- Linear milestone: `M8 — Acquisition Evidence and Reporting`
- Linear document: `VS-29A.3 — Pack 19 Gate Ledger and Planning Record`
- Created: `2026-07-18T15:51:33Z`

## Authority

This ZIP authorises independent pack review and repository implementation planning only.

It does not authorise:

- code, route, component, dependency, migration or configuration changes;
- portal access or role/capability changes;
- acquisition aggregate reads in production;
- exports or artifact generation;
- bucket rebuilds, source changes or compact-contract changes;
- merge, deployment or production canary.

Implementation remains blocked until:

1. Pack 19 is independently approved;
2. the implementation plan is independently approved;
3. VS-29A.2 is certified and closed;
4. VS-27B.3 and VS-27C are certified and closed;
5. final VS-28B export-artifact interfaces are refreshed for any export stage;
6. an activation supplement returns `APPROVE`.

Every production admin, management or marketing canary requires a separate exact supplement.

## Outcome

```text
certified A.2 bounded reader
+ certified B.3 decision-window and chart contract
+ certified C actor/event/revenue capabilities
→ acquisition tab in the existing decision experience
→ exact coverage and dimension views
→ safe live updates
→ optional admin-only aggregate export
→ production canaries
```

## Critical doctrine

```text
One decision experience, not a second dashboard.
Web modules read only the A.2 facade.
Revenue-hidden means revenue is not fetched.
Last-click evidence is not causal attribution.
Missing evidence is not direct.
Top-N always includes exact Other.
No customer/order/source-payload data.
No distinct-order approximation.
```
