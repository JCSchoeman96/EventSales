# TOON Prompts

## Pack reviewer
Task: Attack current-code accuracy, predecessor composition and scope.
Output: APPROVE / REQUEST CHANGES / BLOCKED.

## Access reviewer
Task: Attack assigned scope, authorize-before-existence, revenue masking and revocation.
Output: access verdict.

## Metric/interpretation reviewer
Task: Attack causal wording, coverage semantics, unsupported measures and comparisons.
Output: interpretation verdict.

## DTO/privacy reviewer
Task: Scan DTO/URL/chart/PubSub/log/export for revenue and forbidden data.
Output: leakage verdict.

## UX/accessibility reviewer
Task: Attack filter state, empty/error states, chart CSP and accessible table equivalence.
Output: UX verdict.

## LiveView reviewer
Task: Attack durable rereads, coalescing, subscription cleanup and stale assigns.
Output: live-state verdict.

## Export reviewer
Task: Verify admin-only aggregate artifact, exact filters, parity, audit and spreadsheet safety.
Output: export verdict.

## Activation reviewer
Task: Refresh exact final A.2/B.3/C/B15 interfaces and current deployment.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
