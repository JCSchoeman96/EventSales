# Acquisition Report DTO Contract

## Boundary

Candidate facade:

```text
EventSales.Analytics.AcquisitionDecisionReport
```

The facade is non-web and actor-aware. It composes final B.3 scope metadata, final C capabilities and final A.2 reader output.

Web modules render this DTO only.

## Inputs

- actor;
- report scope: all reportable / assigned / one event;
- selected event ids where final B.3 permits;
- source system;
- currency;
- B.1 window/custom range;
- comparison;
- one `as_of`;
- metric: tickets or revenue;
- dimension kind;
- optional dimension member id;
- top N/page/sort;
- exact contract versions.

## Recommended DTO

```text
meta
capabilities
interpretation
totals
coverage
dimension
series
ticket_types
comparison
states
```

## Meta

- scope kind and safe scope ids;
- timezone;
- currency;
- window start/end;
- comparison start/end/state;
- `as_of`;
- source model;
- metric/semantic/acquisition/normalisation/aggregation/classification versions;
- reader version.

## Capabilities

- `revenue_visible?`;
- `aggregate_export_allowed?`;
- `available_metrics`;
- `available_dimensions`;
- `available_scopes`.

Do not include raw roles or grant rows in the DTO.

## Interpretation

- source model display;
- last-click disclaimer;
- coverage explanation;
- no-causality notice;
- unsupported measure messages.

## Totals

For the selected metric only:

- base gross/reversal/net;
- covered classified gross/reversal/net;
- covered unclassified gross/reversal/net;
- uncovered gross/reversal/net.

If tickets selected, no revenue fields exist.

## Coverage

- gross covered numerator;
- gross base denominator;
- exact ratio or unavailable;
- class totals;
- A.1 covered/eligible order or contribution metadata only if certified and non-misleading;
- coverage window/state.

## Dimension

- kind;
- full-partition status;
- top N and maximum;
- ordered rows;
- exact Other;
- pagination/cursor;
- full result count where certified;
- truncation state.

Each row:

- opaque dimension member id;
- safe label;
- sentinel kind;
- selected metric values;
- share of gross covered measure;
- comparison;
- optional trend reference.

## Series

Bounded points:

- period start/end;
- selected metric base;
- coverage partitions or selected member;
- comparison where supported;
- completeness/freshness/parity state.

## Ticket types

Event-only and only when final A.2 supports exact bounded ticket-type rows.

No order/customer fields.

## States

- sales completeness;
- acquisition coverage;
- source freshness;
- B.2 freshness;
- A.2 projection freshness;
- A.2 bucket freshness;
- parity;
- rebuilding/missing/unsupported/truncated.

## Revenue invariant

When `revenue_visible?` is false, recursively scanning the serialized DTO must find no quantitative revenue/money fields, Decimal values, revenue series, revenue comparison values or revenue labels. The boolean capability flag and generic explanatory copy are allowed.
