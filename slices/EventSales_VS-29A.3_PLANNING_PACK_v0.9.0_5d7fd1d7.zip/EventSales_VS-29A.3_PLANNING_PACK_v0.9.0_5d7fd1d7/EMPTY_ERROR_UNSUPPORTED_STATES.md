# Empty, Error and Unsupported States

## No sales contributions

Show:

- zero certified sales for selected window;
- acquisition coverage unavailable because denominator is zero;
- no dimension chart;
- no implication that tracking failed.

## Sales exist, no acquisition evidence

Show:

- valid sales total;
- 0 covered;
- all uncovered;
- exact A.1 reason/coverage boundary at aggregate-safe level;
- no Direct classification.

## Partial acquisition coverage

Show covered/uncovered values and percentage.

Dimension rows represent covered values only; base and uncovered remain visible.

## Covered but unclassified

Show “Observed but unclassified” as a first-class partition.

Do not merge into uncovered.

## Unsupported dimension

Explain that the selected dimension is not enabled for this source/policy version.

Normalize to Coverage or present a bounded error.

## Unsupported metric

Distinct orders and other uncontracted metrics show unavailable with reason.

Do not substitute contribution count.

## Mixed currency

Require one currency or show grouped separate results only if final B.3/A.2 supports it.

Never sum.

## Updating

Display durable stale/current timestamp and queued/rebuilding state.

Prior values may remain only when clearly stale and actor capability remains valid.

## Parity mismatch

Hide decision charts/tables for the affected result.

Show generic data verification message.

Do not expose internal numeric differences or bucket keys to portal users.

## Invalid/unassigned event

Authorize before existence.

Use the same generic not-found/forbidden external experience.

## Reader failure

- safe retry/view refresh;
- no raw fallback;
- no stack/error details;
- preserve URL filters;
- telemetry safe code.

## Revenue hidden

Tickets remain usable.

Do not render empty revenue placeholders that reveal a hidden capability. Remove revenue metric/control entirely or mark generically unavailable.
