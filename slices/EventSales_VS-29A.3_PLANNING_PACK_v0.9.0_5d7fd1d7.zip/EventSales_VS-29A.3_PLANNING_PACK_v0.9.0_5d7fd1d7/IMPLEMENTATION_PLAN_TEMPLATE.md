# VS-29A.3 Implementation Plan

## 1. Baseline/drift proof
## 2. Files/predecessors inspected
## 3. Current-code gap verification
## 4. Final B.3 route/filter/DTO/chart/topic interfaces
## 5. Final C capabilities/scope/revenue/portal/heartbeat
## 6. Final A.2 reader/dimensions/versions/topics
## 7. Final B15 artifact/export interfaces
## 8. Existing route/tab integration
## 9. Report facade and actor-aware flow
## 10. Authorization-before-existence
## 11. Represented event-set resolution
## 12. Metric-selective reader/revenue masking
## 13. Recursive no-revenue proof
## 14. Multi-event mixed visibility
## 15. URL filter extension/normalization
## 16. Report DTO exact schema
## 17. Interpretation/copy contract
## 18. Coverage/completeness/freshness/parity UX
## 19. Dimension/top-N/Other/overflow
## 20. All-event/event/ticket-type views
## 21. Empty/error/updating/mismatch
## 22. Components/chart hook/CSP
## 23. Accessibility/table fallback
## 24. Live subscriptions/coalescing/reread
## 25. Revocation/heartbeat/assign clearing
## 26. Privacy/display sanitization
## 27. Telemetry/audit
## 28. Query/payload/load bounds
## 29. Feature flags
## 30. Optional admin aggregate export
## 31. Tests-first sequence
## 32. Exact files/dependencies/config/tests
## 33. Static/security/accessibility/browser/load commands
## 34. Child PR sequence
## 35. Admin/management/marketing canary
## 36. Rollback/stop conditions
## 37. Production evidence
## 38. M8 gate mapping
## 39. Programme closeout/successor
## 40. Prohibited actions/verdict
