# Performance and Query Bounds

## Reader-only web path

Every acquisition page calls final A.2 reader through a bounded report facade.

No direct query of:

- Sales orders/items;
- A.1 snapshots;
- A.2 projection/bucket tables from LiveView;
- WooCommerce;
- WebhookEvent payloads.

## Planning defaults

- selected events: final B.3 cap, no more than 100;
- one source/currency;
- one dimension;
- top N default 20, maximum 100;
- dimension page size 50;
- one optional member;
- custom range maximum 366 days;
- chart points inherited from B.1/B.2/A.2;
- ticket-type rows maximum 100;
- comparison one previous-equivalent period;
- no arbitrary dimension cross-product.

Activation may tighten.

## Query count

Target one report-facade call or a small reviewed constant number of reader calls.

No per-event or per-member N+1.

All-event totals use complete reader scope, never visible table rows.

## Caching

Actor-independent sanitized A.2 results may use bounded version-keyed cache only if final B.3/A.2 permits it.

Actor-specific masking/scope occurs after capability resolution.

A cache never becomes authorization truth.

Do not cache a revenue-visible DTO for reuse by a revenue-hidden actor.

## Live storms

Debounce/coalesce invalidations.

One socket cannot trigger unbounded rereads during a flash sale.

## Load evidence

At minimum:

- 100 reportable events;
- 100 dimension members;
- maximum chart points;
- 50 concurrent LiveViews;
- event-scoped and all-event scopes;
- revenue-visible and ticket-only paths;
- rapid A.2 invalidation storm;
- access/revenue revocation;
- top-N/full-page/export interactions.

Record p50/p95 and database query plans from final reader.

## Page payload

Bound JSON/HTML/DOM size.

Do not serialize full dimension pages or hidden revenue to the browser.

## Export

Large exports run asynchronously through B15.

Web request only creates/statuses/downloads bounded artifacts.
