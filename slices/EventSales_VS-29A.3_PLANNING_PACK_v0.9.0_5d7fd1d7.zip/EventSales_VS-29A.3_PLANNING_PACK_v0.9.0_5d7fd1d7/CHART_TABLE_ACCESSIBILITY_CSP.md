# Charts, Tables, Accessibility and CSP

## Reuse B.3 chart system

A.3 must use the final self-hosted CSP-compliant B.3 LiveView hook/component.

Do not create another chart library path.

## Forbidden current pattern

- CDN Chart.js;
- inline `<script>`;
- global `Chart`;
- `unsafe-inline` production exception;
- unbounded JSON in `data-*`;
- chart-only information.

## Required visualisations

### Coverage

A bounded stacked bar or segmented horizontal bar:

- classified;
- unclassified;
- uncovered.

### Dimension ranking

Horizontal bar chart for top N plus Other.

### Trend

Line/stacked area for:

- coverage partitions; or
- one selected dimension member;
- selected tickets/revenue metric.

Do not render 20 simultaneous trend lines by default.

## Accessibility

Every chart has:

- heading and explanatory text;
- table fallback containing exact values;
- visible legend;
- screen-reader summary;
- no colour-only distinction;
- sufficient contrast;
- keyboard-accessible member selection;
- reduced-motion support;
- clear empty/updating/error state.

## Revenue masking

Revenue-hidden actors:

- receive ticket-only chart payload;
- no hidden revenue dataset;
- no revenue axis/tooltip/label;
- no revenue value in DOM attributes or hook events.

## LiveView lifecycle

Hook:

- mounts from bounded typed payload;
- updates on patches;
- destroys/reuses instances;
- ignores stale revision payloads;
- cleans up on removal;
- does not fetch data independently;
- does not use `phx-update=ignore` to retain unauthorized stale content.

## Money

Server sends canonical decimal display strings and/or reviewed integer minor units for plotting.

Browser floats are visual only and never authority.

## Point limits

Inherited from B.1/B.2/A.2.

The component rejects excessive points and renders a bounded error, not a partial chart.
