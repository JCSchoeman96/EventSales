# LiveView Updates and Subscription Contract

## Durable truth

Mount, URL change, reconnect, view refresh and invalidation reload from:

- final capability/scope resolver;
- B.3 source/completeness facade;
- A.2 acquisition reader.

No socket-local aggregate math.

## Topics

Planning categories:

- B.2 source/base bucket invalidation;
- A.2 acquisition bucket invalidation;
- A.1 coverage/version changes where not already propagated;
- F.2 source refresh state;
- C user/event access and revenue visibility changes.

Exact topics come from final predecessors.

## Payload

PubSub contains only safe:

- source/event/ticket-type ids as allowed;
- bucket/version/revision;
- reason;
- updated timestamp.

No source/campaign labels, money, PII or grant details.

## Subscription reconciliation

On each scope change:

1. calculate required bounded topics;
2. unsubscribe topics no longer required;
3. subscribe missing topics;
4. update tracked set.

Do not accumulate topics across lifecycle/filter changes.

## Coalescing

Message storms debounce/coalesce by safe scope/revision.

Planning range: 250–1,000 ms.

Always load the newest durable revision; messages are not deltas.

## Reauthorization

On C access hint or heartbeat:

- clear acquisition DTO/chart/export state first;
- requery actor capabilities and assigned scope;
- if event access lost, redirect generically;
- if revenue lost, reload tickets only;
- if scope shrinks, unsubscribe removed events.

Heartbeat maximum inherited from C, planning 60 seconds.

## Missed messages

Reconnect and heartbeat/durable reload repair missed PubSub.

No correctness claim relies solely on a message.

## Manual actions

- `Refresh view` rereads durable state only.
- `Check WooCommerce now` remains final F.2 admin authority.
- No acquisition bucket rebuild/repair button in A.3.
