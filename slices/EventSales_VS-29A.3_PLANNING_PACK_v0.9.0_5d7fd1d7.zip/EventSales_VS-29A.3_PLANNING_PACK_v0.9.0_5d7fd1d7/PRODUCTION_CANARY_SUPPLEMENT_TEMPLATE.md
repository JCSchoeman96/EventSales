# VS-29A.3 Production Canary Supplement

- Certified PR/head/deployed SHA:
- Certified A.2/B.3/C/B15 versions:
- Actor profile:
- Actor/user reference:
- Exact assigned/reportable events:
- Revenue flags/expected visibility:
- Scope/window/currency:
- Metric/dimension/top/member:
- Feature flags:
- Expected coverage/parity/freshness:
- Expected DTO/chart state:
- PubSub/heartbeat test:
- Accessibility/browser matrix:
- Query/load threshold:
- Export scope if applicable:
- Authorization:
- Operator:
- Start/end:
- Rollback:
- Stop conditions:

Verdict:

- APPROVE ADMIN CANARY
- APPROVE MANAGEMENT TICKET-ONLY CANARY
- APPROVE MANAGEMENT REVENUE CANARY
- APPROVE MARKETING TICKET-ONLY CANARY
- APPROVE MARKETING REVENUE CANARY
- APPROVE ADMIN EXPORT CANARY
- REFRESH
- BLOCKED

Approval applies only to the exact actor, event scope, flags and report filters.
