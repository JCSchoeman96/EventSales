# Admin Acquisition Reporting Canary

## Preconditions

- exact supplement says APPROVE ADMIN CANARY;
- A.2 ready/parity verified;
- admin acquisition flag off by default;
- exact event/source/currency/window selected;
- no portal flag.

## Enable

Enable acquisition view for the approved admin cohort only.

## Validate

- existing sales view unchanged;
- acquisition tab uses existing shell/filter contract;
- source-model disclaimer;
- one `as_of`;
- tickets and revenue exact to A.2;
- classified/unclassified/uncovered parity;
- coverage percentage;
- every enabled dimension;
- top-N and exact Other;
- overflow distinction;
- event and ticket-type views;
- custom range/comparison;
- completeness/freshness/parity/version states;
- no raw Sales query;
- CSP/accessibility;
- PubSub reload/coalescing;
- query/payload/load bounds.

## Negative states

- no sales;
- no evidence;
- partial coverage;
- updating;
- parity mismatch;
- mixed currency;
- invalid member/dimension;
- A.2 unavailable.

## Export

Only when separately approved.

## Stop

Any numeric mismatch, misleading copy, raw query, CSP issue, PII, unbounded load or stale data claim.

## Verdict

- ADMIN CANARY CERTIFIED;
- EXTEND;
- REJECTED.
