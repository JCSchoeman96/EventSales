# CSP, Accessibility and Browser Validation

## CSP

In production-equivalent mode verify:

- no inline script;
- no external CDN;
- self-hosted versioned asset;
- no CSP console violation;
- no `unsafe-inline`/`unsafe-eval` expansion;
- LiveView websocket allowed;
- chart works after patch/navigation.

## Accessibility

Use automated and manual checks:

- headings/landmarks;
- tabs semantics;
- labels/descriptions;
- keyboard-only;
- focus retention on patches;
- screen-reader chart summary;
- exact table fallback;
- colour contrast;
- no colour-only meaning;
- reduced motion;
- zoom/reflow 200% and 400%;
- mobile table/card behaviour;
- error/updating announcements.

## Browser matrix

At least current:

- Chromium desktop/mobile;
- Firefox desktop;
- Android Chrome relevant to users.

Use exact programme browser policy if final B.3 defines one.

## Data equivalence

For every chart point/bar compare rendered table values to DTO.

## Revenue

Ticket-only actor has no revenue axis, tooltip, hidden data attribute or screen-reader text.

## Copy

Verify source-model disclaimer and no causal terms.

## Verdict

- CERTIFIED;
- CERTIFIED WITH DOCUMENTED LIMIT;
- REJECTED.
