# VS-29A.3 Production Validation

## Admin

- existing sales route unchanged;
- acquisition tab/filter/DTO;
- exact A.2 tickets/revenue;
- coverage/parity/states;
- dimensions/top-N/Other;
- event/ticket type;
- URL/comparison;
- live updates;
- CSP/accessibility/load.

## Management

- assigned-only;
- ticket-only;
- revenue enable/revoke;
- multi-event visibility;
- access expiry/revoke/deactivation;
- PubSub suppressed heartbeat;
- no denied tools/export.

## Marketing

Repeat independently.

## Export

Admin only, exact artifact workflow, metadata/parity/formula/privacy/download/audit.

## Negative proof

- no raw Sales/A.1/A.2 table/source query;
- no PII/order/URL/click id;
- no hidden revenue fetch;
- no causal claims;
- no distinct order/conversion/ROAS;
- no inline/CDN chart;
- no subscription accumulation;
- no page-derived totals;
- no portal export.

## Final verdict

- `CERTIFIED — M8 COMPLETE`;
- `CERTIFIED WITH ACCEPTED LIMIT`;
- `REJECTED / BLOCKED`.

After M8, the next programme pack requires an explicit roadmap/product decision.
