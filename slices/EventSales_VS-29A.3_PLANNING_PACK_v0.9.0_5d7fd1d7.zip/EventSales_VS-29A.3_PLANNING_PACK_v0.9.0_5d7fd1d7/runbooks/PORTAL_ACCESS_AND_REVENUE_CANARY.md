# Portal Access and Revenue Canary

## Preconditions

- admin canary certified;
- exact C implementation/heartbeat certified;
- exact management or marketing actor and assignments approved;
- portal acquisition flag scoped to cohort.

## Cases

### Assigned ticket-only

- actor sees only assigned eligible events;
- acquisition tickets/coverage/dimensions visible;
- revenue control absent/unavailable;
- revenue reader not called;
- serialized DTO/DOM/chart contains no revenue.

### Revenue enable

- set reviewed event visibility through C admin workflow;
- access-change hint reloads;
- revenue becomes available only after Postgres reauthorization;
- exact A.2 revenue values.

### Revenue revoke

- clear chart/DTO first;
- reauthorize;
- tickets-only reload;
- old revenue absent from DOM, hook instance and client memory as far as testable;
- within C bound with PubSub and with PubSub suppressed.

### Access revoke/expiry/deactivation

- clear assigns;
- unsubscribe;
- generic redirect/logout;
- no event existence leak;
- within C bound.

### Multi-event

- all events revenue visible → revenue allowed;
- one hidden/expired → all aggregate revenue unavailable;
- no visible-subset total.

## Marketing/management

Run separately because visibility flags and profiles may differ.

## Denied surfaces

- export;
- orders/customers;
- admin links/tools;
- source refresh if C denies it;
- access/target/correction controls.

## Verdict

- PROFILE CANARY CERTIFIED;
- EXTEND;
- REJECTED.
