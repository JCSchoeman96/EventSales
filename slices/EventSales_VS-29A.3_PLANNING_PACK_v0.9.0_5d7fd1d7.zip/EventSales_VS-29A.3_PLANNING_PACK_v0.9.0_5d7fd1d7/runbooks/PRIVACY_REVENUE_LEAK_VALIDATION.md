# Privacy and Revenue Leak Validation

## Seed

Use distinctive synthetic:

- customer name/email/phone/address;
- order number/id/key;
- IP/user-agent;
- full referrer/landing URL;
- query/click ids;
- provider/ticket/download tokens;
- unsafe campaign/source beginning with spreadsheet formula;
- hidden revenue amounts.

## Surfaces

Inspect:

- A.3 DTO;
- LiveView assigns;
- rendered HTML;
- URL/history;
- chart hook payload/client state;
- table fallback;
- PubSub;
- telemetry;
- logs/errors;
- audit;
- export artifact;
- browser accessibility tree;
- cached responses.

## Ticket-only actor

Instrument A.2 reader and prove revenue query/function not invoked.

Then recursively scan all server/client outputs for:

- revenue keys;
- Decimal values;
- exact seeded amounts;
- currency values used only for revenue where not otherwise required.

## Labels

Unsafe/forbidden A.1 evidence must appear only as safe sentinel/state.

## Formula safety

CSV/XLSX text cells cannot execute formulas.

## Access

Unassigned/nonexistent event responses are indistinguishable externally.

## Verdict

Any leak is a blocker and security incident for production.
