# Admin Aggregate Export Canary

## Preconditions

- final B15 artifact framework certified;
- Pack 19 export stage approved/deployed disabled;
- admin report canary certified;
- exact export supplement approved.

## Request

From the exact acquisition report state capture:

- filter hash;
- `as_of`;
- version tuple;
- scope/window/currency;
- metric/dimension;
- top-N or bounded full mode;
- completeness/coverage/freshness/parity.

## Generate

Worker calls aggregate reader/export facade only.

No raw Sales/A.1/A.2 table/source query.

## Verify CSV/XLSX

- metadata;
- exact report totals/rows;
- classified/unclassified/uncovered;
- top-N/Other or complete bounded list;
- safe labels;
- formula-injection protection;
- no order/customer/source-payload data;
- artifact SHA/size/row count;
- complete/truncated state;
- expiry/download.

## Authorization

- global admin success;
- event owner/staff/portal denied at request and download;
- expired/revoked admin session denied.

## Mismatch

Parity mismatch fails artifact plan/generation.

## Audit

Safe request/download audit with filter/artifact hashes.

No raw labels.

## Verdict

- EXPORT CERTIFIED;
- EXTEND;
- REJECTED.
