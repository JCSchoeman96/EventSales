# Operational Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| A.2 reader unavailable | explicit unavailable | repair A.2 |
| parity mismatch | block dimension decisions | A.2/B.2 repair |
| coverage partial | disclose limitation | normal/coverage work |
| mixed currency | reject/group separately | select currency |
| disabled dimension | normalize to coverage/error | policy review |
| invalid member | generic invalid filter | remove member |
| revenue denied | tickets-only; no revenue call | normal |
| one event hidden in multi-scope | all aggregate revenue hidden | narrow scope/admin setting |
| access revoked | clear/redirect | C workflow |
| PubSub missed | heartbeat/reconnect reload | none |
| invalidation storm | coalesce | tune |
| chart hook error | table fallback | asset fix |
| CSP violation | no chart; block rollout | self-hosted hook fix |
| top-N reader missing Other | block | A.2 fix |
| raw label privacy flag | sentinel/block display | A.1 correction |
| web raw-query detected | block/rollback | architecture fix |
| export mismatch | fail artifact | repair/retry |
| export auth changes | deny download | re-request if authorized |
| source-model version incompatible | explicit unsupported | version activation |
| stale unauthorized cache | block/security incident | cache partition/purge |
