# Live Update and Revocation Validation

## Invalidation

Generate approved A.2 changes:

- new bucket revision;
- acquisition evidence reclassification;
- refund/remap correction;
- coverage status change.

Verify:

- safe PubSub hint;
- debounce/coalesce;
- durable reread;
- newest revision only;
- charts/tables update;
- no browser reload.

## Subscription reconciliation

Change:

- current/past/all scope;
- event selection;
- event detail;
- dimension/member;
- actor assignments.

Inspect tracked subscriptions and prove removed topics are unsubscribed.

## Storm

Generate repeated hints.

Verify bounded rereads and no socket/process backlog.

## Missed messages

Suppress one or more hints, reconnect or trigger heartbeat/view refresh, and verify durable current state.

## Access/revenue

Run revoke/flag tests with PubSub present and absent.

Clear old sensitive assigns before asynchronous reload.

## Client hook

Verify chart instance:

- updated;
- stale revision ignored;
- destroyed on navigation/revoke;
- no retained hidden revenue dataset.

## Stop

- correctness depends on message payload delta;
- topic leak across scope;
- subscription accumulation;
- stale unauthorized content;
- unbounded reload loop.
