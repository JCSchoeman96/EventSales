# Final Interface Refresh

## Purpose

Refresh Pack 19 against the actual implemented A.2/B.3/C/B15 interfaces.

## Record exact

### A.2

- reader module/function;
- input filters;
- metric-selective behaviour;
- dimension kinds/member ids;
- top-N/Other;
- series/comparison;
- ticket-type support;
- states/versions;
- PubSub topics/revisions;
- performance bounds.

### B.3

- routes;
- typed filter parser;
- DTO/shell/components;
- chart hook/assets;
- source/completeness/freshness facade;
- subscriptions/debounce;
- feature flags.

### C

- capability names;
- assigned/reportable event resolver;
- portal routes/shell;
- revenue visibility resolver;
- multi-event rule;
- access/revenue topics;
- heartbeat;
- logout/redirect behaviour.

### B15

- artifact type registry;
- request/plan hash;
- async worker/storage;
- CSV/XLSX writers;
- formula guard;
- audit/download/expiry;
- role capability.

## Compare

For each Pack 19 planned interface classify:

- exact match;
- renamed equivalent;
- absent;
- incompatible;
- newly required.

## Blockers

- no metric-selective A.2 read;
- no actor/event capability resolver;
- revenue is available only inside a mixed tickets/revenue DTO;
- no authorize-before-existence route pattern;
- B.3 chart remains inline/CDN;
- A.2 does not expose parity/coverage/freshness;
- portal routes not certified;
- export lacks aggregate artifact capability;
- current main/deployed SHA unknown.

## Output

Complete activation supplement.

No code or production report read.
