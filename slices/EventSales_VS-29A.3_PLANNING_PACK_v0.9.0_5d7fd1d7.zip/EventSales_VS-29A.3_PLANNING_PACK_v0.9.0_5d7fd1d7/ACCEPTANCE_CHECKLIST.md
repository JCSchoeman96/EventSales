# VS-29A.3 Acceptance Checklist

## Governance
- [ ] Exact current main.
- [ ] Pack review approved.
- [ ] Plan review approved.
- [ ] VS-29A.2 certified.
- [ ] VS-27B.3 certified.
- [ ] VS-27C certified.
- [ ] VS-28B export interface certified where used.
- [ ] Activation APPROVE.

## Composition
- [ ] Existing decision routes/shells reused.
- [ ] One typed filter contract.
- [ ] A.2 facade only.
- [ ] No raw Sales/source/projection read.
- [ ] No bucket write/rebuild.
- [ ] No operational PII mixed into decision DTO.

## DTO
- [ ] One `as_of`.
- [ ] Exact scope/window/currency/timezone.
- [ ] All versions.
- [ ] Base and coverage partitions.
- [ ] Gross coverage ratio.
- [ ] Dimension rows/top-N/Other.
- [ ] Series/ticket types bounded.
- [ ] Completeness/coverage/freshness/parity.
- [ ] Interpretation disclaimer.
- [ ] Unsupported states.

## Access/revenue
- [ ] Final capability resolver.
- [ ] Authorize before existence.
- [ ] Assigned events only.
- [ ] Global staff no implicit scope.
- [ ] Revenue resolved before reader.
- [ ] Tickets-only call when hidden.
- [ ] Recursive no-quantitative-revenue assertion.
- [ ] Multi-event all-visible rule.
- [ ] Revenue revoke clears old data.
- [ ] Access revoke within C bound.
- [ ] Portal exports denied.

## Filters/views
- [ ] Sales/acquisition tab.
- [ ] Tickets/revenue metric.
- [ ] Coverage/origin/source/source-medium/campaign/device.
- [ ] Disabled dimensions rejected.
- [ ] Member UUID only.
- [ ] Top max 100.
- [ ] Stable sort/keyset.
- [ ] Page reset on scope.
- [ ] Shareable only within authorization.
- [ ] All-event totals not page-derived.

## Interpretation
- [ ] Last-click/session model named.
- [ ] No causal language.
- [ ] Missing not direct.
- [ ] Unclassified distinct from uncovered.
- [ ] Other distinct from overflow.
- [ ] No orders/conversion/sessions/customers/ROAS.

## Live/CSP/accessibility
- [ ] Self-hosted hook.
- [ ] No inline/CDN.
- [ ] Table fallback.
- [ ] Keyboard/screen-reader/reduced motion.
- [ ] Bounded points/payload.
- [ ] Durable reread.
- [ ] Coalescing.
- [ ] Subscriptions reconciled.
- [ ] Missed PubSub harmless.
- [ ] No stale unauthorized DOM.

## Privacy
- [ ] No PII/order data.
- [ ] No URL/query/click ids.
- [ ] Safe A.2 labels only.
- [ ] No raw labels in URL/telemetry/audit.
- [ ] Text rendering only.
- [ ] Formula injection protection.

## Export
- [ ] Optional/admin only.
- [ ] B15 artifacts.
- [ ] Same filters/as-of.
- [ ] Aggregate rows only.
- [ ] Versions/states/truncation.
- [ ] Mismatch fails.
- [ ] Expiry/download/audit.

## Performance/rollout
- [ ] Bounded query count.
- [ ] 100 events/100 members/max points.
- [ ] 50 clients.
- [ ] Revocation/invalidation storm.
- [ ] Admin canary.
- [ ] Management ticket/revenue canary.
- [ ] Marketing ticket/revenue canary.
- [ ] Rollback flag.
