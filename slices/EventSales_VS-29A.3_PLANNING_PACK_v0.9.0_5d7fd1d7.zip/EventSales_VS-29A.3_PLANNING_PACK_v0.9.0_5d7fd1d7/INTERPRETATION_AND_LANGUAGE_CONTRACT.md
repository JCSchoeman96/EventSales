# Interpretation and Language Contract

## Source model

The primary planned source is:

```text
WooCommerce session-based last-click order attribution evidence
```

Every page and export states the exact source model/version.

## Approved labels

- Acquisition overview
- Recorded acquisition source
- Source and medium
- Recorded campaign
- WooCommerce last-click evidence
- Acquisition coverage
- Covered and classified
- Observed but unclassified
- No usable acquisition evidence
- Revenue associated with recorded source
- Tickets associated with recorded source
- Other recorded sources
- Data updating
- Acquisition evidence unavailable for part of this period

## Prohibited or misleading labels

- Campaign-generated revenue
- Revenue caused by
- Campaign conversions
- Customer journey
- First touch
- Multi-touch
- Marketing ROI
- ROAS
- CPA
- Unique customers
- Sessions converted

unless a later certified contract actually supplies those semantics.

## Tooltips/help text

At minimum:

> This view groups certified ticket and revenue contributions by the acquisition evidence WooCommerce recorded for the order. It uses a session-based last-click model and does not prove that a source or campaign caused a sale.

## Direct

Display `Direct` only for explicit A.1 direct evidence.

Uncovered data uses “No usable acquisition evidence”, never Direct.

## Unknown

- `covered_unclassified` → “Observed but unclassified”;
- valid unknown member → safe “Unknown recorded source”;
- overflow → “Other values beyond reporting limit”;
- malformed/conflict → uncovered state, not raw label.

## Revenue

Use “Revenue associated with …”, not “Revenue from …”, where causality could be inferred.

## Comparison

State percentage unavailable when prior value is zero.

Do not render infinity or 100% by invention.

## Locale

Money and dates follow final B.3 locale/currency/timezone contract.

No float is money authority.
