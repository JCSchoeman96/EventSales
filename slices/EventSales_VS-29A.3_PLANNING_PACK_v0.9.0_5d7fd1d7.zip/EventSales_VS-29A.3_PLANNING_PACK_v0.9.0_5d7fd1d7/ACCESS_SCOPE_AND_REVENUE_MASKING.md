# Access, Scope and Revenue Masking

## Authorization order

1. Resolve current database actor.
2. Parse bounded scope/filter shapes without fetching report data.
3. Resolve final C capability and represented event ids from Postgres.
4. Authorize before event existence/details are revealed.
5. Determine reportable lifecycle eligibility.
6. Determine revenue visibility for the exact represented event set.
7. Select tickets-only or revenue reader request.
8. Build allowlisted DTO.
9. Render.

## Capabilities

Planning direction:

- acquisition reporting is part of the existing `view_assigned_event_decisions` capability;
- no raw role checks in LiveView/templates;
- no new self-registration or portal broadening;
- optional `export_acquisition_aggregates` remains global-admin-only in v1.

Activation refreshes exact final capability names.

## Global admin

May read all certified reportable events and acquisition revenue.

Operational admin links remain outside the decision DTO.

## Management/marketing

May read only active, unexpired, eligible assigned events.

Global staff has no automatic event scope.

## Multi-event revenue

Revenue may be requested only when every represented event is revenue-visible to the actor.

Do not:

- sum the visible subset and label it total;
- expose per-event revenue flags;
- fetch hidden event revenue then discard it in the template.

If mixed visibility:

- tickets remain available;
- revenue metric unavailable;
- generic explanation;
- optional later explicit partition requires a separate reviewed contract.

## Event revenue

Use final C management/marketing visibility flags and expiry.

Missing/expired setting hides revenue.

## Data minimisation

Tickets-only reads must not retrieve revenue columns from A.2 where the final reader supports metric-selective queries.

The DTO builder has a second fail-closed recursive revenue scrub/assertion.

## Revocation

On access/revenue change:

- immediately clear report, chart and export assigns;
- reauthorize from Postgres;
- unsubscribe invalid topics;
- rerender tickets-only or redirect generically;
- heartbeat bound inherited from C, planning maximum 60 seconds.

## Exports

Portal and event-scoped profiles have no acquisition export capability in v1.

Admin export endpoints reauthorize independently; a UI button is not authority.
