# Admin Aggregate Export Contract

## Status

Optional Pack 19 child stage.

Blocked until final VS-28B aggregate export artifact framework is certified.

## Capability

Global admin only in v1.

Portal management/marketing export remains denied even if revenue visible.

## Artifact type

Candidate:

```text
acquisition_decision_export
```

## Input

Exact validated report state:

- scope/event ids;
- source/currency;
- B.1 window/comparison;
- one `as_of`;
- metric;
- dimension;
- optional member;
- complete/full-page versus top-N mode;
- version tuple.

## Data source

Final A.2 reader/export facade only.

No raw Sales, projection table, A.1 snapshot or Woo source query from the export worker.

## Formats

- CSV;
- XLSX where final B15 framework supports it.

## Content

### Metadata

- source model and disclaimer;
- generated/requested times;
- `as_of`;
- scope/window/timezone/currency;
- metric/dimension;
- all versions;
- completeness/coverage/freshness/parity;
- covered/uncovered totals;
- full/top-N/truncated status;
- filter hash;
- artifact hash.

### Rows

- safe dimension label/sentinel;
- selected metric gross/reversal/net;
- gross share;
- comparison;
- optional bounded period points.

No order ids/numbers, customer data, raw acquisition snapshots, URLs or click ids.

## Revenue

Admin is authorized, but export service still resolves capability independently.

A future role export cannot be inferred from this artifact type.

## Parity

Do not generate/download a decision export when parity is mismatch/version incompatible.

Updating/partial coverage may export only if clearly labelled and product law permits; planning default is fail closed for mismatch and allow disclosed partial coverage.

## Top-N

Export request explicitly chooses:

- same top-N plus exact Other; or
- bounded full dimension page/artifact.

Never silently export only visible UI rows.

## Spreadsheet safety

Apply final B15 formula-injection protection to all text cells, including campaign/source labels.

## Audit

Audit safe filter hash, actor, scope ids, metric/dimension, artifact id/hash, rows and state.

No raw label values in audit metadata.
