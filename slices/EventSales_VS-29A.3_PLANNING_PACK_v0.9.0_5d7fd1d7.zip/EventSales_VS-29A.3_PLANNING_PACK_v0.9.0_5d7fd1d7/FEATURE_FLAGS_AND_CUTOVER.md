# Feature Flags and Cutover

## Candidate flags

- acquisition report facade enabled;
- admin acquisition tab enabled;
- portal acquisition tab enabled;
- acquisition live updates enabled;
- admin aggregate export enabled;
- legacy compatibility fallback disabled/enabled only for sales, never acquisition;
- chart hook enabled.

Defaults off until the relevant child stage is certified.

## Sequencing

```text
A.2 certified
→ report facade/DTO tests
→ admin tab hidden
→ admin canary
→ portal management ticket-only canary
→ management revenue-visible canary
→ marketing ticket-only canary
→ marketing revenue-visible canary where configured
→ optional admin export canary
→ broader enablement
```

## No raw fallback

Feature flag rollback hides acquisition view.

It does not switch to raw Sales, A.1 or A.2 table queries.

## Existing routes

Do not alter existing sales view semantics during canary.

`view=acquisition` disabled returns safe not-available or redirects to sales view.

## Portal

Portal flag can disable acquisition without disabling portal sales access.

## Exports

Export flag independent from report display.

## Kill switch

Disable new report loads and unsubscribe acquisition topics.

Clear acquisition assigns on open sockets through normal reload/navigation.

## Version cutover

When A.2 policy/classification version changes:

- shadow new version;
- compare/report certification;
- switch active version explicitly;
- no mixed-version page;
- old shareable URLs normalize to active version unless an admin historical-version view is separately approved.
