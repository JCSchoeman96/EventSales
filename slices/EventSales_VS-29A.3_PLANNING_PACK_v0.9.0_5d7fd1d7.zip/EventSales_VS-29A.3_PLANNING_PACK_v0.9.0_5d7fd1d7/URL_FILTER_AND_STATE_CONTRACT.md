# URL Filter and State Contract

## Reuse B.3

B.3 remains authority for:

- reportable/assigned event scope;
- lifecycle;
- source/currency;
- time preset/custom range;
- comparison;
- `as_of` capture;
- points/resolution limits.

A.3 extends, never duplicates, the typed filter parser.

## Candidate acquisition parameters

| Parameter | Allowed |
|---|---|
| `view` | `sales`, `acquisition` |
| `metric` | `tickets`, `revenue` |
| `dimension` | `coverage`, `origin`, `source`, `source_medium`, `campaign`, `device` |
| `member` | one opaque dimension-member UUID |
| `top` | `10`, `20`, `50`, maximum `100` |
| `sort` | `value_desc`, `value_asc`, `label_asc`, `label_desc` |
| `page` or cursor | bounded stable dimension list only |

Only dimensions activated by the exact A.2 policy are accepted.

## Defaults

Planning defaults:

```text
view=acquisition
metric=tickets
dimension=coverage
top=20
sort=value_desc
```

Revenue may become the default only for an actor whose exact represented event set is fully revenue-visible.

## Revenue URL

For an unauthorized actor requesting `metric=revenue`:

- do not call the revenue reader;
- normalize to `metric=tickets` and replace the URL, or return a generic unavailable state;
- do not reveal which event flag caused denial.

## Member validation

`member` must belong to the selected source, version and dimension.

An unknown member returns a generic invalid filter state without exposing hidden dimension values.

## Scope changes

Changing lifecycle/event/source/currency/window/dimension:

- resets dimension pagination;
- reconciles PubSub subscriptions;
- captures a new `as_of`;
- rereads durable state.

## Bounds

Invalid/excessive values:

- normalize to safe defaults when unambiguous;
- otherwise render one explicit bounded-error state;
- never pass raw values to logs, telemetry or SQL fragments.

## Shareable state

Filters are shareable only within the recipient's authorization scope.

A copied assigned-event URL cannot widen another actor's scope.
