# EventSales VS-27B.1 Planning Pack

## Identity

- Slice: `VS-27B.1`
- Name: Event Sales Metric and Time-Window Contract
- Version: `0.9.0`
- Status: `planning_review_ready`
- Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`
- Content-equivalent prior baseline: `daa87a8a1693e399c8effeb23297efad159397fd`
- GitHub scope: `#124`
- Linear parent: `JC-179`
- Pack: `JC-180`
- Pack review: `JC-181`
- Agent plan: `JC-182`
- Plan review: `JC-183`
- Activation: `JC-184`
- Implementation: `JC-185`

## Authority

This ZIP authorises repository reconnaissance and implementation planning only.

It does not authorise:

- code changes;
- migrations;
- source calls;
- metric changes in production;
- bucket-table creation;
- dashboard redesign;
- merge or deployment.

Implementation requires:

1. independent pack approval;
2. independent plan approval;
3. VS-26G production certification and `JC-178` closeout;
4. VS-26F.2 certification and `JC-167` closeout;
5. exact-current-main activation supplement from `JC-184`;
6. `JC-184` verdict `APPROVE`.

## Outcome

Define one versioned contract for:

```text
metric eligibility
+ reporting timestamps
+ half-open windows
+ previous-period comparisons
+ currency
+ completeness
+ status units
+ refund/correction treatment
```

VS-27B.2 must implement durable buckets from this contract. VS-27B.3 must only present contract outputs.

## Baseline incident note

An accidental one-line root placeholder was created on `main` and immediately removed.

Commits:

- `bbff8a1b51175aec398d7a5e0607cbf6ceceebbd`
- `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

GitHub reports zero net changed files between `daa87a8a1693e399c8effeb23297efad159397fd` and `5d7fd1d79cc156f9e7df7fc71e796413a813d035`.

`JC-184` must still verify whether either direct-main commit triggered Railway deployment.
