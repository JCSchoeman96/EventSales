# Reporting Timestamp Axes

A single timestamp must never serve all purposes.

## 1. Sale occurrence

Used for:

- ticket/revenue windows;
- hourly/daily sale buckets;
- sale-period comparisons;
- product/ticket-type performance.

Recommended precedence, subject to approved source evidence:

```text
authoritative Woo paid timestamp
-> authoritative Woo completed timestamp fallback
-> unwindowed anomaly
```

Recommended durable fields:

- `paid_at_source`;
- `sale_occurred_at`;
- `sale_timestamp_basis` = `paid` or `completed_fallback`;
- source/contract version.

Do not silently rename current `completed_at`.

## 2. Source freshness/change

Used for:

- F.2 source freshness;
- catch-up lag;
- latest source mutation;
- stale banner.

Authority is the certified F.2 committed source cursor/watermark, not the latest sale.

`Order.updated_at_source` may describe one order mutation but is not the source-wide check watermark.

## 3. Status/refund activity

Used for:

- transition/activity windows;
- failed/cancelled/refunded activity;
- operational trends.

Requires a durable occurrence fact/time.

The current mutable order status plus `updated_at_source` cannot reconstruct historical transitions after later updates.

## 4. Read-model freshness

Used for:

- aggregate refresh state;
- cache lifecycle;
- bucket build status.

This is separate from source freshness and sale time.

## 5. As-of

Every calculation captures one `as_of` instant.

All current and comparison windows derive from the same `as_of`.

Historical as-of replay is not part of v1 unless a later contract adds immutable bitemporal facts.
