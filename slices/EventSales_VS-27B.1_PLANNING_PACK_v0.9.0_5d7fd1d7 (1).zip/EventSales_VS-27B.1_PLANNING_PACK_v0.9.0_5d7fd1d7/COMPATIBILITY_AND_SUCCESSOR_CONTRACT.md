# Compatibility and Successor Contract

## Existing MetricRules

Current dashboard behaviour must not silently change merely because the new contract module is deployed.

The plan must choose and test one compatibility path:

1. keep `MetricRules` v1 as a compatibility adapter while introducing a versioned contract; or
2. evolve `MetricRules` behind explicit versioned functions and preserve existing callers until B.2/B.3 migrate.

No caller may privately reproduce the new rules.

## Existing snapshots

`EventAggregateSnapshot` and `DailySalesAggregateSnapshot` are version-1 compatibility read models.

Do not assume they are the final B.2 schema.

Known issues:

- event snapshot mixes lifetime and today;
- daily snapshot repeats total/today concepts;
- one event/day row cannot serve intraday windows;
- refresh reads all event rows;
- status map unit is ambiguous;
- source watermark is not F.2 source freshness.

B.1 should document/deprecate fields or version adapters, not create B.2 buckets.

## Current dashboard/event detail

B.1 does not redesign UI.

It must provide a migration map for B.3:

- `total_sold` -> `tickets_sold`;
- `total_revenue` -> `revenue`;
- `today_*` -> explicit `today_to_now`;
- `status_breakdown` -> explicit order and ticket status units;
- current `refreshed_at` -> read-model freshness only;
- source freshness -> F.2 metadata.

## VS-27B.2 handoff

B.2 receives:

- metric contract version;
- contribution interface;
- exact bucket time alignment;
- correction/rebuild semantics;
- currency key;
- event/ticket dimension keys;
- completeness propagation;
- maximum points/ranges;
- parity truth tables.

B.2 may choose physical schema/indexes but may not change business meaning.

## VS-27B.3 handoff

B.3 receives:

- bounded read facade;
- public metric names;
- window presets;
- comparison states;
- completeness/freshness labels;
- no-PII results;
- explicit current/past/all event scope.

B.3 must not fallback to raw sales scans when a bucket is missing.
