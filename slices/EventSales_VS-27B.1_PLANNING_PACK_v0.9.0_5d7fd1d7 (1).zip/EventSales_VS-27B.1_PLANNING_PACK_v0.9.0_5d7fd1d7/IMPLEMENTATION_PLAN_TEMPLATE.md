# VS-27B.1 Implementation Plan

## 1. Baseline proof and incident drift
## 2. Files inspected
## 3. Certified VS-26G semantic inputs
## 4. Certified VS-26F.2 freshness inputs
## 5. Woo timestamp evidence
## 6. Current metric/snapshot inconsistencies
## 7. Contract module and version
## 8. Canonical contribution model
## 9. Ticket and revenue definitions
## 10. Refund/cancellation correction
## 11. Sale/freshness/activity/read-model timestamps
## 12. Paid/completed precedence and anomaly handling
## 13. Half-open window constructors
## 14. Presets and custom bounds
## 15. Previous-equivalent comparisons
## 16. Status units and activity facts
## 17. All-event/mixed-event scope
## 18. Currency
## 19. Completeness metadata
## 20. MetricRules compatibility
## 21. Snapshot compatibility/deprecation
## 22. Minimal schema/migration requirements
## 23. Tests-first sequence
## 24. Exact files create/modify/generated/forbidden
## 25. Verification commands
## 26. B.2 handoff
## 27. B.3 handoff
## 28. Rollout/kill switches
## 29. Production evidence
## 30. JC-184 activation inputs
## 31. Risks/stop conditions
## 32. Prohibited-actions statement
