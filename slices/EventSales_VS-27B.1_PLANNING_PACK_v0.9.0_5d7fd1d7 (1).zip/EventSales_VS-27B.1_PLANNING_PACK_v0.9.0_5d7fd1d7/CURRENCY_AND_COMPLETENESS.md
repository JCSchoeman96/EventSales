# Currency and Data Completeness Contract

## Currency

Every metric result declares currency.

Rules:

- never add two currencies;
- one-currency scope returns one result;
- multi-currency scope returns grouped results or a bounded `mixed_currency` error;
- default currency is display fallback only, not proof of source currency;
- all current v1 production facts are expected to be ZAR, but activation verifies this.

## Completeness

Every result returns completeness metadata.

Recommended states:

- `unknown`;
- `observed_from`;
- `certified_from`;
- `complete_for_window`;
- `incomplete_for_window`;
- `blocked_by_semantics`;
- `blocked_by_source_gap`.

Recommended fields:

- source system id;
- event scope;
- observed/certified boundary;
- requested window;
- missing interval;
- semantics policy version;
- catch-up watermark;
- backfill certification id when available.

## Rules

- A source can be fresh but historically incomplete.
- A cache can be fresh while source data is stale.
- A current window can be complete even if lifetime history is not.
- Targets/pacing may not run on incomplete required history.
- UI labels must distinguish `observed` from `certified`.
- No lifetime claim from current Railway rows before approved backfill certification.
