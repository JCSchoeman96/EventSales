# Time-Window Contract

## Universal rules

- All persisted/query windows are half-open: `[start_utc, end_utc)`.
- `end_utc > start_utc`.
- `as_of` is captured once.
- V1 business timezone is the configured `Africa/Johannesburg`.
- Window metadata returns local labels and UTC boundaries.
- No arbitrary per-user timezone in v1.
- End boundaries are exclusive.
- Facts exactly on `start_utc` are included.
- Facts exactly on `end_utc` are excluded.

## Rolling intraday windows

- `last_15_minutes`: `[as_of - 15m, as_of)`
- `last_30_minutes`: `[as_of - 30m, as_of)`
- `last_60_minutes`: `[as_of - 60m, as_of)`

These are elapsed-duration windows, not clock-hour buckets.

## Business calendar windows

### Today to now

Local business-day midnight through `as_of`.

### Yesterday

Previous local business day, midnight to midnight.

### Rolling seven days

Explicit exact 168-hour window:

```text
[as_of - 168h, as_of)
```

A seven-business-date view, if later required, uses a different public name.

## Lifetime/observed

There is no unqualified `lifetime` result unless completeness is certified.

Return one of:

- `certified_lifetime`;
- `observed_to_date`;
- `partial_from`.

Completed rows without canonical sale timestamps appear as anomalies, not hidden additions to lifetime totals.

## Custom range

Planning bounds:

- maximum 366 business days;
- hourly resolution only for spans <= 31 days;
- daily resolution for longer spans;
- maximum 744 hourly points;
- maximum 366 daily points;
- maximum selected event scope 100;
- end exclusive;
- one configured business timezone;
- comparison must satisfy the same bounds.

The implementation plan may tighten these based on query evidence. It may not broaden them without review.

## Invalid windows

Reject:

- reversed/zero ranges;
- future end beyond permitted tolerance;
- spans over maximum;
- unsupported timezone;
- excessive event/dimension cardinality;
- mixed unsupported resolution;
- incomplete required metadata.
