# Implementation Agent Prompt Template — VS-27B.1

**Do not use until JC-184 returns APPROVE.**

Activation fills:

- exact main SHA;
- certified VS-26G contract/version;
- certified F.2 freshness interface;
- approved Woo timestamp evidence;
- final metric/window/comparison names;
- exact compatibility strategy;
- exact files/migrations/tests;
- exact B.2/B.3 handoff;
- rollout and stop conditions.

Write tests first. Implement only the activated contract and any explicitly approved source timestamp fields. Open a PR and stop before merge/deployment.

Do not create hourly/daily bucket tables or redesign dashboards.
