# Predecessor Contracts — VS-27B.1

## VS-26G

Certified VS-26G owns:

- semantic kinds;
- ticket entitlement quantity;
- tax/net/gross fields;
- fee identity and attribution;
- refund identity/allocation;
- historical semantic compatibility;
- unknown fail-closed behaviour.

B.1 consumes those fields and policy versions. It does not redefine them.

## VS-26F.2

Certified F.2 owns:

- source catch-up freshness;
- committed source watermark;
- queued/running/blocked state;
- source-stale threshold and live status.

B.1 references F.2 freshness metadata. It never derives source freshness from sale time or cache age.

## VS-27B.2

B.2 creates durable hourly/daily aggregates from B.1's contribution and window contracts.

B.2 may not invent metric rules.

## VS-27B.3

B.3 builds decision surfaces from B.2/read facades.

B.3 may not scan raw order rows or redefine metric labels.
