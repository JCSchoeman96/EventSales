# Current Code Metric Map

| Current area | Existing behaviour | Contract gap |
|---|---|---|
| `MetricRules` | completed + mapped ticket; revenue=`line_total` | no semantic-policy version, refunds, tax/fees, ranges |
| `MetricRules.summarize` | lifetime/today/status map | status counts item rows; no comparisons |
| business date | Johannesburg handled by fixed +2 hours | use reviewed timezone boundary helpers |
| completed missing timestamp | counts lifetime, not today | creates invisible bucket mismatch |
| `EventAggregator` | loads every item for one event | unbounded event-wide read |
| `SnapshotRefresh` | loads all event rows then filters | daily refresh is not date-bounded at DB |
| event snapshot | one mutable lifetime/today row | compatibility model, not final bucket |
| daily snapshot | total and today duplicated for day scope | ambiguous schema |
| `AdminDashboard` | max 50 current events | KPIs may mean displayed page, not all events |
| ticket-type breakdown | max 1,000 rows then in-memory aggregate | silent truncation risk |
| `EventDetail` | direct raw aggregate queries | bypasses future bucket facade |
| status context | MetricRules counts rows; EventDetail sums quantity | same label, different units |
| source watermark in snapshot | max local order `updated_at_source` | not F.2 source freshness |
| parser/order | `date_completed_gmt` only | no paid timestamp or basis |
| status history | current status only | no transition-time activity facts |
