# VS-27B.1 Acceptance Checklist

## Planning/activation
- [ ] Exact baseline recorded.
- [ ] Pack independently reviewed.
- [ ] Plan independently reviewed.
- [ ] VS-26G certified.
- [ ] VS-26F.2 certified.
- [ ] Woo paid/completed timestamp evidence approved.
- [ ] JC-184 approved.

## Contract
- [ ] Contract version.
- [ ] Explicit public metric names.
- [ ] VS-26G semantic-policy version.
- [ ] Ticket entitlement and money separated.
- [ ] Gross/refund/net ticket fields.
- [ ] Ancillary, fee and tax separate.
- [ ] Unknown semantics excluded.
- [ ] Missing timestamp anomaly.

## Time
- [ ] Sale occurrence axis.
- [ ] Source freshness axis.
- [ ] Status/refund activity axis.
- [ ] Read-model freshness axis.
- [ ] One `as_of`.
- [ ] Half-open UTC bounds.
- [ ] Johannesburg local boundaries.
- [ ] 15/30/60 minutes.
- [ ] Today/yesterday.
- [ ] Exact rolling 168 hours.
- [ ] Bounded custom ranges/resolution.
- [ ] Previous-equivalent windows.

## Comparison
- [ ] Equal duration.
- [ ] Non-overlap.
- [ ] Decimal delta/percentage.
- [ ] Zero denominator states.
- [ ] Completeness/currency comparability.

## Status
- [ ] Distinct orders by current status.
- [ ] Ticket quantity by current status.
- [ ] Diagnostic line counts separately named.
- [ ] Mixed-event order rules.
- [ ] Status activity requires durable facts.

## Scope/currency/completeness
- [ ] All-event scope explicit and complete.
- [ ] No page/row truncation.
- [ ] Event/dimension/point bounds.
- [ ] No N+1 all-event path.
- [ ] Currency never mixed.
- [ ] Observed versus certified history.
- [ ] Source fresh versus history complete distinguished.

## Compatibility
- [ ] MetricRules migration strategy.
- [ ] Existing snapshots documented/versioned.
- [ ] Current dashboards do not silently change.
- [ ] No bucket tables.
- [ ] B.2 handoff exact.
- [ ] B.3 handoff exact.

## Tests
- [ ] Ordinary ticket and all statuses.
- [ ] Semantic/refund/fee/tax fixtures.
- [ ] Timestamp precedence/fallback.
- [ ] Missing timestamp.
- [ ] Every boundary instant.
- [ ] Comparison states.
- [ ] Currency/completeness.
- [ ] Mixed-event/all-event.
- [ ] Raw-fact/contribution parity.
- [ ] Full CI.

## Production
- [ ] Contract version deployed.
- [ ] Existing totals compatibility verified.
- [ ] Timestamp fields verified.
- [ ] No bucket/UI rollout.
- [ ] Baseline incident deployment outcome recorded.
- [ ] Certification recorded.
