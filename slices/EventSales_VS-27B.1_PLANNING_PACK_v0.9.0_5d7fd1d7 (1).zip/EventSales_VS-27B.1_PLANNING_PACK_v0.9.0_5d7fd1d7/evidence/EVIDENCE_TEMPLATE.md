# VS-27B.1 Redacted Evidence

- Pack/plan/activation:
- PR/head/CI:
- Metric contract version:
- VS-26G policy version:
- VS-26F.2 freshness version:
- Source timestamp fixture hashes:

## Timestamp proof
- paid present:
- completed present:
- precedence:
- fallback:
- missing timestamp anomaly:
- status/refund occurrence:

## Metric truth table
| Case | Tickets | Revenue | Status unit | Result |
|---|---:|---:|---|---|

## Window proof
- as_of:
- timezone:
- 15/30/60:
- today:
- yesterday:
- rolling 7d:
- custom:
- boundary exactness:

## Comparison proof
- equal duration:
- non-overlap:
- zero denominator:
- incomplete/currency states:

## Scope proof
- events included:
- rows represented:
- no page truncation:
- mixed-event order:
- currency:
- completeness:

## Compatibility
- current totals before:
- current totals after:
- snapshot v1 behaviour:
- B.2 tables created: no
- dashboard redesigned: no

## Baseline incident
- Railway deployment triggered:
- deployed SHA:
- material effect:

Verdict: CERTIFIED / CERTIFIED WITH ACCEPTED RISK / REJECTED
