# Scope and Query Bounds

## Event scope

Every query declares one:

- explicit event ids;
- current public events;
- past events;
- one event;
- approved all-event scope.

`All events` means every event in the selected scope, not the current UI page.

Planning maximum selected events: 100.

## Dimensional bounds

Planning defaults:

- ticket types returned: 500 maximum;
- time points: 744 hourly or 366 daily;
- currencies: grouped, never combined;
- comparison: exactly one previous period;
- no arbitrary metadata dimensions;
- no customer/order-level rows in metric response;
- no N+1 event query path.

## Performance targets

- approximately 10,000 tickets over several weeks;
- fifty concurrent dashboard viewers;
- no raw-order scans from LiveView;
- no per-event loop of raw aggregates for all-event view;
- representative `EXPLAIN` evidence for B.2 indexes;
- result payload bounded and paginated where dimensional lists exceed limits.

## Truncation

A metric result may never silently truncate.

Return explicit:

- complete;
- truncated and unusable for headline totals;
- cardinality exceeded;
- narrower scope required.

UI must not present truncated results as totals.
