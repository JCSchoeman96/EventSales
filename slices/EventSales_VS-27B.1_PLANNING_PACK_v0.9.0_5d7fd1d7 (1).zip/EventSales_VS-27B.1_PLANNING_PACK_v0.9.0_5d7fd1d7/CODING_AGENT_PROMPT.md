# Planning Agent Prompt — VS-27B.1

Repository: `JCSchoeman96/EventSales`
Pack: `EventSales_VS-27B.1_PLANNING_PACK_v0.9.0_5d7fd1d7.zip`
Planning baseline: `5d7fd1d79cc156f9e7df7fc71e796413a813d035`

## Authorised phase

Repository reconnaissance and implementation planning only.

Do not modify files, commit, open/merge a PR, run migrations, call source systems, change production metrics, create bucket tables or redesign dashboards.

## Baseline proof

```bash
git status --short
git rev-parse HEAD
git fetch origin
git rev-parse origin/main
bash scripts/sync_with_origin_main.sh --check
```

Inspect the two baseline incident commits and record any deployment impact known at activation.

## Mandatory reading

Read every path in `FILE_INVENTORY.md`.

Inspect certified VS-26G and VS-26F.2 artifacts. If unavailable, mark dependent fields/policies unresolved for `JC-184`.

## Required decisions

1. exact contract module/version;
2. exact public metric names;
3. VS-26G contribution fields;
4. paid/completed timestamp evidence and precedence;
5. missing sale timestamp anomaly;
6. sale/freshness/status/read-model axes;
7. half-open window constructors;
8. today/yesterday/rolling/custom boundaries;
9. custom range and resolution limits;
10. previous-equivalent comparison rules;
11. refund/cancellation original-bucket correction;
12. current-status versus activity facts;
13. distinct-order versus ticket-quantity units;
14. mixed-event order counting;
15. currency grouping/error;
16. completeness metadata;
17. compatibility with MetricRules/snapshots/callers;
18. whether minimal source timestamp schema is required;
19. tests-first sequence;
20. exact files/migrations/indexes;
21. B.2/B.3 handoff;
22. rollout and production evidence;
23. `JC-184` activation inputs.

## Required output

Complete `IMPLEMENTATION_PLAN_TEMPLATE.md`.

Finish with:

- `PACK VALID`;
- `PACK REFRESH RECOMMENDED`; or
- `PACK BLOCKED`.

Confirm no prohibited action occurred.
