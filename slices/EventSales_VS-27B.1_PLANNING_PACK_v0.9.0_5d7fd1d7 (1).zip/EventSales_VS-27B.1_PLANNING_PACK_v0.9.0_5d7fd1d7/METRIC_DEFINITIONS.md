# Canonical Metric Definitions

All names are planning names. Activation locks exact public names after certified VS-26G fields are known.

## Headline ticket metrics

### `gross_completed_ticket_entitlement`

Sum certified ticket-entitlement quantity for eligible completed sale facts whose canonical sale timestamp falls in the window, before explicit refunded/revoked quantity.

### `ticket_entitlement_reversed`

Sum explicit certified refunded/revoked ticket quantity tied to those original sale facts.

A monetary amount alone cannot create this quantity.

### `tickets_sold`

```text
gross_completed_ticket_entitlement
- ticket_entitlement_reversed
```

This is the default management ticket figure.

It is current net entitlement attributed to the original sale window.

## Headline ticket revenue

### `gross_completed_ticket_revenue`

Certified tax-inclusive ticket revenue for eligible completed sale facts in the window, before allocated ticket refunds.

### `ticket_refund_amount`

Certified ticket-line refund amount allocated under VS-26G and attributed back to the original sale window for current net truth.

### `revenue`

```text
gross_completed_ticket_revenue
- ticket_refund_amount
```

This is the default management revenue figure.

It is tax-inclusive net recognised ticket revenue.

## Separate monetary fields

Never silently fold these into headline ticket revenue:

- ancillary/add-on revenue;
- order-level or event-attributed fees;
- tax component;
- membership/subscription revenue;
- unallocated refund amount;
- unsupported shipping/rounding components.

## Operational anomalies

Return explicit counts/amounts for:

- completed facts with no usable sale timestamp;
- unknown semantic lines;
- unresolved currency;
- unallocated refunds;
- unallocated fees;
- completeness gaps.

These do not contribute to headline metrics.

## Product/ticket type

Group by stable ids.

Every dimension uses the same:

- semantic eligibility;
- order-status eligibility;
- sale timestamp;
- refund/correction policy;
- currency;
- completeness metadata.

## Money

- Decimal only.
- Preserve source precision.
- Round only for presentation/export under a separate display rule.
- Never sum different currencies.
