# Independent Reviewer Prompt — VS-27B.1

Block any design that:

- starts with bucket tables instead of metric meaning;
- counts unknown VS-26G semantics;
- silently treats `completed_at` as paid time;
- uses sale time for source freshness;
- uses cache freshness as source freshness;
- defines windows other than half-open;
- captures different `as_of` values for current/previous;
- labels item-row count as orders or tickets;
- counts a mixed-event order twice in all-event distinct-order totals;
- silently truncates event, row or dimension totals;
- sums currencies;
- hides incomplete historical coverage;
- includes completed rows with no sale timestamp in buckets;
- treats refund amount alone as ticket revocation;
- attributes refund only to refund time and leaves original net bucket unchanged;
- changes current dashboards without compatibility evidence;
- allows B.2/B.3 to redefine rules;
- adds acquisition, targets, access or dashboard scope.

Classify blocker, major and minor.

Verdict:

- APPROVE;
- REQUEST CHANGES;
- BLOCKED.

Approval authorises planning only. JC-184 controls implementation.
