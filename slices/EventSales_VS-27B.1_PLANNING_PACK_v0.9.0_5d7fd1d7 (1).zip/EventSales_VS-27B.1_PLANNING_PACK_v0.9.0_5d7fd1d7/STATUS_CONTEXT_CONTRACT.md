# Status Context Contract

The label `status_breakdown` is forbidden for new public contracts because current code uses inconsistent units.

## Point-in-time current status

### `distinct_orders_by_current_status`

Distinct Woo orders in the selected event/source scope, grouped by current order status.

- All-event mixed-event order counts once.
- Per-event mixed-event order counts once in each relevant event.
- It is point-in-time context, not a sale-window metric.

### `ticket_quantity_by_current_status`

Current certified ticket-entitlement quantity grouped by current order status.

This is a quantity, not a count of lines or orders.

### `order_line_count_by_current_status`

Optional diagnostic only.

Never label it as orders or tickets.

## Status activity

Time-windowed status activity requires durable transition facts:

- transition id;
- order/source identity;
- from/to status;
- occurred_at_source;
- source version;
- event scope derivation;
- idempotency.

Without those facts, the system may show current status only and must not claim historical status-transition trends.

## Required statuses

At minimum:

- pending;
- processing;
- on_hold;
- completed;
- failed;
- cancelled;
- refunded.

Unknown source statuses fail closed and remain operationally visible.
