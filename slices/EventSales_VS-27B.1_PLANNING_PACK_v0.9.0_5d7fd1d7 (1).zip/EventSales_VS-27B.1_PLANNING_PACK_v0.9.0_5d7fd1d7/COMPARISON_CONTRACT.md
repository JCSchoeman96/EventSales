# Previous-Equivalent-Period Contract

## General

Current and previous windows:

- have equal duration;
- never overlap;
- share timezone and scope;
- use the same metric/semantic versions;
- carry separate completeness metadata.

## Rolling/custom

Previous window is immediately before current:

```text
previous_end = current_start
previous_start = previous_end - current_duration
```

## Today to now

Previous equivalent is the previous business day from local midnight to the same elapsed local time.

It is not the whole previous day.

## Yesterday

Previous equivalent is the full business day before yesterday.

## Comparison result

Return:

- current value;
- previous value;
- absolute delta;
- comparison state;
- percentage change only when defined.

States:

- `comparable`;
- `flat_zero` when both are zero;
- `new_activity` when previous is zero and current positive;
- `not_comparable_incomplete`;
- `not_comparable_currency`;
- `not_comparable_missing`.

No infinity, NaN or fabricated 100% value.

Percentage arithmetic uses Decimal.
