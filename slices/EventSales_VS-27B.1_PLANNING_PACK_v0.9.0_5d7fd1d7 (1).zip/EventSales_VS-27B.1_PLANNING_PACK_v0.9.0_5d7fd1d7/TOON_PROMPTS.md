# TOON Prompts — VS-27B.1

## Planning agent
Task: Design the versioned metric and time-window contract from current code.
Output: Complete implementation plan.
Boundary: No code or bucket/UI work.

## Metric reviewer
Task: Attack ticket, revenue, refund, fee and status units.
Output: Truth-table findings.
Boundary: Unknown fails closed.

## Time reviewer
Task: Attack timestamps, half-open boundaries, timezone and comparisons.
Output: Boundary findings/tests.
Boundary: One `as_of`.

## Completeness reviewer
Task: Attack all-event scope, currency and partial-history claims.
Output: Findings.
Boundary: No silent truncation.

## Compatibility reviewer
Task: Attack MetricRules/snapshot/caller migration.
Output: Compatibility verdict.
Boundary: No silent production metric change.

## Activation reviewer
Task: Refresh main plus certified G/F.2 inputs and source timestamps.
Output: APPROVE / REFRESH REQUIRED / BLOCKED.
