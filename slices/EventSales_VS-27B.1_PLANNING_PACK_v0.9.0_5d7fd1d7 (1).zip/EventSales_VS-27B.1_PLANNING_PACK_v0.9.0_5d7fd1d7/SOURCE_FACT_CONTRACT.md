# Canonical Metric Contribution Contract

The same pure contribution contract must drive:

- raw-fact tests;
- compatibility calculations;
- VS-27B.2 bucket writes/rebuilds;
- VS-27B.3 read results.

## Sale contribution

Candidate fields:

- stable contribution id/version;
- source system id;
- order id/Woo id;
- order item id/Woo line id;
- event id;
- ticket type id;
- currency;
- semantic policy version;
- metric contract version;
- sale occurred at;
- sale timestamp basis;
- gross ticket entitlement quantity;
- reversed entitlement quantity;
- net ticket quantity;
- gross ticket revenue;
- ticket refund amount;
- net ticket revenue;
- ancillary revenue;
- fee amount;
- tax amount;
- anomaly flags.

## Activity contribution

Candidate fields:

- stable activity id/type;
- order/event scope;
- occurred_at;
- status/refund type;
- distinct-order identity;
- ticket quantity;
- monetary amount;
- source version.

## Properties

- deterministic;
- Decimal money;
- idempotent under replay;
- stale-source guarded;
- no customer PII;
- no label-based identity;
- unknown semantics contribute zero;
- correction produces exact affected bucket identities;
- raw contribution sum equals bucket contribution sum.

The implementation plan decides whether contributions are persisted facts or pure projections from certified Sales resources. B.2 must receive a stable interface either way.
