# Rollout and Stop Conditions

## Rollout

1. Deploy pure contract/tests and optional approved timestamp fields without changing dashboard labels.
2. Verify migrations and parser compatibility.
3. Re-ingest a bounded redacted/staging fixture set.
4. Compare old MetricRules compatibility outputs.
5. Verify new contract truth tables and boundaries.
6. Record rows lacking canonical sale timestamps.
7. Keep B.2 bucket creation disabled/not present.
8. Keep B.3 dashboard migration absent.
9. Certify contract and unlock B.2.

## Kill switches

- new contract caller disabled;
- paid timestamp precedence fallback to compatibility path;
- compatibility adapter retained;
- no B.2/B.3 activation.

## Stop immediately

- current dashboard totals change unintentionally;
- paid/completed meaning is unproven;
- unknown semantics contribute;
- currencies are summed;
- incomplete history appears certified;
- page/row truncation appears as total;
- status unit remains ambiguous;
- bucket/UI scope enters the PR;
- baseline incident deployment state is unknown where material;
- PII or source secrets enter fixtures/evidence.
