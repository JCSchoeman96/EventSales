# Metric Contract Validation Runbook

## Pure truth-table validation

Run the same fixtures through:

1. raw certified fact projection;
2. canonical contribution function;
3. compatibility MetricRules adapter where applicable;
4. future in-memory bucket reducer test double.

Assert exact parity.

## Boundary validation

For every window test facts at:

- one microsecond before start;
- exactly start;
- one microsecond before end;
- exactly end.

## Comparison validation

Test:

- positive/negative/zero deltas;
- previous zero/current positive;
- both zero;
- incomplete previous period;
- currency mismatch;
- today elapsed-time comparison.

## Scope validation

Test:

- one event;
- 100 events;
- mixed-event order;
- more than current UI page size;
- more than 1,000 source rows;
- multi-currency result;
- incomplete history.

No test may rely on float equality.
