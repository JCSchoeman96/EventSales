# Failure Matrix

| Failure | Safe result | Recovery |
|---|---|---|
| VS-26G version unknown | contract blocked | certify predecessor |
| paid timestamp ambiguous | no paid precedence | approve fallback/evidence |
| no sale timestamp | unwindowed anomaly | source repair/re-ingest |
| unknown semantic | zero contribution | semantics review |
| mixed currency | grouped/error | narrower scope |
| incomplete history | observed/incomplete label | backfill certification |
| status history absent | current status only | add durable transition facts |
| refund allocation absent | no net refund adjustment | VS-26G review |
| page/row limit reached | explicit incomplete error | aggregate/narrow scope |
| comparison previous incomplete | not comparable | complete data |
| contract version drift | reject parity/apply | rebuild/review |
| snapshot v1 mismatch | compatibility output only | B.2 migration |
| cache/PubSub failure | durable metrics unchanged | reload/rebuild |
