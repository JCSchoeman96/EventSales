# Source Timestamp Evidence Runbook

1. Record WooCommerce and relevant plugin versions.
2. Select redacted structural fixtures for:
   - pending/on-hold;
   - paid/processing;
   - completed;
   - failed/cancelled;
   - full/partial refund.
3. Preserve only:
   - order pseudonym;
   - status;
   - `date_created_gmt`;
   - `date_modified_gmt`;
   - `date_paid_gmt`;
   - `date_completed_gmt`;
   - parent/refund structural ids where approved;
   - timestamp sequence.
4. Remove all customer, address, transaction, token and credential values.
5. Determine:
   - whether `date_paid_gmt` is present and stable;
   - whether completed can lack paid;
   - whether paid/completed can differ;
   - timezone/precision;
   - refund/status occurrence evidence.
6. Hash redacted fixtures.
7. Activation reviewer approves precedence or blocks implementation.

Do not query production merely to manufacture a missing edge case. Record absence.
