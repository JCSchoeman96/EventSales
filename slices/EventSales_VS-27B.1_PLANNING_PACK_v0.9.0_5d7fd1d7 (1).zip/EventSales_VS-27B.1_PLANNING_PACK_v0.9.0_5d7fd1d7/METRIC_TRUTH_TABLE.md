# Metric Truth Table

| Order/line condition | Gross ticket qty | Net ticket qty | Gross ticket revenue | Net ticket revenue | Status context |
|---|---:|---:|---:|---:|---|
| completed ordinary reviewed ticket | entitlement | entitlement | reviewed gross | reviewed gross | completed |
| pending/processing/on-hold ticket | 0 | 0 | 0 | 0 | current status |
| failed/cancelled before completion | 0 | 0 | 0 | 0 | current/activity status |
| fully refunded reviewed ticket | original completed | 0 under certified full-refund rule | original gross | 0 | refunded |
| partial monetary refund, no quantity evidence | original completed | unchanged | original gross | minus allocated refund | refund activity |
| explicit quantity refund/revocation | original completed | minus certified quantity | original gross | policy allocation | refund/revocation activity |
| membership/renewal/subscription | 0 | 0 | 0 | 0 | visible |
| payment-plan instalment | 0 new entitlement by default | 0 | 0 until certified allocation | 0 until certified allocation | visible |
| add-on | 0 | 0 | 0 ticket revenue | separate ancillary if certified | visible |
| unknown/conflict | 0 | 0 | 0 | 0 | review/anomaly |
| completed but no sale timestamp | 0 in windows | 0 in windows | 0 in windows | 0 in windows | anomaly |

`gross completed` remains an auditable fact even when current net metrics are later reversed.
