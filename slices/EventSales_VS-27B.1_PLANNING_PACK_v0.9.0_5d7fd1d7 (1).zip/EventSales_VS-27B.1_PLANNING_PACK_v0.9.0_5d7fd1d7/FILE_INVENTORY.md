# Mandatory File Inventory — VS-27B.1

## Governance
- `AGENTS.md`
- `docs/agent/01_PROJECT_WIDE_RULES.md`
- `INDEX.md`
- `docs/feature_packs/EVENTSALES_FEATURE_PACK_STANDARD.md`
- `docs/roadmap/EVENTSALES_LIVE_SALES_PROGRAMME.md`
- `docs/roadmap/EVENTSALES_PRODUCT_DECISIONS.md`

## Predecessor evidence
- certified VS-26G pack/plan/activation/PR/certification;
- certified VS-26F.2 pack/plan/activation/PR/certification;
- approved redacted Woo timestamp/refund fixtures.

## Metric policy
- `lib/event_sales/analytics/metric_rules.ex`
- `lib/event_sales/sales/status_rules.ex`
- `lib/event_sales/sales/resources/order.ex`
- `lib/event_sales/sales/resources/order_item.ex`
- certified VS-26G semantic resources/policy.

## Parser/source timestamps
- `lib/event_sales/ingestion/parsers/woocommerce_order_parser.ex`
- `lib/event_sales/sales/order_upserter.ex`
- certified VS-26F.1 catch-up parser/upserter files.

## Existing aggregates/snapshots
- `lib/event_sales/analytics/aggregators/event_aggregator.ex`
- `lib/event_sales/analytics/aggregate_event.ex`
- `lib/event_sales/analytics/snapshot_refresh.ex`
- `lib/event_sales/analytics/snapshot_reader.ex`
- `lib/event_sales/analytics/snapshot_queries.ex`
- `lib/event_sales/analytics/resources/event_aggregate_snapshot.ex`
- `lib/event_sales/analytics/resources/daily_sales_aggregate_snapshot.ex`
- `lib/event_sales/analytics/hot_state_aggregator.ex`
- `lib/event_sales/analytics/dashboard_cache.ex`
- `lib/event_sales/analytics/workers/refresh_snapshot_worker.ex`
- `lib/event_sales/analytics/workers/rebuild_hot_state_worker.ex`
- `docs/architecture/historical-reporting-snapshots.md`

## Current read facades/UI
- `lib/event_sales/analytics/admin_dashboard.ex`
- `lib/event_sales/analytics/event_detail.ex`
- `lib/event_sales_web/live/admin/dashboard_live.ex`
- `lib/event_sales_web/live/admin/event_detail_live.ex`
- certified VS-26F.2 source-freshness/read files.

## Migrations/indexes
- `priv/repo/migrations/20260515124923_slice_4_sales.exs`
- `priv/repo/migrations/20260518062734_slice_9_7_historical_reporting_snapshots.exs`
- all later Sales/Analytics migrations from certified G/F.2.

## Tests
- `test/event_sales/analytics/metric_rules_test.exs`
- `test/event_sales/sales/status_rules_test.exs`
- `test/event_sales/analytics/event_aggregator_test.exs`
- `test/event_sales/analytics/historical_reporting_snapshots_test.exs`
- `test/event_sales/analytics/snapshot_boundaries_test.exs`
- `test/event_sales/analytics/admin_dashboard_test.exs`
- `test/event_sales/analytics/admin_dashboard_contract_test.exs`
- `test/event_sales/analytics/event_detail_test.exs`
- `test/event_sales_web/live/admin/dashboard_live_test.exs`
- `test/event_sales_web/live/admin/event_detail_live_test.exs`
- certified VS-26G/F.2 tests.
