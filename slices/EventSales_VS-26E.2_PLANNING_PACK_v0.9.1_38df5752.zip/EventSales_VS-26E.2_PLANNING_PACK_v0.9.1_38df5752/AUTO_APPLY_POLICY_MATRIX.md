# Auto-Apply Policy Matrix — Initial V1

Initial v1 auto-Apply is limited to additive, published, simple-product changes with complete persisted risk proof, supported snapshot and policy versions, zero findings and zero historical impact. One disallowed input makes the whole run ineligible; mixed plans are never partially auto-applied.

## Event actions

| Action | Initial v1 result |
|---|---|
| `create` | Candidate eligible only with complete published simple-source proof, supported versions, no findings and zero history. |
| `reuse` | Candidate eligible only with exact identity, exact event membership, no mutation and complete risk proof. |
| `update_metadata` | Manual. |
| `adopt_existing` | Manual. |
| unknown | Ineligible. |

## TicketType actions

| Action | Initial v1 result |
|---|---|
| `create` | Candidate eligible only with complete risk proof and zero history. |
| `reuse` | Candidate eligible only with exact identity and exact event membership. |
| `adopt_existing` | Manual. |
| unknown | Ineligible. |

## ProductMapping actions

| Action | Initial v1 result |
|---|---|
| `create` | Candidate eligible only with no conflict, movement, variation, findings or history. |
| `move` | Manual or rejected. |
| `update` | Manual or rejected. |
| `deactivate` | Manual or rejected. |
| `delete` | Manual or rejected. |
| unknown | Ineligible. |

The current Planner vocabulary contains only ProductMapping `create`. Any other observed ProductMapping action is unsupported and fails closed. Variations are always manual in initial v1.

## Findings

The initial v1 finding-code allowlist is empty. An automatically eligible run contains no persisted findings.

| Condition | Initial v1 result |
|---|---|
| any blocking finding | Ineligible. |
| any warning finding | Ineligible. |
| any info finding, including `duplicate_meta_collapsed` | Ineligible. |
| unknown severity or code | Ineligible. |
| missing finding metadata | Ineligible. |

`duplicate_meta_collapsed` may be reconsidered only after repository evidence and tests prove identical normalized identity, event membership, values, status, source-risk metadata and product semantics for every collapsed row.

## Persisted source risks

Every listed risk is manual or ineligible in initial v1: private/draft/trashed/deleted event; private/draft/trashed/deleted product; private/draft variation; variation mapping required; ambiguous variation name; subscription; payment plan; membership; bundle; add-on; unsupported product type; missing ticket template; unknown product semantics; duplicate ticket name; existing mapping conflict; product moved between events; ambiguous identity; and missing source-risk data.

Missing fields are not safe values. Missing, unknown or unsupported risk data must produce an explicit persisted ineligible reason. Product semantics must come from deterministic source fields and reviewed reason codes, never display-name inference.

## Historical impact

Initial v1 requires all of the following:

```text
affected_pending_lines = 0
affected_quantity = 0
eligible_lines = 0
deferred_lines = 0
conflicting_lines = 0
already_mapped_lines = 0
warnings = []
all destinations resolved
```

Missing totals, an unknown classification, unsupported order status, threshold parsing failure or unresolved destination is ineligible. Any affected historical order line makes the entire run manual. A later policy version may permit bounded history only after separate review and evidence.
