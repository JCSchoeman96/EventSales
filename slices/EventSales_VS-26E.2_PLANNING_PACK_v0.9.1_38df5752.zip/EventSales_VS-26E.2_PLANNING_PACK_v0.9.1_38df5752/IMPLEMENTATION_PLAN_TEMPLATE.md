# VS-26E.2 Implementation Plan

## Baseline and files inspected
## Current Normalizer/Planner/Applier truth
## VS-26E.1 dependency and explicit origin semantics
## Exact persisted source-risk propagation from feed parsing through hashed snapshot
## Pure policy interface, snapshot schema version and pinned policy version
## Full action matrix (`update_metadata` manual; variations manual)
## Closed empty initial finding-code allowlist
## Zero historical-impact rules and unknown/missing handling
## Durable decision/audit fields
## Dedicated decision resource versus justified run extension
## Database uniqueness for `(run_id, hash, policy_version)`
## Durable once-only enqueue key and recoverable decision/enqueue/linkage state machine
## Evaluator scheduling, bounded retries and indexed recovery
## Manual cancellation, Human Apply and stale-hash races
## Global/source mode composition and revalidation before enqueue and claim
## Observation mode
## Admin explanation, PubSub and bounded telemetry
## Migrations, constraints, indexes and bounded query shapes
## Tests-first sequence for every action/risk/history/version/origin/mode/race
## Exact files and forbidden areas
## Verification commands
## Rollout, kill switches and additional end-to-end canary evidence
## JC-129 activation inputs
## Risks and stop conditions
## Prohibited-actions statement

The plan must preserve the existing Applier as sole automated catalogue writer and keep Human Apply unchanged. No implementation begins before JC-129 APPROVE and JC-130 authorisation.
