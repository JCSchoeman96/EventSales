# VS-26E.2 Acceptance Checklist

## Gates and authority
- [ ] v0.9.1 independently re-reviewed at JC-126.
- [ ] JC-127 plan and JC-128 review complete.
- [ ] JC-129 activation supplement returns APPROVE.
- [ ] Execution authority remains false until JC-130.

## Initial-v1 policy
- [ ] Additive published simple-product scope only.
- [ ] `update_metadata`, adoption and every variation remain manual.
- [ ] Current ProductMapping vocabulary is only `create`; unknown actions fail closed.
- [ ] One disallowed action rejects the entire mixed plan.
- [ ] Closed finding-code allowlist is empty.
- [ ] Unknown action, severity, code, version, classification or risk fails closed.
- [ ] Missing finding metadata or source-risk data is ineligible.

## Risk and history
- [ ] Every event/product/variation/product-semantics/identity risk is persisted from feed parsing through the exact hashed snapshot.
- [ ] Evaluator uses persisted truth and never transient WordPress responses.
- [ ] Every historical total is present and zero; warnings are empty; destinations resolve.
- [ ] Any affected historical order line remains manual.

## Versioning and durability
- [ ] Supported snapshot schema version and pinned policy version are required.
- [ ] Decision is unique for `(run_id, dry_run_hash, policy_version)`.
- [ ] Recovery lookup and durable once-only Apply enqueue key are database-indexed.
- [ ] Decision/enqueue/linkage failure is recoverable without duplicate Apply.
- [ ] Current 300-second Oban uniqueness is not the sole correctness mechanism.
- [ ] Audit failure prevents enqueue; stale hash cannot Apply.

## Modes and compatibility
- [ ] Global/source composition is deterministic and any disabled scope wins.
- [ ] Modes and source allowlist revalidate before enqueue and claim.
- [ ] Observation records only and never queues Apply.
- [ ] Human Apply and cancellation races retain existing atomic authority.
- [ ] Applier remains the sole automated catalogue writer.

## Evidence
- [ ] Tests cover every matrix/risk/history/version/origin/mode/race path.
- [ ] VS-26E.1 is described as isolated Railway staging evidence.
- [ ] JC-129 defines additional end-to-end canaries before production enablement.
