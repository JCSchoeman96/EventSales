# TOON Prompts — VS-26E.2

## Planning agent
Task: Plan a pure fail-closed policy over persisted dry-run truth using supported snapshot/policy versions, empty finding allowlist, complete risk proof and zero history.
Output: Tests-first implementation plan only.
Boundary: `update_metadata`, variations and history remain manual; Applier stays sole writer; no code or production action before JC-129 APPROVE and JC-130.

## Risk reviewer
Task: Verify deterministic propagation for every event, product, variation, semantic, identity and missing-risk class from feed parsing through hashed snapshot.
Output: Exact gaps and verdict.
Boundary: Never infer semantics from names or inspect transient WordPress data in policy.

## Policy reviewer
Task: Attack every action, version, finding, historical and unknown-input path.
Output: Findings and verdict.
Boundary: One unsafe input rejects the whole run; finding allowlist is empty; history must be zero.

## Concurrency reviewer
Task: Prove database-backed decision and enqueue uniqueness across retries, crashes and nodes.
Output: Required constraints, recovery states and tests.
Boundary: Current Oban uniqueness is not sole correctness; exact-hash claim remains authoritative.

## Activation reviewer
Task: Refresh exact main, reviewed policy/version/configuration and VS-26E.1 isolated-staging evidence.
Output: APPROVE / REFRESH REQUIRED / BLOCKED plus required end-to-end canaries.
Boundary: No implementation or production action.
