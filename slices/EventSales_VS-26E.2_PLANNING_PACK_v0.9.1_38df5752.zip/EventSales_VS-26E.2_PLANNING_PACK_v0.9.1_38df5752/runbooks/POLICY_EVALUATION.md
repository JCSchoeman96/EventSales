# Policy Evaluation Runbook

1. Reload the durable run, exact snapshot and persisted findings; never fetch WordPress data.
2. Verify `dry_run_ready`, exact run ID/hash, explicit origin, supported snapshot schema version and pinned policy version.
3. Validate complete persisted risk fields. Missing, unknown or unsupported data produces a bounded ineligible reason.
4. Require only supported additive actions. `update_metadata`, adoption, variations, unknown actions and any mixed unsafe plan are ineligible.
5. Require the empty initial finding allowlist: no info, warning or blocking findings; no unknown severity/code or missing metadata.
6. Require every historical total present and zero, warnings empty, all destinations resolved, and no unknown classification, unsupported order status or threshold error.
7. Produce a pure bounded decision and persist it idempotently under unique `(run_id, hash, policy_version)`.
8. Persist origin, modes, summaries, evaluated timestamp and enqueue state. Audit-write failure prevents enqueue.
9. Stop after recording in disabled or observation mode.
10. Immediately before enqueue, revalidate global/source modes and source allowlist; any disabled scope wins.
11. Use the durable once-only enqueue key and recoverable state machine to queue the existing exact-hash Apply worker and link its job.
12. At Apply claim, revalidate modes/allowlist again or use an equivalent independently reviewed claim guard.
13. Never mutate catalogue truth outside the existing Applier. Human Apply remains unchanged.
