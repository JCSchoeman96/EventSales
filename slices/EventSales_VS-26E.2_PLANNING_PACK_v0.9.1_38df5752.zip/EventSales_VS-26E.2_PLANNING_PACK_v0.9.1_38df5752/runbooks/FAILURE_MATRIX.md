# Failure Matrix

| Failure | Durable behavior | Automation result |
|---|---|---|
| unsupported/missing snapshot or policy version | bounded reason | ineligible |
| unknown/missing action, finding, metadata, risk or historical classification | bounded reason | ineligible |
| any finding or affected historical row | bounded reason | ineligible; Human Apply unchanged |
| unresolved destination, missing totals, unsupported order status or threshold parse failure | bounded reason | ineligible |
| duplicate evaluator | return same unique decision | no duplicate decision/job |
| decision/audit write failure | no enqueue | recoverable error |
| Apply enqueue or linkage failure | durable recovery state | retry without duplicate job |
| duplicate Apply insertion attempt | durable once-only key wins | one job maximum |
| hash/status changed or manual cancellation/Apply wins | existing atomic claim wins | no automated mutation |
| source/global disabled before enqueue or claim | bounded reason/state | no automated mutation |
| policy exception | safe durable error where possible | no enqueue |
| observation mode | persist decision only | no enqueue or catalogue mutation |
| post-commit PubSub/cache failure | durable truth retained | bounded recovery/notification failure |

The current 300-second Oban uniqueness is defense in depth only, never the sole duplicate-prevention mechanism.
