# Rollout Plan

1. Deploy decision/audit/evaluator disabled after all implementation gates.
2. Verify supported versions, migrations, constraints, indexes and both enqueue/claim kill-switch guards.
3. Enable observation for one isolated source; persist decisions but never enqueue Apply.
4. Compare decisions with Human Apply outcomes and reject any unsafe eligibility.
5. Run multiple ineligible canaries for findings, risks, variations, unknowns and historical rows.
6. With explicit approval, enable one additive published simple-product zero-history canary.
7. Verify one decision, one Apply job, exact-hash claim and no unrelated mutation.
8. Disable globally and per source; prove Human Apply remains available.
9. Widen only by explicit approval and pinned policy version.

VS-26E.1 passed at `149816a69728b6d09be53275aa6255f4f2e1b0d6`, but its lifecycle evidence was obtained in isolated Railway staging, not through an actual production WordPress lifecycle mutation. JC-129 must specify additional end-to-end canary evidence before production auto-Apply enablement.
