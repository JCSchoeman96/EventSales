# Rollback and Stop Conditions

Kill switches are global disabled, source disabled, observation mode, source allowlist removal and policy-version disable. Any disabled scope wins and must be revalidated before enqueue and Apply claim. Disabling automation must not disable Human Apply.

Stop immediately when:

- `update_metadata`, a variation, a finding or any historical row becomes automatically eligible;
- missing/unknown risk, finding, action, history or version defaults safe;
- duplicate decisions or Apply jobs are possible across retries/nodes;
- correctness relies only on process state or Oban uniqueness;
- stale hash, cancellation, source disable or mode disable is bypassed;
- observation queues Apply or mutates catalogue truth;
- a parallel catalogue writer appears or Human Apply changes;
- unbounded queries, raw protected payloads, PII or secrets appear.

Disable automated queueing first. Preserve durable decisions and runs for audit and recovery.
