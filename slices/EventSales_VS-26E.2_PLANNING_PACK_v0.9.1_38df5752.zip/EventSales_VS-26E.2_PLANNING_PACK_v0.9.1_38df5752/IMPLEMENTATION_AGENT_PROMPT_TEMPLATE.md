# Implementation Agent Prompt Template — VS-26E.2

**Template only. Do not use until JC-129 returns APPROVE and JC-130 authorises implementation.**

Fill from the independently reviewed plan and activation supplement:

- exact activated main SHA;
- snapshot schema and policy versions;
- exact action, empty/closed finding and source-risk matrices;
- zero-history contract;
- explicit origins and deterministic modes;
- exact durable decision/enqueue state, migrations, constraints and indexes;
- exact files and tests-first sequence;
- rollout, evidence, exclusions and stop conditions.

Preserve the existing Applier as sole automated writer and Human Apply unchanged. Implement only activated scope, open a PR and stop before merge or deployment.
