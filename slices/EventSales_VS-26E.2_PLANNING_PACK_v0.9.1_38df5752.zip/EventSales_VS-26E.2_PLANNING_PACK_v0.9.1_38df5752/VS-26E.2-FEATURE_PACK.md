# VS-26E.2 — Conservative Catalog Auto-Apply

## Outcome and authority

A low-risk, explicit automation-origin Catalog Sync dry-run is evaluated by a pure, deterministic, versioned and fail-closed policy. When and only when eligibility is proven, orchestration queues the existing exact-hash Apply worker once. This pack has no execution authority; implementation remains locked through JC-129 and JC-130.

Initial v1 auto-Apply is limited to additive, published, simple-product changes with complete persisted risk proof, supported snapshot and policy versions, no findings and zero historical impact. Risky runs remain ready for Human Apply when existing Apply rules permit it.

## Current repository truth

The existing `EventSales.Catalog.TickeraCatalog.Applier` requires `dry_run_ready`, validates the exact durable hash, rejects blocking findings, atomically claims the run, writes Event, TicketType and ProductMapping changes transactionally, marks the run applied, then performs cache, PubSub and recovery work after commit. It remains the sole automated catalogue writer.

Current actions are Event `create | reuse | update_metadata | adopt_existing`, TicketType `create | reuse | adopt_existing`, and ProductMapping `create`. Any other ProductMapping action is unsupported and fails closed.

Current findings include `duplicate_meta_collapsed`, `variation_mapping_required`, `ambiguous_variation_ticket_type_name`, `duplicate_ticket_type_name`, `private_event_skipped`, `draft_event_skipped`, `published_event_without_ticket_products`, `existing_mapping_conflict`, `existing_mapping_adopted` and the special-case `vwg_pretoria_preserved`.

Current gaps are explicit run origin, snapshot schema version, durable policy decision/audit state, database-enforced enqueue idempotency, and complete propagation of WordPress `requires_review`, `review_reasons`, statuses and product semantics into persisted dry-run truth.

## Exact initial-v1 boundary

- Event `create` is only a candidate with complete published simple-source proof, supported versions, no findings and zero history.
- Event `reuse` is only a candidate with exact identity, exact event membership, no mutation and complete risk proof.
- Event `update_metadata` and `adopt_existing` are manual.
- TicketType `create` and `reuse` require complete proof; `adopt_existing` is manual.
- ProductMapping `create` requires no conflict, movement, variation, finding or history.
- Unknown and unsupported actions are ineligible.
- Variations are always manual.
- One disallowed action makes the entire run ineligible; mixed plans are never partially applied.

The initial finding-code allowlist is empty. Any info, warning or blocking finding is ineligible. Unknown severity/code and missing finding metadata are ineligible. `duplicate_meta_collapsed` remains ineligible unless a later reviewed policy proves identical identity, event membership, values, status, risk metadata and product semantics with repository evidence and tests.

## Persisted source-risk contract

The feed parser, DiscoveryResult, Normalizer, persisted findings and exact hashed snapshot must carry deterministic representations for:

- private, draft, trashed and deleted events;
- private, draft, trashed and deleted products;
- private and draft variations, variation mapping required, and ambiguous variation name;
- subscription, payment plan, membership, bundle, add-on, unsupported product type, missing ticket template and unknown product semantics;
- duplicate ticket name, existing mapping conflict, product moved between events, ambiguous identity and missing source-risk data.

Missing fields are not safe values. Missing, unknown or unsupported risk data creates an explicit ineligible reason. Product semantics must use deterministic source fields and reviewed reason codes, never display names. The evaluator uses persisted dry-run truth only and must not fetch or inspect transient WordPress responses.

## Versioned policy and snapshot

Eligibility requires a supported snapshot schema version, pinned policy version, exact run ID and exact durable dry-run hash. A decision is evaluated against that exact combination. Missing or unsupported versions fail closed. Configuration or policy changes cannot make an old decision eligible; explicit reevaluation of the same run/hash under a new policy version is required.

The pure policy returns an eligible, ineligible or error result with bounded reason codes. It cannot apply, enqueue, call WooCommerce, publish events or mutate caches.

## Zero historical impact

Initial v1 requires:

```text
affected_pending_lines = 0
affected_quantity = 0
eligible_lines = 0
deferred_lines = 0
conflicting_lines = 0
already_mapped_lines = 0
warnings = []
all destinations resolved
```

Unknown classification, missing totals, unsupported order status, threshold parsing failure or unresolved destination is ineligible. Any affected historical order line makes the run manual. Bounded non-zero history is reserved for a later separately reviewed policy version.

## Durable decision and enqueue

JC-127 must justify a dedicated decision resource versus extending the run. Durable state must contain run ID, exact hash, snapshot schema version, policy version, result, bounded reasons, finding/action/history summaries, explicit origin, evaluated global/source modes, evaluated timestamp, enqueue state and Apply job linkage.

Database invariants must include unique `(run_id, dry_run_hash, policy_version)`, indexed recovery by decision/enqueue state and timestamp, and a durable once-only Apply enqueue key. The decision-write/enqueue/linkage state machine must recover without duplicates. Correctness must not depend on process-local state or the current 300-second Oban uniqueness.

Audit-write failure prevents enqueue. Duplicate evaluation returns the same durable decision. Enqueue failure is recoverable without duplicate Apply. Manual cancellation and Human Apply retain authority through existing atomic claims. Stale hashes cannot Apply.

## Origin and modes

Origin is explicit and durable; never infer eligibility from a nil user ID. Initial v1 normally permits only `targeted_trigger`.

Global modes are `disabled | observe | enabled`. Source modes are `inherit | disabled | observe | enabled`. Composition is deterministic and any disabled scope wins. Mode and source allowlist are revalidated immediately before Apply enqueue and again at the existing Apply claim boundary or an equivalent reviewed guard.

Observation persists the durable decision but never queues Apply or mutates catalogue truth. Disabling automation never disables Human Apply.

## Scheduling, performance and notifications

Evaluation occurs after durable dry-run readiness or through an indexed bounded recovery sweep. Postgres is truth, Oban is bounded execution, PubSub follows durable transitions, and Cache/ETS/Redis are read acceleration only. No LiveView polling, full-table scan, unbounded historical load, new GenServer authority or evaluator/UI/WooCommerce call is permitted.

## Rollout and evidence

Roll out disabled, then observation for one source, compare decisions with Human Apply outcomes, run one isolated additive zero-history canary and multiple rejected-risk canaries, verify kill switches, then widen only by explicit approval.

VS-26E.1 passed at serving commit `149816a69728b6d09be53275aa6255f4f2e1b0d6`: signed receiver protocol, durable duplicate handling and payload immutability passed; generation reached 2; dispatcher, Catalog Sync and Apply activity remained 0; final feature flags were disabled; production mutations were 0. This evidence came from isolated Railway staging, not an actual production WordPress lifecycle mutation. JC-129 decides additional end-to-end canary evidence before production auto-Apply enablement.

## Tests-first requirements

Plan tests for every action, every risk, empty finding allowlist, unknown inputs, zero-history fields, supported/unsupported versions, origins and mode composition, durable decision uniqueness, enqueue recovery, duplicate evaluator, stale hash, cancellation/Human Apply races, observation, PubSub, admin explanation and kill switches. Full CI remains an implementation gate.

## Non-goals

No periodic reconciliation, order catch-up, parallel catalogue writer, manual-run auto-Apply, variation/private/draft/deletion/special-product auto-Apply, runtime configuration change or implementation work is authorised by this pack.
