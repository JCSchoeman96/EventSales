# Planning Agent Prompt — VS-26E.2

Repository: `JCSchoeman96/EventSales`

Pack: `EventSales_VS-26E.2_PLANNING_PACK_v0.9.1_38df5752.zip`

Planning baseline: `38df57526370211482d1734d2fb32740ef43d081`

## Authorised phase

JC-127 repository reconnaissance and implementation planning only. Do not modify implementation files, migrate, configure, queue work, commit implementation, deploy or access production systems. JC-129 APPROVE and JC-130 are required before implementation.

Refresh current repository truth and produce a tests-first plan that:

1. propagates the complete deterministic risk vocabulary from feed parsing through DiscoveryResult, Normalizer, findings and the exact hashed snapshot;
2. treats missing/unknown risk as ineligible and never inspects transient WordPress responses;
3. keeps `update_metadata`, adoption, variations and every affected historical order line manual in v1;
4. uses an empty closed finding-code allowlist;
5. requires supported snapshot schema and pinned policy versions;
6. records explicit durable origin;
7. designs durable decision state, database uniqueness and once-only Apply enqueue recovery without relying only on Oban uniqueness;
8. revalidates deterministic global/source modes before enqueue and claim;
9. preserves the existing Applier as sole automated writer and Human Apply unchanged;
10. specifies migrations, indexes, bounded queries, PubSub, observation, rollout, kill switches, exact tests and JC-129 evidence.

Finish with `PACK VALID`, `PACK REFRESH RECOMMENDED` or `PACK BLOCKED`, and confirm no prohibited action occurred.
